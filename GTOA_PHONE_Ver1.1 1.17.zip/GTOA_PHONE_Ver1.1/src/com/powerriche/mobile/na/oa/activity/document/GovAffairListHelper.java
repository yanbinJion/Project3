package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Message;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.activity.adapter.GovAffairListAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshSwipeMenuListView;
import com.powerriche.mobile.na.oa.bean.GovAffairInfo;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 领导政务管理
 * @author  Fitz
 * @date    2015年4月28日
 * @version v1.0
 */
public class GovAffairListHelper implements onSearchListener  {

	private Context context;
	
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;

	private GovAffairListAdapter adapter = null;
	
	private PullToRefreshSwipeMenuListView pullView;	//政务listView
	private SwipeMenuListView mListViewGov;
	
	private PullToRefreshListView pullViewLeader;		//领导listView
	private ListView listViewLeader;
	
	private TextView tvNoDataMsg;
	
	private int pageIndex = 1;
	
	private List<GovAffairInfo> dataList;
	private List<ResultItem> allResultItems = new ArrayList<ResultItem>();
	
	private int searchState = Constants.GOVAFFAIR_STATE_DEFAULT;
	
	private SearchBarWidget mSearchBarWidget;
	private SearchBarWidget mSearchBarWidgetLeader;

	private String searchText;
	
	public GovAffairListHelper(Context context, IRequestCallBack callBack, InvokeHelper helper, SwipeMenuListView swipeMenuListView, TextView tvNoDataMsg,
			PullToRefreshSwipeMenuListView pullView, PullToRefreshListView pullViewLeader, ListView listViewLeader, 
			SearchBarWidget searchBarWidgetGov, SearchBarWidget searchBarWidgetLeader){
		this.context = context;
		this.callBack = callBack;
		this.tvNoDataMsg = tvNoDataMsg;
		this.helper = helper;

		this.mListViewGov = swipeMenuListView;
		this.pullView = pullView;
		
		this.pullViewLeader = pullViewLeader;
		this.listViewLeader = listViewLeader;
		
		adapter = new GovAffairListAdapter(this.context, this);
		this.mListViewGov.setAdapter(adapter);
		this.listViewLeader.setAdapter(adapter);
		
		mSearchBarWidget = searchBarWidgetGov;
		mSearchBarWidget.setOnSearchListener(this);
		
		mSearchBarWidgetLeader = searchBarWidgetLeader;
		mSearchBarWidgetLeader.setOnSearchListener(this);
	}
	
	
	public void loadData(int state, int pageIndex,boolean isDialog){
		this.pageIndex = pageIndex;
		searchState = state;
		//[0:按政务查询，1：按领导查询]
        ApiRequest request = OAServicesHandler.getGovAffairList(state, pageIndex);
        if (request != null){
        	if(isDialog){
        		helper.invokeWidthDialog(request, callBack);
        	}else{
        		helper.invoke(request, callBack);
        	}
        }
    }
	
	public void deleteData(int position, int what){
		GovAffairInfo bean = adapter.getGovAffairInfo(position);
		ApiRequest request = OAServicesHandler.deleteGovAffair(bean.getAffairId());
		
	    if (request != null){
	    	Message msg = new Message();
	    	msg.what = position;
	    	callBack.handleMessage(msg, what);
	    	helper.invokeWidthDialog(request, callBack, what);
	    }
	}
	
	public void deleteBack(HttpResponse response, int position){
		ResultItem item = response.getResultItem(ResultItem.class);
		if(!BeanUtils.isEmpty(item)){
			String code = item.getString("code");
			// 操作成功
			if (Constants.SUCCESS_CODE.equals(code)) {
				adapter.removeData(position);
				adapter.notifyDataSetChanged();
			}else{
				String message = item.getString("message");
				UIHelper.showMessage(context, message);
				return;
			}
		}
	}
	
	
	public void process(HttpResponse response, int what){
			if(pageIndex <= 1){
				allResultItems.clear();
			}
			
			boolean hasMoreData = false;
			List<ResultItem> resultItems = response.getResultItem(ResultItem.class).getItems("data");
			
			if(resultItems != null && resultItems.size() >0){
				allResultItems.addAll(resultItems);
				 dataList = getGovAffairData(resultItems);
				if(dataList!=null && dataList.size()>0){
					if(pageIndex <= 1){
						adapter.clearListData();
					}
					adapter.addData(dataList,searchState,searchText);
					adapter.notifyDataSetChanged();
					hasMoreData = true;
				}
			}
			
			if(searchState == Constants.GOVAFFAIR_STATE_DEFAULT){	//政务查询
				pullView.onPullDownRefreshComplete();
				pullView.onPullUpRefreshComplete();
				pullView.setHasMoreData(hasMoreData);
				pullView.setVisibility(View.VISIBLE);
				pullViewLeader.setVisibility(View.GONE);
				
			}else{	//领导查询
				pullViewLeader.onPullDownRefreshComplete();
				pullViewLeader.onPullUpRefreshComplete();
				pullViewLeader.setHasMoreData(hasMoreData);
				pullView.setVisibility(View.GONE);
				pullViewLeader.setVisibility(View.VISIBLE);
			}
			
			
			if(pageIndex==1 && (BeanUtils.isEmpty(resultItems) || resultItems.size()==0)){
				if(searchState == Constants.GOVAFFAIR_STATE_DEFAULT){
					pullView.setVisibility(View.GONE);
				}else{
					pullViewLeader.setVisibility(View.GONE);
				}
				tvNoDataMsg.setVisibility(View.VISIBLE);
				
			}else{
				if(searchState == Constants.GOVAFFAIR_STATE_DEFAULT){
					pullView.setVisibility(View.VISIBLE);
				}else{
					pullViewLeader.setVisibility(View.VISIBLE);
				}
				tvNoDataMsg.setVisibility(View.GONE);
			}
    }
	
	
	/**
	 * 解析请求的网络数据
	 * @param items
	 * @return
	 */
	List<GovAffairInfo> getGovAffairData(List<ResultItem> items){
		
		List<GovAffairInfo> dataList = new ArrayList<GovAffairInfo>();
		int size = items.size();
		for(int i=0; i<size; i++){
			ResultItem item = items.get(i);
			GovAffairInfo bean = new GovAffairInfo();
			bean.setAffairContent(item.getString("AFFAIR_CONTENT"));
			bean.setAffairId(item.getString("AFFAIR_ID"));
			bean.setBeginData(item.getString("BEGIN_DATE"));
			bean.setBeginTime(item.getString("BEGIN_TIME"));
			bean.setEndData(item.getString("END_DATE"));
			bean.setEndTime(item.getString("END_TIME"));
			bean.setLeaderName(item.getString("LEADER_NAME"));
			dataList.add(bean);
		}
		return dataList;
	}


	@Override
	public void onSearchChange(String search) {
		searchText = search;
		String fieldId = "AFFAIR_CONTENT";
		if(searchState == Constants.GOVAFFAIR_STATE_LEADER){
			fieldId = "LEADER_NAME";
		}
		if (allResultItems != null && allResultItems.size() > 0
				&& !BeanUtils.isEmpty(search)) {
			dataList = getGovAffairData(SearchUtils.filterResults(allResultItems,
					search, fieldId));
		} else {
			dataList = getGovAffairData(allResultItems);
		}

		if (adapter != null) {
			adapter.clearListData();
			adapter.addData(dataList,searchState,searchText);
			adapter.notifyDataSetChanged();
		}
		
	}
	
}
