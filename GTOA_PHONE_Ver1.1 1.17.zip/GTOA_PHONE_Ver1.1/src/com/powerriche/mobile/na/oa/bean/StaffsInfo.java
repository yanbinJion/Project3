package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 办理环节==>员工信息表
 * @author  Fitz
 * @date    2015年5月4日
 * @version v1.0
 */
public class StaffsInfo {

	private String fpuNo;	//到达的环节编号
	private String siteNo;	//到达的环节可选人员的部门编号
	private String siteName;	//到达的环节可选人员的部门名称
	private String staffNo;	//到达的环节可选人员的人员编号
	private String realName;	//到达的环节可选人员的人员姓名
	private String siteOrderNo;
	private String orderNo;
	private String dispOrder;
	
	
	private int status;	//选中状态 0未选择，1选中
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getStaffNo() {
		return staffNo;
	}
	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getSiteOrderNo() {
		return siteOrderNo;
	}
	public void setSiteOrderNo(String siteOrderNo) {
		this.siteOrderNo = siteOrderNo;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getFpuNo() {
		return fpuNo;
	}
	public void setFpuNo(String fpuNo) {
		this.fpuNo = fpuNo;
	}
	public String getDispOrder() {
		return dispOrder;
	}
	public void setDispOrder(String dispOrder) {
		this.dispOrder = dispOrder;
	}
	
	
}
