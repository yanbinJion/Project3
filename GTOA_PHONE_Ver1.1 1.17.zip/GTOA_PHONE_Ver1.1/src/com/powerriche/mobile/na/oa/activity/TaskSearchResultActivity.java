package com.powerriche.mobile.na.oa.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.common.TemperCache;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 16-5-9.
 */
public class TaskSearchResultActivity extends BaseActivity {

    private final String TAG = "TaskSearchResultActivity";

    private PullToRefreshListView listView;
    private ListView mListView;
    private TopActivity topActivity;
    private Button backBtn;

    private List<ResultItem> resultItems = new ArrayList<ResultItem>();

    private String searchTitle;
    private String searchNo;
    private String searchTime;
    private String searchDuring;
    private String searchStatus;
    private String beginTime;
    private String endTime;
    private String direct;

    private String directHint;

    private TextView tvNoDataMsg;
    private InvokeHelper helper;

    private ResultSimpleAdapter adapter;
    private int index = 1;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.task_search_result_layout);
        Intent intent = getIntent();
        searchTitle = intent.getStringExtra("taskTitle");
        searchNo = intent.getStringExtra("taskNo");
//        searchTime = intent.getStringExtra("taskTime");
        searchDuring = intent.getStringExtra("taskDuring");
        searchStatus = intent.getStringExtra("taskStatus");
        beginTime = intent.getStringExtra("beginTime");
        endTime = intent.getStringExtra("endTime");
        direct = intent.getStringExtra("taskDirect");
        //任务是否办结：0 表示未办结 -1 表示已办结
        if (!"0".equals(searchStatus)) {
            directHint = getString(R.string.query_task_finished);
        } else {
            directHint = getString(R.string.query_task_unfinish);
        }
        initView();
    }

    private void initView() {
        topActivity = (TopActivity) findViewById(R.id.top_activity);
        topActivity.setTopTitle(getString(R.string.menu_mytask));// 顶部栏的中间标题
        topActivity.setRightBtnVisibility(View.VISIBLE);// 隐藏右边按钮
        topActivity.setRightBtnVisibility(View.INVISIBLE);//显示右边按钮
        topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
        backBtn = topActivity.getBtnBack();

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        listView = (PullToRefreshListView) findViewById(R.id.my_task_pulllistview);
        mListView = listView.getRefreshableView();
        listView.setPullRefreshEnabled(true);
        listView.setPullLoadEnabled(false);
        listView.setScrollLoadEnabled(true);
        UIHelper.setListViewAttribute(mListView);

        listView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
                index = 1;
                loadData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
                index = index + 1;
                loadData();
            }
        });
        tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
        tvNoDataMsg.setVisibility(View.GONE);
        mListView.setDivider(null);
        mListView.setCacheColorHint(Color.TRANSPARENT);
        mListView.setFadingEdgeLength(0);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
                int resultItemIndex = position;
//                if(resultItemIndex == 0 && (R.id.layout_search_bar_top == mListView.getChildAt(0).getId())){
//                    return;//跳过：被单击的是搜索栏
//                }else{
//                    resultItemIndex = resultItemIndex - 1;
//                }

                ResultItem item = resultItems.get(resultItemIndex);
                if(item == null){
                    return;//空
                }
                //这里进入详情界面
                String streamId = item.getString("WF_NO");
                String taskId = item.getString("TASK_ID");
                String swfNo = item.getString("SWF_NO");
                String traceNo = item.getString("TRACE_NO");
                String fpuNo = item.getString("FPU_NO");
                if (null == streamId || streamId.length() <= 0) {
                    return;
                }
                //这里进入详情界面
                Bundle data = new Bundle();
                data.putString("taskId", taskId);
                data.putString("swfNo", swfNo);
                data.putString("wfNo", streamId);
                data.putString("traceNo", traceNo);
                data.putString("fpuNo", fpuNo);
                data.putBoolean("isComplete", !"0".equals(searchStatus));
                //发送的任务是可以编辑的
                data.putBoolean("editable", "0".equals(direct));
                UIHelper.forwardTargetActivity(TaskSearchResultActivity.this, MTaskDetailActivity.class, data, false);
            }
        });
        loadData();
//        process();
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            if (index == 1) {
                resultItems.clear();// 清除
            }
            List<ResultItem> result = response.getResultItem(ResultItem.class).getItems("data");
//        List<ResultItem> result = new ArrayList<ResultItem>();
            if (!BeanUtils.isEmpty(result)) {
                resultItems.addAll(result);
            }
            if (BeanUtils.isEmpty(result)) {
                tvNoDataMsg.setVisibility(View.VISIBLE);
            } else {
                tvNoDataMsg.setVisibility(View.GONE);
            }
            if (null == adapter) {
                int[] txtids = null;
                String[] keys = new String[]{"TASK_TITLE", "TASK_STATE", "SEND_TIME"};

                // AndroidUI的组件ID
                txtids = new int[]{R.id.list_item_text_field,
                        R.id.list_item_text_field1, R.id.list_item_text_field2};
                keys = new String[]{"TASK_TITLE", "TASK_STATE", "SEND_TIME"};

                adapter = new ResultSimpleAdapter(TaskSearchResultActivity.this, resultItems, R.layout.list_item_gwgl, keys, txtids);
                adapter.setHelper(new ResultSimpleAdapter.ISimpleAdapterHelper() {
                    @Override
                    public Object parseValue(Object currentobj, List<?> items,
                                             int position, String key, View view) {
                        try {
                        ResultItem item = resultItems.get(position);
                        String systemtime = item.getString("SYSTEM_TIME");// 系统时间
                        if ("SEND_TIME".equals(key) && currentobj != null) {
                        	DateUtils dateUtils = new DateUtils(TaskSearchResultActivity.this);
                            return dateUtils.diffFromToNow(DateUtils.parseDate(currentobj.toString()), systemtime);
                        } else if ("TASK_STATE".equals(key) && currentobj != null) {
                            return directHint;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                        return (currentobj == null || "null".equals(currentobj
                                .toString().toLowerCase())) ? "" : currentobj;
                    }

                    @Override
                    public void apply(View convertView, Object obj, int position) {
                        // 如果有搜索关键字，高亮显示
                        if (!BeanUtils.isEmpty(searchTitle)) {
                            TextView textView = (TextView) convertView
                                    .findViewById(R.id.list_item_text_field);
                            SearchUtils.spannableResultItems(textView,
                                    (String) textView.getText(), searchTitle);
                        }
                    }
                });
                mListView.setAdapter(adapter);
            } else {
                adapter.notifyDataSetChanged();
            }

            /**
             * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
             */
            if (BeanUtils.isEmpty(result) || result.size() < Constants.COMMON_PAGE_SIZE) {
                // 已经全部加载完成，关闭UI组件的下拉加载更多功能
                listView.onPullDownRefreshComplete();
                listView.onPullUpRefreshComplete();
                listView.setHasMoreData(false);

                if(index ==1 && (BeanUtils.isEmpty(result) || result.size()==0)){
//                    listView.setVisibility(View.GONE);
                    tvNoDataMsg.setVisibility(View.VISIBLE);
                    listView.getFooterLoadingLayout().show(false);
                }else{
                    listView.setVisibility(View.VISIBLE);
                    tvNoDataMsg.setVisibility(View.GONE);
                }

            } else {
                // 还有更多数据，继续打开“下拉加载更多”功能
                listView.onPullDownRefreshComplete();
                listView.onPullUpRefreshComplete();
                listView.setHasMoreData(true);
                listView.setVisibility(View.VISIBLE);
                tvNoDataMsg.setVisibility(View.GONE);
            }
        }
    };

    private void loadData() {
        helper = new InvokeHelper(this);
        ApiRequest request = OAServicesHandler.searchTask(searchNo, searchTitle, beginTime, endTime, direct, searchDuring, searchStatus, index);
        request.setMessage(getString(R.string.system_load_message));
        helper.invokeWidthDialog(request, callBack);
    }

    //根据搜索条件过滤数据
    private void filterList() {
        List<ResultItem> results = TemperCache.getInstance().getTaskList();
        if (!BeanUtils.isEmpty(results)) {
            String[] keys = new String[] {"TASK_TITLE", "TASK_ID", "SEND_TIME", "TASK_STATE"};
            boolean[] values = new boolean[] {!BeanUtils.isNullOrEmpty(searchTitle) ? true : false,
                    !BeanUtils.isNullOrEmpty(searchNo) ? true : false, !BeanUtils.isNullOrEmpty(searchTime) ? true : false,
                    !BeanUtils.isNullOrEmpty(searchDuring) ? true : false};
            String[] list = new String[]{searchTitle, searchNo, searchTime, searchDuring};
            String temp = null;
            boolean isContain = true;
            for (ResultItem item : results) {
                isContain = true;
                for (int i = 0; i < keys.length; i++) {
                    if (values[i]) {
                        temp = item.getString(keys[i]);
                        if (!(!BeanUtils.isNullOrEmpty(temp) && temp.contains(list[i]))) {
                            isContain = false;
                            break;
                        }
                    }
                }
                if (isContain) {
                    resultItems.add(item);
                }
            }
        }
    }
}
