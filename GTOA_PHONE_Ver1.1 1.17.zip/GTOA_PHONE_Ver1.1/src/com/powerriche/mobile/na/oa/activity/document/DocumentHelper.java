package com.powerriche.mobile.na.oa.activity.document;

import android.content.Context;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.tools.HtmlDocument;

/**
 * Filename		: DocumentHelper.java
 * @Description	:
 * @Author		: 刘剑
 * @Version		: 1.0
 * @Date	    :2012-06-04 下午09:38:24
 */
public class DocumentHelper {
	
	
	public static String getDcoumentHtmlInfo(Context context,ResultItem item,boolean flag){
		HtmlDocument document = new HtmlDocument();
		document.addHeader().addBody().addTable();
		document.addTableLabelItem(context.getString(R.string.system_document_item_title), item.getString("TITLE"));
		document.addTableLabelItem(context.getString(R.string.system_document_item_lwdw), item.getString("SOURCE_ORG_ID"));
		document.addTableLabelItem(context.getString(R.string.system_document_item_lwrq), item.getString("RECEIVE_DATE"));
		document.addTableLabelItem(context.getString(R.string.system_document_item_lwzh), item.getString("DISTRIBUTE_CHARACTERS"));
		document.addTableLabelItem(context.getString(R.string.system_document_item_hj), getHj(item.getInt("URGENCY_DEGREE")));
		document.addTableLabelItem(context.getString(R.string.system_document_item_mj), getMj(item.getInt("IMPORTANCE_DEGREE")));
		document.addTableLabelItem(context.getString(R.string.system_document_item_ztc), item.getString("SUBJECT"));
		document.addTableLabelItem(context.getString(R.string.system_document_item_zy), item.getString("SUMMARY"));
		if(flag){
			document.addTableSingleItem(item.getString("DOCUMENT_CONTENT"));
		}
		document.endTable().addFooter();
		return document.toHtmlString();
	}
	
	/**获取缓急*/
	public static String getHj(int flag){
		switch (flag) {
			case 1:
				return SystemContext.getContext().getString(R.string.document_hj_1);
			case 2:
				return SystemContext.getContext().getString(R.string.document_hj_2);
			case 3:
				return SystemContext.getContext().getString(R.string.document_hj_3);
			case 4:
				return SystemContext.getContext().getString(R.string.document_hj_4);
			case 5:
				return SystemContext.getContext().getString(R.string.document_hj_5);
			case 6:
				return SystemContext.getContext().getString(R.string.document_hj_6);
			default:
				break;
		}
		return "";
	}
	
	/**获取密级*/
	public static String getMj(int flag){
		switch (flag) {
			case 1:
				return SystemContext.getContext().getString(R.string.document_mj_1);
			case 2:
				return SystemContext.getContext().getString(R.string.document_mj_2);
			case 3:
				return SystemContext.getContext().getString(R.string.document_mj_3);
			case 4:
				return SystemContext.getContext().getString(R.string.document_mj_4);
			case 5:
				return SystemContext.getContext().getString(R.string.document_mj_5);
			case 6:
				return SystemContext.getContext().getString(R.string.document_mj_6);
			default:
				break;
		}
		return "";
	}
}
