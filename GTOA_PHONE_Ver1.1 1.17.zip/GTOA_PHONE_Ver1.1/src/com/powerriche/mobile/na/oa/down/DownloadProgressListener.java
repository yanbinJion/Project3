package com.powerriche.mobile.na.oa.down;

/**
 * 类描述：<br>
 * 下载进度监听器
 * @author Alex
 * @date 2013-12-13
 */
public interface DownloadProgressListener {
	public void onDownloadSize(int size);
}
