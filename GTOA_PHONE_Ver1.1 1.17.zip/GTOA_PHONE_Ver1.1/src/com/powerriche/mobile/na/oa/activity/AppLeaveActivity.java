package com.powerriche.mobile.na.oa.activity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.annotation.SuppressLint;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.MyViewPagerAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.LeaveWaitListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
/** 
 * @title  请假申请
 * @author dir_wang
 * @date   2016-7-11上午11:16:42
 */ 
@SuppressLint("SimpleDateFormat")
public class AppLeaveActivity extends BaseActivity implements
		View.OnClickListener {
	private TopActivity topActivity;
	private TextView leaveWait, leaveQuery;
	
    private ViewPager mViewPager;
    private ImageView imageView;// 动画图片
    
    private View view1, view2;
    
    private List<View> views;// Tab页面列表
    private int offset = 0;// 动画图片偏移量
    private int currIndex = 0;// 当前页卡编号
    private int bmpW;// 动画图片宽度
    
    private PullToRefreshListView lv_apply_wait;
    private ListView listView;
    private TextView tvNoDataMsg;
    
    private Button applyQueryBtn;
    private EditText et_apply_begin_time;
    private EditText et_apply_end_time;
    private RadioGroup rg_apply_handle;
    private RadioGroup rg_apply_pass;
    private SearchBarWidget searchTitle;
    private String applyHandle;
    private String applyPass;
    
    private RadioButton rb_apply_query;
    private RadioButton rb_apply_wait;
    private RadioButton rb_apply_finished;
    private RadioButton rb_apply_complete;
    private RadioButton rb_apply_all;
    private RadioButton rb_applying;
    private RadioButton rb_apply_pass;
    private RadioButton rb_apply_refuse;
    private LeaveWaitListHelper leaveWaitListHelper;
    private LinearLayout ll_apply;
	private LinearLayout ll_leave;
	private LinearLayout ll_title;
	private LinearLayout ll_leave_type;
	private TextView tv_leave_type;
	
    //设置radiogroup的监听事件
    private RadioGroup.OnCheckedChangeListener changeListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int id) {
            if (radioGroup == rg_apply_handle) {
                if (id == rb_apply_query.getId()) {
                	applyHandle = rb_apply_query.getTag().toString();
                	System.out.println(applyHandle);
                } else if (id == rb_apply_wait.getId()) {
                	applyHandle = rb_apply_wait.getTag().toString();
                	System.out.println(applyHandle);
                } else if (id == rb_apply_finished.getId()){
                	applyHandle = rb_apply_finished.getTag().toString();
                	System.out.println(applyHandle);
                } else {
                	applyHandle = rb_apply_complete.getTag().toString();
                	System.out.println(applyHandle);
                }
            } else if (radioGroup == rg_apply_pass) {
                if (id == rb_apply_all.getId()) {
                    applyPass = rb_apply_all.getTag().toString();
                    System.out.println(applyPass);
                } else if (id == rb_applying.getId()){
                	applyPass = rb_applying.getTag().toString();
                	System.out.println(applyPass);
                } else if (id == rb_apply_pass.getId()){
                	applyPass = rb_apply_pass.getTag().toString();
                	System.out.println(applyPass);
                } else {
                	applyPass = rb_apply_refuse.getTag().toString();
                	System.out.println(applyPass);
                }	
            }	
        }	
    };	
    	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.apply_manage);
		initView();
		initImageView();
	    initViewPager();
	    initReceiverView();
	}	
		
	@Override
	protected void onResume() {
		super.onResume();
		if(leaveWaitListHelper == null) {
			initReceiverView();
			return;
		}
		loadData();
	}	
		
	// 初始化控件
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.menu_leave));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
		topActivity.setRightBtnOnClickListener(this);
		mViewPager = (ViewPager) findViewById(R.id.apply_viewpager);
		leaveWait = (TextView) findViewById(R.id.tv_leave_wait);
		leaveQuery = (TextView) findViewById(R.id.tv_leave_query);
		ll_apply = (LinearLayout) findViewById(R.id.ll_apply);
		ll_leave = (LinearLayout) findViewById(R.id.ll_leave);
		ll_apply.setVisibility(View.GONE);
		ll_leave.setVisibility(View.VISIBLE);
	}	
		
	/** 
	 * 初始化动画
	 */ 
	private void initImageView() {
        imageView = (ImageView) findViewById(R.id.cursor);
        bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度
        
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;// 获取分辨率宽度
        offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
        Matrix matrix = new Matrix();
        matrix.postTranslate(offset, 0);
        imageView.setImageMatrix(matrix);// 设置动画初始位置
    }	
		
	private void initViewPager() {
        views = new ArrayList<View>();
        LayoutInflater inflater = getLayoutInflater();
        
        view1 = inflater.inflate(R.layout.apply_wait_list, null);
        view2 = inflater.inflate(R.layout.apply_search, null);
        views.add(view1);
        views.add(view2);
        mViewPager.setAdapter(new MyViewPagerAdapter(views));
        mViewPager.setOnPageChangeListener(new MyOnPagerChangeListener());
        leaveWait.setOnClickListener(new MyOnClickListener(0));
        leaveQuery.setOnClickListener(new MyOnClickListener(1));
        
        applyQueryBtn = (Button) view2.findViewById(R.id.btn_apply_query);
        applyQueryBtn.setOnClickListener(this);
        et_apply_begin_time = (EditText) view2.findViewById(R.id.et_apply_begin_time);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -6);
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT);
        et_apply_begin_time.setText(sdf.format(calendar.getTime()));
        et_apply_begin_time.setOnClickListener(this);
        et_apply_end_time = (EditText) view2.findViewById(R.id.et_apply_end_time);
        
        et_apply_end_time.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT));
        et_apply_end_time.setOnClickListener(this);
        
        searchTitle = (SearchBarWidget) view2.findViewById(R.id.apply_query);
        rg_apply_handle = (RadioGroup) view2.findViewById(R.id.rg_apply_handle);
        rg_apply_pass = (RadioGroup) view2.findViewById(R.id.rg_apply_pass);
        searchTitle.getEditTextSearch().setHint(getString(R.string.common_search_hint));
        
        rb_apply_query = (RadioButton) view2.findViewById(R.id.rb_apply_query);
        rb_apply_wait = (RadioButton) view2.findViewById(R.id.rb_apply_wait);
        rb_apply_finished = (RadioButton) view2.findViewById(R.id.rb_apply_finished);
        rb_apply_complete = (RadioButton) view2.findViewById(R.id.rb_apply_complete);
        rb_apply_all = (RadioButton) view2.findViewById(R.id.rb_apply_all);
        rb_applying = (RadioButton) view2.findViewById(R.id.rb_applying);
        rb_apply_pass = (RadioButton) view2.findViewById(R.id.rb_apply_pass);
        rb_apply_refuse = (RadioButton) view2.findViewById(R.id.rb_apply_refuse);
        ll_title = (LinearLayout) view2.findViewById(R.id.ll_title);
        ll_leave_type = (LinearLayout) view2.findViewById(R.id.ll_leave_type);
        tv_leave_type = (TextView) view2.findViewById(R.id.tv_leave_type);
        ll_title.setVisibility(View.GONE);
        ll_leave_type.setVisibility(View.VISIBLE);
        tv_leave_type.setOnClickListener(this);
        tv_leave_type.setText(UIHelper.getQueryType(AppLeaveActivity.this,String.valueOf(tv_leave_type.getTag())));
        tv_leave_type.setTag(String.valueOf(tv_leave_type.getTag()));
        applyHandle = rb_apply_query.getTag().toString();
        applyPass = rb_apply_all.getTag().toString();
        rg_apply_handle.setOnCheckedChangeListener(changeListener);
        rg_apply_pass.setOnCheckedChangeListener(changeListener);
        
    }	
		
		
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			String code = resultItem.getString("code");
			String message = resultItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(AppLeaveActivity.this, message);
				return;
			}
			if(what == leave_request) {
				leaveWaitListHelper.process(response, what);
			}
			
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(AppLeaveActivity.this, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}	
			
		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}	
	};		
			
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			AppLeaveActivity.this.finish();
			break;
		case R.id.btn_top_right:
			UIHelper.forwardTargetActivity(AppLeaveActivity.this, LeaveAddActivity.class, null, false);
			break;
		case R.id.et_apply_begin_time:
			UIHelper.showTimeSelect(this, et_apply_begin_time, DateUtils.DATE_FORMAT);
			break;
		case R.id.et_apply_end_time:
			UIHelper.showTimeSelect(this, et_apply_end_time, DateUtils.DATE_FORMAT);
			break;
		case R.id.tv_leave_type:
			UIHelper.showQueryType(this, tv_leave_type);
			break;
		case R.id.btn_apply_query:
			Bundle data = new Bundle();
			data.putString("searchTitle", searchTitle.getEditTextSearch().getText().toString().trim());
			data.putString("applyType", tv_leave_type.getTag().toString().trim());
			data.putString("applyBeginTime", et_apply_begin_time.getText().toString().trim());
			data.putString("applyEndTime", et_apply_end_time.getText().toString().trim());
			data.putString("applyHandle", applyHandle);
			data.putString("applyPass", applyPass);
			UIHelper.forwardTargetActivity(AppLeaveActivity.this, LeaveQueryResultActivity.class, data, false);
			break;
		default:
			break;
		}
	}
	
	private void initReceiverView(){
		lv_apply_wait = (PullToRefreshListView) view1.findViewById(R.id.lv_apply_wait);
		lv_apply_wait.setPullRefreshEnabled(true);
		lv_apply_wait.setPullLoadEnabled(false);
		lv_apply_wait.setScrollLoadEnabled(true);
		
		listView = lv_apply_wait.getRefreshableView();
        UIHelper.setListViewAttribute(listView);
        
        lv_apply_wait.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
            	pageIndex = 1;
            	leaveWaitListHelper.loadData(leave_request, pageIndex, false);
            }
        
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
            	pageIndex = pageIndex + 1;
            	leaveWaitListHelper.loadData(leave_request, pageIndex, false);
            }
        });
        tvNoDataMsg = (TextView) view1.findViewById(R.id.tv_no_data_msg);
        tvNoDataMsg.setVisibility(View.GONE);
        
        View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
        listView.addHeaderView(header);
        leaveWaitListHelper = new LeaveWaitListHelper(this, header, tvNoDataMsg, lv_apply_wait, listView, callBack, helper);
    }	
		
	private int pageIndex = 1;
		
	int leave_request = 1000;
	private void loadData() {
		leaveWaitListHelper.loadData(leave_request, pageIndex, false);
	}	
		
	private class MyOnClickListener implements View.OnClickListener {
		
		private int index = 0;
		
		public MyOnClickListener(int index) {
			this.index = index;
		}
		
		@Override
		public void onClick(View v) {
			mViewPager.setCurrentItem(index);
		}
		
	}	
		
	private class MyOnPagerChangeListener implements ViewPager.OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量
		
		@Override
		public void onPageScrollStateChanged(int arg0) {
			
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			
		}
		
		@Override
		public void onPageSelected(int arg0) {
            Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);
            animation.setDuration(300);
            imageView.startAnimation(animation);
            if (currIndex == 0) {
            	leaveWait.setBackgroundResource(R.drawable.leave_wait_checked);
                leaveQuery.setBackgroundResource(R.drawable.leave_query_unchecked);
            } else if (currIndex == 1) {
            	leaveWait.setBackgroundResource(R.drawable.leave_wait_unchecked);
            	leaveQuery.setBackgroundResource(R.drawable.leave_query_checked);
            }
        }
	}
	
}
