package com.powerriche.mobile.na.oa.activity;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentPassreadChooseHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 传阅功能选人界面
 * @author  Fitz
 * @date    2015年5月13日
 * @version v1.0
 */
public class DocumentPassreadChooseActivity extends BaseActivity implements OnClickListener, ExpandableListView.OnChildClickListener, ExpandableListView.OnGroupClickListener {


	private Context mContext;
	private ExpandableListView	exListChoose;
	private DocumentPassreadChooseHelper chooseHelper;
	private TextView tvPeople;
	private Button btnSelectAll;
	
	private String documentId, wfNo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		UIHelper.hideTitle(this);
		setContentView(R.layout.document_passread_choose);

		documentId = getIntent().getStringExtra("documentId");
		wfNo = getIntent().getStringExtra("wfNo");
		
		bindView();
		loading();
	}

	private void bindView() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle("传阅选人");
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("确认");

		exListChoose = (ExpandableListView) findViewById(R.id.exList_choose);
		exListChoose.setGroupIndicator(null);//去掉圆形三角箭头
		exListChoose.setDivider(null);
		exListChoose.setCacheColorHint(Color.TRANSPARENT);
		exListChoose.setFadingEdgeLength(0);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.document_passread_choose_header, null);
		tvPeople = (TextView) header.findViewById(R.id.tv_people);
		tvPeople.setVisibility(View.GONE);
		btnSelectAll = (Button) header.findViewById(R.id.btn_all_select);
		btnSelectAll.setOnClickListener(this);
		
		exListChoose.addHeaderView(header);

		chooseHelper = new DocumentPassreadChooseHelper(mContext, callBack, exListChoose, tvPeople);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_back){
			finish();
			
		}else if(id == R.id.btn_top_right){
			returnResult();
			
		}else if(id == R.id.btn_all_select){	//全选操作
			if(btnSelectAll.isSelected()){
				btnSelectAll.setSelected(false);	//取消全选
				chooseHelper.selectAll(false);
			}else{
				btnSelectAll.setSelected(true);	//全选
				chooseHelper.selectAll(true);
			}
			
		}
	}

	private void loading() {
		chooseHelper.loadData();
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	private void closeActivity(){
		this.finish();
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == 0) {
					chooseHelper.process(response);
					
				}else if(what == 1860){
					int code = item.getInt("code");
					String message = item.getString("message");
					if(code==0){
						
					}
					UIHelper.showMessage(mContext, message);
					closeActivity();
				}
			}
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}
		
	};

	private void returnResult() {
		List<UserInfo> valueList = chooseHelper.getValueList();

		if (valueList == null || valueList.size()==0) {//一个都没有选中
			UIHelper.showMessage(mContext, "请至少选择一个人");
			return;
			
		} else {
			StringBuffer sbId = new StringBuffer();
			for (UserInfo user : valueList) {
				String userId = user.getStaffNo();
				sbId.append(userId.trim()).append(",");
			}
			String receiveStaffNo = sbId.substring(0, sbId.length()-1);
			//提交选人数据
			ApiRequest request = OAServicesHandler.sendPassRead(documentId, receiveStaffNo, "", wfNo, "");
			if (request != null) {
				request.setMessage(getString(R.string.system_commit_message));
				helper.invokeWidthDialog(request, callBack, 1860);
			}
		}
	}

	@Override
	public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
		if (parent.isGroupExpanded(groupPosition)) {
			parent.collapseGroup(groupPosition);//折叠：部门
		} else {
			parent.expandGroup(groupPosition);//展开：部门
		}
		return true;
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
		return true;
	}

}
