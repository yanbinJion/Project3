package com.powerriche.mobile.na.oa.activity;
	
import java.util.ArrayList;
import java.util.List;
	
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.TransactInfoAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.TransactSuggestionAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.ApplyParams;
import com.powerriche.mobile.na.oa.bean.LeaveDetail;
import com.powerriche.mobile.na.oa.bean.TransactInfo;
import com.powerriche.mobile.na.oa.bean.TransactSuggestion;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;
    
/** 
 * @title 请假申请详情
 * @author dir_wang
 * @date 2016-7-1上午9:37:36
 */ 
public class LeaveDetailActivity extends BaseActivity implements OnClickListener {
	
	public static final int CODE_BASIC = 0; // 任务信息
	private static LeaveDetailActivity instance;
	private Context mContext;
	
	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片
	
	private View view1, view2, view3;
	
	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	
	private Button btn_leave_send;
	
	private String leaveId;
	
	private Button rightBtn;
	
	private Button btn_leave_process;
	
	private static final int REQUEST_LEAVE_INFO = 0;
	private static final int REQUEST_LEAVE_PROCESS = 1;
	
	private LeaveDetail detail = new LeaveDetail();
	private MyViewPagerAdapter pagerAdapter;
	private TransactSuggestionAdapter suggestionAdapter;
	private TransactInfoAdapter infoAdapter;
	// 对应请假信息，办理信息
	private TextView tv1, tv2, tv3;
	// 详情中，如果没有进度详情，则显示这个
	private String swfNo, wfNo;
	private ListView lv_transact_suggestion;
	private ListView lv_transact_info;
	private TextView tv_no_data_suggestion;
	private TextView tv_no_data_info;
	
	/** 申请人 */
	private TextView leaveProposer;
	
	/** 当前状态 */
	private TextView leaveCurrentState;
	
	/** 请假类别 */
	private TextView leaveCatalog;
	
	/** 请假类型 */
	private TextView leaveType;
	
	/** 请假原因 */
	private TextView leaveReason;
	
	/** 年休假天数 */
	private TextView leaveYearDays;
	
	/** 请假申请开始时间 */
	private TextView beginTime;
	
	/** 请假申请结束时间 */
	private TextView endTime;
	
	/** 请假天数 */
	private TextView totalDays;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		instance = this;
		// 设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.leave_detail);
		
		Intent intent = getIntent();
		leaveId = intent.getStringExtra("documentId"); // 请假编号
		if (!BeanUtils.isNullOrEmpty(leaveId)) {
			leaveId = BeanUtils.floatToInt4Str(leaveId);
			detail.setLeaveId(String.valueOf(leaveId));
		}
		swfNo = intent.getStringExtra("swfNo");
		wfNo = intent.getStringExtra("wfNo");
		if (!BeanUtils.isNullOrEmpty(wfNo)) {
			wfNo = BeanUtils.floatToInt4Str(wfNo);
		}
		bindViews();
		
	}	
	@Override
	protected void onResume() {
		super.onResume();
		getLeaveDetails();
	}	
		
	// 获取请假详情
	private void getLeaveDetails() {
		ApiRequest request = OAServicesHandler.getLeaveDetails(leaveId);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, REQUEST_LEAVE_INFO);
		}
	}	
	// 请假办结
	private void processLeave() {
		ApiRequest request = OAServicesHandler.finishLeaveWorkFlow(leaveId);
		helper.invokeWidthDialog(request, callBack, REQUEST_LEAVE_PROCESS);
	}	
		
	// 显示请假信息
	private void showLeaveInfo(ResultItem result) {
		if (null == result) {
			return;
		}
		detail.setLeaveRealName(result.getString("APPLY_REALNAME"));
		String catalog = BeanUtils.floatToInt4Str(result.getString("LEAVE_CATALOG"));
		detail.setLeaveCatalog(catalog);
		String type = BeanUtils.floatToInt4Str(result.getString("LEAVE_TYPE"));
		detail.setLeaveType(type);
		detail.setLeaveReason(result.getString("LEAVE_REASON"));
		detail.setLeaveYearDays(result.getString("LEAVE_YEAR_DAYS"));
		detail.setBeginTime(result.getString("BEGIN_TIME"));
		detail.setEndTime(result.getString("END_TIME"));
		detail.setLeaveTotalDays(result.getString("LEAVE_TOTAL_DAYS"));
		detail.setIsLeavePass(BeanUtils.floatToInt4Str(result.getString("IS_LEAVE_PASS")));
		detail.setDestoryState(result.getString("DESTROY_STATE"));
		detail.setDestoryTime(result.getString("DESTORY_TIME"));
		detail.setResult(result.getString("RESULT"));
		detail.setFpuNo(result.getString("FPU_NO"));
		detail.setSaveButton(result.getString("DISPLAY_SAVE_BUTTON"));
		detail.setSendButton(result.getString("DISPLAY_SENDNEXT_BUTTON"));
		detail.setAgreeButton(result.getString("DISPLAY_AGREE_BUTTON"));
		detail.setRefuseButton(result.getString("DISPLAY_REFUSE_BUTTON"));
		detail.setDestoryButton(result.getString("DISPLAY_DESTROY_BUTTON"));
		detail.setFinishButton(result.getString("DISPLAY_FINISH_BUTTON"));
		leaveProposer.setText(detail.getLeaveRealName());
		String state = detail.getIsLeavePass();
		if (state.equals("0")) {
			leaveCurrentState.setText(R.string.applying);
			leaveCurrentState.setTextColor(Color.parseColor("#BDB76B"));
		} else if (state.equals("1")) {
			leaveCurrentState.setText(R.string.apply_pass);
			leaveCurrentState.setTextColor(Color.parseColor("#7CFC00"));
		} else {
			leaveCurrentState.setText(R.string.apply_refuse);
			leaveCurrentState.setTextColor(Color.parseColor("#FF2525"));
		}
		leaveCatalog.setText(UIHelper.getLeaveCatalog(mContext,detail.getLeaveCatalog()));
		leaveType.setText(UIHelper.getLeaveType(mContext,detail.getLeaveType()));
		leaveType.setTag(type);
		leaveReason.setText(detail.getLeaveReason());
		leaveYearDays.setText(detail.getLeaveYearDays() + "天");
		beginTime.setText(detail.getBeginTime());
		endTime.setText(detail.getEndTime());
		String leaveTotalDays = detail.getLeaveTotalDays();
		totalDays.setText(leaveTotalDays.endsWith(".0") ? leaveTotalDays.replace(".0", "") + "天" : leaveTotalDays + "天");
		List<ResultItem> processData = result.getItems("ProcessData");
		List<ResultItem> actionData = result.getItems("ActionData");
		if (!BeanUtils.isEmpty(detail)) {
			if (detail.getSendButton().equals("1")) {
				btn_leave_send.setVisibility(View.VISIBLE);
			} else {
				btn_leave_send.setVisibility(View.GONE);
			}
			if (detail.getSaveButton().equals("1")) {
				rightBtn.setVisibility(View.VISIBLE);
				rightBtn.setText("编辑");
			} else if (detail.getDestoryButton().equals("1")){
				rightBtn.setVisibility(View.VISIBLE);
				rightBtn.setText("销假");
			} else if (detail.getFinishButton().equals("1")) {
				rightBtn.setVisibility(View.VISIBLE);
				rightBtn.setText("办结");
			} else {
				rightBtn.setVisibility(View.GONE);
			}
			if (detail.getAgreeButton().equals("1")) {
				btn_leave_process.setVisibility(View.VISIBLE);
			} else {
				btn_leave_process.setVisibility(View.GONE);
			}
		}	
		// 办理意见
		if (!BeanUtils.isEmpty(processData)) {
			List<TransactSuggestion> transactSuggestions = new ArrayList<TransactSuggestion>();
			for (ResultItem item : processData) {
				TransactSuggestion suggestion = new TransactSuggestion();
				suggestion.setData(item.getString("DATA"));
				suggestion.setActionName(item.getString("ACTION_NAME"));
				suggestion.setProcessorDeptName(item.getString("PROCESSOR_DEPT_NAME"));
				suggestion.setProcessor(item.getString("PROCESSOR"));
				suggestion.setSaveDate(item.getString("SAVE_DATE"));
				transactSuggestions.add(suggestion);
			}
			detail.setSuggestion(transactSuggestions);
		}	
		// 办理信息
		if (!BeanUtils.isEmpty(actionData)) {
			List<TransactInfo> transactInfo = new ArrayList<TransactInfo>();
			for (ResultItem item : actionData) {
				TransactInfo info = new TransactInfo();
				info.setActionId(item.getString("ACTION_ID"));
				info.setProcessor(item.getString("PROCESSOR"));
				info.setAction(item.getString("ACTION"));
				info.setBeginTime(item.getString("BEGIN_TIME"));
				info.setEndTime(item.getString("END_TIME"));
				info.setReadTime(item.getString("READ_TIME"));
				info.setRemark(item.getString("REMARK"));
				transactInfo.add(info);
			}
			detail.setInfo(transactInfo);
		}	
	}		
			
	// 显示办理意见列表
	private void showTransactSuggestion() {
		if (BeanUtils.isEmpty(detail.getSuggestion())) {
			tv_no_data_suggestion.setVisibility(View.VISIBLE);
			return;
		}	
		tv_no_data_info.setVisibility(View.GONE);
		if (null == suggestionAdapter) {
			suggestionAdapter = new TransactSuggestionAdapter(this);
			suggestionAdapter.addData(detail.getSuggestion());
			lv_transact_suggestion.setAdapter(suggestionAdapter);
		} else {
			suggestionAdapter.clearListData();
			suggestionAdapter.addData(detail.getSuggestion());
			suggestionAdapter.notifyDataSetChanged();
		}	
	}		
			
			
	// 显示办理信息列表
	private void showTransactInfo() {
		if (BeanUtils.isEmpty(detail.getInfo())) {
			tv_no_data_info.setVisibility(View.VISIBLE);
			return;
		}	
		tv_no_data_info.setVisibility(View.GONE);
		if (null == infoAdapter) {
			infoAdapter = new TransactInfoAdapter(this);
			infoAdapter.addData(detail.getInfo());
			lv_transact_info.setAdapter(infoAdapter);
		} else {
			infoAdapter.clearListData();
			infoAdapter.addData(detail.getInfo());
			infoAdapter.notifyDataSetChanged();
		}	
	}		
			
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem reusltItem = response.getResultItem(ResultItem.class);
			if (!checkResult(reusltItem)) {
				return;
			}
			ResultItem result = null;
			String code = reusltItem.getString("code");
			String message = reusltItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(mContext, message);
				return;
			}
			result = (ResultItem) reusltItem.get("data");
			if (what == REQUEST_LEAVE_INFO) {
				showLeaveInfo(result);
			} else if (what == REQUEST_LEAVE_PROCESS) {
				UIHelper.showMessage(mContext, message);
				LeaveDetailActivity.this.finish();
			}
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			rightBtn.setClickable(true);
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			rightBtn.setClickable(true);
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};
	
	
	private void bindViews() {
		findViewById(R.id.system_back).setOnClickListener(this);
		TextView tvTitle = (TextView) findViewById(R.id.tv_top_title);
		tvTitle.setText(getString(R.string.askleave_detail_title));
		rightBtn = (Button) findViewById(R.id.btn_top_right);
		rightBtn.setOnClickListener(this);
		initTextView();
		initViewPager();
		// 请假信息
		initLeaveInfo();
		// 办理意见
		initTransactSuggestion();
		// 办理信息
		initTransactInfo();
	}
	
	/**
	 * 请假信息初始化控件
	 */
	private void initLeaveInfo() {
		// 申请人
		leaveProposer = (TextView) view1.findViewById(R.id.tv_text_applicant);
		// 当前状态
		leaveCurrentState = (TextView) view1.findViewById(R.id.tv_leave_current_state);
		// 请假类别
		leaveCatalog = (TextView) view1.findViewById(R.id.tv_leave_catalog);
		// 请假类型
		leaveType = (TextView) view1.findViewById(R.id.tv_leave_type);
		// 请假原因
		leaveReason = (TextView) view1.findViewById(R.id.tv_leave_reason);
		// 年休假天数
		leaveYearDays = (TextView) view1.findViewById(R.id.tv_leave_year_days);
		// 请假申请开始时间
		beginTime = (TextView) view1.findViewById(R.id.tv_leave_from);
		// 请假申请结束时间
		endTime = (TextView) view1.findViewById(R.id.tv_leave_to);
		// 请假天数
		totalDays = (TextView) view1.findViewById(R.id.tv_askleave_total);
		btn_leave_send = (Button) view1.findViewById(R.id.btn_leave_send);
		btn_leave_send.setOnClickListener(this);
		btn_leave_process = (Button) view1.findViewById(R.id.btn_leave_process);
		btn_leave_process.setOnClickListener(this);
	}
	
	
	/**
	 * 办理意见初始化控件
	 */
	private void initTransactSuggestion() {
		lv_transact_suggestion = (ListView) view2.findViewById(R.id.lv_transact_suggestion);
		tv_no_data_suggestion = (TextView) view2.findViewById(R.id.tv_no_data_suggestion);
	}
	
	
	/**
	 * 办理信息初始化控件
	 */
	private void initTransactInfo() {
		lv_transact_info = (ListView) view3.findViewById(R.id.lv_transact_info);
		tv_no_data_info = (TextView) view3.findViewById(R.id.tv_no_data_info);
	}
	
	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	@SuppressLint("InflateParams")
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_pager);
		views = new ArrayList<View>();
		LayoutInflater inflater = getLayoutInflater();

		view1 = inflater.inflate(R.layout.askleave_item_detail, null); // 加载请假信息
		view2 = inflater.inflate(R.layout.transact_suggestion_list, null);// 加载办理意见
		view3 = inflater.inflate(R.layout.transact_info_list, null);// 加载办理信息
		views.add(view1);
		views.add(view2);
		views.add(view3);

		initImageView();
		pagerAdapter = new MyViewPagerAdapter();
		viewPager.setAdapter(pagerAdapter);
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
		setSelectTab();
	}

	private void setSelectTab() {
		if (currIndex < 0 || currIndex >= views.size()) {
			currIndex = 0;
		}
		UIHelper.setTabTextHeighLight(mContext, currIndex, tv1, tv2, tv3);
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量
		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);// True:图片停在动画结束位置
			animation.setDuration(300);
			imageView.startAnimation(animation);
			setSelectTab();
			Logger.d("onPageSelected", "curIndex: " + currIndex + "  size: "
					+ views.size());
			if (currIndex == 0) {
				// 请假信息
				if (null == detail) {
					getLeaveDetails();
				}
			} else if (currIndex == 1) { 
				// 办理意见
				showTransactSuggestion();
			} else if (currIndex == 2) {
				// 办理信息
				showTransactInfo();
			}
			Logger.d("onPageSelected", "curIndex: " + currIndex + "  size: "
					+ views.size());
		}
	}

	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}

	public class MyViewPagerAdapter extends PagerAdapter {

		public MyViewPagerAdapter() {
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(views.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(views.get(position));
			Logger.d("MyViewPagerAdapter", "instantiateItem" + position);
			return views.get(position);
		}

		@Override
		public int getCount() {
			return views.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.tv_1);
		tv2 = (TextView) findViewById(R.id.tv_2);
		tv3 = (TextView) findViewById(R.id.tv_3);
		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
		tv3.setOnClickListener(new MyOnClickListener(2));
	}

	/**
	 * 初始化动画
	 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / views.size() - bmpW) / 2;// 计算偏移量-->3个选项卡
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}


	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {// 　返回
			onClickBack();
		} else if (id == R.id.btn_top_right) {// 办理
			if (detail != null) {
				if (detail.getSaveButton().equals("1")) {
					Intent intent = new Intent(LeaveDetailActivity.this,LeaveAddActivity.class);
					intent.putExtra("detail", detail);
					startActivity(intent);
				} else if (detail.getDestoryButton().equals("1")) {
					Intent intent = new Intent(LeaveDetailActivity.this,LeaveDestoryActivity.class);
					intent.putExtra("detail", detail);
					startActivity(intent);
				} else if (detail.getFinishButton().equals("1")) {
					processLeave();
				}
			}
		} else if (id == R.id.btn_leave_send) {
			// 在这里调用发送
			String nextFpuNo = detail.getFpuNo();
			ApplyParams params = new ApplyParams(swfNo, wfNo, nextFpuNo);
			params.setLeaveId(leaveId);
			params.setNextFpuNo(nextFpuNo);
			Bundle data = new Bundle();
			data.putSerializable("params", params);
			data.putString("passState", "0");
			data.putInt("flag", 2);
			UIHelper.forwardTargetActivity(mContext, TransactorActivity.class, data, false);
		} else if (id == R.id.btn_leave_process) {
			// 请假审批
			Bundle data = new Bundle();
			data.putString("leaveId", leaveId);
			UIHelper.forwardTargetActivity(mContext, LeaveProcessActivity.class, data, false);
		}

	}

	private void onClickBack() {
		if (Constants.NOTIFY_DETAIL_BACK) {
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(mContext, MainActivity.class, null,
					true);
		} else {
			UIHelper.deleteTempDoc();
			finish();
		}
	}

	public static void finishActivity() {
		instance.finish();
	}

}
