package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.TaskDetails;
import com.powerriche.mobile.oa.tools.BeanUtils;

import java.util.ArrayList;

/**
 * Created by root on 16-5-23.
 */
public class TaskHistoryAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<TaskDetails.HistoryProgress> mData = new ArrayList<TaskDetails.HistoryProgress>();
    public TaskHistoryAdapter(Context context) {
        this.mContext = context;
    }

    public void updateData(ArrayList<TaskDetails.HistoryProgress> data) {
        mData.clear();
        if (!BeanUtils.isEmpty(data)) {
            mData.addAll(data);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        TaskDetails.HistoryProgress history = mData.get(position);
        if (null == view) {
            holder = new ViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.check_history_item, null);
            holder.tv_progress_from_date = (TextView) view.findViewById(R.id.tv_progress_from_date);
//            holder.tv_progress_to_date = (TextView) view.findViewById(R.id.tv_progress_to_date);
//            holder.tv_progress_complete_degree = (TextView) view.findViewById(R.id.tv_progress_complete_degree);
//            holder.tv_progress_complete_time = (TextView) view.findViewById(R.id.tv_progress_complete_time);
//            holder.tv_progress_sum_human_cost = (TextView) view.findViewById(R.id.tv_progress_sum_human_cost);
//            holder.tv_progress_sum_quantity = (TextView) view.findViewById(R.id.tv_progress_sum_quantity);
//            holder.tv_progress_sum_time = (TextView) view.findViewById(R.id.tv_progress_sum_time);
//            holder.tv_progress_sum_money = (TextView) view.findViewById(R.id.tv_progress_sum_money);

            holder.contentTxt = (TextView) view.findViewById(R.id.task_history_content_txt);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        StringBuffer buffer = new StringBuffer(getString(R.string.task_time_section));
        String blank = "  ";
        buffer.append(history.getFromDate()).append(getString(R.string.askleave_to)).append(history.getToDate()).append(blank);
        buffer.append(getString(R.string.task_complete_degree)).append(history.getDegree()).append(blank);
        buffer.append(getString(R.string.task_complete_time)).append(history.getCompleteTime()).append(blank);
        buffer.append(getString(R.string.task_sum_human_cost)).append(history.getSumHumanCost()).append(blank);
        buffer.append(getString(R.string.task_sum_quantity)).append(history.getSumQuantity()).append(blank);
        buffer.append(getString(R.string.task_sum_time)).append(history.getSumTime()).append(blank);
        buffer.append(getString(R.string.task_sum_money)).append(history.getSumMoney());
        holder.tv_progress_from_date.setText(buffer.toString());
//        holder.tv_progress_to_date.setText(history.getToDate());
//        holder.tv_progress_complete_degree.setText(history.getDegree());
//        holder.tv_progress_complete_time.setText(history.getCompleteTime());
//        holder.tv_progress_sum_human_cost.setText(history.getSumHumanCost());
//        holder.tv_progress_sum_quantity.setText(history.getSumQuantity());
//        holder.tv_progress_sum_time.setText(history.getSumTime());
//        holder.tv_progress_sum_money.setText(history.getSumMoney());
        holder.contentTxt.setText(history.getContent());
        return view;
    }

    private String getString(int res) {
        return mContext.getResources().getString(res);
    }

    class ViewHolder {
        TextView tv_progress_from_date;
//        TextView tv_progress_to_date;
        TextView tv_progress_complete_degree;
        TextView tv_progress_complete_time;
        TextView tv_progress_sum_human_cost;
        TextView tv_progress_sum_quantity;
        TextView tv_progress_sum_time;
        TextView tv_progress_sum_money;

        TextView contentTxt;
    }

}
