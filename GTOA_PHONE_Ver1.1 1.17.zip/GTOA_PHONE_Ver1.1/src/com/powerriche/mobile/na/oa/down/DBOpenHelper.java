package com.powerriche.mobile.na.oa.down;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.powerriche.mobile.oa.tools.Logger;

public class DBOpenHelper extends SQLiteOpenHelper {

	public static final String TAG = "DBOpenHelper";

	private static final String DBNAME = "gtoa_download.db";
	private static final int VERSION = 1;

	public DBOpenHelper(Context context) {
		super(context, DBNAME, null, VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		Logger.e(TAG, "-------->DBOpenHelper.onCreate()：创建本地数据库");
		//创建表：filedownlog，记录文件下载信息
		db.execSQL("CREATE TABLE IF NOT EXISTS filedownlog (id integer primary key autoincrement, downpath varchar(100), threadid INTEGER, downlength INTEGER)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Logger.e(TAG, "-------->DBOpenHelper.onUpgrade()：升级本地数据库，数据库版本号："
				+ oldVersion + "--->" + newVersion);
		db.execSQL("DROP TABLE IF EXISTS filedownlog");//1、先删除旧表
		onCreate(db);//2、再创建新表
	}

	@Override
	public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Logger.e(TAG, "-------->DBOpenHelper.onDowngrade()：降级本地数据库，数据库版本号："
				+ oldVersion + "--->" + newVersion);
		db.execSQL("DROP TABLE IF EXISTS filedownlog");//1、先删除旧表
		onCreate(db);//2、再创建新表
	}

}
