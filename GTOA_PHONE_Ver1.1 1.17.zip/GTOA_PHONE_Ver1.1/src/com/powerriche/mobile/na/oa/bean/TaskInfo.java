package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * 个人任务基本信息类
 * Created by root on 16-5-9.
 */
public class TaskInfo implements Serializable{

    /**int 类型：0代表新增，其他代表修改*/
    private int taskId;
    private String title;
    /**时限：2016-01-03*/
    private String limitTime;
    private String taskYear;
    /** 主送人员编号集合，用逗号分割：123,234*/
    private String submitToNo;
    private String copyToNo;
    private String itemName;
    /** 类型编号int：0 申请   1 申购  2 通知  3 任务  4 采访  5 用车派单  6 工作餐*/
    private String itemType;
    private String itemAddress;
    private String itemRemark;
    private String itemAssign;
    /** 工作内容： 用@拼接 content1@content2@content3*/
    private String itemContent;


    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLimitTime() {
        return limitTime;
    }

    public void setLimitTime(String limitTime) {
        this.limitTime = limitTime;
    }

    public String getTaskYear() {
        return taskYear;
    }

    public void setTaskYear(String taskYear) {
        this.taskYear = taskYear;
    }

    public String getSubmitToNo() {
        return submitToNo;
    }

    public void setSubmitToNo(String submitToNo) {
        this.submitToNo = submitToNo;
    }

    public String getCopyToNo() {
        return copyToNo;
    }

    public void setCopyToNo(String copyToNo) {
        this.copyToNo = copyToNo;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getItemAddress() {
        return itemAddress;
    }

    public void setItemAddress(String itemAddress) {
        this.itemAddress = itemAddress;
    }

    public String getItemRemark() {
        return itemRemark;
    }

    public void setItemRemark(String itemRemark) {
        this.itemRemark = itemRemark;
    }

    public String getItemAssign() {
        return itemAssign;
    }

    public void setItemAssign(String itemAssign) {
        this.itemAssign = itemAssign;
    }

    public String getItemContent() {
        return itemContent;
    }

    public void setItemContent(String itemContent) {
        this.itemContent = itemContent;
    }
}
