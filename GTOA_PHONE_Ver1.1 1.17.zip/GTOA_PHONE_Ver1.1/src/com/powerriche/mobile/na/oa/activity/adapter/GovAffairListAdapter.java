package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.GovAffairActivity;
import com.powerriche.mobile.na.oa.activity.GovAffairAddActivity;
import com.powerriche.mobile.na.oa.activity.document.GovAffairListHelper;
import com.powerriche.mobile.na.oa.bean.GovAffairInfo;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 领导政务adapter
 * 
 * @author Fitz
 * @date 2015年4月28日
 * @version v1.0
 */
public class GovAffairListAdapter extends BaseAdapter {

	private Context mContext = null;
	private LayoutInflater inflater;

	private List<GovAffairInfo> dataList;

	private int searchState = Constants.GOVAFFAIR_STATE_DEFAULT;
	private String searchText;
	
	private GovAffairListHelper helper;

	public GovAffairListAdapter(Context context, GovAffairListHelper helper) {
		this.mContext = context;
		this.inflater = LayoutInflater.from(this.mContext);
		this.dataList = new ArrayList<GovAffairInfo>();
		this.helper = helper;
	}

	@Override
	public int getCount() {
		return dataList.size();
	}

	@Override
	public Object getItem(int position) {
		return dataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {

		ViewHolder holder = null;

		if (view == null) {
			holder = new ViewHolder();
			view = inflater.inflate(R.layout.govaffair_list_item, null);
			holder.tvDatatime = (TextView) view.findViewById(R.id.tv_datetime);
			holder.tvContent = (TextView) view.findViewById(R.id.tv_content);
			holder.tvLeaderName = (TextView) view.findViewById(R.id.tv_Leader_name);
			holder.itemWrap = (LinearLayout) view.findViewById(R.id.ll_item_wrap);
			view.setTag(holder);

		} else {
			holder = (ViewHolder) view.getTag();
		}

		GovAffairInfo bean = dataList.get(position);
		bean.setPosition(position);
		
		String time = bean.getBeginData()+" "+DateUtils.dayForWeek(bean.getBeginData())+" "+bean.getBeginTime()+" -- "+bean.getEndData()+" "+DateUtils.dayForWeek(bean.getEndData())+" "+bean.getEndTime();
		holder.tvDatatime.setText(time);
		// 如果是领导查询，这显示的位置换下
		if (searchState == Constants.GOVAFFAIR_STATE_LEADER) {
			holder.tvContent.setText(bean.getLeaderName());
			holder.tvLeaderName.setText(bean.getAffairContent());
		} else {
			holder.tvContent.setText(bean.getAffairContent());
			holder.tvLeaderName.setText(bean.getLeaderName());
		}
		// 如果有搜索关键字，高亮显示
		if (!BeanUtils.isEmpty(searchText)) {
			SearchUtils.spannableResultItems(holder.tvContent,
					(String) holder.tvContent.getText(), searchText);
		}

		holder.itemWrap.setTag(bean);
		//单击：进入详情
		holder.itemWrap.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				GovAffairInfo tag = (GovAffairInfo) v.getTag();
				if (tag != null) {
					Bundle data = new Bundle();
					//封装交互数据
					data.putString(GovAffairAddActivity.FORWARDER_KEY, tag.getAffairId());
					//进入详情界面
					UIHelper.forwardTargetActivity(mContext, GovAffairAddActivity.class, data, false);
				}
			}
		});
		
		//按政务查询才有删除
		if (searchState == Constants.GOVAFFAIR_STATE_DEFAULT) {
			//长按：确认删除
			holder.itemWrap.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(final View v) {
					final GovAffairInfo tag = (GovAffairInfo) v.getTag();
					if(tag!=null){
						UIHelper.vibrate(mContext, 50); // 震动下	
						final SystemDialog chooseDialog = new SystemDialog(mContext);
						chooseDialog.setTitle("删除提示");
						chooseDialog.setMessage("确定要删除该条数据吗？");
						chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
							@Override
							public void onClick(View view) {
								helper.deleteData(tag.getPosition(), GovAffairActivity.WATH_DELETE);
								removeData(tag.getPosition());
								notifyDataSetChanged();	//更新
							}
						});
						chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
							@Override
							public void onClick(View v) {
								if(chooseDialog!=null){
									chooseDialog.dismiss();
								}
							}
						});
						chooseDialog.show();
					}
					return false;
				}
			});		
		}else{
			holder.itemWrap.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(final View v) {
					return false;
				}
			});	
		}
		return view;
	}

	/**
	 * 添加数据
	 * @param groupList
	 * @param userList
	 */
	public void addData(List<GovAffairInfo> dataList, int state, String searchText) {
		searchState = state;
		this.dataList.addAll(dataList);
		this.searchText = searchText;
	}

	public void clearListData() {
		if (dataList != null) {
			dataList.clear();
		}
	}

	public GovAffairInfo getGovAffairInfo(int position) {
		try{
			return dataList.get(position);
		}catch(Exception e){
			return null;
		}
	}

	public void removeData(int position) {
		try{
			dataList.remove(position);
		}catch(Exception e){
			
		}
	}

	private class ViewHolder {
		TextView tvDatatime, tvContent, tvLeaderName;
		LinearLayout itemWrap;
	}

}
