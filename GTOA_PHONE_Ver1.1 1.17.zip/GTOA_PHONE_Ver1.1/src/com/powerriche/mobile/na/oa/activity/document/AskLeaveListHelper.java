package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.AskLeaveActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;

/**
 * Filename : AskLeaveActivity
 * 
 * @Description : 请假列表查询
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-24 上午 11:38:24
 */
public class AskLeaveListHelper {

	private ListView listView;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();

	private InvokeHelper helper = null;

	private Context mcontext = null;

	private IRequestCallBack callBack = null;

	private ResultSimpleAdapter adapter;

	private PullToRefreshListView mPullView;
	
	private int pageIndex;


	public AskLeaveListHelper(Context context, View contextView) {
		this.mcontext = context;
		AskLeaveActivity acitvity = (AskLeaveActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		mPullView = (PullToRefreshListView) contextView
				.findViewById(R.id.pull_listview);

		listView = (ListView) mPullView.getRefreshableView();
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long arg3) {
				try {
					ResultItem itemp = resultItems.get(index);
					// 封装交互数据
					//Bundle data = new Bundle();
					//data.putString("askLeaveId",
					//		itemp.getString("LEAVE_BIZ_NO"));
					Constants.DOCUMENT_ID = itemp.getString("LEAVE_BIZ_NO");
					helper.invokeWidthDialog(OAServicesHandler.getAskLeaveDetail(itemp.getString("LEAVE_BIZ_NO")), callBack, Constants.OPT_TYPE_LEAVE_DETAIL);
					// 跳转到详情页面
					//UIHelper.forwardTargetActivity(mcontext,
						//	AskLeaveDetailActivity.class, data, false);
					// handler.sendEmptyMessage(AskLeaveActivity.ASKLEAVE_DETAIL);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void loadData(int what, int index,boolean isDialog) {
		this.pageIndex = index;
		// 清楚数据
		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
		ApiRequest request = OAServicesHandler.getAskLeaveList(index);
		if (request != null) {
			if (isDialog) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}

	}

	public void process(HttpResponse response, int what) {
		// resultItems.clear();
		if (pageIndex == 1) {
			resultItems.clear();
		}
		List<ResultItem> items = response.getResultItem(ResultItem.class)
				.getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			resultItems.addAll(items);
		}
		if (adapter == null) {
			int[] txtids = {R.id.list_item_text_field,
					R.id.list_item_text_field1, R.id.list_item_text_field3};
			String[] keys = new String[]{"LEAVE_TYPE", "BEGIN_TIME", "END_TIME"};
			adapter = new ResultSimpleAdapter(mcontext, resultItems,
					R.layout.list_askleave_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						if ("LEAVE_TYPE".equals(key) && currentobj != null) {
							return Constants.LEAVE_TYPE_MAP.get(BeanUtils.floatToInt(currentobj.toString()));
						}else if("BEGIN_TIME".equals(key) && currentobj != null){
							return DateUtils.getDateStr(currentobj.toString(), DateUtils.DATE_HOUR_FORMAT);
						}else if("END_TIME".equals(key) && currentobj != null){
							return DateUtils.getDateStr(currentobj.toString(), DateUtils.DATE_HOUR_FORMAT);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int positon) {

				}
			});
			listView.setAdapter(adapter);

		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items)
				|| items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}
		
	}

}
