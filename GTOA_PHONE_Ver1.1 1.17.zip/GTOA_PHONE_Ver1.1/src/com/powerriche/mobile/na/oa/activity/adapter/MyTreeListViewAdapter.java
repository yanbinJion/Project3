/**
 * @Title: SimpleTreeListViewAdapter.java
 * @Package com.sloop.treeview.adapter
 * Copyright: Copyright (c) 2015
 * 
 * @author sloop
 * @date 2015年2月22日 上午2:01:06
 * @version V1.0
 */

package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.treeview.util.Node;

/**
 * @ClassName: SimpleTreeListViewAdapter
 * @author sloop
 * @date 2015年2月22日 上午2:01:06
 */

public class MyTreeListViewAdapter<T> extends TreeListAdapter<T> {

	public MyTreeListViewAdapter(ListView mTree, Context context, List<T> datas, int defaultExpandLevel) {
		super(mTree, context, datas, defaultExpandLevel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public View getConvertView(Node node, int position, View convertView,
			ViewGroup parent) {
		ViewHolder holder = null;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.list_item, parent, false);
			holder = new ViewHolder();
			holder.mIcon = (ImageView) convertView.findViewById(R.id.item_icon);
			holder.mText = (TextView) convertView.findViewById(R.id.item_text);
			holder.checkBox = (CheckBox) convertView.findViewById(R.id.cb);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		if (node.getIcon() == -1) {
			holder.mIcon.setVisibility(View.INVISIBLE);
		} else {
			holder.mIcon.setVisibility(View.VISIBLE);
			holder.mIcon.setImageResource(node.getIcon());
		}
		holder.checkBox.setVisibility(View.VISIBLE);
		setCheckBoxBg(holder.checkBox,node.isChecked());
		holder.mText.setText(node.getName());

		return convertView;
	}

	private final class ViewHolder {
		ImageView mIcon;
		TextView mText;
		CheckBox checkBox;
	}

	/**
	 * checkbox是否显示
	 * 
	 * @param cb
	 * @param isChecked
	 */
	private void setCheckBoxBg(CheckBox cb, boolean isChecked) {
		if (isChecked) {
			cb.setBackgroundResource(R.drawable.check_box_bg_check);
		} else {
			cb.setBackgroundResource(R.drawable.check_box_bg);
		}
	}

}
