package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.RecordActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
/**
 * @title  个人考勤记录
 * @author dir_wang
 * @date   2016-7-21下午3:28:45
 */
public class RecordListHelper {

	private ListView listView;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();

	private InvokeHelper helper = null;

	private Context mContext = null;

	private IRequestCallBack callBack = null;

	private ResultSimpleAdapter adapter;

	private PullToRefreshListView mPullView;
	private TextView tv_no_data_attendance_record;
	private int pageIndex;


	public RecordListHelper(Context context, View contextView) {
		this.mContext = context;
		RecordActivity acitvity = (RecordActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		mPullView = (PullToRefreshListView) contextView.findViewById(R.id.lv_attendance_record);
		tv_no_data_attendance_record = (TextView) contextView.findViewById(R.id.tv_no_data_attendance_record);
		listView = (ListView) mPullView.getRefreshableView();
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//				ResultItem result = resultItems.get(position);
//				String staffNo = result.getString("STAFF_NO");
//				Bundle data = new Bundle();
//				data.putString("staffNo", staffNo);
//				data.putString("beginTime", getBeginTime().getText().toString());
//				data.putString("endTime", getEndTime().getText().toString());
//				UIHelper.forwardTargetActivity(mContext, MyRecordActivity.class, data, false);
			}
		});
	}

	public void loadData(int what, String beginTime, String endTime, String staffNo, int index, boolean isDialog) {
		// 清除数据
		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
		ApiRequest request = OAServicesHandler.getAttendanceList(beginTime, endTime, staffNo, index);
		if (request != null) {
			if (isDialog) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}

	}

	public void process(HttpResponse response, int what) {
		if (pageIndex == 1) {
			resultItems.clear();
		}
		List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			resultItems.addAll(items);
		}
		if (adapter == null) {
			int[] txtids = { R.id.tv_now_day, R.id.tv_morning_sign_in_time, R.id.tv_morning_sign_in_location, 
					R.id.tv_morning_sign_out_time, R.id.tv_morning_sign_out_location, 
					R.id.tv_afternoon_sign_in_time, R.id.tv_afternoon_sign_in_location, 
					R.id.tv_afternoon_sign_out_time, R.id.tv_afternoon_sign_out_location };
			String[] keys = new String[] { "ATTEND_DATE", "MORNING_SIGN_IN_TIME", "MORNING_SIGN_IN_ADDRESS", 
					"MORNING_SIGN_OUT_TIME", "MORNING_SIGN_OUT_ADDRESS", 
					"AFTERNOON_SIGN_IN_TIME", "AFTERNOON_SIGN_OUT_TIME", 
					"AFTERNOON_SIGN_OUT_TIME", "AFTERNOON_SIGN_OUT_ADDRESS" };
			adapter = new ResultSimpleAdapter(mContext, resultItems,
					R.layout.record_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						ResultItem result = resultItems.get(position);
						String morning_sign_in = result.getString("morning_sign_in");
						String morning_sign_out = result.getString("morning_sign_out");
						String afternoon_sign_in = result.getString("morning_sign_out");
						String afternoon_sign_out = result.getString("morning_sign_out");
						String str = "";
						if ("ATTEND_DATE".equals(key)) {
							
						}
						if (morning_sign_in.equals("0")) {
							
						} else {
							
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int positon) {

				}
			});
			listView.setAdapter(adapter);
			tv_no_data_attendance_record.setVisibility(View.VISIBLE);

		} else {
			adapter.notifyDataSetChanged();
			tv_no_data_attendance_record.setVisibility(View.GONE);
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items) || items.size() < Constants.RECORD_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}
		
	}
	

}
