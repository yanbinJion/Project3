package com.powerriche.mobile.na.oa.activity.base;

import android.content.Context;
import android.os.Message;

import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;

/**
 * FileName    : IRequestCallBack
 * Description : 
 * @author     : 刘剑
 * @version    : 1.0
 * Create Date : 2011-12-14 下午21:50:38
 **/
public interface IRequestCallBack {
	
	/**
	 * 数据正确请求的（主要处理入口＄1�7
	 * @param response
	 */
	public void process(HttpResponse response,int what);
	
	/**
	 * 数据解析错误或�1�7�是返回出错
	 * @param response
	 * @param error
	 */
	public void onReturnError(HttpResponse response,ResultItem error,int what);
	
	/**网络连接不上的数捄1�7*/
	public void onNetError(int what);
	
	/**
	 * 处理其他的消息机刄1�7
	 * @param messageType
	 * @param messageObj
	 * @param 原始的message
	 */
	public void handleMessage(Message message,int what);
	
	/**
	 * closeDialog关闭实现（一般不霄1�7要实玄1�7,除特殊情况）
	 * @param dialogObj
	 */
	public void finish(Object dialogObj,int what);
	
	/**
	 * 绑定整个过程的Context
	 * @param context
	 */
	public void bindContext(Context context);
	
	/**
	 * 绑定当前的消息机刄1�7
	 * @param handler
	 */
	public void bindHandler(BaseHandler handler,int what);
	
	/**
	 * 获取对应的消息机刄1�7
	 * @param handler
	 */
	public BaseHandler getHandler(int what);
	
	/**
	 * 获取handler对应的what
	 * @param handler
	 * @return
	 */
	public int getHandlerWhat(BaseHandler handler);
}
