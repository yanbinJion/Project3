package com.powerriche.mobile.na.oa.activity;

import android.content.Context;

import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;

public class TaskBanLiHelper {
	
	private Context context;
	
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;
	
	public TaskBanLiHelper(Context context, IRequestCallBack callBack){
		this.context = context;
		this.callBack = callBack;
		this.helper = ((GovAffairAddActivity) this.context).getInvokeHelper();
		
	}
	
	
	
	

}
