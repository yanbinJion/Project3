package com.powerriche.mobile.na.oa.dao;

import android.content.Context;
import android.database.Cursor;

import com.powerriche.mobile.oa.tools.Logger;


/**
 * 类描述：<br>
 * 初始化数据库
 * @author  Fitz
 * @date    2014-12-4
 */
public class BaseDAO {

	public static String tAg = "BaseDAO";
	
	protected Database db;

	public BaseDAO(Context context) {
		this.db = Database.getInstance(context);
	}

	public void close() {
		try {
			Logger.d(tAg, "closing..." + this.getClass().getName());
			//this.db.close();
			Logger.d(tAg,"closed." + this.getClass().getName());
		} catch (Exception e) {
			Logger.e(tAg, e.getMessage());
		}
		//this.sqlite = null;
	}

	public  void execSQL(String sql, Object[] bindArgs) {
		if (Database.writableSQLiteDatabase == null || !Database.writableSQLiteDatabase.isOpen()) {
			Database.writableSQLiteDatabase = null;
			Database.writableSQLiteDatabase = this.db.getDb(true);
			Logger.d(tAg,"regetDB " + this.getClass().getName());
		}

		try {
			Database.writableSQLiteDatabase.execSQL(sql, bindArgs);
		} catch (java.lang.IllegalStateException ise) {
			String mes = ise.getMessage();
			if (mes != null && mes.indexOf("not open") != -1) {
				Logger.d(tAg,"regetDB " + this.getClass().getName());
				Database.writableSQLiteDatabase.execSQL(sql, bindArgs);
			}
		}
	}

	public  void execSQL(String sql) {
		if (Database.writableSQLiteDatabase == null || !Database.writableSQLiteDatabase.isOpen()) {
			Database.writableSQLiteDatabase = null;
			Database.writableSQLiteDatabase = this.db.getDb(true);
			Logger.d(tAg,"regetDB " + this.getClass().getName());
		}

		try {
			Database.writableSQLiteDatabase.execSQL(sql);
		} catch (java.lang.IllegalStateException ise) {
			String mes = ise.getMessage();
			if (mes != null && mes.indexOf("not open") != -1) {
				Logger.d(tAg, "regetDB " + this.getClass().getName());
				
				Database.writableSQLiteDatabase.execSQL(sql);
			}
		}
	}

	public Cursor rawQuery(String sql, String[] selectionArgs) {
		if (Database.readableSQLiteDatabase == null || !Database.readableSQLiteDatabase.isOpen()) {
			Database.readableSQLiteDatabase = null;
			Database.readableSQLiteDatabase = this.db.getDb(true);

			Logger.d(tAg, "rawQuery " + this.getClass().getName());
		}

		Cursor result = null;
		try {
			result = Database.readableSQLiteDatabase.rawQuery(sql, selectionArgs);
		} catch (java.lang.IllegalStateException ise) {
			String mes = ise.getMessage();
			if (mes != null && mes.indexOf("close") != -1) {
				Database.readableSQLiteDatabase = null;
				Database.readableSQLiteDatabase = this.db.getDb(true);
				result = Database.readableSQLiteDatabase.rawQuery(sql, selectionArgs);
			}
		}

		return result;
	}

	public Database getDatabase() {
		return this.db;
	}

	public void deleteAll(String tableName) {
		String sql = "DELETE FROM ".concat(tableName);
		this.execSQL(sql);
	}
	
	public void deleteById(Integer id,String tableName) {
		String sql = "DELETE FROM ".concat(tableName).concat(" WHERE id = ")+id;
		this.execSQL(sql);
	}
	
}
