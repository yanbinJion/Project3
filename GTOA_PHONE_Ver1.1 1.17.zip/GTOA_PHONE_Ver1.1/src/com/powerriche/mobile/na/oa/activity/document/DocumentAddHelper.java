package com.powerriche.mobile.na.oa.activity.document;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocumentInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;

/**
 * 类描述：<br> 
 * 新建公文帮助类
 * @author  Fitz
 * @date    2015年4月28日
 * @version v1.0
 */
public class DocumentAddHelper {

	private static final String TAG = "DocumentAddHelper";
	
	private Context mContext;
	private IRequestCallBack callBack = null;
	private InvokeHelper helper = null;
	private int operateType = 0;
	
	public DocumentAddHelper(Context context, IRequestCallBack callBack, InvokeHelper helper, int operateType){
		this.mContext = context;
		this.callBack = callBack;
		this.helper = helper;
		this.operateType = operateType;
	}
	
	public void saveDocument(DocumentInfo bean, int what){
		ApiRequest request = OAServicesHandler.saveDocument(bean);
        if (request != null){
        	request.setMessage(mContext.getString(R.string.system_commit_message));
            helper.invoke(request, callBack, what);
        }
	}
	
	public void submit(EditText etTitle, EditText etTextNo, EditText etDepartment, EditText etUserName, TextView tvHuanji, 
			TextView tvLevel, EditText etZhaiyao, int what,Button rightBtn){
		String title = etTitle.getText().toString();
		String charset = etTextNo.getText().toString();
		String department = etDepartment.getText().toString();
		String userName = etUserName.getText().toString();

		String huanji = null;
		Object obj = tvHuanji.getTag();
		if(obj!=null){
			huanji = obj.toString();
		}
		
		String level = null;
		obj = tvLevel.getTag();
		if(obj!=null){
			level = obj.toString();
		}
		
		String zhaiyao = etZhaiyao.getText().toString();	//摘要
		
		if(!valiedate(title, charset, department, userName, huanji, level, zhaiyao, etTitle, etTextNo, etDepartment, etUserName,
				tvHuanji, tvLevel, etZhaiyao)){
			return;
		}
		
		DocumentInfo bean = new DocumentInfo();
		bean.setTitle(title);
		bean.setCharacters(charset);
		bean.setDepartment(department);
		bean.setDrafter(userName);
		bean.setSummary(zhaiyao);//摘要
		bean.setUrgency(huanji);	//缓急
		bean.setLevel(level);	//密级
		if(operateType==1){	//修改
			bean.setDocumentId(Integer.parseInt(etTitle.getTag().toString()));
		}
		bean.setOperateType(operateType);	//添加操作
		saveDocument(bean, what);
		rightBtn.setClickable(false);
	}
	
	
	private boolean valiedate(String title, String charset, String department, String userName, String huanji, String level, String zhaiyao,
			EditText etTitle, EditText etTextNo, EditText etDepartment, EditText etUserName, TextView tvHuanji, TextView tvLevel, EditText etZhaiyao){
		if(BeanUtils.isEmpty(title)){
			return setReturnMsg(etTitle, "标题不能为空");
		}
		/*if(BeanUtils.isEmpty(charset)){
			return setReturnMsg(etTextNo, "文件字号不能为空");
		}*/
		if(BeanUtils.isEmpty(department)){
			return setReturnMsg(etDepartment, "拟稿单位不能为空");
		}
		if(BeanUtils.isEmpty(userName)){
			return setReturnMsg(etUserName, "拟稿人不能为空");
		}
		if(BeanUtils.isEmpty(huanji)){
			return setReturnMsg(tvHuanji, "请选择缓急状态");
		}
		if(BeanUtils.isEmpty(level)){
			return setReturnMsg(tvLevel, "请选择密级状态");
		}
		return true;
	}
	
	private boolean setReturnMsg(TextView view, String msg){
		view.setText("");
		view.requestFocus();
		Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
		return false;
	}
	
	
	
	/**
	 * 上传正文
	 * @param documentId
	 * @param swfNo
	 * @param traceNo
	 */
	public void uploadDocFile(String documentId, String swfNo, String traceNo, File file, int what, Handler handler){
		UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadDocFile", documentId, swfNo, traceNo, what);
		List<File> files = new ArrayList<File>();
		files.add(file);
		params.setListFile(files);
		
		HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
		post.execute(params);
	}

	/** 附件上传 */
	public void uploadFile(String documentId, String swfNo, LinearLayout llFileWrap, Handler handler, int what){
		if(llFileWrap!=null){
			int fileCount = llFileWrap.getChildCount();
			if(fileCount>0){
				List<File> files = new ArrayList<File>();
				for(int i=0; i<fileCount; i++){
					View view = llFileWrap.getChildAt(i);
					TextView tv = (TextView) view.findViewById(R.id.tv_file_name);
					String path = (String) tv.getTag();
					
					File file = new File(path);
					if(file!=null && file.exists()){
						files.add(file);
					}
				}
				
				UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadFile", documentId, swfNo, "", what);
				params.setListFile(files);
				HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
				post.execute(params);
			}
		}
	}
	
}
