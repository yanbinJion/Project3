package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.PurchaseApply;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.na.oa.bean.PurchaseApply.PurchaseDetail;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author dir_wang
 * @create date 2016-6-28 下午12:06:11
 */
public class ApplyPurchaseActivity extends BaseActivity implements View.OnClickListener, View.OnLongClickListener {

    private static final int REQUEST_SAVE_PURCHASE = 10000;
    private final int UPLOAD_FILE = 11;
    private final String TAG = ApplyRegisterActivity.class.getSimpleName();

    private int contentSize = 1;
    private ViewPager mViewPager;
    private ImageView imageView;
    private Context mContext;

    private List<View> views;// Tab页面列表
    private TextView tv1, tv2;
    private View view1, view2;

    private Button rightBtn;// 右边的按钮图标
    private Button backBtn;
    private int offset = 0;// 动画图片偏移量
    private int currIndex = 0;// 当前页卡编号
    private int bmpW;// 动画图片宽度

    private EditText et_purchase_title;
    private TextView tv_purchase_proposer;
    private TextView tv_purchase_time;
    private EditText et_purchase_complete_time;
    private TextView tv_purchase_type;
    private EditText et_purchase_details;
    private TextView tv_add_goods_apply;
    private LinearLayout apply_list_lay;

    private LinearLayout typeLay;
    private EditText et_purchase_type;
    private LinearLayout payLay;
    private EditText et_purchase_pay;
    private EditText et_purchase_reason;
    private TextView tv_purchase_pay;
    private LinearLayout sumLay;
    private TextView sumTxt;

    private Button fileUploadBtn;
    private LinearLayout fileListLay;
    private TextView tv_file_group;
    private ScrollView scrollView;

    LayoutInflater mInflater;
    private PurchaseApply detail;
    private ArrayList<TextView> totalTxt = new ArrayList<TextView>();

    private Handler mHanlder = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            if (null == msg) {
                return;
            }
            if (msg.what == UPLOAD_FILE) {
                ResultItem item = (ResultItem) msg.obj;
                String code = item.getString("code");
                String message = item.getString("message");
                UIHelper.showMessage(mContext, message);
                System.out.println("message=" + message);
                UIHelper.deleteTempDoc();	//退出前，删掉临时文件
                ApplyPurchaseActivity.this.finish();
            }
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("TEST", " onCreate ");
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.apply_register);
        Intent intent = getIntent();
        detail = (PurchaseApply) intent.getSerializableExtra("purchaseDetail");
        mContext = this;
        initView();
        initImageView();
        initTextView();
        initViewPager();
        if (null == detail) {
            initContentView(contentSize);
        }
    }


    private void initView() {
        TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
        topActivity.setTopTitle(getString(R.string.purchase_register));
        topActivity.setBtnBackOnClickListener(this);
        topActivity.setRightBtnVisibility(View.VISIBLE);
        topActivity.setRightBtnStyle(getString(R.string.btn_submit_save));
        topActivity.setRightBtnOnClickListener(this);
        rightBtn = topActivity.getBtnRight();
        backBtn = topActivity.getBtnBack();
        mInflater = getLayoutInflater();
    }

    /**
     * 初始化动画
     */
    private void initImageView() {
        imageView = (ImageView) findViewById(R.id.cursor);
        bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度
        
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;// 获取分辨率宽度
        offset = (screenW / 2 - bmpW) / 2;// 计算偏移量
        Matrix matrix = new Matrix();
        matrix.postTranslate(offset, 0);
        imageView.setImageMatrix(matrix);// 设置动画初始位置
    }	
    	
    /** 
     * 初始化头标
     */	
    private void initTextView() {
        tv1 = (TextView) findViewById(R.id.tv_apply_info);
        tv2 = (TextView) findViewById(R.id.tv_apply_details);
        tv1.setText(R.string.purchase_info);
        tv2.setText(R.string.purchase_detail);
        tv1.setOnClickListener(new MyOnClickListener(0));
        tv2.setOnClickListener(new MyOnClickListener(1));
    }


    /**
     * 方法说明：<br>
     * 初始化 页卡
     */
    private void initViewPager() {
        mViewPager = (ViewPager) findViewById(R.id.vp_pager);
        views = new ArrayList<View>();

        view1 = mInflater.inflate(R.layout.apply_purchase, null);
        view2 = mInflater.inflate(R.layout.apply_goods_details, null);

        views.add(view1);
        views.add(view2);
        mViewPager.setAdapter(new MyViewPagerAdapter(views));
        mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
        et_purchase_title = (EditText) view1.findViewById(R.id.et_purchase_title);
        tv_purchase_proposer = (TextView) view1.findViewById(R.id.tv_purchase_proposer);
        tv_purchase_time = (TextView) view1.findViewById(R.id.tv_purchase_time);
        et_purchase_reason = (EditText) view1.findViewById(R.id.et_text_sqreason);
        et_purchase_complete_time = (EditText) view1.findViewById(R.id.et_purchase_complete_time);
        tv_purchase_type = (TextView) view1.findViewById(R.id.tv_purchase_type);
        typeLay = (LinearLayout) view1.findViewById(R.id.purchase_type_lay);
        et_purchase_type = (EditText) view1.findViewById(R.id.et_purchase_type);
        payLay = (LinearLayout) view1.findViewById(R.id.purchase_pay_lay);
        et_purchase_pay = (EditText) view1.findViewById(R.id.et_purchase_pay);
        et_purchase_details = (EditText) view1.findViewById(R.id.et_purchase_details);
        tv_purchase_pay = (TextView) view1.findViewById(R.id.tv_purchase_pay);
        fileListLay = (LinearLayout) view1.findViewById(R.id.ll_file_wrap);
        tv_file_group = (TextView) view1.findViewById(R.id.tv_file_group);
        tv_file_group.setTag(true);
		tv_file_group.setVisibility(View.VISIBLE);
        fileUploadBtn = (Button) view1.findViewById(R.id.btn_upload);
        tv_purchase_pay.setVisibility(View.VISIBLE);
        tv_purchase_type.setText(UIHelper.getPurchaseApplyType(ApplyPurchaseActivity.this,String.valueOf(tv_purchase_type.getTag())));
        tv_purchase_pay.setText(UIHelper.getPayApplyType(ApplyPurchaseActivity.this,String.valueOf(tv_purchase_pay.getTag())));
        tv_purchase_proposer.setText(SystemContext.getUserName());
        tv_purchase_time.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT));
        et_purchase_complete_time.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT));
        et_purchase_complete_time.setOnClickListener(this);
        tv_purchase_type.setOnClickListener(this);
        tv_purchase_pay.setOnClickListener(this);
        tv_file_group.setOnClickListener(this);
        fileUploadBtn.setOnClickListener(this);

        scrollView = (ScrollView) view2.findViewById(R.id.scrollView);
        tv_add_goods_apply = (TextView) view2.findViewById(R.id.tv_add_goods_apply);
        apply_list_lay = (LinearLayout) view2.findViewById(R.id.apply_list_lay);
        sumLay = (LinearLayout) view2.findViewById(R.id.sum_price_lay);
        sumLay.setVisibility(View.VISIBLE);
        sumTxt = (TextView) view2.findViewById(R.id.purchase_sum_txt);
        tv_add_goods_apply.setOnClickListener(this);
        if (detail != null) {
        	et_purchase_title.setText(detail.getPurchaseTitle());
        	et_purchase_reason.setText(detail.getPurchaseReason());
        	et_purchase_complete_time.setText(detail.getPurchaseDate());
        	String type = BeanUtils.floatToInt4Str(detail.getPurchaseType());
        	if (type.equals("0") || type.equals("1")) {
        		tv_purchase_type.setText(UIHelper.getPurchaseApplyType(ApplyPurchaseActivity.this,type));
        		tv_purchase_type.setTag(type);
    		} else {
    			tv_purchase_type.setText(detail.getPurchaseTypeName());
    			tv_purchase_type.setTag(type);
    			et_purchase_type.setText(detail.getPurchaseTypeName());
    		}
        	String pay = BeanUtils.floatToInt4Str(detail.getPayMode());
        	if (pay.equals("0") || pay.equals("1") || pay.equals("2")) {
        		tv_purchase_pay.setText(UIHelper.getPayApplyType(ApplyPurchaseActivity.this,pay));
        		tv_purchase_pay.setTag(pay);
    		} else {
    			tv_purchase_pay.setText(detail.getPayModeName());
    			tv_purchase_pay.setTag(pay);
    			et_purchase_pay.setText(detail.getPayModeName());
    		}
        	et_purchase_details.setText(detail.getRemark());
        	if (detail.getDetails() != null) {
        		int size = detail.getDetails().size();
        		showPurchaseDetail(detail.getDetails());
        		for (int i = 0; i < size; i++) {
    				LinearLayout child = (LinearLayout) apply_list_lay.getChildAt(i);
    				EditText et_goods_name = (EditText) child.findViewById(R.id.et_goods_name);
    				EditText et_goods_remark = (EditText) child.findViewById(R.id.et_goods_remark);
    				EditText et_goods_counts = (EditText) child.findViewById(R.id.et_goods_counts);
    				EditText et_goods_unit = (EditText) child.findViewById(R.id.et_goods_unit);
    				EditText et_goods_price = (EditText) child.findViewById(R.id.et_goods_price);
    				TextView tv_goods_total = (TextView) child.findViewById(R.id.tv_goods_total);
    				List<PurchaseApply.PurchaseDetail> purchaseDetail = detail.getDetails();
    				et_goods_name.setText(purchaseDetail.get(i).getPurchaseName());
    				et_goods_remark.setText(purchaseDetail.get(i).getSpec());
    				et_goods_counts.setText(purchaseDetail.get(i).getQuantity());
    				et_goods_unit.setText(purchaseDetail.get(i).getUnit());
    				et_goods_price.setText(purchaseDetail.get(i).getUnitPrice());
    				tv_goods_total.setText(purchaseDetail.get(i).getTotalPrice());
    				
    			}
        	}
        }
    }

    /**
     * 保存申领
     */
    private void sendSaveRequest(PurchaseApply purchase) {
        ApiRequest request = OAServicesHandler.savePurchase(purchase);
        if (request != null) {
            request.setMessage(getString(R.string.system_commit_message));
            helper.invokeWidthDialog(request, callBack, REQUEST_SAVE_PURCHASE);
        }
    }


    private class MyOnClickListener implements View.OnClickListener {
        private int index=0;
        public MyOnClickListener(int i){
            index=i;
        }
        public void onClick(View v) {
            mViewPager.setCurrentItem(index);
        }
    }


    public class MyViewPagerAdapter extends PagerAdapter {
        private List<View> mListViews;

        public MyViewPagerAdapter(List<View> mListViews){
            this.mListViews = mListViews;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object){
            container.removeView(mListViews.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(mListViews.get(position), 0);

            if(currIndex==0){
                UIHelper.setTabTextHighlight(mContext, tv1, tv2);
            }

            return mListViews.get(position);
        }

        @Override
        public int getCount() {
            return  mListViews.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0==arg1;
        }
    }



    public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {
        int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

        public void onPageScrollStateChanged(int arg0) {

        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        public void onPageSelected(int arg0) {
            Animation animation = new TranslateAnimation(one*currIndex, one*arg0, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);// True:图片停在动画结束位置
            animation.setDuration(300);
            imageView.startAnimation(animation);

            if(currIndex==0){
                UIHelper.setTabTextHighlight(mContext, tv1, tv2);

            }else if(currIndex==1){
                UIHelper.hideKeyboard(ApplyPurchaseActivity.this);	//隐藏软键盘
                UIHelper.setTabTextHighlight(mContext, tv2, tv1);
            }
        }
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            ResultItem item = response.getResultItem(ResultItem.class);
            Log.i("TEST", " callBack ");
            if (checkResult(item)) {
                String code = item.getString("code");
                String message = item.getString("message");
                if (Constants.SUCCESS_CODE.equals(code)) {
                	 Log.i("TEST", " callBack 2 ");
					if (fileListLay.getChildCount() > 0 && REQUEST_SAVE_PURCHASE == what) {
						Log.i("TEST", " callBack 3 ");
						String documentId = null;
						String swfNo = null;
						List<DocFileInfo> fileList = null;
						if (null != detail) {
							Log.i("TEST", " callBack 4 ");
							documentId = detail.getDocumentId();
							fileList = detail.getFiles();
						} else {
							Log.i("TEST", " callBack 5 ");
							List<ResultItem> items = item.getItems("data");
							documentId = items.get(0).getString("DOCUMENT_ID");
							swfNo = items.get(0).getString("SWF_NO");
							Log.i("TEST", " swfNo "+swfNo);
							System.out.println("数据解析是否成功！！ swfNo "+swfNo+" documentId "+documentId);
//							documentId = item.getString("DOCUMENT_ID");
						}
						uploadFile(documentId, swfNo, fileListLay, mHanlder, UPLOAD_FILE, fileList);
                    }
					UIHelper.showMessage(mContext, message);
					ApplyPurchaseActivity.this.finish();
                } else {
                    rightBtn.setEnabled(true);
                    UIHelper.showMessage(mContext, message);
                }
            }
        }

        @Override
        public void onReturnError(HttpResponse response, ResultItem error,
                                  int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_data_error_message));
        }

        @Override
        public void onNetError(int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_net_error_message));
        }

    };

    @Override
    public void onClick(View view) {
        if (backBtn == view) {
            finish();
        } else if(rightBtn == view) {
            if (!validateApply()) {
                return;
            }
            sendSaveRequest(purchaseApply);
        } else if(et_purchase_complete_time == view) {
            UIHelper.showTimeSelect(mContext, et_purchase_complete_time, DateUtils.DATE_FORMAT);
        } else if(tv_purchase_type == view) {
            UIHelper.showPurchaseApplyType(mContext, tv_purchase_type, typeLay);
        } else if(tv_add_goods_apply == view) {
            addContent(apply_list_lay.getChildCount(), null);
            scrollToBottom();
        } else if (tv_purchase_pay == view) {
            UIHelper.showPayApplyType(this, tv_purchase_pay, payLay);
        } else if (fileUploadBtn == view) {
        	// 点击添加附件
            UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
        } else if (tv_file_group == view) {
        	UIHelper.isOpenFile(mContext, tv_file_group, fileListLay);
        }
    }

    @Override
    public boolean onLongClick(final View v) {
        UIHelper.vibrate(mContext, 50);	//震动下
        if(v.getId() == R.id.rl_add_item_wrap){
            final SystemDialog chooseDialog = new SystemDialog(mContext);
            chooseDialog.setMessage("确定要删除这条附件？");
            chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
                @Override
                public void onClick(View view) {
                    int fileSize = fileListLay.getChildCount();
                    if(fileSize > 0){
                        DocFileInfo bean = (DocFileInfo) v.getTag();
                        if(bean==null) return;

                        for(int i=0; i<fileSize; i++){
                            View fileView = fileListLay.getChildAt(i);
                            if(fileView==null){
                                continue;
                            }
                            TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
                            String tempPath = (String) tvFileName.getTag();
                            if(bean.getFilePath().equals(tempPath)){	//如果按钮相等，则删除这条数据
                                fileListLay.removeViewAt(i);
                            }
                        }
                    }
                }
            });
            chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
                @Override
                public void onClick(View v) {
                    if(chooseDialog!=null){
                        chooseDialog.dismiss();
                    }
                }
            });
            chooseDialog.show();
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == SDCardFileExplorerActivity.REQUEST_CODE_FILE && data!=null){
            String fileName = data.getStringExtra("FILE_NAME");
            String filePath = data.getStringExtra("FILE_PATH");
            UIHelper.setFileWrap(mContext, fileListLay, this, this, fileName, filePath, "", "");
            if(fileListLay != null && fileListLay.getChildCount() > 0){
                tv_file_group.setVisibility(View.VISIBLE);
            }
        }
    }
    
    /** 附件上传 */
    private void uploadFile(String documentId, String swfNo, LinearLayout llFileWrap, Handler handler, int what, List<DocFileInfo> fileList){
        if(llFileWrap!=null){
            int fileCount = llFileWrap.getChildCount();
            if(fileCount>0){
                List<File> files = new ArrayList<File>();
                for(int i = 0; i < fileCount; i++){
                    View view = llFileWrap.getChildAt(i);
                    TextView tv = (TextView) view.findViewById(R.id.tv_file_name);
                    String path = (String) tv.getTag();

                    File file = new File(path);
					if (file != null && file.exists()) {
                        if (!BeanUtils.isEmpty(fileList)) {
                            for (DocFileInfo temp : fileList) {
                                if (tv.getText().toString().trim().equals(temp.getFileName())) {
                                    continue;
                                }
                            }
                        }
                        files.add(file);
                    }
                }

                UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadFile", documentId, swfNo, "", what);
                params.setListFile(files);
                HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
                post.execute(params);
            }
        }
    }
    
    private PurchaseApply purchaseApply;

    private boolean setPurchaseDetail() {
        ArrayList<PurchaseApply.PurchaseDetail> details = new ArrayList<PurchaseApply.PurchaseDetail>();
        PurchaseApply.PurchaseDetail temp = null;
        for (int i = 0; i < apply_list_lay.getChildCount(); i++) {
            LinearLayout child = (LinearLayout) apply_list_lay.getChildAt(i);
            String goods_name = ((EditText) child.findViewById(R.id.et_goods_name)).getText().toString();
            String purchaseSpec = ((EditText) child.findViewById(R.id.et_goods_remark)).getText().toString();
            String purchaseQua = ((EditText) child.findViewById(R.id.et_goods_counts)).getText().toString();
            String purchaseUnit = ((EditText) child.findViewById(R.id.et_goods_unit)).getText().toString();
            String purchasePrice = ((EditText) child.findViewById(R.id.et_goods_price)).getText().toString();
            String purchaseTotal = ((TextView) child.findViewById(R.id.tv_goods_total)).getText().toString();
//            if (BeanUtils.isNullOrEmpty(goods_name) && BeanUtils.isNullOrEmpty(purchaseSpec) && BeanUtils.isNullOrEmpty(purchaseQua)
//                    && BeanUtils.isNullOrEmpty(purchaseUnit) && BeanUtils.isNullOrEmpty(purchasePrice) && BeanUtils.isNullOrEmpty(purchaseTotal)) {
//                continue;
//            }
            if (BeanUtils.isNullOrEmpty(goods_name)) {
                Toast.makeText(this, R.string.purchase_apply_detail_name_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
            if (BeanUtils.isNullOrEmpty(purchasePrice)) {
                Toast.makeText(this, R.string.purchase_apply_detail_price_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
            if (BeanUtils.isNullOrEmpty(purchaseQua)) {
                Toast.makeText(this, R.string.purchase_apply_detail_quantity_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
            temp = purchaseApply.new PurchaseDetail();
            temp.setPurchaseName(goods_name);
            temp.setQuantity(purchaseQua);
            temp.setSpec(purchaseSpec);
            temp.setTotalPrice(purchaseTotal);
            temp.setUnit(purchaseUnit);
            temp.setUnitPrice(purchasePrice);
            details.add(temp);
        }
        purchaseApply.setDetails(details);
        return true;
    }
    
    private boolean validateApply() {
        String title = et_purchase_title.getText().toString().trim();
        String reason = et_purchase_reason.getText().toString().trim();
        String typeName = et_purchase_type.getText().toString();
        String payName = et_purchase_pay.getText().toString();
        if (BeanUtils.isNullOrEmpty(title)) {
            Toast.makeText(this, R.string.purchase_apply_title_not_null, Toast.LENGTH_SHORT).show();
            return false;
        }
        if (BeanUtils.isNullOrEmpty(reason)) {
            Toast.makeText(this, R.string.purchase_apply_reason_not_null, Toast.LENGTH_SHORT).show();
            return false;
        }
        if (typeLay.getVisibility() == View.VISIBLE) {
            if (BeanUtils.isNullOrEmpty(typeName)) {
                Toast.makeText(this, R.string.purchase_apply_type_name_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        if (payLay.getVisibility() == View.VISIBLE) {
            if (BeanUtils.isNullOrEmpty(payName)) {
                Toast.makeText(this, R.string.purchase_apply_pay_name_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        if (apply_list_lay.getChildCount() <= 0) {
            if (BeanUtils.isEmpty(apply_list_lay)) {
                Toast.makeText(this, R.string.purchase_apply_detail_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        if (purchaseApply == null) {
        	purchaseApply = new PurchaseApply();
        }
        if (!setPurchaseDetail()) {
            return false;
        }
        
        purchaseApply.setPurchaseId(detail == null ? "0" : detail.getPurchaseId());
        purchaseApply.setPurchaseTitle(title);
        purchaseApply.setPurchaseReason(reason);
        purchaseApply.setRemark(et_purchase_details.getText().toString());
        purchaseApply.setPayMode((String) tv_purchase_pay.getTag());
        purchaseApply.setPayModeName(payName);
        purchaseApply.setPurchaseDate(et_purchase_complete_time.getText().toString());
        purchaseApply.setPurchaseType((String) tv_purchase_type.getTag());
        purchaseApply.setPurchaseTypeName(typeName);
        return true;
    }

    //编辑界面，显示已有的工作列表信息
    private void showPurchaseDetail(List<PurchaseApply.PurchaseDetail> list) {
        if (BeanUtils.isEmpty(list)) {
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            addContent(i, list.get(i));
        }
    }

    //初始化显示view
    private void initContentView(int count) {
        if (apply_list_lay.getChildCount() > 0) {
            apply_list_lay.removeAllViews();
        }
        for (int i = 0; i < count; i++) {
            addContent(i, null);
        }
        scrollToBottom();
    }

    //新增一个view
    private void addContent(int index, PurchaseDetail detail) {
        LinearLayout layout = (LinearLayout) mInflater.inflate(R.layout.apply_purchase_detail_item, null);
        EditText tv_goods_name = (EditText) layout.findViewById(R.id.et_goods_name);
        ImageView iv_delete = (ImageView) layout.findViewById(R.id.iv_delete);
        EditText purchaseSpec = (EditText) layout.findViewById(R.id.et_goods_remark);
        final EditText purchaseQua = (EditText) layout.findViewById(R.id.et_goods_counts);
        final EditText purchaseUnit = (EditText) layout.findViewById(R.id.et_goods_unit);
        final EditText purchasePrice = (EditText) layout.findViewById(R.id.et_goods_price);
        final TextView purchaseTotal = (TextView) layout.findViewById(R.id.tv_goods_total);
        setRemoveListener(iv_delete, index);
        totalTxt.add(purchaseTotal);
        apply_list_lay.addView(layout);
        purchasePrice.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!BeanUtils.isNullOrEmpty(purchasePrice.getText().toString())
                        && !BeanUtils.isNullOrEmpty(purchaseQua.getText().toString())) {
                    int price = Integer.valueOf(purchasePrice.getText().toString());
                    int quan = Integer.valueOf(purchaseQua.getText().toString());
                    purchaseTotal.setText(String.valueOf(price * quan));
                } else {
                    purchaseTotal.setText("");
                }
                sumPrice();
            }
        });
        purchaseQua.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!BeanUtils.isNullOrEmpty(purchasePrice.getText().toString())
                        && !BeanUtils.isNullOrEmpty(purchaseQua.getText().toString())) {
                    int price = Integer.valueOf(purchasePrice.getText().toString());
                    int quan = Integer.valueOf(purchaseQua.getText().toString());
                    purchaseTotal.setText(String.valueOf(price * quan));
                } else {
                    purchaseTotal.setText("");
                }
                sumPrice();
            }
        });
    }

    //统计总价格
    private void sumPrice() {
        int sum = 0;
        if (!BeanUtils.isEmpty(totalTxt)) {
            for (TextView txt : totalTxt) {
                if (!BeanUtils.isNullOrEmpty(txt.getText().toString())) {
                    sum += Integer.valueOf(txt.getText().toString());
                }
            }
        }
        if (sum > 0) {
            sumTxt.setText(String.valueOf(sum));
        }
    }

    //当view的个数变化时，到最底下显示
    private void scrollToBottom() {
        mHanlder.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    //修改删除或新增后，提示的显示
    private void changeIndex() {
        LinearLayout layout = null;
        for (int i = 0; i < apply_list_lay.getChildCount(); i++) {
            layout = ((LinearLayout) apply_list_lay.getChildAt(i));
            ImageView img = (ImageView) layout.findViewById(R.id.iv_delete);
            setRemoveListener(img, i);
        }
        scrollToBottom();
    }

    //设置删除事件和删除后view的显示
    private void setRemoveListener(ImageView img, final int size) {
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (apply_list_lay.getChildCount() > size && size > 0) {
                    Logger.d(TAG, "remove index: " + size + "   " + view.getRootView());
                    apply_list_lay.removeViewAt(size);
                    totalTxt.remove(size);
                    changeIndex();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (apply_list_lay.getChildCount() > 0) {
            apply_list_lay.removeAllViews();
        }
        if (null != totalTxt) {
            totalTxt.clear();
        }
        if (null != views) {
            views.clear();
        }
    }

}
