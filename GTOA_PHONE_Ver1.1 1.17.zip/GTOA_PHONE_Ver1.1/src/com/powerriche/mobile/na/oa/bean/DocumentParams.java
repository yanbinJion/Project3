package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

import com.powerriche.mobile.oa.common.ResultItem;

/**
 * 类描述：<br> 
 * 办理送出传递参数
 * @author  Fitz
 * @date    2015年5月26日
 * @version v1.0
 */
public class DocumentParams implements Serializable{

	private static final long serialVersionUID = 5666081527436672940L;
	
	public DocumentParams(){}

	public DocumentParams(String swfNo, String fpuNo, String wfNo, String traceNo, String documentId){
		this.swfNo = swfNo;
		this.fpuNo = fpuNo;
		this.wfNo = wfNo;
		this.traceNo = traceNo;
		this.documentId = documentId;
	}
	
	private String swfNo;
	private String fpuNo;
	private String wfNo;
	private String traceNo;
	private String documentId;
	private String passreadId;
	private String isPassRead;
	private int isBackFlag;
	
	private ResultItem resultItem;

	public String getSwfNo() {
		return swfNo;
	}

	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}

	public String getFpuNo() {
		return fpuNo;
	}

	public void setFpuNo(String fpuNo) {
		this.fpuNo = fpuNo;
	}

	public String getWfNo() {
		return wfNo;
	}

	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}

	public String getTraceNo() {
		return traceNo;
	}

	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getPassreadId() {
		return passreadId;
	}

	public void setPassreadId(String passreadId) {
		this.passreadId = passreadId;
	}

	public String getIsPassRead() {
		return isPassRead;
	}

	public void setIsPassRead(String isPassRead) {
		this.isPassRead = isPassRead;
	}

	public int getIsBackFlag() {
		return isBackFlag;
	}

	public void setIsBackFlag(int isBackFlag) {
		this.isBackFlag = isBackFlag;
	}

	public ResultItem getResultItem() {
		return resultItem;
	}

	public void setResultItem(ResultItem resultItem) {
		this.resultItem = resultItem;
	}

}
