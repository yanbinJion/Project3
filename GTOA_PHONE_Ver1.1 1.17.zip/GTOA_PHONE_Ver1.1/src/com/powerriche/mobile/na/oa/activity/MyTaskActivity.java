package com.powerriche.mobile.na.oa.activity;
	
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.ReceiverTaskHelper;
import com.powerriche.mobile.na.oa.activity.document.SendTaskHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.TemperCache;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
	
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
	
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
	
/**	
 * Created by root on 16-5-5.
 */ 
public class MyTaskActivity extends BaseActivity implements View.OnClickListener{
	
    private TopActivity topActivity;
    
    private TextView sendTaskTxt;
    private TextView receiverTaskTxt;
    private TextView queryTaskTxt;
    
    private ViewPager mViewPager;
    private ImageView imageView;// 动画图片
    
    private View view1, view2, view3;
    
    private List<View> views;// Tab页面列表
    private int offset = 0;// 动画图片偏移量
    private int currIndex = 0;// 当前页卡编号
    private int bmpW;// 动画图片宽度
    private Button addBtn;
    
    //---------发文相关控件及变量-------------
    private PullToRefreshListView pullViewSend;
    private ListView listViewSend;
    private TextView tvNoDataMsgSend;
    private int pageIndexSend = 1;
    private SendTaskHelper sendTaskHelper;
    
    private PullToRefreshListView pullViewReceiver;
    private ListView listViewReceiver;
    private TextView tvNoDataMsgReceiver;
    private int pageIndexReceiver = 1;
    private ReceiverTaskHelper receiverTaskHelper;
    
    private Button queryBtn;
    private EditText taskNoEdt;
    private EditText beginTimeEdt;
    private EditText endTimeEdt;
    private RadioGroup duringRadio;
    private RadioGroup statusRadio;
    private SearchBarWidget searchTitle;
    private String taskDuring;
    private String taskStatus;
    private String taskDirect;
    
    private RadioButton registerRadio;
    private RadioButton planRadio;
    private RadioButton dispatcherRadio;
    private RadioButton unfinishedRadio;
    private RadioButton finishRadio;
    
    private RadioGroup directGroup;
    private RadioButton sendRadio;
    private RadioButton receiverRadio;
    
    //设置radiogroup的监听事件
    private RadioGroup.OnCheckedChangeListener changeListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int id) {
            if (radioGroup == duringRadio) {
                if (id == registerRadio.getId()) {
                    taskDuring = registerRadio.getTag().toString();
                } else if (id == planRadio.getId()) {
                    taskDuring = planRadio.getTag().toString();
                } else {
                    taskDuring = dispatcherRadio.getTag().toString();
                }
            } else if (radioGroup == statusRadio) {
                if (id == unfinishedRadio.getId()) {
                    taskStatus = unfinishedRadio.getTag().toString();
                } else {
                    taskStatus = finishRadio.getTag().toString();
                }
            } else if (radioGroup == directGroup) {
                if (id == sendRadio.getId()) {
                    taskDirect = sendRadio.getTag().toString();
                } else {
                    taskDirect = receiverRadio.getTag().toString();
                }
            }
        }
    };	
    	
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.my_task_layout);
        bindView();
        initImageView();
        initViewPager();
        initView();
        initReceiverView();
        TemperCache.getInstance().clearTaskList();
    }			  
    		      
    /** 		  
     * 初始化界面控件   
     * */		 
    private void bindView() {
        // 设置顶部的标题栏
        topActivity = (TopActivity) findViewById(R.id.top_activity);
        topActivity.setBtnBackOnClickListener(this);
        topActivity.setTopTitle(getString(R.string.menu_mytask));// 顶部栏的中间标题
        topActivity.setRightBtnVisibility(View.VISIBLE);// 隐藏右边按钮
        topActivity.setRightBtnVisibility(View.VISIBLE);//显示右边按钮
        topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
        addBtn = topActivity.getBtnRight();
        addBtn.setOnClickListener(this);
        		   
        sendTaskTxt = (TextView) findViewById(R.id.send_task_txt);
        receiverTaskTxt = (TextView) findViewById(R.id.reciver_task_txt);
        queryTaskTxt = (TextView) findViewById(R.id.query_task_txt);
        mViewPager = (ViewPager) findViewById(R.id.my_task_viewPager);
        		  
    }			  
    			  
    /** 初始化动画 */ 
    private void initImageView() {
        imageView = (ImageView) findViewById(R.id.cursor);
        bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度
        	   
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;// 获取分辨率宽度
        offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
        Matrix matrix = new Matrix();
        matrix.postTranslate(offset, 0);
        imageView.setImageMatrix(matrix);// 设置动画初始位置
               
    }		    
    		    
    private void initViewPager() {
        views = new ArrayList<View>();
        LayoutInflater inflater = getLayoutInflater();
             
        view1 = inflater.inflate(R.layout.my_task_list_layout, null);
        view2 = inflater.inflate(R.layout.my_task_list_layout, null);
        view3 = inflater.inflate(R.layout.my_task_search_layout, null);
        views.add(view1);
        views.add(view2);
        views.add(view3);
        mViewPager.setAdapter(new MyViewPagerAdapter(views));
        mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
        sendTaskTxt.setOnClickListener(new MyOnClickListener(0));
        receiverTaskTxt.setOnClickListener(new MyOnClickListener(1));
        queryTaskTxt.setOnClickListener(new MyOnClickListener(2));
        	
        queryBtn = (Button) view3.findViewById(R.id.task_search_btn);
        queryBtn.setOnClickListener(this);
        
        beginTimeEdt = (EditText) view3.findViewById(R.id.task_from_time_edt);
        beginTimeEdt.setOnClickListener(this);
        endTimeEdt = (EditText) view3.findViewById(R.id.task_to_time_edt);
        endTimeEdt.setOnClickListener(this);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT);
        beginTimeEdt.setText(sdf.format(calendar.getTime()));
        endTimeEdt.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT));
        searchTitle = (SearchBarWidget) view3.findViewById(R.id.my_task_search);
        taskNoEdt = (EditText) view3.findViewById(R.id.task_no_edt);
        statusRadio = (RadioGroup) view3.findViewById(R.id.status_radioGroup);
        duringRadio = (RadioGroup) view3.findViewById(R.id.duiring_radioGroup);
        searchTitle.getEditTextSearch().setHint(getString(R.string.common_search_hint));
        		
        registerRadio = (RadioButton) view3.findViewById(R.id.register_radio);
        planRadio = (RadioButton) view3.findViewById(R.id.plan_radio);
        dispatcherRadio = (RadioButton) view3.findViewById(R.id.dispatcher_radio);
        unfinishedRadio = (RadioButton) view3.findViewById(R.id.unfinish_radio);
        finishRadio = (RadioButton) view3.findViewById(R.id.finished_radio);
        directGroup = (RadioGroup) view3.findViewById(R.id.task_direct_radioGroup);
        sendRadio = (RadioButton) view3.findViewById(R.id.send_radio);
        receiverRadio = (RadioButton) view3.findViewById(R.id.receiver_radio);
        		
        taskDuring = registerRadio.getTag().toString();
        taskStatus = unfinishedRadio.getTag().toString();
        taskDirect = sendRadio.getTag().toString();
        statusRadio.setOnCheckedChangeListener(changeListener);
        duringRadio.setOnCheckedChangeListener(changeListener);
        directGroup.setOnCheckedChangeListener(changeListener);
        		
    }			
    			
    /**			
     * 初始化控件     
     */ 		
    private void initView(){
        pullViewSend = (PullToRefreshListView) view1.findViewById(R.id.my_task_pulllistview);
        pullViewSend.setPullRefreshEnabled(true);
        pullViewSend.setPullLoadEnabled(false);
        pullViewSend.setScrollLoadEnabled(true);
        		
        listViewSend = pullViewSend.getRefreshableView();
        UIHelper.setListViewAttribute(listViewSend);
        		
        pullViewSend.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
                pageIndexSend = 1;
                sendTaskHelper.loadData(Constants.OPT_TYPE_SEND_TASK, Constants.WHAT_REQUEST_SEND_TASK, pageIndexSend, false);
            }	
            	
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
                pageIndexSend = pageIndexSend + 1;
                sendTaskHelper.loadData(Constants.OPT_TYPE_SEND_TASK, Constants.WHAT_REQUEST_SEND_TASK, pageIndexSend, false);
            }	
        });		
        tvNoDataMsgSend = (TextView) view1.findViewById(R.id.tv_no_data_msg);
        tvNoDataMsgSend.setVisibility(View.GONE);
        		
        View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
        listViewSend.addHeaderView(header);
        		
        //初始化帮助类
        sendTaskHelper = new SendTaskHelper(this, header, tvNoDataMsgSend, pullViewSend, listViewSend, callBack, helper);
    }			
    			
    void initReceiverView(){
        pullViewReceiver = (PullToRefreshListView) view2.findViewById(R.id.my_task_pulllistview);
        pullViewReceiver.setPullRefreshEnabled(true);
        pullViewReceiver.setPullLoadEnabled(false);
        pullViewReceiver.setScrollLoadEnabled(true);
        		
        listViewReceiver = pullViewReceiver.getRefreshableView();
        UIHelper.setListViewAttribute(listViewReceiver);
        		
        pullViewReceiver.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
                pageIndexReceiver = 1;
                receiverTaskHelper.loadData(Constants.OPT_TYPE_RECEIVER_TASK, Constants.WHAT_REQUEST_RECEIVER_TASK, pageIndexReceiver, false);
            }	
            	
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
                pageIndexReceiver = pageIndexReceiver + 1;
                receiverTaskHelper.loadData(Constants.OPT_TYPE_RECEIVER_TASK, Constants.WHAT_REQUEST_RECEIVER_TASK, pageIndexReceiver, false);
            }	
        }); 	
        tvNoDataMsgReceiver = (TextView) view2.findViewById(R.id.tv_no_data_msg);
        tvNoDataMsgReceiver.setVisibility(View.GONE);
        		
        View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
        listViewReceiver.addHeaderView(header);
            	
        //初始化帮助类
        receiverTaskHelper = new ReceiverTaskHelper(this, header, tvNoDataMsgReceiver, pullViewReceiver, listViewReceiver, callBack, helper);
    }			
    			
    private void loadSendData() {
        pageIndexSend = 1;
        sendTaskHelper.loadData(Constants.OPT_TYPE_SEND_TASK, Constants.WHAT_REQUEST_SEND_TASK, pageIndexSend, false);
    }				
    				
    private void loadReceiverData() {
        pageIndexReceiver = 1;
        receiverTaskHelper.loadData(Constants.OPT_TYPE_RECEIVER_TASK, Constants.WHAT_REQUEST_RECEIVER_TASK, pageIndexReceiver, false);
    }				
    				
    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override   
        public void process(HttpResponse response, int what) {
            if (what == Constants.WHAT_REQUEST_SEND_TASK) {
                sendTaskHelper.process(response, what);
            } else {
                receiverTaskHelper.process(response, what);
            }       
        }			
    };				
    				
    @Override   	
    public void onClick(View v) {
        Button back = topActivity.getBtnBack();
        if (v == back) {
            finish();
        } else if (v == beginTimeEdt || v == endTimeEdt) {
            UIHelper.showTimeSelect(this, (EditText) v, DateUtils.DATE_FORMAT);
        } else if (v == addBtn) {
            startActivity(new Intent(this, AddTaskActivity.class));
        } else if (v == queryBtn) {
            Intent intent = new Intent(this, TaskSearchResultActivity.class);
            intent.putExtra("taskTitle", searchTitle.getEditTextSearch().getText().toString().trim());
//            intent.putExtra("taskTitle", "cs");
            intent.putExtra("taskNo", taskNoEdt.getText().toString().trim());
//            intent.putExtra("taskTime", beginTimeEdt.getText().toString().trim());
            intent.putExtra("taskDuring", taskDuring);
            intent.putExtra("taskStatus", taskStatus);
            intent.putExtra("taskDirect", taskDirect);
            intent.putExtra("beginTime", beginTimeEdt.getText().toString().trim());
            intent.putExtra("endTime", endTimeEdt.getText().toString().trim());
            startActivity(intent);
        }	
    }		
    		
    
    @Override
    public void onResume() {
    	super.onResume();
    	if (currIndex == 0) {
    		if (null == sendTaskHelper) {
    			initView();
    			return;
    		}
    		loadSendData();
    	} else if (currIndex == 1) {
    		if (null == receiverTaskHelper) {
    			initReceiverView();
    			return;
    		}	
    		loadReceiverData();
    	}		
    }			
    			
    @Override	
    public void onDestroy() {
        super.onDestroy();
        if (null != views) {
            views.clear();
        }	
    }		
    		
    private class MyOnClickListener implements View.OnClickListener {
        private int index = 0;
        	
        public MyOnClickListener(int i) {
            index = i;
        }	
        	
        public void onClick(View v) {
            mViewPager.setCurrentItem(index);
        }	
    }		
    		
    public class MyViewPagerAdapter extends PagerAdapter {
        private List<View> mListViews;
        	
        public MyViewPagerAdapter(List<View> mListViews) {
            this.mListViews = mListViews;
        }	
        	
        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(mListViews.get(position));
        }	
        	
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(mListViews.get(position), 0);
            return mListViews.get(position);
        }	
        	
        @Override
        public int getCount() {
            return mListViews.size();
        }	
        	
        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }	
    }   	
    		
    public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {
        int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量
        	
        public void onPageScrollStateChanged(int arg0) {
        	
        }	
        	
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        	
        }	
        	
        public void onPageSelected(int arg0) {
            Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);
            animation.setDuration(300);
            imageView.startAnimation(animation);
            
            if (currIndex == 0) {
                sendTaskTxt.setBackgroundResource(R.drawable.task_send_checked);//“发文”是选中项
                receiverTaskTxt.setBackgroundResource(R.drawable.task_receiver_unchecked);
                queryTaskTxt.setBackgroundResource(R.drawable.task_search_unchecked);
                //显示右上角的按钮
//                enabledRightBtn();
                
            } else if (currIndex == 1) {
                sendTaskTxt.setBackgroundResource(R.drawable.task_send_unchecked);
                receiverTaskTxt.setBackgroundResource(R.drawable.task_receiver_checked);//“来文”是选中项
                queryTaskTxt.setBackgroundResource(R.drawable.task_search_unchecked);
                loadReceiverData();
//                if (isFirst2) {
//                    loadReceiveDocData();
//                    //isFirst2 = false;
//                }
//                //不显示右上角的按钮
//                disableRightBtn();
                
            } else if (currIndex == 2) {
                sendTaskTxt.setBackgroundResource(R.drawable.task_send_unchecked);
                receiverTaskTxt.setBackgroundResource(R.drawable.task_receiver_unchecked);
                queryTaskTxt.setBackgroundResource(R.drawable.task_search_checked);//“已办”是选中项
//                if (isFirst3) {
//                    loadDoneData();
//                    //isFirst3 = false;
//                }
//                //不显示右上角的按钮
//                disableRightBtn();
            }	
        }		
    }			
}				
				