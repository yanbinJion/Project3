package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.DocumentAddHelper;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.TextBodyUtile;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 新建公文 
 * @author  Fitz
 * @date    2015年4月27日
 * @version v1.0
 */
public class DocumentAddActivity extends BaseActivity implements OnClickListener, OnLongClickListener{
	
	public static final int REQUEST_CODE_BASIC = 0;
	public static final int REQUEST_CODE_TEXT = 402;
	public static final int REQUEST_CODE_TEXT_CHILD = 403;
	
	private Context mContext;
	
	private ViewPager viewPager;//页卡内容
	private ImageView imageView;// 动画图片
	
	private TextView tv1, tv2;
	private View view1, view2;
	
	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	
	
	//**********新增公文相关控件---基本信息相关控件*********
	private EditText etTitle, etTextNo, etDepartment, etUserName, etZhaiyao;
	private TextView tvHuanji, tvLevel, tvFileGroup;
	private LinearLayout llFileWrap;
	private TextView tvNewFile;
	
	private DocumentAddHelper documentHelper = null;
	
	private Bundle data;
	
	private Button rightBtn;// 右边的按钮图标
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.document_add);
		
		bindViews();
		registerBroadcast();
		documentHelper = new DocumentAddHelper(mContext, callBack, helper, 0);
	}
	
	private void bindViews(){
	    TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.document_add_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnStyle("保存");
		topActivity.setRightBtnOnClickListener(this);
		rightBtn = topActivity.getBtnRight();
		initImageView();
		initTextView();
		initViewPager();
		
		etTitle = (EditText) view1.findViewById(R.id.et_title); 
		etTitle.requestFocus();
		etTextNo = (EditText) view1.findViewById(R.id.et_text_no); 
		
		etDepartment = (EditText) view1.findViewById(R.id.et_department); 
		etDepartment.setText(SystemContext.getSiteName());	//拟稿单位(部门)
		etUserName = (EditText) view1.findViewById(R.id.et_user_name);
		etUserName.setText(SystemContext.getUserName());	//拟稿人(系统登录用户)
		
		tvHuanji = (TextView) view1.findViewById(R.id.tv_huanji);
		tvHuanji.setOnClickListener(this);
		tvLevel = (TextView) view1.findViewById(R.id.tv_level);
		tvLevel.setOnClickListener(this);
		
		etZhaiyao = (EditText) view1.findViewById(R.id.et_zhaiyao);
		view1.findViewById(R.id.btn_upload).setOnClickListener(this);
		
		llFileWrap = (LinearLayout) view1.findViewById(R.id.ll_file_wrap);
		tvFileGroup = (TextView) view1.findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		tvFileGroup.setVisibility(View.VISIBLE);
		
		view2.findViewById(R.id.btn_new_file).setOnClickListener(this);
		tvNewFile = (TextView) view2.findViewById(R.id.tv_new_file);
	}	
		
		
		
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				UIHelper.deleteTempDoc();	//退出前，删掉临时文件
				finish();
				break;
			case R.id.btn_top_right :// 标题栏的右边按钮
				documentHelper.submit(etTitle, etTextNo, etDepartment, etUserName, tvHuanji, tvLevel, etZhaiyao, REQUEST_CODE_BASIC,rightBtn);
				break;
			case R.id.btn_upload :// 上传附件
				UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
				break;
			case R.id.tv_huanji :// 弹出缓急选择框
				UIHelper.showHuanji(mContext, tvHuanji);
				break;
			case R.id.tv_level :// 弹出级别选择框
				UIHelper.showLevel(mContext, tvLevel);
				break;
			case R.id.btn_new_file :
				UIHelper.openWps(mContext, null, Constants.WPS_NORMAL);
				break;
			case R.id.tv_file_group :
				UIHelper.isOpenFile(mContext, tvFileGroup, llFileWrap);
				break;
		}
		
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode==SDCardFileExplorerActivity.REQUEST_CODE_FILE && data!=null){
			String fileName = data.getStringExtra("FILE_NAME");
			String filePath = data.getStringExtra("FILE_PATH");
			UIHelper.setFileWrap(mContext, llFileWrap, this, this, fileName, filePath, "", "");
			if(llFileWrap!=null && llFileWrap.getChildCount()>0){
				tvFileGroup.setVisibility(View.VISIBLE);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
	private String documentId;
	private String swfNo;
	private String traceNo;
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		private boolean hasTextBodyFile = false;
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			rightBtn.setClickable(true);
			if(checkResult(item)){
				String code = item.getString("code");
				String message = item.getString("message");
				if (what == REQUEST_CODE_BASIC) {
					if(Constants.SUCCESS_CODE.equals(code)){
						
						UIHelper.showMessage(mContext, message);
						//如果保存成功，则判断是否有正文需要上传，如果有先上传正文
						documentId = item.getString("DOCUMENT_ID");	//公文编号
						swfNo = item.getString("SWF_NO");
						traceNo = item.getString("traceNo");
						//封装交互数据：调转到详情页面使用
						data = new Bundle();
						String fpuNo = item.getString("fpuNo"); // 当前环节编号
						String wfNo = item.getString("wfNo"); // 流程编号
						data.putString("documentId", BeanUtils.floatToInt4Str(documentId));//取整
						data.putString("wfNo", BeanUtils.floatToInt4Str(wfNo));//取整
						data.putString("fpuNo", BeanUtils.isEmpty4Get(fpuNo));
						data.putString("swfNo", BeanUtils.isEmpty4Get(swfNo));
						data.putString("traceNo", BeanUtils.floatToInt4Str(traceNo));//取整
						
						String path = Constants.SDCARD_DIR_NEW_FILE.concat(Constants.SDCARD_TEMP_FILE);
						File file = new File(path);
						if(file.exists()){
							hasTextBodyFile = true;
							//正文上传
							documentHelper.uploadDocFile(documentId, swfNo, traceNo, file, REQUEST_CODE_TEXT, handler);
						}
						
						if(!hasTextBodyFile){	//如果没有正文，则开始检查附件上传
							if(llFileWrap.getChildCount()>0){
								documentHelper.uploadFile(documentId, swfNo, llFileWrap, handler, REQUEST_CODE_TEXT_CHILD);
							}else{
								finishActivity();
							}
						}
						
					}else{
						UIHelper.showMessage(mContext, message);
					}	
				}		
			}			
		}				
						
		@Override		
        public void onReturnError(HttpResponse response, ResultItem error,
                int what) {
		    rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_data_error_message));
        }	
			
        @Override
        public void onNetError(int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_net_error_message));
        }	
			
	};		
			
			
	private Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
				
			ResultItem item = (ResultItem) msg.obj;
			String message = item.getString("message");
			if(msg.what == REQUEST_CODE_TEXT){			//上传正文返回
				UIHelper.showMessage(mContext, message);
				
				//描述：上传正文成功后，开始上传附件内容，先判断附件是否有附件内容
//				UIHelper.showMessage(mContext, message);
				if(llFileWrap.getChildCount()>0){
					//附件上传不受正文上传成功失败影响
					documentHelper.uploadFile(documentId, swfNo, llFileWrap, handler, REQUEST_CODE_TEXT_CHILD);
				}else{
					if(Constants.SUCCESS_CODE.equals(item.getString("code"))){
						//上传成功得删掉临时文件
						UIHelper.deleteTempDoc();
						finishActivity();
					}
				}
				
			} else if(msg.what == REQUEST_CODE_TEXT_CHILD){		//上传附件返回
				UIHelper.showMessage(mContext, message);
				finishActivity();
				
			}else{
				if(!BeanUtils.isEmpty(msg.obj)){
					UIHelper.showMessage(mContext, msg.obj.toString());
				}else{
					UIHelper.showMessage(mContext, "不明确的错误");
				}
			}	
		}		
	};			
				
				
	private void finishActivity(){
		TabOfficialActivity.OP_REFRESH = 1;	//主界面恢复的时候，需要刷新数据
		//完成新建之后，就调转到公文详情页面
		UIHelper.forwardTargetActivity(mContext, DocumentDetailActivity.class, data, true);
		
		//this.finish();
	}
	
	
	@Override
	protected void onResume() {
		super.onResume();
	}
	
	
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (saveFileBroadcast != null) {
			unregisterReceiver(saveFileBroadcast);
		}
		mContext = null;
	}
	
	/** 注册广播 */
	private void registerBroadcast() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(TextBodyUtile.ACTION_SAVE_FILE);
		registerReceiver(saveFileBroadcast, filter);
	}
	
	private BroadcastReceiver saveFileBroadcast = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			final String filePath = intent.getExtras().getString("filePath"); // 文件路径
			if (TextBodyUtile.IS_SAVE_FILE && TextBodyUtile.FILE_PATH.equals(filePath)) {
				if(FileUtils.exists(filePath)){
					tvNewFile.setText(getString(R.string.document_open_file)); // 显示打开正文
				}
				TextBodyUtile.IS_SAVE_FILE = false;
				TextBodyUtile.FILE_PATH = "";
			}
		}
	};
	
	
	/**
	 * 初始化动画 
	 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度
		
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 2 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}
	
	/**
	 * 初始化头标
	 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.tv_1);
		tv2 = (TextView) findViewById(R.id.tv_2);

		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
	}
	
	
	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_pager);
		views = new ArrayList<View>();
		LayoutInflater inflater = getLayoutInflater();
		
		view1 = inflater.inflate(R.layout.document_add_basic, null);
		view2 = inflater.inflate(R.layout.document_add_body, null);
		
		views.add(view1);
		views.add(view2);
		viewPager.setAdapter(new MyViewPagerAdapter(views));
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}
	
	
	private class MyOnClickListener implements OnClickListener{
        private int index=0;
        public MyOnClickListener(int i){
        	index=i;
        }
		public void onClick(View v) {
			viewPager.setCurrentItem(index);			
		}
	}
	
	
	public class MyViewPagerAdapter extends PagerAdapter{
		private List<View> mListViews;
		
		public MyViewPagerAdapter(List<View> mListViews){
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object){
			container.removeView(mListViews.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			 container.addView(mListViews.get(position), 0);
			 
			 if(currIndex==0){
				 UIHelper.setTabTextHighlight(mContext, tv1, tv2);
			 }
			 
			 return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return  mListViews.size();
		}
		
		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0==arg1;
		}
	}
	
	
	
    public class MyOnPageChangeListener implements OnPageChangeListener{
    	int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量
		
		public void onPageScrollStateChanged(int arg0) {
			
		}
		
		public void onPageScrolled(int arg0, float arg1, int arg2) { 
			
		}
		
		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one*currIndex, one*arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);// True:图片停在动画结束位置
			animation.setDuration(300);
			imageView.startAnimation(animation);
			
			if(currIndex==0){
				UIHelper.setTabTextHighlight(mContext, tv1, tv2);
				
			}else if(currIndex==1){
				UIHelper.hideKeyboard(DocumentAddActivity.this);	//隐藏软键盘
				UIHelper.setTabTextHighlight(mContext, tv2, tv1);
			}
		}
    }



	@Override
	public boolean onLongClick(final View v) {
		UIHelper.vibrate(mContext, 50);	//震动下
		if(v.getId() == R.id.rl_add_item_wrap){
			final SystemDialog chooseDialog = new SystemDialog(mContext);
			chooseDialog.setMessage("确定要删除这条附件？");
			chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
				@Override
				public void onClick(View view) {
					if(llFileWrap!=null){
						int fileSize = llFileWrap.getChildCount();
						if(fileSize>0){
							DocFileInfo bean = (DocFileInfo) v.getTag();
							if(bean==null) return;
							
							for(int i=0; i<fileSize; i++){
								View fileView = llFileWrap.getChildAt(i);
								if(fileView==null){
									continue;
								}
								TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
								String tempPath = (String) tvFileName.getTag();
								if(bean.getFilePath().equals(tempPath)){	//如果按钮相等，则删除这条数据
									llFileWrap.removeViewAt(i);
								}
							}
						}
					}
				}
			});
			chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
				@Override
				public void onClick(View v) {
					if(chooseDialog!=null){
						chooseDialog.dismiss();
					}
				}
			});
			chooseDialog.show();
		}
		return false;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			UIHelper.deleteTempDoc();
			finish();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
}
