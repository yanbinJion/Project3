package com.powerriche.mobile.na.oa.activity;

import java.io.File;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br>
 * 任务信息：查看显示大图
 * 
 * @author 李运期
 * @date 2015年5月4日
 * @version v1.0
 */
public class TaskReplyShowBigImageActivity extends BaseActivity
		implements
			OnClickListener {

	private static final String TAG = "TaskReplyShowBigImageActivity";

	private Context mContext;

	private ImageView imageview;

	private String localImagePath; // 本地图片路径

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.task_reply_show_big_image);

		bindViews();

		imageview = (ImageView) findViewById(R.id.imageView_show_big);

		localImagePath = getIntent().getStringExtra("localImagePath");
		if (!BeanUtils.isEmpty(localImagePath)) {
			File file = new File(localImagePath);
			if (file != null && file.exists()) {
				Bitmap bmp = BitmapFactory.decodeFile(localImagePath);
				imageview.setImageBitmap((Bitmap) bmp);
			}
		}

	}

	private void bindViews() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.task_show_image));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.GONE);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				finish();
				break;
		}
	}

}
