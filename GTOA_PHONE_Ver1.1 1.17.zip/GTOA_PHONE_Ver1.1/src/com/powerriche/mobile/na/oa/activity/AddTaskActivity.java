package com.powerriche.mobile.na.oa.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.TaskAddHelper;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.TaskDetails;
import com.powerriche.mobile.na.oa.bean.TaskInfo;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by root on 16-5-6.
 */
public class AddTaskActivity extends BaseActivity implements View.OnClickListener, View.OnLongClickListener {

    private static final int TASK_INFO = 0;
    private static final int TASK_EVENT_INFO = 1;
    private int pager;

    private final int mainRequestCode = 1000;
    private final int copyRequestCode = 1001;
    private final int BASIC_REQUEST = 10;
    private final int UPLOAD_FILE = 11;
    private final String TAG = AddTaskActivity.class.getSimpleName();

    private int contentSize = 3;
    private ViewPager mViewPager;
    private ImageView imageView;
    private Context mContext;

    private List<View> views;// Tab页面列表
    private TextView tv1, tv2;
    private View view1, view2;

    private Button rightBtn;// 右边的按钮图标
    private Button backBtn;
    private int offset = 0;// 动画图片偏移量
    private int currIndex = 0;// 当前页卡编号
    private int bmpW;// 动画图片宽度

    private TextView typeTxt;
    private TaskAddHelper addHelper;
    private TaskInfo taskInfo;

    private EditText titleEdt;
    private EditText timeEdt;
    private EditText uploadEdt;
    private TextView yearEdt;
    private EditText receiverEdt;
    private EditText copyEdt;
    private EditText caseEdt;
    private EditText addressEdt;
    private EditText deviceEdt;
    private EditText remarkEdt;
    private TextView addTxt;
    private LinearLayout eventLstLay;

    private Button fileUploadBtn;
    private LinearLayout fileListLay;

    private ScrollView mScroll;

    LayoutInflater mInflater;

    private TaskDetails detail;

    private ArrayList<EditText> contentList = new ArrayList<EditText>();

    private Handler mHanlder = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            if (null == msg) {
                return;
            }
            if (msg.what == UPLOAD_FILE) {
                ResultItem item = (ResultItem) msg.obj;
                String code = item.getString("code");
                String message = item.getString("message");
                UIHelper.showMessage(mContext, message);
                UIHelper.deleteTempDoc();	//退出前，删掉临时文件
                AddTaskActivity.this.finish();
            }
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.task_add_layout);
        Intent intent = getIntent();
        detail = (TaskDetails) intent.getSerializableExtra("taskDetail");
        mContext = this;
        initView();
        initImageView();
        initTextView();
        initViewPager();
        if (null == detail) {
            initContentView(contentSize);
        }
    }

    private void initView() {
        TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
        topActivity.setTopTitle(getString(R.string.task_add_title));
        topActivity.setBtnBackOnClickListener(this);
        topActivity.setRightBtnVisibility(View.VISIBLE);
        topActivity.setRightBtnStyle(getString(R.string.btn_submit_save));
        topActivity.setRightBtnOnClickListener(this);
        rightBtn = topActivity.getBtnRight();
        backBtn = topActivity.getBtnBack();
        
        mInflater = getLayoutInflater();
    }	
    	
    /** 
     * 初始化动画
     */ 
    private void initImageView() {
        imageView = (ImageView) findViewById(R.id.cursor);
        bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度
        
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;// 获取分辨率宽度
        offset = (screenW / 2 - bmpW) / 2;// 计算偏移量
        Matrix matrix = new Matrix();
        matrix.postTranslate(offset, 0);
        imageView.setImageMatrix(matrix);// 设置动画初始位置
    }	
    	
    /** 
     * 初始化头标
     */ 
    	
    private void initTextView() {
        tv1 = (TextView) findViewById(R.id.tv_1);
        tv2 = (TextView) findViewById(R.id.tv_2);
        
        tv1.setOnClickListener(new MyOnClickListener(0));
        tv2.setOnClickListener(new MyOnClickListener(1));
    }	
    	
    	
    /**	
     * 方法说明：<br>
     * 初始化 页卡
     */	
    private void initViewPager() {
        mViewPager = (ViewPager) findViewById(R.id.vp_pager);
        views = new ArrayList<View>();
        
        view1 = mInflater.inflate(R.layout.task_add_base, null);
        view2 = mInflater.inflate(R.layout.task_add_event, null);
        
        views.add(view1);
        views.add(view2);
        mViewPager.setAdapter(new MyViewPagerAdapter(views));
        mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
        
        titleEdt = (EditText) view1.findViewById(R.id.et_title);
        timeEdt = (EditText) view1.findViewById(R.id.et_process_time);
        uploadEdt = (EditText) view1.findViewById(R.id.type_txt);
        yearEdt = (TextView) view1.findViewById(R.id.et_year);
        receiverEdt = (EditText) view1.findViewById(R.id.tv_main_receiver);
        copyEdt = (EditText) view1.findViewById(R.id.tv_subreceiver);
        fileUploadBtn = (Button) view1.findViewById(R.id.btn_upload);
        fileListLay = (LinearLayout) view1.findViewById(R.id.file_upload_lay);
        fileUploadBtn.setOnClickListener(this);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 3);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        timeEdt.setText(sdf.format(calendar.getTime()));
        timeEdt.setOnClickListener(this);
        receiverEdt.setOnClickListener(this);
        copyEdt.setOnClickListener(this);
        yearEdt.setOnClickListener(this);
        yearEdt.setFocusable(false);
        
        caseEdt = (EditText) view2.findViewById(R.id.et_event_case);
        addressEdt = (EditText) view2.findViewById(R.id.et_event_address);
        deviceEdt = (EditText) view2.findViewById(R.id.edt_event_device);
        remarkEdt = (EditText) view2.findViewById(R.id.edt_event_note);
        eventLstLay = (LinearLayout) view2.findViewById(R.id.task_event_list_lay);
        addTxt = (TextView) view2.findViewById(R.id.tv_event_list_add);
        typeTxt = (TextView) view2.findViewById(R.id.txt_event_type);
        typeTxt.setText(UIHelper.getTaskEventTypeString(AddTaskActivity.this,(String) typeTxt.getTag()));
        mScroll = (ScrollView) view2.findViewById(R.id.event_scroll);
        typeTxt.setOnClickListener(this);
        addTxt.setOnClickListener(this);
        int year = Calendar.getInstance().get(Calendar.YEAR);
        yearEdt.setText("" + year);
        if (null != detail) {
            titleEdt.setText(detail.getTaskTitle());
            timeEdt.setText(detail.getLimitTime());
            yearEdt.setText(detail.getTaskYear());
            receiverEdt.setText(detail.getMainName());
            copyEdt.setText(detail.getCopyName());
            receiverEdt.setTag(detail.getMainSubmit());
            copyEdt.setTag(detail.getCopySubmit());
//            receiverEdt.setEnabled(false);
//            copyEdt.setEnabled(false);
            if (null != detail.getFileInfoList()) {
                for (DocFileInfo file : detail.getFileInfoList()) {
                	UIHelper.setFileWrap(mContext, fileListLay, this, this, file.getFileName(), file.getFilePath(), "", "");
                    if(fileListLay!=null && fileListLay.getChildCount()>0){
                        fileListLay.setVisibility(View.VISIBLE);
                    }
                }
            }
            	
            if (null != detail.getEvent()) {
                TaskDetails.EventInfo event = detail.getEvent();
                caseEdt.setText(event.getReason());
                addressEdt.setText(event.getAddress());
                deviceEdt.setText(event.getDevice());
                remarkEdt.setText(event.getRemark());
                typeTxt.setText(UIHelper.getTaskEventTypeString(AddTaskActivity.this,event.getType()));
                typeTxt.setTag(event.getType());
                showEventWork(event.getWorkList());
            }	
        }		
    }			
    			
    			
    private class MyOnClickListener implements View.OnClickListener {
        private int index=0;
        public MyOnClickListener(int i){
            index=i;
        }
        public void onClick(View v) {
            mViewPager.setCurrentItem(index);
        }
    }


    public class MyViewPagerAdapter extends PagerAdapter {
        private List<View> mListViews;

        public MyViewPagerAdapter(List<View> mListViews){
            this.mListViews = mListViews;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object){
            container.removeView(mListViews.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(mListViews.get(position), 0);

            if(currIndex==0){
                UIHelper.setTabTextHighlight(mContext, tv1, tv2);
            }

            return mListViews.get(position);
        }

        @Override
        public int getCount() {
            return  mListViews.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0==arg1;
        }
    }



    public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {
        int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

        public void onPageScrollStateChanged(int arg0) {

        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        public void onPageSelected(int arg0) {
            Animation animation = new TranslateAnimation(one*currIndex, one*arg0, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);// True:图片停在动画结束位置
            animation.setDuration(300);
            imageView.startAnimation(animation);

            if(currIndex==0){
                UIHelper.setTabTextHighlight(mContext, tv1, tv2);

            }else if(currIndex==1){
                UIHelper.hideKeyboard(AddTaskActivity.this);	//隐藏软键盘
                UIHelper.setTabTextHighlight(mContext, tv2, tv1);
            }
        }
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            ResultItem item = response.getResultItem(ResultItem.class);
            if (checkResult(item)) {
                String code = item.getString("code");
                String message = item.getString("message");
                if (Constants.SUCCESS_CODE.equals(code)) {
                    if (fileListLay.getChildCount() > 0 && BASIC_REQUEST == what) {
                        String documentId = null;
                        String swfNo = null;
                        ArrayList<DocFileInfo> fileList = null;
                        if (null != detail) {
                            documentId = detail.getDocumentId();
                            fileList = detail.getFileInfoList();
                        } else {
                        	List<ResultItem> items = item.getItems("data");
                        	documentId = items.get(0).getString("DOCUMENT_ID");
                        	swfNo = items.get(0).getString("SWF_NO");
//                            documentId = item.getString("document_id");
                        }
                        addHelper.uploadFile(documentId, swfNo, fileListLay, mHanlder, UPLOAD_FILE, fileList);
                    } else {
                        UIHelper.showMessage(mContext, message);
                        AddTaskActivity.this.finish();
                    }
                } else {
                    rightBtn.setEnabled(true);
                    UIHelper.showMessage(mContext, message);
                }
            }
        }

        @Override
        public void onReturnError(HttpResponse response, ResultItem error,
                                  int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_data_error_message));
        }

        @Override
        public void onNetError(int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_net_error_message));
        }

    };

    @Override
    public void onClick(View view) {
        if (backBtn == view) {
            UIHelper.deleteTempDoc();	//退出前，删掉临时文件
            finish();
        } else if (rightBtn == view) {
            if (null == addHelper) {
                addHelper = new TaskAddHelper(this, callBack, helper);
            }
            setTaskInfo();
            if (!validate()) {
                return;
            }
            rightBtn.setEnabled(false);
            addHelper.onCommit(taskInfo, BASIC_REQUEST);
        } else if (view == typeTxt) {
            UIHelper.showTaskEventType(this, typeTxt);
        } else if (timeEdt == view) {
            UIHelper.showTimeSelect(this, timeEdt, DateUtils.DATE_FORMAT);
        } else if (receiverEdt == view) {
            chooseContacts(mainRequestCode);
        } else if (copyEdt == view) {
            chooseContacts(copyRequestCode);
        } else if (addTxt == view) {
            addContent(eventLstLay.getChildCount(), "");
            scrollToBottom();
        } else if (fileUploadBtn == view) {
            //点击添加附件
            UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
        } else if (yearEdt == view) {
            UIHelper.showTaskEventYear(this, yearEdt);
        }
    }

    @Override
    public boolean onLongClick(final View v) {
        UIHelper.vibrate(mContext, 50);	//震动下
        if(v.getId() == R.id.rl_add_item_wrap){
            final SystemDialog chooseDialog = new SystemDialog(mContext);
            chooseDialog.setMessage("确定要删除这条附件？");
            chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
                @Override
                public void onClick(View view) {
                    int fileSize = fileListLay.getChildCount();
                    if(fileSize > 0){
                        DocFileInfo bean = (DocFileInfo) v.getTag();
                        if(bean==null) return;

                        for(int i=0; i<fileSize; i++){
                            View fileView = fileListLay.getChildAt(i);
                            if(fileView==null){
                                continue;
                            }
                            TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
                            String tempPath = (String) tvFileName.getTag();
                            if(bean.getFilePath().equals(tempPath)){	//如果按钮相等，则删除这条数据
                                fileListLay.removeViewAt(i);
                            }
                        }
                    }
                }
            });
            chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
                @Override
                public void onClick(View v) {
                    if(chooseDialog!=null){
                        chooseDialog.dismiss();
                    }
                }
            });
            chooseDialog.show();
        }
        return false;
    }

    private void chooseContacts(int requestCode) {
        /*Intent intent = new Intent(this, ChoosePeopleActivity.class);
        intent.putExtra(ChoosePeopleActivity.KEY_IS_MULTIPLE_SELECT, true);
        startActivityForResult(intent, requestCode);*/
    	Intent intent = new Intent(this, SelectedPeopleActivity.class);
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(
    		int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==SDCardFileExplorerActivity.REQUEST_CODE_FILE && data!=null){
            String fileName = data.getStringExtra("FILE_NAME");
            String filePath = data.getStringExtra("FILE_PATH");
            UIHelper.setFileWrap(mContext, fileListLay, this, this, fileName, filePath, "", "");
            if(fileListLay!=null && fileListLay.getChildCount()>0){
                fileListLay.setVisibility(View.VISIBLE);
            }
        } else if (Activity.RESULT_OK == resultCode && null != data) {
            String ids = data.getStringExtra(SelectedPeopleActivity.KEY_USER_IDS_STRING);
            String names = data.getStringExtra(SelectedPeopleActivity.KEY_USER_NAMES_STRING);
            //主送联系人
            if (!BeanUtils.isNullOrEmpty(ids) && !BeanUtils.isNullOrEmpty(names)) {
                if (requestCode == mainRequestCode) {
                    receiverEdt.setText(names);
                    receiverEdt.setTag(ids);
                } else if (requestCode == copyRequestCode) {
                    //抄送联系人
                    copyEdt.setText(names);
                    copyEdt.setTag(ids);
                }
            }
        }
    }

    private boolean validate() {
        if (null == taskInfo) {
            return false;
        }
        if (BeanUtils.isNullOrEmpty(taskInfo.getTitle())) {
            return setReturnMsg("标题不能为空");
        } else if (BeanUtils.isNullOrEmpty(taskInfo.getTaskYear())) {
            return setReturnMsg("年度不能为空");
        } else if (BeanUtils.isEmptyStrs(taskInfo.getSubmitToNo())) {
            return setReturnMsg("主送人员不能为空");
        } else if (BeanUtils.isNullOrEmpty(taskInfo.getLimitTime())) {
            return setReturnMsg("完成时间不能为空");
        } else if (BeanUtils.isNullOrEmpty(taskInfo.getItemType())) {
            return setReturnMsg("类型不能为空");
        } else if (BeanUtils.isNullOrEmpty(taskInfo.getItemName())) {
            return setReturnMsg("申请原因不能为空");
        }
        return true;
    }

    private boolean setReturnMsg(String msg){
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
        return false;
    }

    private void setTaskInfo() {
        if (null == taskInfo) {
            taskInfo = new TaskInfo();
        }
        taskInfo.setTaskId(null == detail ? 0 : detail.getTaskId());
        taskInfo.setTitle(titleEdt.getText().toString());
        taskInfo.setLimitTime(timeEdt.getText().toString());
        taskInfo.setTaskYear(yearEdt.getText().toString());
//        if (null != detail) {
//            taskInfo.setSubmitToNo(detail.getMainSubmit());
//            taskInfo.setCopyToNo(detail.getCopySubmit());
//        } else {
        taskInfo.setSubmitToNo(String.valueOf(receiverEdt.getTag()));
        Object obj = copyEdt.getTag();
        if (null != obj) {
            taskInfo.setCopyToNo(String.valueOf(obj));
        }
//        }
        taskInfo.setItemName(caseEdt.getText().toString());
        taskInfo.setItemAddress(addressEdt.getText().toString());
        taskInfo.setItemAssign(deviceEdt.getText().toString());
        taskInfo.setItemRemark(remarkEdt.getText().toString());
        taskInfo.setItemType(String.valueOf(typeTxt.getTag()));
        if (null != contentList && contentList.size() > 0) {
            StringBuffer buffer = new StringBuffer();
            EditText edt = null;
            boolean flag = false;
            for (int i = 0; i < contentList.size(); i++) {
                edt = contentList.get(i);
                if (null != edt && edt.getText().toString().trim().length() > 0) {
                    if (flag) {
                        buffer.append("@");
                    }
                    buffer.append(edt.getText().toString());
                }
                flag = true;
            }
            taskInfo.setItemContent(buffer.toString());
        }
    }

    //编辑界面，显示已有的工作列表信息
    private void showEventWork(List<String> eventList) {
        if (BeanUtils.isEmpty(eventList)) {
            return;
        }
        for (int i = 0; i < eventList.size(); i++) {
            addContent(i, eventList.get(i));
        }
    }

    //初始化显示view
    private void initContentView(int count) {
        if (eventLstLay.getChildCount() > 0) {
            eventLstLay.removeAllViews();
        }
        for (int i = 0; i < count; i++) {
            addContent(i, "");
        }
        scrollToBottom();
    }

    //新增一个view
    private void addContent(int index, String str) {
        LinearLayout layout = (LinearLayout) mInflater.inflate(R.layout.task_evnet_list_item, null);
        EditText content = (EditText) layout.findViewById(R.id.event_content_edt);
        TextView txt = (TextView) layout.findViewById(R.id.event_no_txt);
        ImageView img = (ImageView) layout.findViewById(R.id.event_delete_img);
        txt.setText(getString(R.string.task_event_list_tip) + (index + 1));
        content.setText(str);
        contentList.add(content);
        setRemoveListener(img, index);
        eventLstLay.addView(layout);
    }

    //当view的个数变化时，到最底下显示
    private void scrollToBottom() {
        mHanlder.post(new Runnable() {
            @Override
            public void run() {
                mScroll.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    //修改删除或新增后，提示的显示
    private void changeIndex() {
        LinearLayout layout = null;
        for (int i = 0; i < eventLstLay.getChildCount(); i++) {
            layout = ((LinearLayout) eventLstLay.getChildAt(i));
            TextView txt = (TextView) layout.findViewById(R.id.event_no_txt);
            txt.setText(getString(R.string.task_event_list_tip) + (i + 1));
            ImageView img = (ImageView) layout.findViewById(R.id.event_delete_img);
            setRemoveListener(img, i);
        }
        scrollToBottom();
    }

    //设置删除事件和删除后view的显示
    private void setRemoveListener(ImageView img, final int size) {
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (contentList.size() > size) {
                    Logger.d(TAG, "remove index: " + size + "   " + view.getRootView());
                    contentList.remove(size);
                    eventLstLay.removeViewAt(size);
                    changeIndex();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (eventLstLay.getChildCount() > 0) {
            eventLstLay.removeAllViews();
        }
        if (null != contentList) {
            contentList.clear();
        }
        if (null != views) {
            views.clear();
        }
    }
}
