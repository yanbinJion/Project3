package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.UserInfoHelper;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 组织成员个人信息
 * 
 * @author Fitz
 * @date 2015年4月22日
 * @version v1.0
 */
public class UserInfoActivity extends BaseActivity implements OnClickListener {

	protected static final int WHAT_GET_USER = 2000;
	public static final int WHAT_EDIT_USER = 2001;

	private Context mContext;
	private EditText etUserName, etSex, etPhone, etMobile;
	private TextView etAccount, tvUserNameTop, tvDepartmentTop, etDepartment,
			etJob;
	private LinearLayout llEditUser;
	private TopActivity topActivity;

	// private LinearLayout llOpMenu;
	private TextView tvPhonetemp, tvMobileTemp;
	private String mobile;
	private String phone;

	private String staffNo;
	private UserInfoHelper userHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		// 设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.user_info);

		staffNo = getIntent().getStringExtra(UserInfoHelper.KEY_USER_STAFFNO);
		if (BeanUtils.isEmpty(staffNo)) {
			UIHelper.showMessage(mContext, getString(R.string.system_no_data));
			finish();
			return;
		}

		bindView();

		userHelper = new UserInfoHelper(mContext, callBack);
		userHelper.loadData(staffNo, WHAT_GET_USER);//加载用户信息
	}

	void bindView() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.user_my_info));// 我的资料
		topActivity.setRightBtnVisibility(View.INVISIBLE);
		topActivity.setRightBtnStyle("保存");// 右边按钮文字：保存
		topActivity.setRightBtnOnClickListener(this);

		tvUserNameTop = (TextView) findViewById(R.id.tv_user_name_top);
		tvDepartmentTop = (TextView) findViewById(R.id.tv_user_department_top);
		etAccount = (TextView) findViewById(R.id.tv_user_account);
		etUserName = (EditText) findViewById(R.id.tv_user_name);
		etDepartment = (TextView) findViewById(R.id.tv_user_department);
		etJob = (TextView) findViewById(R.id.tv_user_position);
		etSex = (EditText) findViewById(R.id.tv_user_sex);
		etSex.setOnClickListener(this);
		etPhone = (EditText) findViewById(R.id.tv_user_phone);
		etMobile = (EditText) findViewById(R.id.tv_user_mobile);

		tvPhonetemp = (TextView) findViewById(R.id.tv_user_phone_temp); // 用于显示值
		tvPhonetemp.setOnClickListener(this);
		tvMobileTemp = (TextView) findViewById(R.id.tv_user_mobile_temp); // 用于显示值
		tvMobileTemp.setOnClickListener(this);

		llEditUser = (LinearLayout) findViewById(R.id.ll_edit_user);
		llEditUser.setOnClickListener(this);
		llEditUser.setVisibility(View.VISIBLE);

        etUserName.setText(SystemContext.getUserName());
        etDepartment.setText(SystemContext.getSiteName());
        etJob.setText(SystemContext.getPosition());
        etSex.setText(SystemContext.getSex());
        etSex.setTag("0".equals(SystemContext.getSex()) || "男".equals(SystemContext.getSex()) ? 0 : 1);
        etPhone.setText(SystemContext.getPhone());
        etMobile.setText(SystemContext.getMobile());

		// llOpMenu = (LinearLayout) findViewById(R.id.ll_op_menu);
		// findViewById(R.id.btn_call).setOnClickListener(this);
		// findViewById(R.id.btn_note).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {
			finish();
		} else if (id == R.id.btn_top_right) {// 标题栏的右边按钮
			if (doCheckData()) {// 验证
				doSubmitData();// 提交数据
			}

		} else if (id == R.id.ll_edit_user) { // 编辑
			relieveViewEdit();

		} else if (id == R.id.tv_user_sex) { // 性别
			UIHelper.showSex(mContext, etSex);

		}/*
		 * else if(id == R.id.btn_call){ //呼叫 if(BeanUtils.isEmpty(mobile)){
		 * UIHelper.showMessage(mContext, "该用户没有联系电话"); return; } Intent intent
		 * = new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+mobile));
		 * mContext.startActivity(intent);
		 * 
		 * }else if(id == R.id.btn_note){ //短信 if(BeanUtils.isEmpty(mobile)){
		 * UIHelper.showMessage(mContext, "该用户没有联系电话"); return; } Intent intent
		 * = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+mobile));
		 * mContext.startActivity(intent);
		 * 
		 * }
		 */else if (id == R.id.tv_user_mobile_temp) {
			showDialog(mobile);

		} else if (id == R.id.tv_user_phone_temp) {
			showDialog(phone);
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String code = item.getString("code");
				String message = item.getString("message");
				if (what == WHAT_GET_USER) {// 获取加载用户信息
					if (Constants.SUCCESS_CODE.equals(code)) {
						UserInfo user = userHelper.getUserInfo(response);
						if (!BeanUtils.isEmpty(user)) {
							setViewValue(user);
						}
					}
				} else if (what == WHAT_EDIT_USER) { // 编辑资料成功返回操作
					if (Constants.SUCCESS_CODE.equals(code)) {
						MainActivity.realName.setText(getViewValue(etUserName));
                        String name = etUserName.getText().toString();
                        String dept = etDepartment.getText().toString();
                        String position = etJob.getText().toString();
                        String sex = etSex.getText().toString();
                        String phone = etPhone.getText().toString();
                        String mobile = etMobile.getText().toString();
                        SystemContext.saveUserInfo(name, dept, mobile, position, sex, phone);
						// 弹出提示
						UIHelper.showMessage(mContext, message);
						disabledViewEdit();
					}
				}
			}
		}
	};

	private void showDialog(final String phone) {
		if (BeanUtils.isEmpty(phone)) {
			// UIHelper.showMessage(mContext, "该用户没有联系电话");
			return;
		}

		final SystemDialog dialog = new SystemDialog(mContext);
		dialog.setMessage("请选择");
		dialog.setOnCancelClickListener("呼叫", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"
						+ phone));
				mContext.startActivity(intent);// 内部类
			}
		});
		dialog.setOnConfirmClickListener("短信", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_SENDTO, Uri
						.parse("smsto:" + phone));
				mContext.startActivity(intent);
			}
		});
		dialog.show();
	}

	/** 解除不可编辑 */
	private void relieveViewEdit() {
		// etAccount.setEnabled(true);
		// etDepartment.setEnabled(true);
		// etJob.setEnabled(true);

		topActivity.setTopTitle(getString(R.string.user_edit_info));// 编辑资料
		topActivity.setRightBtnVisibility(View.VISIBLE);// 显示标题栏右边按钮

		// 设置可以编辑的项目
		etUserName.setEnabled(true);
		// etUserName.setOnFocusChangeListener(focusListener);
		etSex.setEnabled(true);
		Drawable nav_up = getResources().getDrawable(R.drawable.btn_expand);
		nav_up.setBounds(0, 0, nav_up.getMinimumWidth(),
				nav_up.getMinimumHeight());
		etSex.setCompoundDrawables(null, null, nav_up, null);
		// etSex.setOnFocusChangeListener(focusListener);
		etPhone.setEnabled(true);
		// etPhone.setOnFocusChangeListener(focusListener);
		etMobile.setEnabled(true);
		// etMobile.setOnFocusChangeListener(focusListener);
		etPhone.setVisibility(View.VISIBLE);
		etMobile.setVisibility(View.VISIBLE);
//		tvPhonetemp.setVisibility(View.GONE);
//		tvMobileTemp.setVisibility(View.GONE);

		llEditUser.setVisibility(View.GONE);
	}

	/** 不可编辑 */
	private void disabledViewEdit() {
		topActivity.setTopTitle(getString(R.string.user_my_info));// 我的资料

		// 设置可以编辑的项目
		etUserName.setEnabled(false);
		etSex.setEnabled(false);
		etSex.setCompoundDrawables(null, null, null, null);
		etPhone.setEnabled(false);
		etMobile.setEnabled(false);
		topActivity.setRightBtnVisibility(View.INVISIBLE);// 隐藏标题栏右边按钮
		llEditUser.setVisibility(View.VISIBLE);
		// llOpMenu.setVisibility(View.GONE);
	}

	private void setViewValue(UserInfo user) {
		tvUserNameTop.setText(user.getRealName());
		tvDepartmentTop.setText(user.getSiteName());
		etAccount.setText(user.getStaffNo());
		etUserName.setText(user.getRealName());
		etDepartment.setText(user.getSiteName());
		etJob.setText(user.getPosition());
//		int sex = "1".equals(user.getSex()) ? 1 : 0;
//		etSex.setText("1".equals(user.getSex()) ? "男" : "女");
//		etSex.setTag(sex);
		int sex = "0".equals(user.getSex()) ? 0 : 1;
		etSex.setText("0".equals(user.getSex()) ? "男" : "女");
		etSex.setTag(sex);
		phone = user.getPhone();
		mobile = user.getMobile();
		etPhone.setText(phone);
		etMobile.setText(mobile);

		

		etPhone.setVisibility(View.GONE);
		etMobile.setVisibility(View.GONE);

		tvPhonetemp.setText(user.getPhone());
		tvMobileTemp.setText(user.getMobile());
		tvPhonetemp.setVisibility(View.VISIBLE);
		tvMobileTemp.setVisibility(View.VISIBLE);

		// 显示编辑按钮
		if (Constants.IS_USER_PORTAL) {
			String accountProtal = SystemContext.getAccountProtal();
			if (staffNo.equals(accountProtal)) {
				etAccount.setText(SystemContext.getUserId());
				llEditUser.setVisibility(View.VISIBLE);
				// llOpMenu.setVisibility(View.GONE);
			}
		} else {
			String account = SystemContext.getAccount();
			if (staffNo.equals(account)) {
				etAccount.setText(SystemContext.getUserId());
				llEditUser.setVisibility(View.VISIBLE);
				// llOpMenu.setVisibility(View.GONE);
			}
		}
		
	}

	private String getViewValue(TextView view) {
		return view.getText().toString();
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	OnFocusChangeListener focusListener = new View.OnFocusChangeListener() {
		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			if (!hasFocus) { // 失去焦点
				if (doCheckData()) {// 验证
					doSubmitData();// 提交数据
				}
			}
		}
	};

	/** 提交数据 */
	public void doSubmitData() {
		String realName = getViewValue(etUserName);
		String sex = getViewValue(etSex);
		String phone = getViewValue(etPhone);
		String mobile = getViewValue(etMobile);

		if (!BeanUtils.isEmpty(realName) && !BeanUtils.isEmpty(sex)
				&& !BeanUtils.isEmpty(mobile)) { // 值不为空的时候才去保存
//			sex = "男".equals(sex) ? "1" : "0";
			sex = "男".equals(sex) ? "男" : "女";
			userHelper.editUser(realName, sex, phone, mobile, WHAT_EDIT_USER);
		}
	}

	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		if (BeanUtils.isEmpty(getViewValue(etUserName))) {// 姓名
			UIHelper.showMessage(mContext,
					getString(R.string.required_tip_user_name));
			return false;
		}

		if (BeanUtils.isEmpty(getViewValue(etSex))) {// 性别不能为空
			UIHelper.showMessage(mContext, getString(R.string.required_tip_sex));
			return false;
		}

		if (!BeanUtils.isEmpty(getViewValue(etPhone))) {// 电话格式不对
			if (!BeanUtils.isPhone(getViewValue(etPhone))) {
				UIHelper.showMessage(mContext,
						getString(R.string.error_tip_user_phone));
				return false;
			}
		}

		if (BeanUtils.isEmpty(getViewValue(etMobile))) {// 手机号码
			UIHelper.showMessage(mContext,
					getString(R.string.required_tip_user_mobile));
			return false;
		}
		if (!BeanUtils.isMobileNO(getViewValue(etMobile))) {// 手机号码格式不对
			UIHelper.showMessage(mContext,
					getString(R.string.error_tip_user_mobile));
			return false;
		}

		return true;// 验证通过
	}

}
