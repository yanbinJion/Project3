package com.powerriche.mobile.na.oa.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.*;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.ApplyParams;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.FileInfo;
import com.powerriche.mobile.na.oa.bean.PurchaseApply;
import com.powerriche.mobile.na.oa.bean.PurchaseApply.PurchaseDetail;
import com.powerriche.mobile.na.oa.bean.TransactInfo;
import com.powerriche.mobile.na.oa.bean.TransactSuggestion;
import com.powerriche.mobile.na.oa.down.DownloadInfoBean;
import com.powerriche.mobile.na.oa.down.DownloadInfoDAO;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.na.oa.view.widget.ActionSheetDialog;
import com.powerriche.mobile.na.oa.view.widget.ActionSheetDialog.OnSheetItemClickListener;
import com.powerriche.mobile.na.oa.view.widget.ActionSheetDialog.SheetItemColor;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @title  申购详情界面
 * @author dir_wang
 * @date   2016-7-7下午5:18:17
 */ 
public class PurchaseDetailActivity extends BaseActivity implements View.OnClickListener, DownloadUIHelper.DownloadButtonListener, View.OnLongClickListener {
	private Context mContext;
	private static PurchaseDetailActivity mInstance;
    private String purchaseId, swfNo, wfNo;
    
    private ViewPager viewPager;// 页卡内容
    private ImageView imageView;// 动画图片
    
    private View view1, view2, view3, view4;
    
    private List<View> views;// Tab页面列表
    private int offset = 0;// 动画图片偏移量
    private int currIndex = 0;// 当前页卡编号
    private int bmpW;// 动画图片宽度
    
    private Button btn_purchase_send, btn_purchase_process;
    
    private TextView tvFileGroup;
    private LinearLayout llFileWrap;
    
    private Button rightBtn;
    private TextView tv_purchase_title, tv_purchase_proposer, tv_purchase_time, tv_purchase_reason, tv_purchase_complete_time, tv_purchase_type, tv_purchase_pay, tv_purchase_details;
    private ListView lv_apply_details;
	private TextView tv_no_data_details;
	private ListView lv_transact_suggestion;
	private TextView tv_no_data_suggestion;
	private ListView lv_transact_info;
	private TextView tv_no_data_info;
	private PurchaseDetailsAdapter detailsAdapter;
    private TransactSuggestionAdapter suggestionAdapter;
    private TransactInfoAdapter infoAdapter;
    
    public static final int CODE_PASS_READ_TAG = 1000;
    private static final int REQUEST_PURCHASE_INFO = 0;
	private static final int REQUEST_PURCHASE_PROCESS = 1;
	
    /**
     * 已办的公文或者会议都不能删除增加附件<br>
     * true可以删除新增
     */
    private boolean isDeleteAddToken = true;
    
    private DownloadUIHelper downloadUIHelper = null;
    private DownloadInfoDAO dao = null;
    
    private PurchaseApply detail = new PurchaseApply();
    private MyViewPagerAdapter pagerAdapter;
    
    //对应申购信息，申购明细，办理意见，办理信息
    private TextView tv1,tv2, tv3, tv4;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 设置横竖屏幕
        this.mContext = this;
        mInstance = this;
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.my_apply_detail);
        purchaseId = getIntent().getStringExtra("purchaseId"); // 任务编号
        if (!BeanUtils.isNullOrEmpty(purchaseId)) {
            purchaseId = BeanUtils.floatToInt4Str(purchaseId);
            detail.setPurchaseId(String.valueOf(purchaseId));
        }
        swfNo = getIntent().getStringExtra("swfNo");
		wfNo = getIntent().getStringExtra("wfNo");
		if (!BeanUtils.isNullOrEmpty(wfNo)) {
			wfNo = BeanUtils.floatToInt4Str(wfNo);
		}
        bindViews();
        
        this.downloadUIHelper = new DownloadUIHelper(this);
        this.downloadUIHelper.setEventListener(this);
        this.dao = new DownloadInfoDAO(this);
        
    }	
    	
    // 获取申领详情
    public void getPurchaseDetail() {
        ApiRequest request = OAServicesHandler.getPurchaseDetail(purchaseId);
        if (request != null) {
            helper.invokeWidthDialog(request, callBack, REQUEST_PURCHASE_INFO);
        }
    }	
    	
    // 申购办结
	private void processPurchase() {
		ApiRequest request = OAServicesHandler.finishPurchaseWorkFlow(purchaseId);
		helper.invokeWidthDialog(request, callBack, REQUEST_PURCHASE_PROCESS);
	}	
		
    // 显示申领详情信息
    private void showPurchaseInfo(ResultItem result) {
        if (null == result) {
            return;
        }
        String purchaseType = BeanUtils.floatToInt4Str(result.getString("PURCHASE_TYPE"));
        String payMode = BeanUtils.floatToInt4Str(result.getString("PAY_MODE"));
        detail.setPurchaseTitle(result.getString("PURCHASE_TITLE"));
        detail.setPurchaseProposer(result.getString("APPLY_REAL_NAME"));
        detail.setPurchaseReason(result.getString("PURCHASE_REASON"));
        detail.setPurchaseTime(result.getString("APPLY_TIME"));
        detail.setPurchaseDate(result.getString("PURCHASE_DATE"));
        detail.setPurchaseType(purchaseType);
        detail.setPurchaseTypeName(result.getString("PURCHASE_TYPE_NAME"));
        detail.setPayMode(payMode);
        detail.setPayModeName(result.getString("PAY_MODE_NAME"));
        detail.setRemark(result.getString("REMARK"));
        detail.setDocumentId(BeanUtils.floatToInt4Str(result.getString("DOCUMENT_ID")));
        detail.setShowAgree("1".equals(result.getString("DISPLAY_AGREE_BUTTON")));
        detail.setShowRefuse("1".equals(result.getString("DISPLAY_REFUSE_BUTTON")));
        detail.setShowSave("1".equals(result.getString("DISPLAY_SAVE_BUTTON")));
        detail.setShowSend("1".equals(result.getString("DISPLAY_SENDNEXT_BUTTON")));
        detail.setShowFinish("1".equals(result.getString("DISPLAY_FINISH_BUTTON")));
        detail.setTotleAccount(result.getString("TOTAL_ACCOUNT"));
        detail.setResult(BeanUtils.floatToInt4Str(result.getString("RESULT")));
        detail.setPassState(BeanUtils.floatToInt4Str(result.getString("PASS_STATE")));
        detail.setFpuNo(result.getString("FPU_NO"));
        tv_purchase_title.setText(detail.getPurchaseTitle());
        tv_purchase_proposer.setText(detail.getPurchaseProposer());
        tv_purchase_reason.setText(detail.getPurchaseReason());
        tv_purchase_time.setText(detail.getPurchaseTime());
        tv_purchase_complete_time.setText(detail.getPurchaseDate());
        if (purchaseType.equals("0") || purchaseType.equals("1")) {
        	tv_purchase_type.setText(UIHelper.getPurchaseApplyType(PurchaseDetailActivity.this,detail.getPurchaseType()));
        	tv_purchase_type.setTag(purchaseType);
        } else {
        	tv_purchase_type.setText(detail.getPurchaseTypeName());
        	tv_purchase_type.setTag(purchaseType);
        }
        if (payMode.equals("0") || payMode.equals("1") || payMode.equals("2")) {
        	tv_purchase_pay.setText(UIHelper.getPayApplyType(PurchaseDetailActivity.this,detail.getPayMode()));
        	tv_purchase_pay.setTag(payMode);
        } else {
        	tv_purchase_pay.setText(detail.getPayModeName());
        	tv_purchase_pay.setTag(payMode);
        }
        tv_purchase_details.setText(detail.getRemark());
        //解析明细
        List<ResultItem> details = result.getItems("PurchaseDetails");
        if (!BeanUtils.isEmpty(details)) {
            List<PurchaseApply.PurchaseDetail> list = new ArrayList<PurchaseApply.PurchaseDetail>(details.size());
            for (ResultItem item : details) {
                PurchaseApply.PurchaseDetail temp = detail.new PurchaseDetail();
                temp.setDetailId(item.getString("PURCHASE_DETAIL_ID"));
                temp.setUnitPrice(item.getString("UNIT_PRICE"));
                temp.setUnit(item.getString("UNIT"));
                temp.setTotalPrice(item.getString("TOTAL_PRICE"));
                temp.setSpec(item.getString("SPEC"));
                temp.setPurchaseName(item.getString("PURCHASE_NAME"));
                temp.setQuantity(item.getString("QUANTITY"));
                list.add(temp);
            }
//            ContentComparator comparator = new ContentComparator();
//            Collections.sort(list, comparator);
            detail.setDetails(list);
            showPurchaseDetails();
        }	
        	
        //解析附件
        List<ResultItem> file = result.getItems("File");
        if (!BeanUtils.isEmpty(file)) {
            List<DocFileInfo> files = new ArrayList<DocFileInfo>(
                    file.size());
            for (ResultItem item : file) {
            	DocFileInfo docFileInfo = new DocFileInfo();
				docFileInfo.setFileCode(item.getString("FK_FILE_CODE"));
				docFileInfo.setFileName(item.getString("FILE_NAME"));
				docFileInfo.setFilePath(item.getString("FTP_PATH"));
				docFileInfo.setFileTitle(item.getString("FILE_TITLE"));
				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(item.getString("FILE_SIZE"));//文件大小
				if(!BeanUtils.isEmpty(fileSizeStr)){
					fileSize = Integer.parseInt(fileSizeStr);
				}
				docFileInfo.setFileSize(fileSize);
				files.add(docFileInfo);
            }
            detail.setFiles(files);
            foreachFiles(files);
        }

        //办理意见
        List<ResultItem> processData = result.getItems("ProcessData");
        if (!BeanUtils.isEmpty(processData)) {
            List<TransactSuggestion> transactSuggestion = new ArrayList<TransactSuggestion>(processData.size());
            TransactSuggestion suggestion = null;
            for (ResultItem item : processData) {
            	suggestion = new TransactSuggestion();
            	suggestion.setProcessor(item.getString("PROCESSOR"));
            	suggestion.setActionName(item.getString("ACTION_NAME"));
            	suggestion.setData(item.getString("DATA"));
            	suggestion.setProcessorDeptName(item.getString("PROCESSOR_DEPT_NAME"));
            	suggestion.setSaveDate(item.getString("SAVE_DATE"));
            	transactSuggestion.add(suggestion);
            }
            detail.setTransactSuggestion(transactSuggestion);
        }

        //办理信息
        List<ResultItem> actionData = result.getItems("ActionData");
        if (!BeanUtils.isEmpty(actionData)) {
            List<TransactInfo> transactInfo = new ArrayList<TransactInfo>(actionData.size());
            TransactInfo info = null;
            for (ResultItem item : actionData) {
            	info = new TransactInfo();
            	info.setAction(item.getString("ACTION"));
            	info.setActionId(item.getString("ACTION_ID"));
            	info.setBeginTime(item.getString("BEGIN_TIME"));
            	info.setEndTime(item.getString("END_TIME"));
            	info.setProcessor(item.getString("PROCESSOR"));
            	info.setReadTime(item.getString("READ_TIME"));
            	info.setRemark(item.getString("REMARK"));
            	transactInfo.add(info);
            }
            detail.setTransactInfo(transactInfo);
        }
        if (detail != null) {
        	if (detail.isShowSend()) {
    			btn_purchase_send.setVisibility(View.VISIBLE);
    		} else {
    			btn_purchase_send.setVisibility(View.GONE);
    		}
    		if (detail.isShowSave()) {
    			rightBtn.setVisibility(View.VISIBLE);
    			rightBtn.setText(R.string.apply_edit);
    		} else if (detail.isShowFinish()) {
    			rightBtn.setVisibility(View.VISIBLE);
    			rightBtn.setText(R.string.apply_complete);
    		} else {
    			rightBtn.setVisibility(View.GONE);
    		}
    		if (detail.isShowAgree()) {
    			btn_purchase_process.setVisibility(View.VISIBLE);
    		} else {
    			btn_purchase_process.setVisibility(View.GONE);
    		}
        }
    }
    
    private class ContentComparator implements Comparator<PurchaseApply.PurchaseDetail> {

		@Override
		public int compare(PurchaseDetail object1, PurchaseDetail object2) {
			Integer obj1 = BeanUtils.floatToInt(object1.getDetailId());
			Integer obj2 = BeanUtils.floatToInt(object2.getDetailId());
			if(obj1 > obj2) {
				return 1;
			} else {
				return -1;
			}
		}

    	
    }
    
	// 显示申购明细列表
	private void showPurchaseDetails() {
		List<PurchaseDetail> list = detail.getDetails();
		if (BeanUtils.isEmpty(list)) {
			tv_no_data_details.setVisibility(View.VISIBLE);
			return;
		}
		tv_no_data_details.setVisibility(View.GONE);
		if (null == detailsAdapter) {
			detailsAdapter = new PurchaseDetailsAdapter(this);
			detailsAdapter.addData(detail.getDetails());
			lv_apply_details.setAdapter(detailsAdapter);
		} else {
			detailsAdapter.clearListData();
			detailsAdapter.addData(detail.getDetails());
			detailsAdapter.notifyDataSetChanged();
		}	
	}		
			
	// 显示办理意见列表
	private void showTransactSuggestion() {
		if (BeanUtils.isEmpty(detail.getTransactSuggestion())) {
			tv_no_data_suggestion.setVisibility(View.VISIBLE);
			return;
		}
		tv_no_data_suggestion.setVisibility(View.GONE);
		if (null == suggestionAdapter) {
			suggestionAdapter = new TransactSuggestionAdapter(this);
			suggestionAdapter.addData(detail.getTransactSuggestion());
			lv_transact_suggestion.setAdapter(suggestionAdapter);
		} else {
			suggestionAdapter.clearListData();
			suggestionAdapter.addData(detail.getTransactSuggestion());
			suggestionAdapter.notifyDataSetChanged();
		}	
			
	}		
			
	// 显示办理信息列表
	private void showTransactInfo() {
		if (BeanUtils.isEmpty(detail.getTransactInfo())) {
			tv_no_data_info.setVisibility(View.VISIBLE);
			return;
		}
		tv_no_data_info.setVisibility(View.GONE);
		if (null == infoAdapter) {
			infoAdapter = new TransactInfoAdapter(this);
			infoAdapter.addData(detail.getTransactInfo());
			lv_transact_info.setAdapter(infoAdapter);
		} else {
			infoAdapter.clearListData();
			infoAdapter.addData(detail.getTransactInfo());
			infoAdapter.notifyDataSetChanged();
		}	
	}		
			
    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            ResultItem reusltItem = response.getResultItem(ResultItem.class);
            if (!checkResult(reusltItem)) {
                return;
            }
            ResultItem result = null;
            String code = reusltItem.getString("code");
            String message = reusltItem.getString("message");
            if (!Constants.SUCCESS_CODE.equals(code)) {
                UIHelper.showMessage(mContext, message);
                return;
            }
            result = (ResultItem) reusltItem.get("data");
            if (what == REQUEST_PURCHASE_INFO) {
            	showPurchaseInfo(result);
            } else if (what == REQUEST_PURCHASE_PROCESS) {
            	 UIHelper.showMessage(mContext, message);
            	 PurchaseDetailActivity.this.finish();
            }
        }

        @Override
        protected void showErrorMessage(String message) {
            UIHelper.showMessage(mContext, message);
        }

        @Override
        public void onReturnError(HttpResponse response, ResultItem error,
                                  int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_data_error_message));
        }

        @Override
        public void onNetError(int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_net_error_message));
        }
    };

    private void bindViews() {
        findViewById(R.id.system_back).setOnClickListener(this);
        TextView tvTitle = (TextView) findViewById(R.id.tv_top_title);
        tvTitle.setText(getString(R.string.purchase_details));
        rightBtn = (Button) findViewById(R.id.btn_top_right);
        rightBtn.setOnClickListener(this);
        
        initTextView();
        initViewPager();
        // 申购信息
        initPurchaseInfo();
        // 申购明细
        initPurchaseDetail();
        // 办理意见
        initTransactSuggestion();
        // 办理信息
        initTransactInfo();
    }	
    	
    	
    /** 
     * 申购信息初始化控件
     */ 
    private void initPurchaseInfo() {
    	tv_purchase_title = (TextView) view1.findViewById(R.id.tv_purchase_title);
    	tv_purchase_proposer = (TextView) view1.findViewById(R.id.tv_purchase_proposer);
    	tv_purchase_time = (TextView) view1.findViewById(R.id.tv_purchase_time);
        tv_purchase_reason = (TextView) view1.findViewById(R.id.tv_purchase_reason);
        tv_purchase_complete_time = (TextView) view1.findViewById(R.id.tv_purchase_complete_time);
        tv_purchase_type = (TextView) view1.findViewById(R.id.tv_purchase_type);
        tv_purchase_pay = (TextView) view1.findViewById(R.id.tv_purchase_pay);
        tv_purchase_details = (TextView) view1.findViewById(R.id.tv_purchase_details);
        btn_purchase_send = (Button) view1.findViewById(R.id.btn_purchase_send);
        tvFileGroup = (TextView) view1.findViewById(R.id.tv_file_group);
        tvFileGroup.setOnClickListener(this);
        btn_purchase_send.setOnClickListener(this);
        tvFileGroup.setTag(true);
        tvFileGroup.setVisibility(View.VISIBLE);
        llFileWrap = (LinearLayout) view1.findViewById(R.id.ll_file_upload);
        llFileWrap.setVisibility(View.GONE);
        btn_purchase_process = (Button) view1.findViewById(R.id.btn_purchase_process);
        btn_purchase_process.setOnClickListener(this);
        
    }	
    	
    /** 
	 * 申购明细初始化控件
	 */ 
	private void initPurchaseDetail() {
		lv_apply_details = (ListView) view2.findViewById(R.id.lv_apply_details);
		tv_no_data_details = (TextView) view2.findViewById(R.id.tv_no_data_details);
	}	
	    
	/**
	 * 办理意见初始化控件
	 */
	private void initTransactSuggestion() {
		lv_transact_suggestion = (ListView) view3.findViewById(R.id.lv_transact_suggestion);
		tv_no_data_suggestion = (TextView) view3.findViewById(R.id.tv_no_data_suggestion);
	}
	
	/**
	 * 办理信息初始化控件
	 */
	private void initTransactInfo() {
		lv_transact_info = (ListView) view4.findViewById(R.id.lv_transact_info);
		tv_no_data_info = (TextView) view4.findViewById(R.id.tv_no_data_info);
	}

    /**
     * 方法说明：<br>
     * 初始化 页卡
     */
    @SuppressLint("InflateParams")
    private void initViewPager() {
        viewPager = (ViewPager) findViewById(R.id.vp_pager);
        views = new ArrayList<View>();
        LayoutInflater inflater = getLayoutInflater();

        view1 = inflater.inflate(R.layout.purchase_info, null); // 加载任务信息
        view2 = inflater.inflate(R.layout.apply_details_list, null);// 加载事件信息
        view3 = inflater.inflate(R.layout.transact_suggestion_list, null);
        view4 = inflater.inflate(R.layout.transact_info_list, null);


        views.add(view1);
        views.add(view2);
        views.add(view3);
        views.add(view4);

        initImageView();
        pagerAdapter = new MyViewPagerAdapter();
        viewPager.setAdapter(pagerAdapter);
        viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
        setSelectTab();
    }

    private void setSelectTab() {
        if (currIndex < 0 || currIndex >= views.size()) {
            currIndex = 0;
        }
        UIHelper.setTabTextHeighLight(this, currIndex, tv1, tv2, tv3,tv4);
    }

    public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

		public void onPageScrollStateChanged(int arg0) {

		}

        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);// True:图片停在动画结束位置
			animation.setDuration(300);
			imageView.startAnimation(animation);
			currIndex = arg0;
            setSelectTab();
            Logger.d("onPageSelected", "curIndex: " + currIndex + "  size: " + views.size());
            if (currIndex == 0) {// 申领信息
                if (null == detail) {
                    getPurchaseDetail();
                }
            } else if (currIndex == 1) {
            	showPurchaseDetails();
            } else if (currIndex == 2) {
            	showTransactSuggestion();
            } else if (currIndex == 3) {
            	showTransactInfo();
            }
            Logger.d("onPageSelected", "curIndex: " + currIndex + "  size: " + views.size());
        }
    }

    private class MyOnClickListener implements View.OnClickListener {
        private int index = 0;

        public MyOnClickListener(int i) {
            index = i;
        }

        public void onClick(View v) {
            viewPager.setCurrentItem(index);
        }
    }

    public class MyViewPagerAdapter extends PagerAdapter {

        public MyViewPagerAdapter() {
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(views.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {

            container.addView(views.get(position));
            Logger.d("MyViewPagerAdapter", "instantiateItem" + position);
            return views.get(position);
        }

        @Override
        public int getCount() {
            return views.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }
    }

    /**
     * 初始化头标
     */
    private void initTextView() {
        tv1 = (TextView) findViewById(R.id.tv_1);
        tv2 = (TextView) findViewById(R.id.tv_2);
        tv3 = (TextView) findViewById(R.id.tv_3);
        tv4 = (TextView) findViewById(R.id.tv_4);
        tv1.setText(R.string.purchase_info);
        tv2.setText(R.string.purchase_detail);
        tv1.setOnClickListener(new MyOnClickListener(0));
        tv2.setOnClickListener(new MyOnClickListener(1));
        tv3.setOnClickListener(new MyOnClickListener(2));
        tv4.setOnClickListener(new MyOnClickListener(3));
    }

    /**
     * 初始化动画
     */
    private void initImageView() {
    	imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor)
				.getWidth();// 获取图片宽度

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / views.size() - bmpW) / 2;// 计算偏移量-->3个选项卡
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
    }

    @Override
    public void onProgressUpdate(String url, long totalSize, long dealtSize) {
        RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
                true);
        if (btnDown == null)
            return;
        btnDown.setBackgroundResource(R.drawable.ic_down_ing); // 正在下载
        btnDown.setCricleAndProgressColor(
                this.getResources().getColor(R.color.gray_split_line_bg), this
                .getResources().getColor(R.color.down_progress_color));

        float num = (float) dealtSize / (float) totalSize;
        int result = (int) (num * 100);

        btnDown.setProgress(result);

    }

    @Override
    public void onDownloadComplete(String url) {
        RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
                true); // 下载完成
        if (btnDown == null)
            return;
        btnDown.setBackgroundResource(R.drawable.ic_down_finish);
        btnDown.setCricleAndProgressColor(
                this.getResources().getColor(R.color.transparent), this
                .getResources().getColor(R.color.transparent));

        UIHelper.openFile(this, url);
    }

    @Override
    public void onDownloadStateChange(String url, int state) {
        switch (state) {
            case DownloadInfoDAO.DOWNLOAD_STATE_3:
                RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
                        true); // 暂停下载
                if (btnDown != null) {
                    btnDown.setBackgroundResource(R.drawable.ic_down_pause);
                    btnDown.setCricleAndProgressColor(
                            this.getResources().getColor(R.color.transparent), this
                            .getResources().getColor(R.color.transparent));
                }
                break;
        }
    }

    @Override
    public void onDownloadError(String url, int state) {
        RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
                true);
        if (btnDown != null) {
            btnDown.setBackgroundResource(R.drawable.ic_down);
            btnDown.setCricleAndProgressColor(
                    this.getResources().getColor(R.color.gray_split_line_bg),
                    this.getResources().getColor(R.color.down_progress_color));
        }
        UIHelper.showMessage(this, "下载错误");
    }

    @Override
    public boolean onLongClick(View arg0) {
        return false;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.system_back) {// 　返回
            onClickBack();
        } else if (id == R.id.btn_top_right) {
        	if (detail != null) {
        		// 编辑
        		if (detail.isShowSave()) {
        			Intent intent = new Intent(PurchaseDetailActivity.this,
        					ApplyPurchaseActivity.class);
        			intent.putExtra("purchaseDetail", detail);
        			startActivity(intent);
        		} else if (detail.isShowFinish()) {
        			// 办结
        			processPurchase();
        		}
        	}
        	
        } else if (id == R.id.btn_purchase_send) {
            // 在这里调用发送
        	String nextFpuNo = detail.getFpuNo();
        	ApplyParams params = new ApplyParams(swfNo, wfNo, nextFpuNo);
			Log.i("send", " swfNo= "+swfNo+" nextFpuNo "+nextFpuNo);
			params.setPurchaseId(purchaseId);
			params.setNextFpuNo(nextFpuNo);
			Bundle data = new Bundle();
			data.putSerializable("params", params);
			data.putString("passState", "0");
			data.putInt("flag", 1);
			UIHelper.forwardTargetActivity(this,
					TransactorActivity.class, data, false);
        } else if (id == R.id.btn_purchase_process) {
        	showActionSheetDialog();
		}else if (id == R.id.btn_process || id == R.id.rl_item_wrap
				|| id == R.id.rl_add_item_wrap) { // 附件下载
			UIHelper.downViewClick(mContext, v, downloadUIHelper, dao);
		}

	}
    
    private void showActionSheetDialog() {
		new ActionSheetDialog(mContext)
				.builder()
				.setTitle("点击同意或不同意后将送到办理环节，同意后则该审批事项通过，无需上级领导审批！")
				.setCancelable(false)
				.setCanceledOnTouchOutside(true)
				.addSheetItem("同意", SheetItemColor.Red,
						new OnSheetItemClickListener() {
							@Override
							public void onClick(int which) {
								String nextFpuNo = detail.getFpuNo();
								ApplyParams params = new ApplyParams(swfNo, wfNo, nextFpuNo);
								params.setPurchaseId(purchaseId);
								params.setNextFpuNo(nextFpuNo);
								Bundle data = new Bundle();
								data.putSerializable("params", params);
								data.putString("passState", "1");
								data.putInt("flag", 20);
								UIHelper.forwardTargetActivity(mContext,
										TransactorActivity.class, data, false);
							}
						})
				.addSheetItem("不同意", SheetItemColor.Red,
						new OnSheetItemClickListener() {
							@Override
							public void onClick(int which) {
								String nextFpuNo = detail.getFpuNo();
								ApplyParams params = new ApplyParams(swfNo, wfNo, nextFpuNo);
								params.setPurchaseId(purchaseId);
								params.setNextFpuNo(nextFpuNo);
								Bundle data = new Bundle();
								data.putSerializable("params", params);
								data.putString("passState", "-1");
								data.putInt("flag", 21);
								UIHelper.forwardTargetActivity(mContext,
										TransactorActivity.class, data, false);
							}
						}).show();
	}

    private void onClickBack() {
        if (Constants.NOTIFY_DETAIL_BACK) {
            UIHelper.setNotifyRestore();

            UIHelper.forwardTargetActivity(this, MainActivity.class, null,
                    true);

        } else {
            UIHelper.deleteTempDoc();
            finish();
        }
    }

    private class ViewHolderFile {
        TextView tvFileName;
        ImageView ivType;
        RoundProgressButton btnDownload;
        RelativeLayout rlItemWrap, rlRoundBtnWrap;
    }

    /**
     * 循环附件
     *
     * @param fileList
     */
    private void foreachFiles(List<DocFileInfo> fileList) {
        if (BeanUtils.isEmpty(fileList)) {
            return;
        }
        llFileWrap.removeAllViews();
        for (int i = 0, len = fileList.size(); i < len; i++) {
            final DocFileInfo bean = fileList.get(i);
            ViewHolderFile holder = new ViewHolderFile();
            
            View view = LayoutInflater.from(this).inflate(
                    R.layout.govaffair_file_item, null);
            holder.rlItemWrap = (RelativeLayout) view
                    .findViewById(R.id.rl_item_wrap);
            holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
            holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
            
            holder.btnDownload = (RoundProgressButton) view
                    .findViewById(R.id.btn_process);
            holder.rlRoundBtnWrap = (RelativeLayout) view
                    .findViewById(R.id.rl_round_btn_wrap);
            
            String extend = FileUtils.getFileExtends(bean.getFileName());
            UIHelper.setFileTypeIcon(this, holder.ivType, extend); // 设置文件类型
            
            holder.tvFileName.setText(bean.getFileName());
            holder.tvFileName.setTag(bean.getFilePath());
            
            holder.btnDownload.setTag(bean);
            holder.btnDownload.setOnClickListener(this);
            
            // String url =
            // UIHelper.downFileUrl(bean.getFileCode());//getString(R.string.system_servics_download).concat(bean.getFilePath());
            String url;
            // 0,标识使用system_servics_download下载，1标识使用system_servics_url下载
            if ("1".equals(getString(R.string.is_download_flag))) {
                url = UIHelper.downFileUrl(bean.getFileCode());
            } else {
                url = getString(R.string.system_servics_download).concat(
                        bean.getFilePath());
            }
            holder.rlRoundBtnWrap.setTag(url);// 下载标识
            
            holder.rlItemWrap.setTag(bean);// 长按删除
            holder.rlItemWrap.setOnClickListener(this);
            
            if (isDeleteAddToken) {
                holder.rlItemWrap.setOnLongClickListener(this);
            }
            
			try {
				DownloadInfoBean downBean = dao.getAppBeanByCd(bean.getFileCode());
				if (downBean != null) { // 下载完成
					int state = downBean.getState();
					if (state == DownloadInfoDAO.DOWNLOAD_STATE_2) {
						holder.btnDownload
								.setBackgroundResource(R.drawable.ic_down_finish); // 存在则打开

					} else if (state == DownloadInfoDAO.DOWNLOAD_STATE_3) {
						holder.btnDownload
								.setBackgroundResource(R.drawable.ic_down_pause); // 暂停状态

					} else {
						holder.btnDownload
								.setBackgroundResource(R.drawable.ic_down); // 否则下载
					}
				} else {
					holder.btnDownload
							.setBackgroundResource(R.drawable.ic_down); // 否则下载
				}
				holder.btnDownload.setCricleAndProgressColor(this
						.getResources().getColor(R.color.transparent), this
						.getResources().getColor(R.color.transparent));
			} catch (Exception e) {
				
			}	
            llFileWrap.addView(view);
        }		
        if (llFileWrap.getChildCount() > 0) {
            llFileWrap.setVisibility(View.VISIBLE);
            tvFileGroup.setVisibility(View.VISIBLE);
        } else {
            llFileWrap.setVisibility(View.GONE);
            tvFileGroup.setVisibility(View.GONE);
        }		
    }			
    			
    @Override	
    protected void onPause() {
        super.onPause();
        if (this.downloadUIHelper != null)
            this.downloadUIHelper.unRegUiHandler();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getPurchaseDetail();
        if (this.downloadUIHelper != null)
            this.downloadUIHelper.regUiHandler();// 界面恢复调用
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (this.downloadUIHelper != null)
            this.downloadUIHelper.unRegUiHandler();
    }
    
    public static void finishActivity() {
    	mInstance.finish();
	}

}
