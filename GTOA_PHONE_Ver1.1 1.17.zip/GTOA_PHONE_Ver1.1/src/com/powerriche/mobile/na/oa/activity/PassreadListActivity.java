package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentGwcyDaiyueHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentGwcyYichuanHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentGwcyYiyueHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 公文传阅
 * @author 李运期
 * @date 2015年4月30日
 * @version v1.0
 */
public class PassreadListActivity extends BaseActivity implements OnClickListener {

	private Context mContext;
	
	//********************页卡相关变量************************
	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片

	private TextView tv1, tv2, tv3;
	private View view1, view2, view3;

	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度

	
	//---------待阅相关控件及变量-------------
	private PullToRefreshListView pullViewDaiyue;
	private ListView listViewDaiyue;
	private TextView tvNoDataMsgDaiyue;
	private int pageIndexDaiyue = 1;
	private DocumentGwcyDaiyueHelper daiyueHelper;

	//---------已阅相关控件及变量-------------
	private PullToRefreshListView pullViewYiyue;
	private ListView listViewYiyue;
	private TextView tvNoDataMsgYiyue;
	private int pageIndexYiyue = 1;
	public static boolean isFirst2 = true;
	private DocumentGwcyYiyueHelper yiyueHelper;

	//---------已传相关控件及变量-------------
	private PullToRefreshListView pullViewYichuan;
	private ListView listViewYichuan;
	private TextView tvNoDataMsgYichuan;
	private int pageIndexYichuan = 1;
	public static boolean isFirst3 = true;
	private DocumentGwcyYichuanHelper yichuanHelper;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		BeanUtils.setPortraitAndLandscape(this);	//设置横竖屏幕
		setContentView(R.layout.passread_list);
		
		bindView();
		loadData4DY();// 第一个加载项
	}

	void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.menu_transfer));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.INVISIBLE);// 隐藏右边按钮

		initImageView();
		initTextView();
		initViewPager();
		
		initDaiyueView();
		initYiyueView();
		initYichuanView();
	}
	

	/**
	 * 初始化待阅控件 
	 */
	void initDaiyueView(){
		pullViewDaiyue = (PullToRefreshListView) view1.findViewById(R.id.pulllistview_daiyue);
		pullViewDaiyue.setPullRefreshEnabled(true);
		pullViewDaiyue.setPullLoadEnabled(false);
		pullViewDaiyue.setScrollLoadEnabled(true);
	
		listViewDaiyue = pullViewDaiyue.getRefreshableView();
		UIHelper.setListViewAttribute(listViewDaiyue);
	
		pullViewDaiyue.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexDaiyue = 1;
				daiyueHelper.loadData(Constants.OPT_TYPE_GWCY_DY, Constants.WHAT_REQUEST_GWCY_DY, pageIndexDaiyue);
			}
	
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexDaiyue = pageIndexDaiyue + 1;
				daiyueHelper.loadData(Constants.OPT_TYPE_GWCY_DY, Constants.WHAT_REQUEST_GWCY_DY, pageIndexDaiyue);
			}
		});
		tvNoDataMsgDaiyue = (TextView) view1.findViewById(R.id.tv_no_data_daiyue);
		//初始化帮助类
		daiyueHelper = new DocumentGwcyDaiyueHelper(mContext, pullViewDaiyue, listViewDaiyue, tvNoDataMsgDaiyue, helper, callBack);
	}
	
	
	/**
	 * 初始化已阅控件
	 */
	void initYiyueView(){
		pullViewYiyue = (PullToRefreshListView) view2.findViewById(R.id.pulllistview_yiyue);
		pullViewYiyue.setPullRefreshEnabled(true);
		pullViewYiyue.setPullLoadEnabled(false);
		pullViewYiyue.setScrollLoadEnabled(true);
		
		listViewYiyue = pullViewYiyue.getRefreshableView();
		UIHelper.setListViewAttribute(listViewYiyue);
		
		pullViewYiyue.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexYiyue = 1;
				yiyueHelper.loadData(Constants.OPT_TYPE_GWCY_YY, Constants.WHAT_REQUEST_GWCY_YY, pageIndexYiyue);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexYiyue = pageIndexYiyue + 1;
				yiyueHelper.loadData(Constants.OPT_TYPE_GWCY_YY, Constants.WHAT_REQUEST_GWCY_YY, pageIndexYiyue);
			}
		});
		tvNoDataMsgYiyue = (TextView) view2.findViewById(R.id.tv_no_data_msg_yiyue);
		tvNoDataMsgYiyue.setVisibility(View.GONE);
		yiyueHelper = new DocumentGwcyYiyueHelper(mContext, pullViewYiyue, listViewYiyue, tvNoDataMsgYiyue, helper, callBack);
	}
	
	/**
	 * 初始化已传控件
	 */
	void initYichuanView(){
		pullViewYichuan = (PullToRefreshListView) view3.findViewById(R.id.pulllistview_yichuan);
		pullViewYichuan.setPullRefreshEnabled(true);
		pullViewYichuan.setPullLoadEnabled(false);
		pullViewYichuan.setScrollLoadEnabled(true);
		
		listViewYichuan = pullViewYichuan.getRefreshableView();
		UIHelper.setListViewAttribute(listViewYichuan);
		
		pullViewYichuan.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexYichuan = 1;
				yichuanHelper.loadData(Constants.OPT_TYPE_GWCY_YC, Constants.WHAT_REQUEST_GWCY_YC, pageIndexYichuan);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexYichuan = pageIndexYichuan + 1;
				yichuanHelper.loadData(Constants.OPT_TYPE_GWCY_YC, Constants.WHAT_REQUEST_GWCY_YC, pageIndexYichuan);
			}
		});
		tvNoDataMsgYichuan = (TextView) view3.findViewById(R.id.tv_no_data_msg_yichuan);
		tvNoDataMsgYichuan.setVisibility(View.GONE);
		
		yichuanHelper = new DocumentGwcyYichuanHelper(mContext, pullViewYichuan, listViewYichuan, tvNoDataMsgYichuan, helper, callBack);
	}

	/**
	 * 加载数据：待阅
	 */
	public void loadData4DY() {
		pageIndexDaiyue = 1;
		daiyueHelper.loadData(Constants.OPT_TYPE_GWCY_DY, Constants.WHAT_REQUEST_GWCY_DY, pageIndexDaiyue);
	}

	/**
	 * 加载数据：已阅
	 */
	public void loadData4YY() {
		pageIndexYiyue = 1;
		yiyueHelper.loadData(Constants.OPT_TYPE_GWCY_YY, Constants.WHAT_REQUEST_GWCY_YY, pageIndexYiyue);
	}

	/**
	 * 加载数据：已传
	 */
	public void loadData4YC() {
		pageIndexYichuan = 1;
		yichuanHelper.loadData(Constants.OPT_TYPE_GWCY_YC, Constants.WHAT_REQUEST_GWCY_YC, pageIndexYichuan);
	}

	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.system_back){
			onClickBack();
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			//请假详情返回
			if(what == Constants.OPT_TYPE_LEAVE_DETAIL){
				AskLeaveItemHelper leaveItemHelper= new AskLeaveItemHelper();
				leaveItemHelper.process(mContext, response, true);
				
			}else{
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					if (what == Constants.WHAT_REQUEST_GWCY_DY) {// 公文传阅-待阅
						daiyueHelper.process(response, what);
						
					}else if(what == Constants.WHAT_REQUEST_GWCY_YY){	//已阅
						yiyueHelper.process(response, what);
						
					}else if(what == Constants.WHAT_REQUEST_GWCY_YC){	//已传
						yichuanHelper.process(response, what);
					}
				}
			}
		}
	};

	@Override
	protected void onResume() {
		try {
			if (daiyueHelper != null) {
				daiyueHelper.doRemoveItemById();
			}
			if(yiyueHelper!=null){
				yiyueHelper.doRemoveItemById();
			}
			if(yichuanHelper!=null){
				yichuanHelper.doRemoveItemById();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.onResume();
	}
	
	
	/** 初始化动画 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}
	
	/** 初始化头标 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.btn_dy);
		tv2 = (TextView) findViewById(R.id.btn_yy);
		tv3 = (TextView) findViewById(R.id.btn_yc);

		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
		tv3.setOnClickListener(new MyOnClickListener(2));
	}

	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_pager);
		views = new ArrayList<View>();
		LayoutInflater inflater = this.getLayoutInflater();

		view1 = inflater.inflate(R.layout.passread_list_daiyue, null);
		view2 = inflater.inflate(R.layout.passread_list_yiyue, null);
		view3 = inflater.inflate(R.layout.passread_list_yichuan, null);
		views.add(view1);
		views.add(view2);
		views.add(view3);
		viewPager.setAdapter(new MyViewPagerAdapter(views));
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}

	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}

	public class MyViewPagerAdapter extends PagerAdapter {
		private List<View> mListViews;

		public MyViewPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(mListViews.get(position), 0);
			return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);
			animation.setDuration(300);
			imageView.startAnimation(animation);

			if (currIndex == 0) {
				tv1.setBackgroundResource(R.drawable.system_icon_gwcy_dy_s);// “待阅”是选中项
				tv2.setBackgroundResource(R.drawable.system_icon_gwcy_yy);
				tv3.setBackgroundResource(R.drawable.system_icon_gwcy_yc);

			} else if (currIndex == 1) {
				tv1.setBackgroundResource(R.drawable.system_icon_gwcy_dy);
				tv2.setBackgroundResource(R.drawable.system_icon_gwcy_yy_s);// “已阅”是选中项
				tv3.setBackgroundResource(R.drawable.system_icon_gwcy_yc);
				if (isFirst2) {
					loadData4YY();
					//isFirst2 = false;
				}

			} else if (currIndex == 2) {
				tv1.setBackgroundResource(R.drawable.system_icon_gwcy_dy);
				tv2.setBackgroundResource(R.drawable.system_icon_gwcy_yy);
				tv3.setBackgroundResource(R.drawable.system_icon_gwcy_yc_s);// “已传”是选中项
				if (isFirst3) {
					loadData4YC();
					//isFirst3 = false;
				}
			}
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			onClickBack();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void onClickBack(){
		if(Constants.NOTIFY_DETAIL_BACK){
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(mContext, MainActivity.class, null, true);
	        
		}else{
			finish();
		}
	}

}
