package com.powerriche.mobile.na.oa.activity.document;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.os.Handler;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.DocManagerInfo;
import com.powerriche.mobile.na.oa.bean.DocumentInfo;
import com.powerriche.mobile.na.oa.bean.MeetInfo;
import com.powerriche.mobile.na.oa.bean.SignUpInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;

/**
 * 类描述：<br>
 * 会议详情
 * @author Fitz
 * @date 2015年5月9日
 * @version v1.0
 */
public class MeetDetailHelper {

	private Context mContext;
	private IRequestCallBack callBack = null;
	private InvokeHelper helper = null;

	public MeetDetailHelper(Context context, IRequestCallBack callBack, InvokeHelper helper) {
		this.mContext = context;
		this.callBack = callBack;
		this.helper = helper;
	}
	
	// 获取会议详情
	public void getMeetDetail(String meetingId, String wfNo, int what) {
		ApiRequest request = OAServicesHandler.getMeetDetail(meetingId, wfNo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	// 会议通知，获取公文详情
	public void getDocumentDetail(String documentId, String wfNo, int what) {
		ApiRequest request = OAServicesHandler.getDocumentDetail(
				documentId, wfNo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	// 获取报名信息列表
	public void getSignUpList(String meetId, int pageIndex, int what) {
		ApiRequest request = OAServicesHandler.getMeetSingUp(meetId, pageIndex);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	// 删除报名信息列表
	public void delSignUp(String signUpId, int what) {
		ApiRequest request = OAServicesHandler.delMeetSingUp(signUpId);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	// 保存报名信息列表
	public void saveSignUp(SignUpInfo signUpInfo, int what) {
		ApiRequest request = OAServicesHandler.saveMeetSingUp(signUpInfo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}
	
	/**
	 * 加载数据，请求办理环节信息
	 * @param swfNo
	 * @param fpuNo
	 */
	public void loadTranceData(String swfNo, String fpuNo, int what){
        ApiRequest request = OAServicesHandler.getNextFpuAndStaffList(swfNo, fpuNo);
        if (request != null){
            helper.invokeWidthDialog(request, callBack, what);
        }
    }

	public Map<String, Object> process(String meetingId,HttpResponse response, int doucmentType) {
		Map<String, Object> map = new HashMap<String, Object>();

		ResultItem item = response.getResultItem(ResultItem.class);
		if (!BeanUtils.isEmpty(item)) {
			processMeetInfo(meetingId, item, map, doucmentType);
		}
		return map;
	}

	/*public List<SignUpInfo> processSignUp(String meetingId, ResultItem item, Map<String, Object> map) {
		List<SignUpInfo> dataList = null;
		if (!BeanUtils.isEmpty(item)) {
			dataList = signUpManager(meetingId,item);
		}
		return dataList;
	}*/

	private void processMeetInfo(String meetingId, ResultItem item, Map<String, Object> map, int doucmentType) {
		if (BeanUtils.isEmpty(item.getItems("data"))) {
			return;
		}
		
		ResultItem docItem = item.getItems("data").get(0);

		if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {
			getMeetDetail(docItem, map);
			
		}else{
			getDocumentDetail(docItem, map);
		}
		
		// 办理信息
		processManager(docItem, map);
		//附件
		processFileList(docItem, map);
		// 报名列表
		signUpManager(meetingId, docItem, map);
	}
	
	
	/** 解析会议详情 */
	private void getMeetDetail(ResultItem docItem, Map<String, Object> map){
		MeetInfo bean = new MeetInfo();
		String title = docItem.getString("MEETING_TITLE");
		String beginTime = docItem.getString("BEGIN_TIME");
		String endTime = docItem.getString("REGISTER_TIME");
		String persider = docItem.getString("PRESIDER");
		String address = docItem.getString("MEETING_ADDR");
		String content = docItem.getString("MEETING_CONTENT");
		String documentId = docItem.getString("CONTENT_DOCUMENT_ID");

		int exChangFlag = docItem.getInt("EXCHANGE_FLAG", 0);
		int isReceiptReplied = docItem.getInt("IS_RECEIPT_REPLIED", 0);
		int isFirstFpu = docItem.getInt("IS_FIRST_FPU", 0);
		int result = docItem.getInt("RESULT", 0);
		int isCallback = docItem.getInt("IS_CALLBACK", 0);
		
		bean.setTitle(title);
		bean.setBeginTime(beginTime);
		bean.setEndTime(endTime);
		bean.setPersider(persider);
		bean.setAddress(address);
		bean.setContent(content);
		bean.setExchangeFlag(exChangFlag);
		bean.setIsReceiptReplied(isReceiptReplied);
		bean.setIsFirstFpu(isFirstFpu);
		bean.setResult(result);
		bean.setDocumentId(BeanUtils.floatToInt4Str(documentId));
		bean.setIsCallback(isCallback);
		map.put("docBean", bean);
	}
	
	/** 解析公文详情 */
	private void getDocumentDetail(ResultItem docItem, Map<String, Object> map){
		DocumentInfo docBean = new DocumentInfo();
		String wfNo = docItem.getString("WF_NO"); //流程编号
		String sdwNo = docItem.getString("SWF_NO"); //系统流程编号
		String fpuNo = docItem.getString("FPU_NO"); //当前环节
		String docCode = docItem.getString("DOCUMENT_CODE"); //公文编号
		String title = docItem.getString("TITLE"); //标题
		String urgency = docItem.getString("URGENCY_DEGREE"); //缓急1:平件    2：平急    3：急件 4：加急   5：特急    6：特提
		String createDate = docItem.getString("CREATE_DATE"); //创建时间
		String summary = docItem.getString("SUMMARY"); //摘要
		String department = docItem.getString("DRAFT_DEPT");	//拟稿单位
		String userName = docItem.getString("DRAFTER");	//拟稿人
		String level = docItem.getString("IMPORTANCE_DEGREE");	//级别1：公开    2：国内    3：内部 	4：秘密    5：机密    6：绝密
		
		int exChangFlag = docItem.getInt("EXCHANGE_FLAG", 0);
		int isReceiptReplied = docItem.getInt("IS_RECEIPT_REPLIED", 0);
		int isFirstFpu = docItem.getInt("IS_FIRST_FPU", 0);
		int result = docItem.getInt("RESULT", 0);
		int isCallback = docItem.getInt("IS_CALLBACK", 0);

		docBean.setWfNo(wfNo);
		docBean.setSwfNo(sdwNo);
		docBean.setDocCode(docCode);
		docBean.setTitle(title);
		docBean.setUrgency(BeanUtils.floatToInt4Str(urgency));//取整
		docBean.setCreateDate(createDate);
		docBean.setSummary(BeanUtils.isEmptyStr(summary));
		docBean.setDepartment(department);
		docBean.setLevel(BeanUtils.floatToInt4Str(level));//取整
		docBean.setDrafter(BeanUtils.isEmptyStr(userName));
		docBean.setExchangeFlag(exChangFlag);
		docBean.setIsReceiptReplied(isReceiptReplied);
		docBean.setIsFirstFpu(isFirstFpu);
		docBean.setResult(result);
		docBean.setIsCallback(isCallback);
		docBean.setFpuNo(fpuNo == null?"":fpuNo);
		map.put("docBean", docBean);
	}
	
	private void processFileList(ResultItem item, Map<String, Object> map) {
		List<DocFileInfo> fileList = new ArrayList<DocFileInfo>();
		// 获取附件数据
		List<ResultItem> fileItems = item.getItems("File"); // 文件列表
		if (fileItems != null && fileItems.size() > 0) {
			for (ResultItem fileItem : fileItems) {
				String fileCode = fileItem.getString("FILE_CODE"); //文件编号
				String fileLog = fileItem.getString("FILE_CATALOG");//文件标示码
				String fileName = fileItem.getString("FILE_NAME"); //文件名称
				String fileType = fileItem.getString("FILE_TYPE"); //文件类型
				String filePath = fileItem.getString("FILE_PATH"); //文件路径
				String fileTitle = fileItem.getString("FILE_TITLE");//文件标题
				
				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(fileItem.getString("FILE_SIZE"));//文件大小
				if(!BeanUtils.isEmpty(fileSizeStr)){
					fileSize = Integer.parseInt(fileSizeStr);
				}
				
				int logInt = BeanUtils.floatToInt(fileLog);
				DocFileInfo fileBean = new DocFileInfo(fileCode, fileType, fileName, logInt,fileSize);
//				fileBean.setFileName(fileName);
				fileBean.setFileTitle(fileTitle);
				fileBean.setFilePath(filePath);
				fileList.add(fileBean);
			}
		}

		map.put("fileList", fileList);
	}

	private void processManager(ResultItem item, Map<String, Object> map) {
		List<DocManagerInfo> managerList = new ArrayList<DocManagerInfo>();
		// 办理信息
		List<ResultItem> processItems = item.getItems("PROCESSDATA");
		if (processItems != null && processItems.size() > 0) {
			for (ResultItem processItem : processItems) {
				String processor = BeanUtils.isEmptyStr(processItem.getString("PROCESSOR")); // 办理人
				String department = BeanUtils.isEmptyStr(processItem.getString("PROCESSOR_DEPT_NAME")); // 办理人所在部门
				String datatime = BeanUtils.isEmptyStr(processItem.getString("SAVE_DATE")); // 办理时间
				String suggest = BeanUtils.isEmptyStr(processItem.getString("DATA")); // 办理意见

				DocManagerInfo bean = new DocManagerInfo(processor, department, datatime, suggest);
				managerList.add(bean);
			}
		}

		map.put("managerList", managerList);
	}

	/**
	 * 解析报名列表数据
	 * @param item
	 * @param map
	 */
	private void signUpManager(String meetingId, ResultItem item,Map<String, Object> map) {
		List<SignUpInfo> signUpList = new ArrayList<SignUpInfo>();
		// 办理信息
		List<ResultItem> signUpItems = item.getItems("SignUpList");
		if (signUpItems != null && signUpItems.size() > 0) {
			for (ResultItem processItem : signUpItems) {
				String signUpId = BeanUtils.isEmptyStr(processItem.getString("CONVENTIONER_ID")); // 报名编号
				String conventioner = BeanUtils.isEmptyStr(processItem.getString("REAL_ATTENDER")); // 参会人
				String conventionerRole = BeanUtils.isEmptyStr(processItem.getString("CONVENTIONER_DEPT")); // 参会单位
				String contactTel = BeanUtils.isEmptyStr(processItem.getString("CONTACT_TEL")); // 参会人电话
				String summary = BeanUtils.isEmptyStr(processItem.getString("SUMMARY")); // 备注
				//创建对象
				SignUpInfo bean = new SignUpInfo(meetingId,signUpId, conventioner, conventionerRole, contactTel, summary);
				signUpList.add(bean);
			}
		}
		
		map.put("signUpList", signUpList); 
	}
	
	/**
	 * 上传正文
	 * @param documentId
	 * @param swfNo
	 * @param traceNo
	 */
	public void uploadDocFile(String documentId, String swfNo, String traceNo, File file, int what, Handler handler){
		UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadDocFile", documentId, swfNo, traceNo, what);
		List<File> files = new ArrayList<File>();
		files.add(file);
		params.setListFile(files);
		
		HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
		post.execute(params);
		/*ApiRequest request = OAServicesHandler.uploadDocFile(documentId, swfNo, traceNo, file);
		if (request != null){
			request.setMessage(mContext.getString(R.string.system_upload_file));
			helper.invokeWidthDialog(request, callBack, what);
		}*/
	}

}
