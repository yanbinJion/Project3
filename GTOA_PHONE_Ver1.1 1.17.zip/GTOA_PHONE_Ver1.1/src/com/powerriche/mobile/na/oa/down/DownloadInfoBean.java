package com.powerriche.mobile.na.oa.down;

import java.io.Serializable;

/**
 * 类描述：<br> 
 * 下载信息封装类
 * @author  Miter
 * @date    2013-12-13
 */
public class DownloadInfoBean implements Serializable{

	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private String fileCode;
	
	private String fileType;
	
	private long fileSize;
	
	private String url;
	
	private Long createtime;
	
	private Integer state;//0 未下载,1:正在下载,2:下载完成,3:暂停下载,4:已安装,5:已激活
	
	private Integer reportstate;
	
	private String downDir;
	
	private String name;
	
	private String icon;
	
	
	public void setReportstate(Integer reportstate) {
		this.reportstate = reportstate;
	}
	public Integer getReportstate() {
		return reportstate;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public String getUrl() {
		return url;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFileCode() {
		return fileCode;
	}

	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}

	public Long getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Long createtime) {
		this.createtime = createtime;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getDownDir() {
		return downDir;
	}

	public void setDownDir(String downDir) {
		this.downDir = downDir;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
    public long getFileSize()
    {
        return fileSize;
    }
    public void setFileSize(long fileSize)
    {
        this.fileSize = fileSize;
    }
	
	

}
