package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.ExecutiveMeetingActivity;
import com.powerriche.mobile.na.oa.activity.ExecutiveMeetingDetailActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : ExecutiveMeetListHelper
 * 
 * @Description : 常务会议列表查询
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-24 上午 11:38:24
 */
public class ExecutiveMeetListHelper implements onSearchListener {

	private ListView listView;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();
	private List<ResultItem> allResultItems = new ArrayList<ResultItem>();

	private InvokeHelper helper = null;

	private Context mcontext = null;

	private IRequestCallBack callBack = null;

	private ResultSimpleAdapter adapter;
	
	private PullToRefreshListView mPullView;

	private TextView tvNoDataMsg;

	private SearchBarWidget mSearchBarWidget;
	
	private String searchText;
	
	private int pageIndex;

	public ExecutiveMeetListHelper(Context context, View contextView, TextView tvNoDataMsg) {
		this.mcontext = context;
		ExecutiveMeetingActivity acitvity = (ExecutiveMeetingActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		this.tvNoDataMsg = tvNoDataMsg;

		mPullView = (PullToRefreshListView) contextView.findViewById(R.id.pull_listview);

		mSearchBarWidget = (SearchBarWidget) contextView.findViewById(R.id.search_bar_widget);
		mSearchBarWidget.setOnSearchListener(this);

		listView = (ListView) mPullView.getRefreshableView();

		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long arg3) {
				try {
					// 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
					int resultItemIndex = index;
					if(resultItemIndex == 0 && (R.id.layout_search_bar_top == listView.getChildAt(0).getId())){
						return;//跳过：被单击的是搜索栏
					}else{
						resultItemIndex = resultItemIndex - 1;
					}
					ResultItem itemp = resultItems.get(resultItemIndex);
					String meetingId = itemp.getString("MEETING_ID");
					// 封装交互数据
					Bundle data = new Bundle();
					data.putString("meetingId", meetingId);
					// 跳转到详情页面
					UIHelper.forwardTargetActivity(mcontext,
							ExecutiveMeetingDetailActivity.class, data, false);
					// handler.sendEmptyMessage(ExecutiveMeetingActivity.EXECMEET_DETAIL);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void loadData(int what, int index,boolean isDialog) {
		this.pageIndex = index;
		
		// 清楚数据
		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
		ApiRequest request = OAServicesHandler.getExecMeetList(index);
		if (request != null) {
			if(isDialog){
				helper.invokeWidthDialog(request, callBack, what);
			}else{
				helper.invoke(request, callBack, what);
			}
		}
	}

	public void process(HttpResponse response, int what) {
		// resultItems.clear();
		if (pageIndex == 1) {
			resultItems.clear();
			allResultItems.clear();
		}
		List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			resultItems.addAll(items);
			allResultItems.addAll(items);
		}
		if (adapter == null) {
			int[] txtids = { R.id.list_item_text_field,
					R.id.list_item_text_field1 };
			String[] keys = new String[] { "MEETING_TITLE", "BEGIN_TIME" };
			adapter = new ResultSimpleAdapter(mcontext, resultItems,
					R.layout.list_execmeet_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int position) {
					// 如果有搜索关键字，高亮显示
					if (!BeanUtils.isEmpty(searchText)) {
						TextView textView = (TextView) convertView
								.findViewById(R.id.list_item_text_field);
						SearchUtils.spannableResultItems(textView,
								(String) textView.getText(), searchText);
					}
				}
			});
			listView.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items) || items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
			
			if(pageIndex==1 && (BeanUtils.isEmpty(items) || items.size()==0)){
				mPullView.setVisibility(View.GONE);
				tvNoDataMsg.setVisibility(View.VISIBLE);
			}else{
				mPullView.setVisibility(View.VISIBLE);
				tvNoDataMsg.setVisibility(View.GONE);
			}
			
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}
		
	}

	@Override
	public void onSearchChange(String search) {
		searchText = search;
		resultItems.clear();// 清除
		if (allResultItems != null && allResultItems.size() > 0
				&& !BeanUtils.isEmpty(search)) {
			resultItems.addAll(SearchUtils
					.filterResults(allResultItems, search,"MEETING_TITLE"));
		} else {
			resultItems.addAll(allResultItems);
		}

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}

	}

}
