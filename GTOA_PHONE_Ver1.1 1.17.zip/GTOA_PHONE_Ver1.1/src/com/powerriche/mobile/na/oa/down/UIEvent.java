package com.powerriche.mobile.na.oa.down;

/**
 * 类描述：<br> 
 * 通知UI事件
 * @author  Miter
 * @date    2013-12-17
 */
public interface UIEvent {

	/**
	 * 更新进度
	 * 
	 * @param mUrl 下载的url
	 * @param downloadSize 已下载的大小
	 * @param totalSize 总的大小
	 */
	void onProgressUpdate(String url, long downloadSize, long totalSize);

	/**
	 * 更新下载状态
	 * 
	 * @param url
	 * @param state
	 */
	void onDownloadStateChange(String url, int state);
	
	/**
	 * 下载失败通知
	 * @param url
	 * @param Error
	 */
	void onDownloadError(String url, int error);
	
	
	/**
	 * 图标下载完成
	 * @param url
	 * @param data
	 *//*
	void onDownloadIconFinish(String url, byte[] data);
	
	
	*//**
	 * 图标下载失败
	 * @param url
	 * @param data
	 *//*
	void onDownloadIconException(String url, int code);*/
}
