package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * @title 办理信息类
 * @author dir_wang
 * @date 2016-8-1下午5:51:56
 */
public class TransactInfo implements Serializable {
	private static final long serialVersionUID = -8641779414844313926L;
	private String actionId;
	private String processor;
	private String action;
	private String beginTime;
	private String endTime;
	private String readTime;
	private String remark;

	public String getActionId() {
		return actionId;
	}

	public String getProcessor() {
		return processor;
	}

	public String getAction() {
		return action;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public String getReadTime() {
		return readTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public void setReadTime(String readTime) {
		this.readTime = readTime;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
