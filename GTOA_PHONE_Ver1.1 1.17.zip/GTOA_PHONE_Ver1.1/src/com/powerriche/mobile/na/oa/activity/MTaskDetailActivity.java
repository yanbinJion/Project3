package com.powerriche.mobile.na.oa.activity;
	
import java.util.ArrayList;
import java.util.List;
	
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
	
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.*;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.UserListHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.NoScrollListView;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.TaskDetails;
import com.powerriche.mobile.na.oa.bean.TaskParams;
import com.powerriche.mobile.na.oa.down.DownloadInfoBean;
import com.powerriche.mobile.na.oa.down.DownloadInfoDAO;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper.DownloadButtonListener;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;
    	
/** 	
 * 任务详情
 *  	
 * @author homezww
 *  	
 */ 	

public class MTaskDetailActivity extends BaseActivity implements
		OnClickListener, OnLongClickListener, DownloadButtonListener {
		
	public static final int CODE_BASIC = 0; // 任务信息
		
    private static MTaskDetailActivity instance;
    	
	private Context mContext;
	
	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片
	
	private View view1, view2, view3, view4, view5;
	
	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	
	private TextView tv_shangbaoleixing, tv_title_view1,
			tv_task_niandu, tv_zhusongperson, tv_xiabanperson;
	private Button sendBtn;
	
	private TextView tv_leixing;
	
	private EditText et_text_sqreason, et_taskevent_addrs, et_taskevent_zysb, et_beizhu,
			tv_banli_shiixan;
	private LinearLayout eventWorkLay;
	
	private TextView tvFileGroup;
	private LinearLayout llFileWrap;
	
	private PullToRefreshListView pullView;
	private ListView listView;
	private TextView noDataTxt;
	
	public static String meetingId;
	private String fpuNo, swfNo, traceNo, taskId;
	private String wfNo;
	
	private Button rightBtn = null, btnBaoming = null;
	
    private Button processBtn;
    
	public static final int CODE_PASS_READ_TAG = 1000;
	
	/**
	 * 已办的公文或者会议都不能删除增加附件<br>
	 * true可以删除新增
	 */
	private boolean isDeleteAddToken = true;
	
	private DownloadUIHelper downloadUIHelper = null;
	private DownloadInfoDAO dao = null;
	// 当前信息是否可以编辑
	private boolean editable = false;
    //当前任务是否已经办结
    private boolean isComplete = false;
	// 是否是首次进入
	private boolean isfirst = true;
	
	private TaskDetails detail = new TaskDetails();
	private MyViewPagerAdapter pagerAdapter;
	
	private TaskProcessAdapter processAdapter;
    //历史进度信息的详情id
    private String progressDetailId;
    //历史进度信息列表
    private NoScrollListView historyList;
    private TaskHistoryAdapter historyAdapter;
    private ListView progressList;
    private TaskProgressInfoAdapter progressInfoAdapter;
    private String curProgressId;
    private String documentId;
    
    private ListView suggestList;
    private TaskSuggestAdapter suggestAdapter;
    private TextView suggestNoData;
    private TextView processNoData;
    
    //详情中，如果有进度详情，则显示这个
    private HorizontalScrollView horizontalScrollView;
    //对应任务详情，事件信息，进度信息，处理信息，处理意见
    private TextView tv1,tv2, tv3, tv4, tv5;
    //详情中，如果没有进度详情，则显示这个
    private LinearLayout tabLayout;
    //对应任务详情，事件信息，处理信息，处理意见
    private TextView tv6,tv7, tv8, tv9;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		this.mContext = this;
        instance = this;
		// 设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.my_task_detail_layout);
	
		taskId = getIntent().getStringExtra("taskId"); // 任务编号
//		if (!BeanUtils.isNullOrEmpty(taskId)) {
//			taskId = BeanUtils.floatToInt4Str(taskId);
//			detail.setTaskId(Integer.valueOf(taskId));
//		}
	
		Intent intent = getIntent();
		swfNo = intent.getStringExtra("swfNo"); // 系统流程编号
		wfNo = intent.getStringExtra("wfNo");
//		if (!BeanUtils.isNullOrEmpty(tempWFNO)) {
//			wfNo = Integer.valueOf(tempWFNO.contains(".") ? tempWFNO.substring(
//					0, tempWFNO.indexOf(".")) : tempWFNO);
//		}
        isComplete = intent.getBooleanExtra("isComplete", false);
        traceNo = intent.getStringExtra("traceNo");
		fpuNo = intent.getStringExtra("fpuNo");
		editable = intent.getBooleanExtra("editable", editable);
        
		Log.i("TEST", " taskId="+taskId+" swfNo ="+swfNo+" wfNo= "+wfNo+" isComplete= "+isComplete+" traceNo= "+traceNo+" fpuNo= "+fpuNo+" editable= "+editable);
		bindViews();
		
		this.downloadUIHelper = new DownloadUIHelper(mContext);
		this.downloadUIHelper.setEventListener(this);
		this.dao = new DownloadInfoDAO(mContext);
		
	}	
		
    private void getDocumentId() {
        ApiRequest request = OAServicesHandler.getTaskProgressDocumentId();
        if (request != null) {
            helper.invoke(request, callBack, taskDocumentId);
        }	
    }	
    	
	// 获取任务详情
	public void getTaskDetail() {
		ApiRequest request = OAServicesHandler.getTaskDetail(taskId, wfNo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, taskDetail);
		}
	}	
		
	// 获取事件详情
	private void getEventDetail() {
		ApiRequest request = OAServicesHandler.getTaskWorkContent(taskId);
		helper.invoke(request, callBack, taskEvent);
	}	
		
	// 获取进度详情
	private void getProgressDetail() {
		ApiRequest request = OAServicesHandler.getTaskProgressInfo(taskId);
		helper.invoke(request, callBack, taskProgress);
	}	
		
	// 查看历史
	private void getHistoryProgressInfo(String no) {
//		String processNo = progressInfo.getProcessNo();
		ApiRequest request = OAServicesHandler.getTaskHistoryProgressInfo(
				taskId, no);
		helper.invokeWidthDialog(request, callBack, historyProgressInfo);
	}	
		
	// 任务办结接口
	private void processTask() {
		ApiRequest request = OAServicesHandler.finishWorkFlow(taskId);
		helper.invokeWidthDialog(request, callBack, processTask);
	}	
		
	// 任务签收接口
	private void assignTask() {
		ApiRequest request = OAServicesHandler.taskSignUp(taskId);
		helper.invokeWidthDialog(request, callBack, assignTask);
	}	
		
	// 任务分派
	private void dispatcherTask() {
		ApiRequest request = OAServicesHandler.assignTask(taskId);
		helper.invokeWidthDialog(request, callBack, dispatcherTask);
	}	
		
    //设置控件是否可以编辑
    private void setDisable() {
        tv_title_view1.setEnabled(false);
        tv_banli_shiixan.setEnabled(false);
        tv_shangbaoleixing.setEnabled(false);
        tv_task_niandu.setEnabled(false);
        tv_zhusongperson.setEnabled(false);
        tv_xiabanperson.setEnabled(false);
        
        tv_leixing.setEnabled(false);
        tv_leixing.setEnabled(false);
        et_text_sqreason.setEnabled(false);
        et_taskevent_addrs.setEnabled(false);
        et_taskevent_zysb.setEnabled(false);
        et_beizhu.setEnabled(false);
        
//        tv_report_name.setEnabled(false);
//        et_from_date.setEnabled(false);
//        et_to_date.setEnabled(false);
//        tv_progress_complete_degree.setEnabled(false);
//        tv_progress_complete_time.setEnabled(false);
//        tv_progress_sum_human_cost.setEnabled(false);
//        tv_progress_sum_quantity.setEnabled(false);
//        tv_progress_sum_time.setEnabled(false);
//        tv_progress_sum_money.setEnabled(false);
    }	
    	
	int taskDetail = 0;
	int taskEvent = 1;
	int taskProgress = 2;
	int taskProcessor = 3;
	int processTask = 4;
	int assignTask = 5;
	int dispatcherTask = 6;
	int historyProgressInfo = 7;
    int taskDocumentId = 8;
    	
	// 显示任务详情信息
	private void showDetailInfo(ResultItem result) {
		if (null == result) {
			return;
		}
		detail.setContact(result.getString("CONTACTOR"));
		detail.setContactPhone(result.getString("CONTACTOR_PHONE"));
		detail.setCopySubmit(result.getString("COPY_TO_NO"));
		detail.setCreateName(result.getString("CREATE_NAME"));
		detail.setCreateTime(result.getString("CREATE_TIME"));
		detail.setLimitTime(result.getString("LIMIT_TIME"));
		detail.setMainSubmit(result.getString("SUBMIT_TO_NO"));
		detail.setMainName(result.getString("SUBMIT_TO_NAME"));
		detail.setCopyName(result.getString("COPY_TO_NAME"));
		detail.setSubmitType(result.getString("PLAN_TIMESPAN_TYPE"));
		detail.setTaskCode(result.getString("TASK_CODE"));
        String taskName = result.getString("TASK_TITLE");
        if (!BeanUtils.isNullOrEmpty(taskName)) {
            String about = "关于";
            String one = "的";
            int aboutIndex = taskName.indexOf(about);
            int oneIndex = taskName.lastIndexOf(one);
            if (aboutIndex == 0 && (taskName.length() > about.length() + one.length())) {
                taskName = taskName.substring(aboutIndex + about.length(), oneIndex);
            }
		    detail.setTaskTitle(taskName);
        }
        detail.setTaskState(BeanUtils.floatToInt4Str(result.getString("TASK_STATE")));
        detail.setSign(BeanUtils.floatToInt4Str(result.getString("IS_SIGN")));
        detail.setPassState(BeanUtils.floatToInt4Str(result.getString("PASS_STATE")));
        detail.setActionNo(result.getString("ACTION_NO"));
        detail.setProcessResult(BeanUtils.floatToInt4Str(result.getString("RESULT")));
        //任务接收
        if (!editable) { 
            if (!detail.isEditable()) {
                isComplete = true;
            }
        } else {
            //任务发送
            if (!detail.isEditable()) {
                isComplete = true;
            } else if ("0".equals(detail.getTaskState()) && detail.isProcessAction()) {
                processBtn.setVisibility(View.VISIBLE);
            }
        }
        setUiEnable();
		String year = result.getString("TASK_YEAR");
		year = (null != year && year.contains(".")) ? year.substring(0,
				year.indexOf(".")) : year;
		detail.setTaskYear(year);
		detail.setDocumentId(result.getString("DOCUMENT_ID"));
		tv_title_view1.setText(detail.getTaskTitle());
		tv_banli_shiixan.setText(detail.getLimitTime());
		tv_shangbaoleixing.setText(detail.getType());
		tv_task_niandu.setText(detail.getTaskYear());
		tv_zhusongperson.setText(detail.getMainName());
		tv_xiabanperson.setText(detail.getCopyName());
		List<ResultItem> file = result.getItems("File");
		List<ResultItem> process = result.getItems("ProcessData");
        List<ResultItem> suggest = result.getItems("ActionData");
		if (!BeanUtils.isEmpty(file)) {
			ArrayList<DocFileInfo> files = new ArrayList<DocFileInfo>();
			for (ResultItem item : file) {
				DocFileInfo docFileInfo = new DocFileInfo();
				docFileInfo.setFileCode(item.getString("FK_FILE_CODE"));
				docFileInfo.setFileName(item.getString("FILE_NAME"));
				docFileInfo.setFilePath(item.getString("FTP_PATH"));
				docFileInfo.setFileTitle(item.getString("FILE_TITLE"));
				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(item.getString("FILE_SIZE"));//文件大小
				if(!BeanUtils.isEmpty(fileSizeStr)){
					fileSize = Integer.parseInt(fileSizeStr);
				}
				docFileInfo.setFileSize(fileSize);
				files.add(docFileInfo);
			}
			detail.setFileInfoList(files);
			foreachFiles(files);
		}
		if (!BeanUtils.isEmpty(process)) {
			ArrayList<TaskDetails.ProcessInfo> processes = new ArrayList<TaskDetails.ProcessInfo>(
					process.size());
			for (ResultItem item : process) {
				TaskDetails.ProcessInfo pro = detail.new ProcessInfo();
				pro.setActionName(item.getString("ACTION_NAME"));
				pro.setData(item.getString("DATA"));
				pro.setDeptName(item.getString("PROCESSOR_DEPT_NAME"));
				pro.setProcessor(item.getString("PROCESSOR"));
				pro.setProcessTime(item.getString("SAVE_DATE"));
				processes.add(pro);
			}
			detail.setProcessInfos(processes);
		}
        if (!BeanUtils.isEmpty(suggest)) {
            ArrayList<TaskDetails.Suggest> suggests = new ArrayList<TaskDetails.Suggest>(suggest.size());
            for (ResultItem item : suggest) {
                TaskDetails.Suggest temp = detail.new Suggest();
                temp.setActionId(item.getString("ACTION_ID"));
                temp.setAction(item.getString("ACTION"));
                temp.setBeginTime(item.getString("BEGIN_TIME"));
                temp.setProcessor(item.getString("PROCESSOR"));
                temp.setEndTime(item.getString("END_TIME"));
                temp.setReadTime(item.getString("READ_TIME"));
                temp.setRemark(item.getString("REMARK"));
                suggests.add(temp);
            }
            detail.setSuggests(suggests);
        }
        if (!isComplete) {
            sendBtn.setVisibility(View.VISIBLE);
        }
	}

	// 显示事件详情
	private void showEventInfo(ResultItem result) {
		
		if (null == result) {
			return;
		}
		
		Log.i("TEST", result.getString("ITEM_TYPE")+"  hehe "+result.getString("ITEM_NAME")+" hehe "+result.getString("ITEM_ADDRESS")+" hehe "+result.getString("ITEM_ASSIGN"));
		
		TaskDetails.EventInfo eventInfo = detail.new EventInfo();
		String type = result.getString("ITEM_TYPE");
//		type = type.substring(0, type.indexOf("."));
		tv_leixing.setText(UIHelper.getTaskEventTypeString(MTaskDetailActivity.this,type));
		tv_leixing.setTag(result.getString("ITEM_TYPE"));
		et_text_sqreason.setText(result.getString("ITEM_NAME"));
		et_taskevent_addrs.setText(result.getString("ITEM_ADDRESS"));
		et_taskevent_zysb.setText(result.getString("ITEM_ASSIGN"));
		et_beizhu.setText(result.getString("ITEM_REMARK"));
		
		Log.i("TEST", result.getString("ITEM_TYPE")+"  hehe "+result.getString("ITEM_NAME")+" hehe "+result.getString("ITEM_ADDRESS")+" hehe "+result.getString("ITEM_ASSIGN"));
		
		eventInfo.setReason(result.getString("ITEM_NAME"));
		eventInfo.setAddress(result.getString("ITEM_ADDRESS"));
		eventInfo.setDevice(result.getString("ITEM_ASSIGN"));
		eventInfo.setRemark(result.getString("ITEM_REMARK"));
		eventInfo.setType(type);
		List<ResultItem> workList = result.getItems("WorkList");
		if (!BeanUtils.isEmpty(workList)) {
			LayoutInflater inflater = getLayoutInflater();
			if (eventWorkLay.getChildCount() > 0) {
				eventWorkLay.removeAllViews();
			}
			ArrayList<String> events = new ArrayList<String>(workList.size());
			for (int i = 0; i < workList.size(); i++) {
				LinearLayout layout = (LinearLayout) inflater.inflate(
						R.layout.task_evnet_list_item, null);
				TextView txt = (TextView) layout
						.findViewById(R.id.event_no_txt);
				EditText content = (EditText) layout
						.findViewById(R.id.event_content_edt);
				txt.setText(getString(R.string.task_event_list_tip) + (i + 1));
				content.setText(workList.get(i).getString("ITEM_CONTENT"));
				if(!BeanUtils.isNullOrEmpty(workList.get(i).getString("ITEM_CONTENT"))) {
					content.setText(workList.get(i).getString("ITEM_CONTENT"));
				}
				content.setFocusable(false);
				content.setEnabled(false);
				events.add(workList.get(i).getString("ITEM_CONTENT"));
				eventWorkLay.addView(layout);
			}
			eventInfo.setWorkList(events);
		}
		detail.setEvent(eventInfo);
	}

	// 显示历史进度信息
	private void showHistoryProgressInfo(List<ResultItem> resultSet) {
		if (BeanUtils.isEmpty(resultSet)) {
			return;
		}
//        isApprovalGroup();
        TaskDetails.HistoryProgress history = null;
        ArrayList<TaskDetails.HistoryProgress> infos = new ArrayList<TaskDetails.HistoryProgress>(resultSet.size());
        for (ResultItem result : resultSet) {
            history = detail.new HistoryProgress();
            history.setCompleteTime(result.getString("PROGRESS_COMPLETE_TIME"));
            history.setContent(result.getString("PROGRESS_CONTENT"));
            history.setDegree(result.getString("PROGRESS_COMPLETE_DEGREE"));
            history.setDetailId(BeanUtils.floatToInt4Str(result.getString("PROGRESS_DETAILS_ID")));
            history.setDocumentId(BeanUtils.floatToInt4Str(result.getString("DOCUMENT_ID")));
            history.setFromDate(result.getString("PROGRESS_FROM_DATE"));
            history.setProgressId(BeanUtils.floatToInt4Str(result.getString("PROGRESS_ID")));
            history.setRemark(result.getString("REMARK"));
//            history.setReportName();
//            history.setReportTime();
            history.setSumHumanCost(result.getString("PROGRESS_SUM_HUMAN_COST"));
            history.setSumMoney(result.getString("PROGRESS_SUM_MONEY"));
            history.setSumQuantity(result.getString("PROGRESS_SUM_QUANTITY"));
            history.setSumTime(result.getString("PROGRESS_SUM_TIME"));
            history.setToDate(result.getString("PROGRESS_TO_DATE"));
            infos.add(history);
        }
//        detail.setHistoryInfos(infos);
//        if (null == historyAdapter) {
//            historyAdapter = new TaskHistoryAdapter(this);
//            historyList.setAdapter(historyAdapter);
//        }
//        historyAdapter.updateData(infos);
        detail.putProgressMaps(curProgressId, infos);
        updateProgressList();
//		tv_check_history.setVisibility(View.VISIBLE);
	}

	// 显示进度信息
	private void showProgressInfo(ResultItem resultItem) {
		if (null == resultItem) {
			return;
		}
        String code = resultItem.getString("code");
        String message = resultItem.getString("message");
        Object resultTemp = resultItem.get("data");
        if (!Constants.SUCCESS_CODE.equals(code) || null == resultTemp) {
//          UIHelper.showMessage(mContext, message);
//            views.clear();
            views.remove(view3);
            tv3.setVisibility(View.GONE);
//            views.add(view1);
//            views.add(view2);
//            views.add(view4);
//            views.add(view5);
//            initImageView();
            tv1.setOnClickListener(new MyOnClickListener(0));
            tv2.setOnClickListener(new MyOnClickListener(1));
            tv4.setOnClickListener(new MyOnClickListener(2));
            tv5.setOnClickListener(new MyOnClickListener(3));
            pagerAdapter.notifyDataSetChanged();
            setSelectTab();
            return;
        } else if (tv3.getVisibility() != View.VISIBLE){
//            views.clear();
            tv3.setVisibility(View.VISIBLE);
            views.set(2, view3);
//            views.add(view1);
//            views.add(view2);
//            views.add(view3);
//            views.add(view4);
//            views.add(view5);
            initImageView();
            tv1.setOnClickListener(new MyOnClickListener(0));
            tv2.setOnClickListener(new MyOnClickListener(1));
            tv3.setOnClickListener(new MyOnClickListener(2));
            tv4.setOnClickListener(new MyOnClickListener(3));
            tv5.setOnClickListener(new MyOnClickListener(4));
            pagerAdapter.notifyDataSetChanged();
            setSelectTab();
        }
        initImageView();
        List<ResultItem> resultSet = null;
        if (null != resultTemp && resultTemp instanceof ResultItem) {
            resultSet = new ArrayList<ResultItem>(1);
            resultSet.add((ResultItem) resultItem.get("data"));
        } else {
            resultSet = resultItem.getItems("data");
        }
        infos = new ArrayList<TaskDetails.ProgressInfo>(resultSet.size());
        TaskDetails.ProgressInfo info = null;
        for (ResultItem result : resultSet) {
            info = detail.new ProgressInfo();
            info.setProcessNo(result.getString("PROCESS_NO"));
            info.setProgressContent(result.getString("PROGRESS_CONTENT"));
            info.setReportName(result.getString("REPORT_NAME"));
            info.setFromDate(result.getString("PROGRESS_FROM_DATE"));
            info.setToDate(result.getString("PROGRESS_TO_DATE"));
            info.setProgerssCompleteDegree(result.getString("PROGRESS_COMPLETE_DEGREE"));
            info.setCompleteTime(result.getString("PROGRESS_COMPLETE_TIME"));
            info.setCost(result.getString("PROGRESS_SUM_HUMAN_COST"));
            info.setQuantity(result.getString("PROGRESS_SUM_QUANTITY"));
            info.setSumTime(result.getString("PROGRESS_SUM_TIME"));
            info.setSumMoney(result.getString("PROGRESS_SUM_MONEY"));
            infos.add(info);
        }
//        progressInfo = infos.get(infos.size() - 1);
        detail.setProgressInfos(infos);
        updateProgressList();
        curProgressId = infos.get(0).getProcessNo();
        getHistoryProgressInfo(curProgressId);
	}

	// 显示办理信息列表
	private void showProcessInfo() {
		if (BeanUtils.isEmpty(detail.getProcessInfos())) {
            processNoData.setVisibility(View.VISIBLE);
			return;
		}
        processNoData.setVisibility(View.GONE);
		if (null == processAdapter) {
			processAdapter = new TaskProcessAdapter(this);
			processAdapter.addData(detail.getProcessInfos());
			listView.setAdapter(processAdapter);
		} else {
			processAdapter.clearListData();
			processAdapter.addData(detail.getProcessInfos());
			processAdapter.notifyDataSetChanged();
		}
	}

    // 显示办理意见列表
    private void showProcessSuggest() {
        if (BeanUtils.isEmpty(detail.getSuggests())) {
            suggestNoData.setVisibility(View.VISIBLE);
            return;
        }
        suggestNoData.setVisibility(View.GONE);
        if (null == suggestAdapter) {
            suggestAdapter = new TaskSuggestAdapter(this);
            suggestAdapter.addData(detail.getSuggests());
            suggestList.setAdapter(suggestAdapter);
        } else {
            suggestAdapter.clearListData();
            suggestAdapter.addData(detail.getSuggests());
            suggestAdapter.notifyDataSetChanged();
        }
    }

    private TaskProgressInfoAdapter.OnTextClickListener textClickListener = new TaskProgressInfoAdapter.OnTextClickListener() {
        @Override
        public void onTextClick(View v, String no) {
            if (null != detail && !BeanUtils.isEmpty(detail.getMapListByNo(no))) {
                progressInfoAdapter.notifyDataSetChanged();
                return;
            }
            getHistoryProgressInfo(no);
        }
    };

    private void updateProgressList() {
        if (null == progressInfoAdapter) {
            progressInfoAdapter = new TaskProgressInfoAdapter(this, textClickListener);
            progressList.setAdapter(progressInfoAdapter);
        }
        progressInfoAdapter.setChildData(detail.getProgressMaps());
        progressInfoAdapter.updateData(detail.getProgressInfos());
    }

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem reusltItem = response.getResultItem(ResultItem.class);
			if (taskProgress == what) {
				showProgressInfo(reusltItem);
				return;
			}
            if (!checkResult(reusltItem)) {
                return;
            }
			ResultItem result = null;
			String code = reusltItem.getString("code");
			String message = reusltItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(mContext, message);
				return;
			}
            //历史进度信息返回数据是list，需要解析为集合
            if (historyProgressInfo == what) {
                List<ResultItem> resultSet = reusltItem.getItems("data");
                showHistoryProgressInfo(resultSet);
                return;
            } else if (taskProgress == what) {
                showProgressInfo(reusltItem);
                return;
            }
            result = (ResultItem) reusltItem.get("data");
            if (what == taskDetail) {
                getEventDetail();
                getProgressDetail();
				showDetailInfo(result);
			} else if (what == taskEvent) {
//				ResultItem resultItem = result.getItems("data").get(0);
				showEventInfo(result);
			} else if (processTask == what) {
				UIHelper.showMessage(mContext, message);
				MTaskDetailActivity.this.finish();
			} else if (assignTask == what) {
				rightBtn.setText(getString(R.string.task_pop_item_upload));
				detail.setSign("1");
				UIHelper.showMessage(mContext, message);
			} else if (dispatcherTask == what) {
				UIHelper.showMessage(mContext, message);
				MTaskDetailActivity.this.finish();
			} else if (taskDocumentId == what) {
                documentId = reusltItem.getString("document_id");
            }
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			rightBtn.setClickable(true);
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			rightBtn.setClickable(true);
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	private EditText et_from_date, et_to_date;
	private TextView tv_report_name, tv_progress_complete_degree,
			tv_progress_complete_time, tv_progress_sum_human_cost,
			tv_progress_sum_quantity, tv_progress_sum_time,
			tv_progress_sum_money;

	private void bindViews() {
		findViewById(R.id.system_back).setOnClickListener(this);
		TextView tvTitle = (TextView) findViewById(R.id.tv_top_title);
		tvTitle.setText(getString(R.string.taskmeet_detail_title));
		rightBtn = (Button) findViewById(R.id.btn_top_right);
		
		initTextView();
		initViewPager();
		initView1Zbhy();// 第1部分：任务信息-任务详情
		initView2();// 第2部分：事件信息
		initViewProgressInfo();// 第3部分：进度信息
        setUiEnable();
	}

    private void setUiEnable() {
        //如果不是已经办理或者是可编辑
        if (!isComplete) {
        	System.out.println("---------------------");
            rightBtn.setVisibility(View.VISIBLE);
            rightBtn.setOnClickListener(this);
            //如果是接收任务而且没有签收
            if (!editable && (null != detail && !detail.isSign())) {
                rightBtn.setText(getString(R.string.send_accept_counts));
            } else {
                //如果是接收任务详情界面，该任务已经签收，则只能上报，没有办结操作
                if (!editable) {
                    rightBtn.setText(getString(R.string.task_pop_item_upload));
                    //发送详情界面
                } else {
                    UIHelper.setBtnStyle(mContext, this.rightBtn,
                            R.drawable.ic_more_menu);
                }
            }
            
            btnBaoming = (Button) findViewById(R.id.btn_top_baoming);
            btnBaoming.setOnClickListener(this);
        } else {
        	System.out.println("--------ffdasfasdfsf-------------");
            rightBtn.setVisibility(View.GONE);
        }
        setDisable();
    }	
    	
	// 初始化进度信息控件
	private void initViewProgressInfo() {
        progressList = (ListView) view3.findViewById(R.id.task_progress_lst);
        suggestList = (ListView) view5.findViewById(R.id.task_progress_lst);
        suggestNoData = (TextView) view5.findViewById(R.id.tv_no_data_msg);
        processNoData = (TextView) view4.findViewById(R.id.tv_no_data_msg);
	}	
		
	private TextView tv_check_history;
	private LinearLayout ll_check_history;
		
	private void initView2() {
		tv_leixing = (TextView) view2.findViewById(R.id.tv_leixing);
		et_text_sqreason = (EditText) view2.findViewById(R.id.et_text_sqreason);
		et_taskevent_addrs = (EditText) view2
				.findViewById(R.id.et_taskevent_addrs);
		et_taskevent_zysb = (EditText) view2
				.findViewById(R.id.et_taskevent_zysb);
		et_beizhu = (EditText) view2.findViewById(R.id.et_beizhu);
		
		eventWorkLay = (LinearLayout) view2.findViewById(R.id.event_work_lay);
		
		// processList = (ListView) view4.findViewById(R.id.task_process_list);
		// processNoDataLay = (LinearLayout)
		// view4.findViewById(R.id.task_process_empty_lay);
		pullView = (PullToRefreshListView) view4
				.findViewById(R.id.my_task_pulllistview);
		pullView.setPullRefreshEnabled(false);
		pullView.setPullLoadEnabled(false);
		pullView.setScrollLoadEnabled(false);
		noDataTxt = (TextView) view4.findViewById(R.id.tv_no_data_msg);
		noDataTxt.setVisibility(View.GONE);
		
		listView = pullView.getRefreshableView();
		UIHelper.setListViewAttribute(listView);
	}	
		
	private void initView1Zbhy() {
		tv_title_view1 = (TextView) view1.findViewById(R.id.tv_title);// tv_title_view1
		tv_banli_shiixan = (EditText) view1.findViewById(R.id.tv_banli_shiixan);
		tv_banli_shiixan.setOnClickListener(this);
		tv_shangbaoleixing = (TextView) view1
				.findViewById(R.id.tv_shangbaoleixing);
		tv_task_niandu = (TextView) view1.findViewById(R.id.tv_task_niandu);
		tv_zhusongperson = (TextView) view1.findViewById(R.id.tv_zhusongperson);
		tv_xiabanperson = (TextView) view1.findViewById(R.id.tv_xiabanperson);
		
		tvFileGroup = (TextView) view1.findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		tvFileGroup.setVisibility(View.VISIBLE);
		llFileWrap = (LinearLayout) view1.findViewById(R.id.ll_file_wrap);
		llFileWrap.setVisibility(View.GONE);
        processBtn = (Button) view1.findViewById(R.id.task_detail_process_btn);
        processBtn.setOnClickListener(this);
        
        sendBtn = (Button) view1.findViewById(R.id.btn_send);
        if (!isComplete) {
            sendBtn.setOnClickListener(this);
            sendBtn.setVisibility(View.GONE);
        }
	}

	private ExpandableListView exUserList;
	private UserListHelper userHelper;

	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	@SuppressLint("InflateParams")
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_pager);
		views = new ArrayList<View>();
		LayoutInflater inflater = getLayoutInflater();
		
		view1 = inflater.inflate(R.layout.task_info_viewshow1, null); // 加载任务信息
		view2 = inflater.inflate(R.layout.task_eventinfo_viewshow, null);// 加载事件信息
		view3 = inflater.inflate(R.layout.task_jinduinfo_viewshow, null);// 加载进度信息
		// view4 = inflater.inflate(R.layout.task_banli_viewshow4, null);//办理信息
		view4 = inflater.inflate(R.layout.my_task_list_layout, null);
        view5 = inflater.inflate(R.layout.task_detail_suggest, null);
        
		// view2.findViewById(R.id.btn_new_file).setOnClickListener(this);
        
		views.add(view1);
		views.add(view2);
		views.add(view3);
		views.add(view4);
        views.add(view5);
        
		initImageView();
		pagerAdapter = new MyViewPagerAdapter();
		viewPager.setAdapter(pagerAdapter);
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
        setSelectTab();
        
	}	
		
    private void setSelectTab() {
        if (currIndex < 0 || currIndex >= views.size()) {
            currIndex = 0;
        }
        if (tv3.getVisibility() == View.VISIBLE) {
            UIHelper.setTabTextHeighLight(mContext, currIndex, tv1, tv2, tv3, tv4, tv5);
        } else {
            UIHelper.setTabTextHeighLight(mContext, currIndex, tv1, tv2, tv4, tv5);
        }	
    }		
    		
	public class MyOnPageChangeListener implements OnPageChangeListener {
			
		public void onPageScrollStateChanged(int arg0) {
			
		}	
			
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			
		}	
			
		public void onPageSelected(int arg0) {
//            int one = offset * 2 + bmpW - 20;// 页卡1 -> 页卡2 偏移量
//            if (tv3.getVisibility() == View.VISIBLE) {
//			    UIHelper.setTabTextHeighLight(mContext, arg0, tv1, tv2, tv3, tv4, tv5);
//            } else {
//                UIHelper.setTabTextHeighLight(mContext, arg0, tv1, tv2, tv4, tv5);
//            }
//			Animation animation = new TranslateAnimation((offset * 2 + bmpW)
//					* currIndex, (offset * 2 + bmpW) * arg0, 0, 0);
			currIndex = arg0;
            setSelectTab();
//			animation.setFillAfter(true);// True:图片停在动画结束位置
//			animation.setDuration(200);
//			imageView.startAnimation(animation);
            Logger.d("onPageSelected", "curIndex: " + currIndex + "  size: " + views.size());
			if (currIndex == 0) {// 任务信息
				if (null == detail) {
					getTaskDetail();
				}
			} else if (currIndex == 1) { // 打开事件信息
				if (null == detail.getEvent()) {
					getEventDetail();
				}
			} else if (currIndex == views.size() - 1) {
                showProcessSuggest();
			} else if (currIndex == views.size() - 2) {
                showProcessInfo();
            } else {
                if (null == detail.getProgressInfos()) {
				    getProgressDetail();
                }
			}
            Logger.d("onPageSelected", "curIndex: " + currIndex + "  size: " + views.size());
		}
	}

	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}

	public class MyViewPagerAdapter extends PagerAdapter {
		
		public MyViewPagerAdapter() {
		}
		
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(views.get(position));
		}
		
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			
			container.addView(views.get(position));
			
//            if (tv3.getVisibility() == View.VISIBLE) {
//                UIHelper.setTabTextHeighLight(mContext, position, tv1, tv2, tv3, tv4, tv5);
//            } else {
//                UIHelper.setTabTextHeighLight(mContext, position, tv1, tv2, tv4, tv5);
//            }
            Logger.d("MyViewPagerAdapter", "instantiateItem" + position);
			return views.get(position);
		}	
			
		@Override
		public int getCount() {
			return views.size();
		}	
			
		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}	
		
	/**	
	 * 初始化头标
	 */	
	private void initTextView() {
        horizontalScrollView = (HorizontalScrollView) findViewById(R.id.detail_horizontal_scroll);
		tv1 = (TextView) findViewById(R.id.tv_1);
		tv2 = (TextView) findViewById(R.id.tv_2);
		
		tv3 = (TextView) findViewById(R.id.tv_3);
		tv4 = (TextView) findViewById(R.id.tv_4);
        tv5 = (TextView) findViewById(R.id.tv_5);
        
        tv6 = (TextView) findViewById(R.id.tv_6);
        tv7 = (TextView) findViewById(R.id.tv_7);
        tv8 = (TextView) findViewById(R.id.tv_8);
        tv9 = (TextView) findViewById(R.id.tv_9);
        
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor)
				.getWidth();// 获取图片宽度
        tv1.setOnClickListener(new MyOnClickListener(0));
        tv2.setOnClickListener(new MyOnClickListener(1));
        tv3.setOnClickListener(new MyOnClickListener(2));
        tv4.setOnClickListener(new MyOnClickListener(3));
        tv5.setOnClickListener(new MyOnClickListener(4));
	}	
		
	/** 
	 * 初始化动画
	 */ 
	private void initImageView() {
//		DisplayMetrics dm = new DisplayMetrics();
//		getWindowManager().getDefaultDisplay().getMetrics(dm);
//		int screenW = dm.widthPixels;// 获取分辨率宽度
//		offset = (screenW / views.size() - bmpW) / 2;// 计算偏移量-->3个选项卡
//		Matrix matrix = new Matrix();
//		matrix.postTranslate(offset, 0);
//		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}	
		
	@Override
	public void onProgressUpdate(String url, long totalSize, long dealtSize) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
				true);
		if (btnDown == null)
			return;
		btnDown.setBackgroundResource(R.drawable.ic_down_ing); // 正在下载
		btnDown.setCricleAndProgressColor(
				this.getResources().getColor(R.color.gray_split_line_bg), this
						.getResources().getColor(R.color.down_progress_color));
		
		float num = (float) dealtSize / (float) totalSize;
		int result = (int) (num * 100);
		
		btnDown.setProgress(result);
		
	}	
		
	@Override
	public void onDownloadComplete(String url) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
				true); // 下载完成
		if (btnDown == null)
			return;
		btnDown.setBackgroundResource(R.drawable.ic_down_finish);
		btnDown.setCricleAndProgressColor(
				this.getResources().getColor(R.color.transparent), this
						.getResources().getColor(R.color.transparent));
		
		UIHelper.openFile(mContext, url);
	}	
		
	@Override
	public void onDownloadStateChange(String url, int state) {
		switch (state) {
		case DownloadInfoDAO.DOWNLOAD_STATE_3:
			RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
					true); // 暂停下载
			if (btnDown != null) {
				btnDown.setBackgroundResource(R.drawable.ic_down_pause);
				btnDown.setCricleAndProgressColor(
						this.getResources().getColor(R.color.transparent), this
								.getResources().getColor(R.color.transparent));
			}
			break;
		}	
	}		
			
	@Override
	public void onDownloadError(String url, int state) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
				true);
		if (btnDown != null) {
			btnDown.setBackgroundResource(R.drawable.ic_down);
			btnDown.setCricleAndProgressColor(
					this.getResources().getColor(R.color.gray_split_line_bg),
					this.getResources().getColor(R.color.down_progress_color));
		}
		UIHelper.showMessage(mContext, "下载错误");
	}

	@Override
	public boolean onLongClick(View arg0) {
		return false;
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {// 　返回
			onClickBack();
		} else if (id == R.id.btn_top_right) {// 办理
			if (!editable) {
				if (null != detail && !detail.isSign()) {
					assignTask();
				} else {
					Intent intent = new Intent(MTaskDetailActivity.this,
							ProgressMaterialsActivity.class);
                    intent.putExtra("documentId", documentId);
                    if(infos != null) {
		                intent.putExtra("progress_from_date", infos.get(0).getFromDate());
		                intent.putExtra("progress_to_date", infos.get(0).getToDate());
		                intent.putExtra("complete_time", infos.get(0).getCompleteTime());
                    }
					intent.putExtra("taskId", taskId);
					startActivity(intent);
				}
			} else {
				showPop(v);
			}
		} else if (v == tv_banli_shiixan) {
			UIHelper.showTimeSelect(this, tv_banli_shiixan,
					DateUtils.DATE_FORMAT);
		} else if (id == R.id.et_from_date) {
			UIHelper.showTimeSelect(this, et_from_date, DateUtils.DATE_FORMAT);
		} else if (id == R.id.et_to_date) {
			UIHelper.showTimeSelect(this, et_to_date, DateUtils.DATE_FORMAT);
		} else if (id == R.id.btn_send) {
            // 在这里调用发送
//			DocumentParams params = new DocumentParams(swfNo, fpuNo, "" + wfNo, traceNo, detail.getDocumentId());
            TaskParams params = new TaskParams(traceNo, detail.getDocumentId(), "" + wfNo, swfNo, fpuNo);
            params.setTaskId(taskId);
            Bundle data = new Bundle();
            data.putSerializable("TASK_PARAMS", params);
            UIHelper.forwardTargetActivity(mContext, TaskTransactorActivity.class, data, false);
		} else if (id == R.id.task_detail_process_btn) {
            Bundle data = new Bundle();
            data.putString("taskId", taskId);
            UIHelper.forwardTargetActivity(mContext, TaskProcessActivity.class, data, false);
		} else if (id == R.id.btn_process || id == R.id.rl_item_wrap || id == R.id.rl_add_item_wrap) { // 附件下载
			UIHelper.downViewClick(mContext, v, downloadUIHelper, dao);
		}

	}

	private void onClickBack() {
		if (Constants.NOTIFY_DETAIL_BACK) {
			UIHelper.setNotifyRestore();

			UIHelper.forwardTargetActivity(mContext, MainActivity.class, null,
					true);

		} else {
			UIHelper.deleteTempDoc();
			finish();
		}
	}	
		
	private class ViewHolderFile {
		TextView tvFileName;
		ImageView ivType;
		RoundProgressButton btnDownload;
		RelativeLayout rlItemWrap, rlRoundBtnWrap;
	}	
		
	/** 注册广播 */
	private void registerBroadcast() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(TextBodyUtile.ACTION_SAVE_FILE);
		registerReceiver(saveFileBroadcast, filter);
	}		
			
	/**		
	 * 循环附件
	 * 		
	 * @param fileList
	 */		
	private void foreachFiles(List<DocFileInfo> fileList) {
		if (BeanUtils.isEmpty(fileList)) {
			return;
		}   
		llFileWrap.removeAllViews();
		for (int i = 0, len = fileList.size(); i < len; i++) {
			final DocFileInfo bean = fileList.get(i);
			ViewHolderFile holder = new ViewHolderFile();
			
			View view = LayoutInflater.from(mContext).inflate(
					R.layout.govaffair_file_item, null);
			holder.rlItemWrap = (RelativeLayout) view
					.findViewById(R.id.rl_item_wrap);
			holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
			holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
			
			holder.btnDownload = (RoundProgressButton) view
					.findViewById(R.id.btn_process);
			holder.rlRoundBtnWrap = (RelativeLayout) view
					.findViewById(R.id.rl_round_btn_wrap);
			
			String extend = FileUtils.getFileExtends(bean.getFileName());
			UIHelper.setFileTypeIcon(mContext, holder.ivType, extend); // 设置文件类型
			
			holder.tvFileName.setText(bean.getFileName());
			holder.tvFileName.setTag(bean.getFilePath());
			
			holder.btnDownload.setTag(bean);
			holder.btnDownload.setOnClickListener(this);
			
			// String url =
			// UIHelper.downFileUrl(bean.getFileCode());//getString(R.string.system_servics_download).concat(bean.getFilePath());
			String url;
			// 0,标识使用system_servics_download下载，1标识使用system_servics_url下载
			if ("1".equals(getString(R.string.is_download_flag))) {
				url = UIHelper.downFileUrl(bean.getFileCode());
			} else {
				url = getString(R.string.system_servics_download).concat(bean.getFilePath());
			}
			holder.rlRoundBtnWrap.setTag(url);// 下载标识

			holder.rlItemWrap.setTag(bean);// 长按删除
			holder.rlItemWrap.setOnClickListener(this);

			if (isDeleteAddToken) {
				holder.rlItemWrap.setOnLongClickListener(this);
			}

			try {
				DownloadInfoBean downBean = dao.getAppBeanByCd(bean.getFileCode());
				if (downBean != null) { // 下载完成
					int state = downBean.getState();
					if (state == DownloadInfoDAO.DOWNLOAD_STATE_2) {
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_finish); // 存在则打开

					} else if (state == DownloadInfoDAO.DOWNLOAD_STATE_3) {
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_pause); // 暂停状态

					} else {
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
					}
				} else {
					holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
				}
				holder.btnDownload.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), this.getResources().getColor(R.color.transparent));
			} catch (Exception e) {
				
			}	
			llFileWrap.addView(view);
		}		
		if (llFileWrap.getChildCount() > 0) {
			llFileWrap.setVisibility(View.VISIBLE);
			tvFileGroup.setVisibility(View.VISIBLE);
		} else {
			llFileWrap.setVisibility(View.GONE);
			tvFileGroup.setVisibility(View.GONE);
		}	
	}		
			
	@Override
	protected void onPause() {
		super.onPause();
		if (this.downloadUIHelper != null)
			this.downloadUIHelper.unRegUiHandler();
	}	
		
	@Override
	protected void onResume() {
		super.onResume();
		dissmissPop();
        getTaskDetail();
        getDocumentId();
		if (this.downloadUIHelper != null)
			this.downloadUIHelper.regUiHandler();// 界面恢复调用
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		detail.clearDetails();
		mContext = null;
		if (saveFileBroadcast != null) {
			// unregisterReceiver(saveFileBroadcast);
		}
        if (null != detail) {
            detail.clearDetails();
        }
        if (null != progressInfoAdapter) {
            progressInfoAdapter.destoryAdapter();
        }
		if (this.downloadUIHelper != null)
			this.downloadUIHelper.unRegUiHandler();
	}

	private BroadcastReceiver saveFileBroadcast = new BroadcastReceiver() {
		@Override
		public void onReceive(final Context context, Intent intent) {
			// 接收到的参数
			final String filePath = intent.getExtras().getString("filePath"); // 文件路径
			// if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) { //
			// 主办会议没有正文编辑后上传，会议通知有（公文详情）
			// return;
			// }
			// 只有可以新建的时候可以进行上传

		}
	};

	private PopupWindow mPopWindow;
	private ListView popList;

	private TaskDetails.ProgressInfo progressInfo;

	private ArrayList<TaskDetails.ProgressInfo> infos;

	private void showPop(View v) {
		if (null == mPopWindow) {
			DisplayMetrics dm = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(dm);
			int screenW = dm.widthPixels;// 获取分辨率宽度
			View view = getLayoutInflater().inflate(R.layout.task_pop_menu,
					null);
			mPopWindow = new PopupWindow(view, screenW / 4,
					ViewGroup.LayoutParams.WRAP_CONTENT);
			popList = ((ListView) view.findViewById(R.id.task_pop_list));
			mPopWindow.setBackgroundDrawable(new BitmapDrawable());
            int length = ((null != detail && "2".equals(detail.getTaskState()) ? 2 : 0));
			popList.setAdapter(new PopListAdapter(this, editable, length));
		}
		mPopWindow.showAsDropDown(v, -10, 0);
		mPopWindow.setFocusable(true);
		mPopWindow.setOutsideTouchable(true);
		popList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> adapterView, View view,
					final int i, long l) {
				if (editable) {
					if (i == 0) {
						Intent intent = new Intent(MTaskDetailActivity.this,
								AddTaskActivity.class);
						intent.putExtra("taskDetail", detail);
						startActivity(intent);
					} else if (i == 1) {
						processTask();
					} else if (i == 2) {
						dispatcherTask();
					}
				} else {
					if (i == 0) {
						Intent intent = new Intent(MTaskDetailActivity.this,
								ProgressMaterialsActivity.class);
                        intent.putExtra("documentId", documentId);
						intent.putExtra("taskId", taskId);
						startActivity(intent);
					}
//					else if (i == 1) {
//						processTask();
//					}
				}
			}
		});
		mPopWindow.update();
	}

	private void dissmissPop() {
		if (null != mPopWindow) {
			mPopWindow.dismiss();
		}
	}

    public static void finishActivity() {
        instance.finish();
    }

}
