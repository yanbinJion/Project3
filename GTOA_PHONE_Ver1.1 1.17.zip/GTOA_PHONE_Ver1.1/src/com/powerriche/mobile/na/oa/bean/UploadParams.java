package com.powerriche.mobile.na.oa.bean;

import java.io.File;
import java.io.Serializable;
import java.util.List;

/**
 * 类描述：<br> 
 * 上传文件参数
 * @author  Fitz
 * @date    2015年5月28日
 * @version v1.0
 */
public class UploadParams implements Serializable{

	private static final long serialVersionUID = 5666081527436672940L;
	
	public UploadParams(){}
	
	public UploadParams(String serviceUrl, String actionName, String documentId, String swfNo, String traceNo, int what){
		this.serviceUrl = serviceUrl;
		this.actionName = actionName;
		this.documentId = documentId;
		this.swfNo = swfNo;
		this.traceNo = traceNo;
		this.what = what;
	}

	private String serviceUrl;	//服务器地址
	private String actionName;	//请求方法
	private String documentId;	//公文ID
	private String swfNo;
	private String traceNo;
	private int what;	//handle msg what
	
	private List<File> listFile;	//文件

	public String getServiceUrl() {
		return serviceUrl;
	}
	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}
	public String getActionName() {
		return actionName;
	}
	public void setActionName(String actionName) {
		this.actionName = actionName;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getSwfNo() {
		return swfNo;
	}
	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}
	public String getTraceNo() {
		return traceNo;
	}
	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}
	public List<File> getListFile() {
		return listFile;
	}
	public void setListFile(List<File> listFile) {
		this.listFile = listFile;
	}

	public int getWhat() {
		return what;
	}

	public void setWhat(int what) {
		this.what = what;
	}

}
