package com.powerriche.mobile.na.oa.down;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;

import com.powerriche.mobile.na.oa.dao.BaseDAO;


/**
 * TaskDAO
 * @author Metre Mi
 * 2013-7-26
 */
public class DownloadInfoDAO extends BaseDAO {
	
	/** -1 等待下载 */
	public final static int DOWNLOAD_STATE_00 = -1;
	
	/** 未下载 */
	public final static int DOWNLOAD_STATE_0 = 0;
	
	/** 正在下载 */
	public final  static int DOWNLOAD_STATE_1 = 1;
	
	/** 下载完成  */
	public final static int DOWNLOAD_STATE_2 = 2;
	
	/** 暂停下载  */
	public final static int DOWNLOAD_STATE_3 = 3;
	
	private Context context;
	
	public DownloadInfoDAO(Context context) {
		super(context);
		this.context = context;
	}

	public void insert(String fileCode, String url, String fileType, long fileSize, Integer state, Long createtime, String name) {
		StringBuffer sql = new StringBuffer();
		DownloadInfoBean downBean = getAppBeanByCd(fileCode);
		if(downBean==null){
			sql.append("INSERT INTO ").append(DownloadInfoField.TABLE_NAME).append('(');
			sql.append(DownloadInfoField.FILECODE).append(',');
			sql.append(DownloadInfoField.URL).append(',');
			sql.append(DownloadInfoField.FILETYPE).append(',');
			sql.append(DownloadInfoField.FILESIZE).append(',');
			sql.append(DownloadInfoField.STATE).append(',');
			sql.append(DownloadInfoField.NAME).append(',');
			sql.append(DownloadInfoField.REPORTSTATE).append(',');
			sql.append(DownloadInfoField.CREATETIME).append(") values(?,?,?,?,?,?,?,?)");
			
			Object[] values = {fileCode, url, fileType,fileSize, state, name, "-1", createtime};
			this.execSQL(sql.toString(), values);
			
		}else{
			sql.append("UPDATE ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" SET ").append(DownloadInfoField.URL).append("=?, ");
			sql.append(DownloadInfoField.FILETYPE).append("=?, ");
			sql.append(DownloadInfoField.FILESIZE).append("=? ");
			sql.append(" WHERE ").append(DownloadInfoField.FILECODE).append("=?");
			Object[] values = {url, fileType, fileSize, fileCode};
			this.execSQL(sql.toString(), values);
		}
	}
	
	public void insertLocal(String fileCode, String url, String fileType, Integer state, String name, String downDir) {
		DownloadInfoBean downBean = getAppBeanByCd(fileCode);
		if(downBean==null){
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO ").append(DownloadInfoField.TABLE_NAME).append('(');
			sql.append(DownloadInfoField.FILECODE).append(',');
			sql.append(DownloadInfoField.URL).append(',');
			sql.append(DownloadInfoField.FILETYPE).append(',');
			sql.append(DownloadInfoField.FILESIZE).append(',');
			sql.append(DownloadInfoField.STATE).append(',');
			sql.append(DownloadInfoField.NAME).append(',');
			sql.append(DownloadInfoField.DOWNDIR).append(',');
			sql.append(DownloadInfoField.REPORTSTATE).append(',');
			sql.append(DownloadInfoField.CREATETIME).append(") values(?,?,?,?,?,?,?,?,?)");

			Object[] values = {fileCode, url, fileType, 0, state, name, downDir, DOWNLOAD_STATE_2, System.currentTimeMillis()};

			this.execSQL(sql.toString(), values);
		}
	}
	
	public void updReportStateByCd(String fileCode, String reportState) {
		
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE ").append(DownloadInfoField.TABLE_NAME);
		sql.append(" SET ").append(DownloadInfoField.REPORTSTATE);
		sql.append("=?  WHERE ").append(DownloadInfoField.FILECODE);
		sql.append("=?");

		Object[] values = {reportState, fileCode};
		this.execSQL(sql.toString(), values);
	}

	public void updStateByUrl(DownloadInfoBean bean) {
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE ").append(DownloadInfoField.TABLE_NAME);
		sql.append(" SET ").append(DownloadInfoField.STATE);
		sql.append("=? ,").append(DownloadInfoField.DOWNDIR);
		sql.append("=? WHERE ").append(DownloadInfoField.URL);
		sql.append("=?");

		Object[] values = {bean.getState(), bean.getDownDir(),bean.getUrl()};
		this.execSQL(sql.toString(), values);
	}
	
	public void updStateByCd(DownloadInfoBean bean) {
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE ").append(DownloadInfoField.TABLE_NAME);
		sql.append(" SET ").append(DownloadInfoField.STATE);
		sql.append("=?  WHERE ").append(DownloadInfoField.FILECODE);
		sql.append("=?");

		Object[] values = {bean.getState(), bean.getFileCode()};
		this.execSQL(sql.toString(), values);
	}
	
	public void updStateByCd(String fileCode, Integer state) {
		
		Log.d("updStateByCd appCd : "+state);
		Log.d("updStateByCd state : "+state);
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE ").append(DownloadInfoField.TABLE_NAME);
		sql.append(" SET ").append(DownloadInfoField.STATE);
		sql.append("=?  WHERE ").append(DownloadInfoField.FILECODE);
		sql.append("=?");

		Object[] values = {state, fileCode};
		this.execSQL(sql.toString(), values);
	}

	public void updStateByPackgeName(String fileCode, Integer state) {
		
		Log.d("updStateByCd appCd : "+state);
		Log.d("updStateByCd state : "+state);
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE ").append(DownloadInfoField.TABLE_NAME);
		sql.append(" SET ").append(DownloadInfoField.STATE);
		sql.append("=?  WHERE ").append(DownloadInfoField.FILECODE);
		sql.append("=?");
		
		Object[] values = {state, fileCode};
		this.execSQL(sql.toString(), values);
	}
	
	public DownloadInfoBean getAppBeanByCd(String cd) {
		DownloadInfoBean bean = null;
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE ").append(DownloadInfoField.FILECODE);
			sql.append("=?");
			String[] values = {cd};
			cursor = this.rawQuery(sql.toString(),values);
			if (cursor != null) {
				if (cursor.moveToNext()) {
					bean = cursorToDownloadInfoBean(cursor);
				}
			}
			
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return bean;
	}
	
	
	public List<DownloadInfoBean> qryDowningGame(Integer state) {
		List<DownloadInfoBean> list = new ArrayList<DownloadInfoBean>();
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE ").append(DownloadInfoField.STATE);
			sql.append("=?");
			cursor = this.rawQuery(sql.toString(), new String[]{String.valueOf(state)} );
			if (cursor != null) {
				while (cursor.moveToNext()) {
					list.add(cursorToDownloadInfoBean(cursor));
				}
			}
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return list;
	}
	
	
	public Integer qryDowningGameSize(Integer state) {
		Integer res = 0;
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT count(*) ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE ").append(DownloadInfoField.STATE);
			sql.append("= ?");
			cursor = this.rawQuery(sql.toString(), new String[]{String.valueOf(state)} );
			if (cursor != null) {
				if (cursor.moveToNext()) {
					res = cursor.getInt(0);
				}
			}
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return res;
	}
	
	/**
	 * 方法说明：<br>
	 * 获取下载任务列表<br>
	 * 但不包含已删除的游戏
	 * @return
	 */
	public List<DownloadInfoBean> qryAllDownloadGame() {
		List<DownloadInfoBean> list = new ArrayList<DownloadInfoBean>();
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE state!=6 ORDER BY id DESC");
			cursor = this.rawQuery(sql.toString(), null);
			if (cursor != null) {
				while (cursor.moveToNext()) {
					list.add(cursorToDownloadInfoBean(cursor));
				}
			}
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return list;
	}
	
	
	
	/**
	 * 方法说明：<br>
	 * 从数据库获取下载记录
	 * @param url
	 * @return
	 */
	public DownloadInfoBean getDownloadInfoByUrl(String url) {
		DownloadInfoBean bean = null;
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE ").append(DownloadInfoField.URL);
			sql.append("=?");
			String[] values = {url};
			cursor = this.rawQuery(sql.toString(),values);
			if (cursor != null) {
				if (cursor.moveToNext()) {
					bean = cursorToDownloadInfoBean(cursor);
				}
			}
			
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return bean;
	}
	
	public DownloadInfoBean getAppBeanByPackageName(String fileCode) {
		DownloadInfoBean bean = null;
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE ").append(DownloadInfoField.FILECODE);
			sql.append("=?");
			String[] values = {fileCode};
			cursor = this.rawQuery(sql.toString(),values);
			if (cursor != null) {
				if (cursor.moveToNext()) {
					bean = cursorToDownloadInfoBean(cursor);
				}
			}
			
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return bean;
	}
	
	
	
	
	private DownloadInfoBean cursorToDownloadInfoBean(Cursor cursor){
		DownloadInfoBean bean = new DownloadInfoBean();
		bean.setId(cursor.getInt(cursor.getColumnIndex(DownloadInfoField.ID)));
		bean.setFileCode(cursor.getString(cursor.getColumnIndex(DownloadInfoField.FILECODE)));
		bean.setFileType(cursor.getString(cursor.getColumnIndex(DownloadInfoField.FILETYPE)));
		bean.setFileSize(cursor.getLong(cursor.getColumnIndex(DownloadInfoField.FILESIZE)));
		bean.setState(cursor.getInt(cursor.getColumnIndex(DownloadInfoField.STATE)));
		bean.setUrl(cursor.getString(cursor.getColumnIndex(DownloadInfoField.URL)));
		bean.setCreatetime(cursor.getLong(cursor.getColumnIndex(DownloadInfoField.CREATETIME)));
		bean.setDownDir(cursor.getString(cursor.getColumnIndex(DownloadInfoField.DOWNDIR)));
		bean.setName(cursor.getString(cursor.getColumnIndex(DownloadInfoField.NAME)));
		
		bean.setReportstate(cursor.getInt(cursor.getColumnIndex(DownloadInfoField.REPORTSTATE)));
		
		return bean;
	}
	
	public Integer getAppsCount() {
		Integer result = 0;
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT count(*) ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			cursor = this.rawQuery(sql.toString(),null);
			if (cursor != null) {
				while (cursor.moveToNext()) {
					result = cursor.getInt(0);
				}
			}
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return result;
	}
	
	
	public void deleteAll() {
		this.deleteAll(DownloadInfoField.TABLE_NAME);
	}

	public void removeById(String cd) {
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("delete from ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" where ").append(DownloadInfoField.FILECODE);
			sql.append("=?");
			String[] values = { cd };
			this.execSQL(sql.toString(), values);
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
	}
	
	public void deleteByPackage(String fileCode){
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("delete from ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" where ").append(DownloadInfoField.FILECODE);
			sql.append("=?");
			String[] values = { fileCode };
			this.execSQL(sql.toString(), values);
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 查询正在下载的，暂停下载 的总数
	 * @return
	 */
	public Integer getDownloadSize(){
		Integer result = 0;
		Cursor cursor = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT count(*) ");
			sql.append(" FROM ").append(DownloadInfoField.TABLE_NAME);
			sql.append(" WHERE ").append(DownloadInfoField.STATE);
			sql.append(" =-1 or state =0 or state=1 or state = 3");
			cursor = this.rawQuery(sql.toString(),null);
			if (cursor != null) {
				while (cursor.moveToNext()) {
					result = cursor.getInt(0);
				}
			}
		} catch (Exception e) {
			Log.e(this.getClass(), e);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					Log.e(this.getClass(), e);
				}
				cursor = null;
			}
		}
		return result;
	}
}
