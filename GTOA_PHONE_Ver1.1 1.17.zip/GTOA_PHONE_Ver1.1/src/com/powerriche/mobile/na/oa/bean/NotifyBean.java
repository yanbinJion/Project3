package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * 类描述：<br> 
 * 消息通知Bean
 * @author  Fitz
 * @date    2015年7月30日
 * @version v1.0
 */
public class NotifyBean implements Serializable{

	private static final long serialVersionUID = 384420318190182849L;
	
	//*************基础信息*************
	private String msgId;	//ID
	private int type;	//消息类型
	private int read;	//阅读：0未读，1已读
	private int status;	//状态：0为通知，1已通知
	
	private String title;
	private String content;
	private String param;

	
	private int isBroadcast;
	private boolean isTipsMusic;	//是播放提示音
	private boolean isNightNotify;	//是否夜间仿打扰
	
	
	private String wfNo;	//流程编号
	private String swfNo;	//系统流程编号
	private String documentId;	//公文ID
	private String traceNo;	//跟踪编号
	
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getIsBroadcast() {
		return isBroadcast;
	}
	public void setIsBroadcast(int isBroadcast) {
		this.isBroadcast = isBroadcast;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public boolean isTipsMusic() {
		return isTipsMusic;
	}
	public void setTipsMusic(boolean isTipsMusic) {
		this.isTipsMusic = isTipsMusic;
	}
	public boolean isNightNotify() {
		return isNightNotify;
	}
	public void setNightNotify(boolean isNightNotify) {
		this.isNightNotify = isNightNotify;
	}
	public int getRead() {
		return read;
	}
	public void setRead(int read) {
		this.read = read;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
	public String getWfNo() {
		return wfNo;
	}
	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}
	public String getSwfNo() {
		return swfNo;
	}
	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getTraceNo() {
		return traceNo;
	}
	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}
}
