package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * Filename : AgencyIndexActivity
 * 
 * @Description : 请假详情
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-21 09:38:24
 */
public class AskLeaveDetailActivity extends BaseActivity implements
		OnClickListener {

	private AskLeaveItemHelper askLeaveItemHelper;

	/** 查询单个数据标识 */
	public final static int WHAT_REQUEST_ITEM = 5457;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.askleave_item_detail);
		bindView();
	}

	private void bindView() {

		TopActivity topActivity = (TopActivity) this
				.findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.askleave_detail_title));
		topActivity.setRightBtnVisibility(View.INVISIBLE);

		askLeaveItemHelper = new AskLeaveItemHelper(
				AskLeaveDetailActivity.this,
				this.findViewById(R.id.layout_leave_detail),0);
		
		ResultItem item = (ResultItem) getIntent().getSerializableExtra("item");
		if (item != null) {
			askLeaveItemHelper.processBaseInfo(item);
		}else{
			askLeaveItemHelper.searhData(WHAT_REQUEST_ITEM);
		}
	}

	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.system_back:// 返回
			finish();
			break;
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == WHAT_REQUEST_ITEM) {
					//askLeaveItemHelper.process(response, what);
				}
			}
		}

		@Override
		public void finish(Object dialogObj, int what) {
			super.finish(dialogObj, what);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_request_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

}
