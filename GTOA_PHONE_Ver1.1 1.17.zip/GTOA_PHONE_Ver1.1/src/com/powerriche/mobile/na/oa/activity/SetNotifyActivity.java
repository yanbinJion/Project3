package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.tools.SettingPreference;

/**
 * 类描述：<br> 
 * 消息通知设置
 * @author  Fitz
 * @date    2015年5月9日
 * @version v1.0
 */
public class SetNotifyActivity extends BaseActivity implements OnClickListener{

	private Context mContext;
	
	private Button btnNotify, btnTips, btnNight;
	
	private SettingPreference sharedPreferences;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		setContentView(R.layout.system_set_notification);
		bindView();
	}
	
	void bindView(){
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.set_notify));
		topActivity.setRightBtnVisibility(View.INVISIBLE);
		
		btnNotify = (Button) findViewById(R.id.btn_set_notify);
		btnNotify.setOnClickListener(this);
		btnTips = (Button) findViewById(R.id.tv_set_tips);
		btnTips.setOnClickListener(this);
		btnNight = (Button) findViewById(R.id.btn_set_night);
		btnNight.setOnClickListener(this);
		findViewById(R.id.rl_set_notify).setOnClickListener(this);
		findViewById(R.id.rl_set_tips).setOnClickListener(this);
		findViewById(R.id.rl_set_night).setOnClickListener(this);
		
		
		sharedPreferences = new SettingPreference(mContext);
		// 设置值的时候，0未关闭，1为打开
		int notifyValue = sharedPreferences.getSettingParam(Constants.SET_NOTIFY, 1);	//消息通知
		int tipsValue = sharedPreferences.getSettingParam(Constants.SET_TIPS, 1);		//提示音
		int nightValue = sharedPreferences.getSettingParam(Constants.SET_NIGHT, 0);	//夜间防打扰
		
		if(notifyValue==0){
			btnNotify.setSelected(false);
		}else{
			btnNotify.setSelected(true);
		}
		if(tipsValue==0){
			btnTips.setSelected(false);
		}else{
			btnTips.setSelected(true);
		}
		if(nightValue==0){
			btnNight.setSelected(false);
		}else{
			btnNight.setSelected(true);
		}
		
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(R.id.system_back == id){
			finish();
			
		}else if(id==R.id.btn_set_notify || id==R.id.rl_set_notify){	//消息通知开关设置
			setBtnSelect(btnNotify, Constants.SET_NOTIFY);
			
		}else if(id==R.id.tv_set_tips || id==R.id.rl_set_tips){
			setBtnSelect(btnTips, Constants.SET_TIPS);
			
		}else if(id==R.id.btn_set_night || id==R.id.rl_set_night){
			setBtnSelect(btnNight, Constants.SET_NIGHT);
			
		}
	}
	
	void setBtnSelect(Button btn, String key){
		int value = 0;
		if(btn.isSelected()){
			btn.setSelected(false);
		}else{
			value = 1;
			btn.setSelected(true);
		}
		sharedPreferences.setSettingParam(key, value);
	}
	
}
