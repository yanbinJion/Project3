package com.powerriche.mobile.na.oa.activity.grtaskdetails;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.GovAffairAddActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 个人任务--任务信息
 * 
 * @author home
 * 
 */
public class PersonTaskDetailHelper {

	private Context context;
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;

	public PersonTaskDetailHelper(Context context, IRequestCallBack callBack) {
		this.context = context;
		this.callBack = callBack;
		this.helper = ((GovAffairAddActivity) this.context).getInvokeHelper();
	}

	public void getPersonTaskDetail(String taskId, String wfNo, int what) {
		ApiRequest request = OAServicesHandler.getTaskDetail(taskId, wfNo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	public Map<String, Object> process(HttpResponse response, int what) {
		Map<String, Object> map = new HashMap<String, Object>();

		ResultItem item = response.getResultItem(ResultItem.class);
		if (!BeanUtils.isEmpty(item)) {
			String code = item.getString("code");
			// 操作成功
			if (Constants.SUCCESS_CODE.equals(code)) {
				processPersonTaskInfo(item, map);
			} else {
				UIHelper.showMessage(context, item.getString("message"));
				((BaseActivity) context).finish();
			}
		} else {
			UIHelper.showMessage(context,
					context.getString(R.string.document_detail_empty));
			((BaseActivity) context).finish();
		}
		return map;
	}

	private void processPersonTaskInfo(ResultItem item, Map<String, Object> map) {
		item = item.getItems("data").get(0);

		map.put("task_title", item.getString("TASK_TITLE"));// 任务标题
		map.put("task_code", item.getString("TASK_CODE"));// 任务编号
		map.put("create_name", item.getString("CREATE_NAME"));// 创建人
		map.put("create_time", item.getString("CREATE_TIME")); // 创建时间
		map.put("limit_time", item.getString("LIMIT_TIME"));// 办理时间
		map.put("play_ts_type", item.getString("PLAN_TIMESPAN_TYPE"));// 计划上报类型

		map.put("task_year", item.getString("TASK_YEAR"));// 任务年度
		map.put("contacter", item.getString("CONTACTER"));// // 联系人

		map.put("contacter_phone", item.getString("CONTACTER_PHONE"));
		map.put("submit_to_name", item.getString("SUBMIT_TO_NAME"));
		map.put("copy_to_name", item.getString("COPY_TO_NAME"));

		// 附件信息
		map.put("fk_file_code", item.getString("FK_FILE_CODE"));// 附件编号
		map.put("file_title", item.getString("FILE_TITLE"));// 附件标题

		map.put("file_name", item.getString("FILE_NAME"));// 附件名称
		map.put("ftp_path", item.getString("FTP_PATH"));// 附件地址

		// 办理信息
		map.put("data", item.getString("DATA"));// 办理意见
		map.put("action_name", item.getString("ACTION_NAME"));// 办理环节名称

		map.put("processor_dept_name", item.getString("PROCESSOR_DEPT_NAME"));// 办理部门名称
		map.put("processor", item.getString("PROCESSOR"));// 办理人
		map.put("save_date", item.getString("SAVE_DATE"));// 办理时间

		// 附件编号
		processFileList(item, map);

	}

	private void processFileList(ResultItem item, Map<String, Object> map) {
		List<DocFileInfo> fileList = new ArrayList<DocFileInfo>();
		// 获取附件数据
		List<ResultItem> fileItems = item.getItems("File"); // 文件列表
		if (fileItems != null && fileItems.size() > 0) {
			for (ResultItem fileItem : fileItems) {
				String fileCode = fileItem.getString("FK_FILE_CODE"); // 文件编号
				String fileName = fileItem.getString("FILE_NAME"); // 文件名称
				String fileType = fileItem.getString("FILE_TYPE"); // 文件类型
				String filePath = fileItem.getString("FILE_PATH"); // 文件路径
				String fileTitle = fileItem.getString("FILE_TITLE");// 文件标题

				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(fileItem
						.getString("FILE_SIZE"));// 文件大小
				if (!BeanUtils.isEmpty(fileSizeStr)) {
					fileSize = Integer.parseInt(fileSizeStr);
				}

				DocFileInfo fileBean = new DocFileInfo(fileCode, fileType,
						fileName, 0, fileSize);
				fileBean.setFilePath(filePath);
				fileBean.setFileTitle(fileTitle);
				fileList.add(fileBean);
			}
		}

		map.put("fileList", fileList);
	}

}
