package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentGwglFawenHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentGwglLaiwenHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentGwglYibanHelper;
import com.powerriche.mobile.na.oa.activity.view.BaseLinearLayout;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 公文管理
 * @author 李运期
 * @date 2015年4月24日
 * @version v1.0
 */
public class TabOfficialActivity extends BaseLinearLayout implements OnClickListener{

	/**
	 * 公文新增后，发文列表是否刷新，0不刷新，1刷新-->author Fitz
	 */
	public static int OP_REFRESH = 0;
	
	private Context	mContext;
	private MainActivity mainActivity;
	
	//********************页卡相关变量************************
	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片

	private TextView tv1, tv2, tv3;
	private View view1, view2, view3;

	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度

	
	//---------发文相关控件及变量-------------
	private PullToRefreshListView pullViewFawen;
	private ListView listViewFawen;
	private TextView tvNoDataMsgFawen;
	private int pageIndexFawen = 1;
	private DocumentGwglFawenHelper fawenHelper;

	//---------来文相关控件及变量-------------
	private PullToRefreshListView pullViewLaiwen;
	private ListView listViewLaiwen;
	private TextView tvNoDataMsgLaiwen;
	private int pageIndexLaiwen = 1;
	public static boolean isFirst2 = true;
	private DocumentGwglLaiwenHelper laiwenHelper;

	//---------已办相关控件及变量-------------
	private PullToRefreshListView pullViewYiban;
	private ListView listViewYiban;
	private TextView tvNoDataMsgYiban;
	private int pageIndexYiban = 1;
	public static boolean isFirst3 = true;
	private DocumentGwglYibanHelper yibanHelper;
	private TopActivity topActivity;
	

	public TabOfficialActivity(Context context) {
		super(context);
		this.mContext = context;

		LayoutInflater.from(context).inflate(R.layout.main_official, this, true);
		mainActivity = (MainActivity) context;
	}

	@Override
	public void onCreate(Intent intent) {
		bindView();
		loadSendDocData();//第一个加载项
	}

	private void bindView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackVisibility(View.INVISIBLE);
		topActivity.setTopTitle(mainActivity.getString(R.string.menu_gwgl));//顶部栏的中间标题
		
		enabledRightBtn();
		topActivity.setRightBtnOnClickListener(this);
		
		
		initImageView();
		initTextView();
		initViewPager();
		
		initFawenView();
		initLaiwenView();
		initYibanView();
	}
	
	/**
	 * 显示右边按钮
	 */
	private void enabledRightBtn() {
		topActivity.setRightBtnVisibility(View.VISIBLE);//显示右边按钮
		topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
	}
	
	/**
	 * 隐藏右边按钮
	 */
	private void disableRightBtn() {
		topActivity.setRightBtnVisibility(View.INVISIBLE);//显示右边按钮
		//topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
	}
	

	/**
	 * 初始化发文控件 
	 */
	void initFawenView(){
		pullViewFawen = (PullToRefreshListView) view1.findViewById(R.id.pulllistview_fawen);
		pullViewFawen.setPullRefreshEnabled(true);
		pullViewFawen.setPullLoadEnabled(false);
		pullViewFawen.setScrollLoadEnabled(true);

		listViewFawen = pullViewFawen.getRefreshableView();
		UIHelper.setListViewAttribute(listViewFawen);

		pullViewFawen.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexFawen = 1;
				fawenHelper.loadData(Constants.OPT_TYPE_GWGL_FW, Constants.WHAT_REQUEST_GWGL_FAWEN, pageIndexFawen, false);
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexFawen = pageIndexFawen + 1;
				fawenHelper.loadData(Constants.OPT_TYPE_GWGL_FW, Constants.WHAT_REQUEST_GWGL_FAWEN, pageIndexFawen, false);
			}
		});
		tvNoDataMsgFawen = (TextView) view1.findViewById(R.id.tv_no_data_msg);
		tvNoDataMsgFawen.setVisibility(View.GONE);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		listViewFawen.addHeaderView(header);
		
		//初始化帮助类
		fawenHelper = new DocumentGwglFawenHelper(mContext, header, tvNoDataMsgFawen, pullViewFawen, listViewFawen, mainActivity, callBack);
	}
	

	/**
	 * 初始化来文控件
	 */
	void initLaiwenView(){
		pullViewLaiwen = (PullToRefreshListView) view2.findViewById(R.id.pulllistview_laiwen);
		pullViewLaiwen.setPullRefreshEnabled(true);
		pullViewLaiwen.setPullLoadEnabled(false);
		pullViewLaiwen.setScrollLoadEnabled(true);
		
		listViewLaiwen = pullViewLaiwen.getRefreshableView();
		UIHelper.setListViewAttribute(listViewLaiwen);
		
		pullViewLaiwen.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexLaiwen = 1;
				laiwenHelper.loadData(Constants.OPT_TYPE_GWGL_LW, Constants.WHAT_REQUEST_GWGL_LAIWEN, pageIndexLaiwen, false);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexLaiwen = pageIndexLaiwen + 1;
				laiwenHelper.loadData(Constants.OPT_TYPE_GWGL_LW, Constants.WHAT_REQUEST_GWGL_LAIWEN, pageIndexLaiwen, false);
			}
		});
		tvNoDataMsgLaiwen = (TextView) view2.findViewById(R.id.tv_no_data_msg);
		tvNoDataMsgLaiwen.setVisibility(View.GONE);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		listViewLaiwen.addHeaderView(header);
		
		laiwenHelper = new DocumentGwglLaiwenHelper(mContext, header, tvNoDataMsgLaiwen, pullViewLaiwen, listViewLaiwen, mainActivity, callBack);
	}

	/**
	 * 初始化已办控件
	 */
	void initYibanView(){
		pullViewYiban = (PullToRefreshListView) view3.findViewById(R.id.pulllistview_yiban);
		pullViewYiban.setPullRefreshEnabled(true);
		pullViewYiban.setPullLoadEnabled(false);
		pullViewYiban.setScrollLoadEnabled(true);
		
		listViewYiban = pullViewYiban.getRefreshableView();
		UIHelper.setListViewAttribute(listViewYiban);
		
		pullViewYiban.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexYiban = 1;
				yibanHelper.loadData(Constants.OPT_TYPE_GWGL_YB, Constants.WHAT_REQUEST_GWGL_YIBAN, pageIndexYiban, false);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexYiban = pageIndexYiban + 1;
				yibanHelper.loadData(Constants.OPT_TYPE_GWGL_YB, Constants.WHAT_REQUEST_GWGL_YIBAN, pageIndexYiban, false);
			}
		});
		tvNoDataMsgYiban = (TextView) view3.findViewById(R.id.tv_no_data_msg);
		tvNoDataMsgYiban.setVisibility(View.GONE);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		listViewYiban.addHeaderView(header);
		
		yibanHelper = new DocumentGwglYibanHelper(mContext, header, tvNoDataMsgYiban, pullViewYiban, listViewYiban, mainActivity, callBack);
	}
	
	/**
	 * 加载数据：发文
	 */
	private void loadSendDocData() {
		pageIndexFawen = 1;
		fawenHelper.loadData(Constants.OPT_TYPE_GWGL_FW, Constants.WHAT_REQUEST_GWGL_FAWEN, pageIndexFawen, true);
	}

	/**
	 * 加载数据：来文
	 */
	private void loadReceiveDocData() {
		pageIndexLaiwen = 1;
		laiwenHelper.loadData(Constants.OPT_TYPE_GWGL_LW, Constants.WHAT_REQUEST_GWGL_LAIWEN, pageIndexLaiwen, true);
	}

	/**
	 * 加载数据：已办
	 */
	private void loadDoneData() {
		pageIndexYiban = 1;
		yibanHelper.loadData(Constants.OPT_TYPE_GWGL_YB, Constants.WHAT_REQUEST_GWGL_YIBAN, pageIndexYiban, true);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.btn_top_right://新建公文
			// 跳转到新建公文页面
			UIHelper.forwardTargetActivity(mContext, DocumentAddActivity.class, null, false);
			break;
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (mainActivity.checkResult(item)) {
				if (what == Constants.WHAT_REQUEST_GWGL_FAWEN) {
					fawenHelper.process(response, what);
					
				}else if(what == Constants.WHAT_REQUEST_GWGL_LAIWEN){
					laiwenHelper.process(response, what);
					
				}else if(what == Constants.WHAT_REQUEST_GWGL_YIBAN){
					yibanHelper.process(response, what);
				}else if(what == Constants.OPT_TYPE_LEAVE_DETAIL){
					//请假详情
					AskLeaveItemHelper leaveItemHelper= new AskLeaveItemHelper();
					leaveItemHelper.process(mContext, response, false);
				}
			}
		}
	};
	
	@Override
	public void onShow(Intent intent) {

	}
	
	@Override
	public void onResume(){
		if(OP_REFRESH==1){
			loadSendDocData();
			OP_REFRESH = 0;
		}
		fawenHelper.doRemoveItemById();
		laiwenHelper.doRemoveItemById();
		yibanHelper.doRemoveItemById();
	}

	@Override
	public void onDestroy() {
		mContext = null;
	}
	
	/** 初始化动画 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度

		DisplayMetrics dm = new DisplayMetrics();
		mainActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}
	
	/** 初始化头标 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.btn_fw);
		tv2 = (TextView) findViewById(R.id.btn_lw);
		tv3 = (TextView) findViewById(R.id.btn_yb);

		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
		tv3.setOnClickListener(new MyOnClickListener(2));
	}

	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_official);
		views = new ArrayList<View>();
		LayoutInflater inflater = mainActivity.getLayoutInflater();

		view1 = inflater.inflate(R.layout.main_official_fawen, null);
		view2 = inflater.inflate(R.layout.main_official_laiwen, null);
		view3 = inflater.inflate(R.layout.main_official_yiban, null);
		views.add(view1);
		views.add(view2);
		views.add(view3);
		viewPager.setAdapter(new MyViewPagerAdapter(views));
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}

	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}

	public class MyViewPagerAdapter extends PagerAdapter {
		private List<View> mListViews;

		public MyViewPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(mListViews.get(position), 0);
			/*if (currIndex == 0) {
				if (isFirst1) {
					loadSendDocData();//第一个加载项
					isFirst1 = false;
				}
			}*/
			return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);
			animation.setDuration(300);
			imageView.startAnimation(animation);

			if (currIndex == 0) {
				tv1.setBackgroundResource(R.drawable.system_icon_gwgl_fw_s);//“发文”是选中项
				tv2.setBackgroundResource(R.drawable.system_icon_gwgl_lw);
				tv3.setBackgroundResource(R.drawable.system_icon_gwgl_yb);
				//显示右上角的按钮
				enabledRightBtn();

			} else if (currIndex == 1) {
				tv1.setBackgroundResource(R.drawable.system_icon_gwgl_fw);
				tv2.setBackgroundResource(R.drawable.system_icon_gwgl_lw_s);//“来文”是选中项
				tv3.setBackgroundResource(R.drawable.system_icon_gwgl_yb);
				if (isFirst2) {
					loadReceiveDocData();
					//isFirst2 = false;
				}
				//不显示右上角的按钮
				disableRightBtn();

			} else if (currIndex == 2) {
				tv1.setBackgroundResource(R.drawable.system_icon_gwgl_fw);
				tv2.setBackgroundResource(R.drawable.system_icon_gwgl_lw);
				tv3.setBackgroundResource(R.drawable.system_icon_gwgl_yb_s);//“已办”是选中项
				if (isFirst3) {
					loadDoneData();
					//isFirst3 = false;
				}
				//不显示右上角的按钮
				disableRightBtn();
			}
		}
	}

}
