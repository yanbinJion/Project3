package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.widget.ExpandableListView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.UserListActivity;
import com.powerriche.mobile.na.oa.activity.adapter.UserListAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DepartmentInfo;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;

/**
 * 类描述：<br> 
 * 组织成员列表帮助类
 * @author  Fitz
 * @date    2015年4月24日
 * @version v1.0
 */
public class UserListHelper implements onSearchListener  {

	private Context context;
	
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;

	private UserListAdapter adapter = null;
	
	private ExpandableListView exUserList;
	
	private SearchBarWidget mSearchBarWidget;

	private String searchText;
	
	private List<ResultItem> allResultItems = new ArrayList<ResultItem>();
	
	public UserListHelper(Context context, IRequestCallBack callBack, ExpandableListView exUserList){
		this.context = context;
		this.callBack = callBack;
		this.exUserList = exUserList;
		this.helper = ((UserListActivity) context).getInvokeHelper();
		mSearchBarWidget = (SearchBarWidget) ((UserListActivity) this.context).findViewById(R.id.search_bar_widget);
		mSearchBarWidget.setOnSearchListener(this);
	}
	
	
	public void loadData(){
		allResultItems.clear();
        ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
        if (request != null){
            helper.invokeWidthDialog(request, callBack);
        }
    }
	
	
	public void process(HttpResponse response, int what){
		
    	List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
    	allResultItems.addAll(items);
    	
        if (!BeanUtils.isEmpty(items)){
        	Map<String, List<?>> map = getContactBeanList(items);
        	
        	@SuppressWarnings("unchecked")
			List<DepartmentInfo> departmentList = (List<DepartmentInfo>) map.get("groups");
    		@SuppressWarnings("unchecked")
			List<List<UserInfo>> userList = (List<List<UserInfo>>) map.get("users");
        	
        	adapter = new UserListAdapter(context);
        	exUserList.setAdapter(adapter);
        	
        	adapter.addData(departmentList, userList,searchText);
        	adapter.notifyDataSetChanged();
        }
    }
	
	
	
	/**
	 * 解析数据
	 * @param resultItems
	 * @return
	 */
	private Map<String, List<?>> getContactBeanList(List<ResultItem> resultItems){
		
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		
		List<DepartmentInfo> departmentList = new ArrayList<DepartmentInfo>();
		List<List<UserInfo>> userList = new ArrayList<List<UserInfo>>();
		
		List<UserInfo> dataList = new ArrayList<UserInfo>();
		for(int i=0;i<resultItems.size();i++){
			ResultItem item = resultItems.get(i);
			
			String siteNo = item.getString("SITE_NO");		//部门编号
			String siteName = item.getString("SITE_NAME");		//部门名称
			
			//部门下的人员数组
			List<ResultItem> childItems = item.getItems("STAFF");
			if(!BeanUtils.isEmpty(childItems)){
				int size = childItems.size();
				for(int j=0;j<size;j++){
					ResultItem childItem = childItems.get(j);
					String staffNo = childItem.getString("STAFF_NO");	//人员编号
					String realName = childItem.getString("STAFF_NAME");	//人员名称
					String mobile = childItem.getString("MOBILE");	//手机
					String uapStaffNo = childItem.getString("UAP_STAFF_NO");
					UserInfo userInfo = new UserInfo(staffNo, realName, mobile);
					userInfo.setSiteNo(siteNo);
					userInfo.setSiteName(siteName);
					userInfo.setUapStaffNo(uapStaffNo);
					dataList.add(userInfo);
				}
			}
			
			DepartmentInfo department = new DepartmentInfo(siteNo, siteName);
			departmentList.add(department);
		}
		
		//把子项添加到组中，按索引
		for(DepartmentInfo group:departmentList){
			List<UserInfo> tempList = new ArrayList<UserInfo>();
			for(UserInfo user:dataList){
				if(group.getSiteNo().equals(user.getSiteNo())){
					tempList.add(user);
				}
			}
			userList.add(tempList);
		}
		
		map.put("groups", departmentList);
		map.put("users", userList);
		
		return map;
	}


	@Override
	public void onSearchChange(String search) {
		searchText = search;
		Map<String, List<?>> map = new HashMap<String, List<?>>();
		if (allResultItems != null && allResultItems.size() > 0 && !BeanUtils.isEmpty(search)) {
			map = getContactBeanList(filterStaff(SearchUtils.filterResults(allResultItems, search, "STAFF.STAFF_NAME")));
		} else {
			map = getContactBeanList(allResultItems);
		}
		
		if (adapter != null) {
			adapter.clearListData();
			
			@SuppressWarnings("unchecked")
			List<DepartmentInfo> departmentList = (List<DepartmentInfo>) map.get("groups");
    		@SuppressWarnings("unchecked")
			List<List<UserInfo>> userList = (List<List<UserInfo>>) map.get("users");
    		
			adapter.addData(departmentList, userList, searchText);
			adapter.notifyDataSetChanged();
			if(!BeanUtils.isEmpty(search)){
				for(int i=0;i<departmentList.size();i++){
					exUserList.expandGroup(i);
				}
			}else{
				for(int i=0;i<departmentList.size();i++){
					if(i==0){
						exUserList.expandGroup(0);
					}else{
						exUserList.collapseGroup(i);
					}
				}
			}
		}
	}
	
	/**
	 * 过滤调多余的用户
	 * @param resultItems
	 * @return
	 */
	public List<ResultItem> filterStaff(List<ResultItem>  resultItems){
		
		if(resultItems == null || resultItems.size() < 1){
			return resultItems;
		}
		List<ResultItem>  backItems = new ArrayList<ResultItem>();
		for (ResultItem resultItem : resultItems) {
			Map<String, Object> items = resultItem.getItems();
			if (items == null || items.isEmpty()) {
				continue;
			}
			List<ResultItem> childItems = null;
			List<ResultItem> newChildItems = new ArrayList<ResultItem>();
			if (items.get("STAFF") instanceof ResultItem) {
				childItems = new ArrayList<ResultItem>();
				childItems.add((ResultItem) items.get("STAFF"));
			}else if (items.get("STAFF") instanceof List<?>) {
				childItems = (List<ResultItem>) items.get("STAFF");
			}
			
			if (childItems != null && childItems.size() > 0) {
				for (int j = 0; j < childItems.size(); j++) {
					String val = (String) childItems.get(j).get("STAFF_NAME");
					if (val == null || val.isEmpty()) {
						continue;
					}
					if (val.contains(searchText)) {
						newChildItems.add(childItems.get(j));
					}
				}
			}
			//items.put("STAFF", newChildItems);
			ResultItem backResultItem  = new ResultItem();
			backResultItem.put("SITE_NAME", items.get("SITE_NAME"));
			backResultItem.put("SITE_NO", items.get("SITE_NAME"));
			backResultItem.put("STAFF", newChildItems);
			backItems.add(backResultItem);
		}
		return backItems;
		
	}
	
}
