package com.powerriche.mobile.na.oa.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : ModifyPasswordActivity
 * 
 * @Description : 修改密码
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-21 17:50:00
 */
public class ModifyPasswordActivity extends BaseActivity implements
		OnClickListener {

	private final static int DIALOG_CHECK = 4234;

	private final static int DIALOG_MESSAGE = 2234;

	private final static int DIALOG_SUCCESS = 0;

	private EditText oldPasswordEdit;

	private EditText newPasswordEdit;

	private EditText confirmPasswordEdit;

	private String alertMessage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.modify_password_layout);
		oldPasswordEdit = (EditText) findViewById(R.id.oldPassword);
		newPasswordEdit = (EditText) findViewById(R.id.newPassword);
		confirmPasswordEdit = (EditText) findViewById(R.id.confirmPassword);
		bindView();

	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				alertMessage = getString(R.string.modifiy_password_success);
				showDialog(DIALOG_SUCCESS);
				return;
			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));

		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	public void onClick(View view) {
		// 返回
		if (view.getId() == R.id.system_back) {
			toUserAccountSecurity();
		} else if (view.getId() == R.id.btn_top_right) {
			// 判断
			if (checkInput()) {
				String oldPassword = oldPasswordEdit.getText().toString();
				String password = newPasswordEdit.getText().toString();
				toModifyPassword(oldPassword, password);
			} else {
				showDialog(DIALOG_CHECK);
			}
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {

		case DIALOG_CHECK:
			return new AlertDialog.Builder(ModifyPasswordActivity.this)
					.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(alertMessage)
					.setNegativeButton(R.string.system_dialog_confirm,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}
							}).create();

		case DIALOG_SUCCESS:
			return new AlertDialog.Builder(ModifyPasswordActivity.this)
					.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(alertMessage)
					.setNegativeButton(R.string.system_dialog_confirm,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									toUserAccountSecurity();
								}
							}).create();
		case DIALOG_MESSAGE:
			return new AlertDialog.Builder(ModifyPasswordActivity.this)
					.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(alertMessage)
					.setNegativeButton(R.string.system_dialog_confirm,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
								}
							}).create();
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	// 绑定页面头部
	private void bindView() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.modifiy_password_title));
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(getString(R.string.system_comfirm));
	}

	/** 验证提交的数据 */
	public boolean checkInput() {
		alertMessage = "";
		// 原密码
		if (oldPasswordEdit != null
				&& BeanUtils.isEmpty(oldPasswordEdit.getText().toString())) {
			alertMessage = getString(R.string.modifiy_oldpassword_hint);
			return false;
		}

		// 新密码
		if (newPasswordEdit != null
				&& BeanUtils.isEmpty(newPasswordEdit.getText().toString())) {
			alertMessage = getString(R.string.modifiy_newpassword_hint);
			return false;
		}

		// 确认密码
		if (confirmPasswordEdit != null
				&& BeanUtils.isEmpty(confirmPasswordEdit.getText().toString())) {
			alertMessage = getString(R.string.modifiy_confirmpassword_hint);
			return false;
		}

		// 确认密码和新密码
		if (!confirmPasswordEdit.getText().toString()
				.equals(newPasswordEdit.getText().toString())) {
			alertMessage = getString(R.string.modifiy_password_notsame);
			return false;
		}

		// 正则表达式验证新密码
		String regPwd = "^([A-Za-z0-9_\\-]){6,18}$";//正则表达式：只能是6到18位的字母、数字、下划线和中划线组成
		if (!newPasswordEdit.getText().toString().matches(regPwd)) {
			alertMessage = getString(R.string.modifiy_newpassword_error_hint);
			return false;
		}

		return true;
	}

	/** 修改密码 */
	public void toModifyPassword(String oldPassword, String password) {
		ApiRequest request = OAServicesHandler.modifyPassword(oldPassword,
				password);
		request.setMessage(getString(R.string.system_commit_message));
		helper.invokeWidthDialog(request, callBack);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			toUserAccountSecurity();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	// 调转到帐号安全页面
	public void toUserAccountSecurity() {
		UIHelper.forwardTargetActivity(ModifyPasswordActivity.this,
				UserAccountSecurityActivity.class, null, true);
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}
}
