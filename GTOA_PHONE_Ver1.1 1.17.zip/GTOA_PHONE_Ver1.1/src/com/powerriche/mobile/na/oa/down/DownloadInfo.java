package com.powerriche.mobile.na.oa.down;

/**
 * 类描述：<br> 
 * 下载信息说明类
 * @author  Miter
 * @date    2013-12-17
 */
public class DownloadInfo {
	
	/** 文件类型 */
	public static final int FILE_TYPE_ABSOLUTE = 0;
	/** apk文件 */
	public static final int FILE_TYPE_APK = 1;
	/** 图片文件 */
	public static final int FILE_TYPE_IMG = 2;
	/** 其他文件 */
	public static final int FILE_TYPE_OTHER = 3;

	/** 下载状态 */
	public static final int STATE_INIT = 0;
	
	/** 用户触发下载，等待有空闲网络可用状 */
	public static final int STATE_WAITTING = 1;
	
	/**正在下载状 */
	public static final int STATE_DOWNLOADING = 2;
	
	/** 暂停状 */
	public static final int STATE_PAUSE =3;
	
	/** 网络错误 */
	public static final int STATE_ERROR_NET =4;
	
	/** 写文件错 */
	public static final int STATE_ERROR_IO =5;
	
	/** 下载成功 */
	public static final int STATE_COMPLE = 6;
	
	/** 下载失败 */
	public static final int STATE_DOWNLOAD_FAILED = 7;
	
	/** 安装完成 */
	public static final int STATE_INSTALL_SUCCESS = 8;
	
	public static final int STATE_INSTALLING = 9;
	
	public static final int STATE_UNINSTALLING = 10;
	
	public static final int STATE_NEED_REDOWNLOAD = 11;
	
	public static final int STATE_UNINSTALL_SUCCESS = 12;
	
	/** 被删 */
	public static final int STATE_DELETED = 999;
	
	public static final int STATE_DOWNLOAD_ERROR = 404;
	
	public String mUrl = "";
	public String mPath = "";
	public String mFileName = "";
	public String mFullPath = "";
	public String mFullPathTemp = "";
	public long totalSize = 0;
	public long downloadSize = 0;
	public long mProductID = 0;
	public long mFileID = 0;
	public String mIconURL = "";
	public String mPackageName = "";
	public int mVersionCode = 0;
	public String mSignMD5 = "";
	public long mStarttime = 0;
	public long mFinishTime = 0;
	public int mFileType = 1;
	public int mState = 0;
	
	//只有apk才有包名
	public String mAppName;
	public String mDisplayName;
	public long mPackageId;  //是long类型
	
	public DownloadInfo() { }

	public long setTotalSize(long size) {
		totalSize = size;
		return totalSize;
	}
	
	public long setDownloadSize(long size) {
		downloadSize = size;
		return downloadSize;
	}
	
	public void setAppName(String appName) {
		mAppName = appName;
	}
	
	public boolean isDownloadComplete() {
		return (downloadSize == totalSize) && (totalSize != 0);
	}
}
