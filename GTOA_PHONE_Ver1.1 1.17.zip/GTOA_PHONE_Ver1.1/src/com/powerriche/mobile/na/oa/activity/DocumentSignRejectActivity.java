package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 公文签收跟拒签
 * 
 * @author Fitz
 * @date 2015年5月13日
 * @version v1.0
 */
public class DocumentSignRejectActivity extends BaseActivity implements
		OnClickListener {

	private Context mContext;
	private TextView tvTips;
	private EditText etReason;
	private Button btnCheckBox, btnSubmit;
	private LinearLayout llFinishWrap;

	private int isFinish, isReject;

	private String documentId, wfNo, traceNo;
	private boolean isSign;
	
	private String fpuNo, swfNo;
	
	private int passreadTag = -1;	//如果passread不等于1000，则初始话办理信息view，否则初始化传阅信息view
	private int isBackFlag = 1;//返回标识，1标识公文详情 2标识会议详情，
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.document_detail_sign_or_reject);
		mContext = this;
		
		documentId = getIntent().getStringExtra("documentId");
		wfNo = getIntent().getStringExtra("wfNo");
		traceNo = getIntent().getStringExtra("traceNo");
		isSign = getIntent().getBooleanExtra("isSign", false);
		fpuNo = getIntent().getStringExtra("fpuNo");	//当前环节编号
		swfNo = getIntent().getStringExtra("swfNo");	//系统流程编号
		passreadTag = getIntent().getIntExtra("IS_PASS_READ", -1);	//传阅入口标示
		isBackFlag = getIntent().getIntExtra("isBackFlag",1);//调转到公共详情还是其他详情，
		if (BeanUtils.isEmpty(documentId) || BeanUtils.isEmpty(wfNo)
				|| BeanUtils.isEmpty(traceNo)) {
			UIHelper.showMessage(mContext, "参数丢失");
			finish();
			return;
		}

		bindView();
	}

	void bindView() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.INVISIBLE);

		etReason = (EditText) findViewById(R.id.et_reason);
		tvTips = (TextView) findViewById(R.id.tv_tips);
		btnSubmit = (Button) findViewById(R.id.btn_submit);
		btnSubmit.setOnClickListener(this);
		btnCheckBox = (Button) findViewById(R.id.btn_finish_work);
		btnCheckBox.setOnClickListener(this);

		llFinishWrap = (LinearLayout) findViewById(R.id.ll_finish_wrap);

		//签收
		if (isSign) {
			topActivity.setTopTitle(getString(R.string.system_single_title));
			btnSubmit.setText(getString(R.string.send_accept_counts));
			etReason.setHint(getString(R.string.system_gw_receive_reason));
			tvTips.setText(getString(R.string.system_gw_receive_reason));
			llFinishWrap.setVisibility(View.GONE);
			isFinish = 0;
			isReject = 0;

		} else {
		//拒绝
			topActivity.setTopTitle(getString(R.string.system_refused_title));
			btnSubmit.setText(getString(R.string.send_reject_counts));
			etReason.setHint(getString(R.string.system_gw_refused_reason));
			tvTips.setText(getString(R.string.system_gw_refused_reason));
			isReject = 1;
		}
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.btn_submit) { // 提交数据
			checkData();
		} else if (v.getId() == R.id.btn_finish_work) { // 拒签是判断是否结束流程
			if (btnCheckBox.isSelected()) {
				btnCheckBox.setSelected(false);
				isFinish = 0; // 不结束
			} else {
				btnCheckBox.setSelected(true);
				isFinish = 1; // 结束
			}
		} else if (v.getId() == R.id.system_back) {//返回
			goback(0);
		}
	}

	private void checkData() {
		String reason = etReason.getText().toString();
		//只有拒绝的时候才进行判断
		if (!isSign) {
			if (BeanUtils.isEmpty(reason)) {
				UIHelper.showMessage(mContext,
						getString(R.string.system_gw_refused_reason));
				etReason.requestFocus();
				return;
			}
		}
		submit(reason);
	}

	/**
	 * 返回详情界面
	 * @param flag 办理结果标志：1-办理成功（返回待办列表需要移除当前待办项），0-未办理或办理不成功（返回待办列表不需要移除当前待办项）
	 */
	private void goback(int flag){
		Bundle data = new Bundle();
		data.putString("documentId", documentId);
		data.putString("wfNo", wfNo);
		data.putString("traceNo", traceNo);
		data.putString("fpuNo",fpuNo);	//当前环节编号
		data.putString("swfNo",swfNo);	//系统流程编号
		data.putInt("IS_PASS_READ", passreadTag);	//传阅入口标示
		/** 办理结果标志：1-办理成功（返回待办列表需要移除当前待办项），0-未办理或办理不成功（返回待办列表不需要移除当前待办项）*/
		data.putInt("DEAL_WITH_FLAG", flag);//办理结果标志
		DocumentDetailActivity.dealwithFlag = flag;//办理结果标志
		MeetDetailActivity.dealwithFlag = flag;//办理结果标志
		
		if(isBackFlag == 1){
			UIHelper.forwardTargetActivity(mContext, DocumentDetailActivity.class, data, true);
		}else if(isBackFlag == 2){
			UIHelper.forwardTargetActivity(mContext, MeetDetailActivity.class, data, true);
		}else{
			finish();
		}
		
	}

	private void submit(String reason) {
		UIHelper.signReceiveDoc(mContext, callBack, helper, 1001, documentId,
				wfNo, traceNo, isReject, reason, isFinish);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == 1001) {
					int code = item.getInt("code");
					String message = item.getString("message");
					if (code == 0) {
						if (isSign) {
							message = getString(R.string.system_succes_qs);
						} else {
							message = getString(R.string.system_succes_js);
						}
						goback(1);
					} else {
						if (isSign) {
							message = getString(R.string.system_error_qs);
						} else {
							message = getString(R.string.system_error_js);
						}
					}
					UIHelper.showMessage(mContext, message);

				}
			}
		}
	};

}
