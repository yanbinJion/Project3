package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

public class Attendance implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1435915946074402640L;
	private String attendDate;
	private String morningSignIn;
	private String morningSignInTime;
	private String morningSignInAddress;
	private String morningSignInState;
	private boolean morningSignInFlag;
	private String morningSignOut;
	private String morningSignOutTime;
	private String morningSignOutAddress;
	private String morningSignOutState;
	private boolean morningSignOutFlag;
	private String afternoonSignIn;
	private String afternoonSignInTime;
	private String afternoonSignInAddress;
	private String afternoonSignInState;
	private boolean afternoonSignInFlag;
	private String afternoonSignOut;
	private String afternoonSignOutTime;
	private String afternoonSignOutAddress;
	private String afternoonSignOutState;
	private boolean afternoonSignOutFlag;

	public String getAttendDate() {
		return attendDate;
	}

	public String getMorningSignIn() {
		return morningSignIn;
	}

	public String getMorningSignInTime() {
		return morningSignInTime;
	}

	public String getMorningSignInAddress() {
		return morningSignInAddress;
	}

	public String getMorningSignInState() {
		return morningSignInState;
	}

	public boolean isMorningSignInFlag() {
		return morningSignInFlag;
	}

	public String getMorningSignOut() {
		return morningSignOut;
	}

	public String getMorningSignOutTime() {
		return morningSignOutTime;
	}

	public String getMorningSignOutAddress() {
		return morningSignOutAddress;
	}

	public String getMorningSignOutState() {
		return morningSignOutState;
	}

	public boolean isMorningSignOutFlag() {
		return morningSignOutFlag;
	}

	public String getAfternoonSignIn() {
		return afternoonSignIn;
	}

	public String getAfternoonSignInTime() {
		return afternoonSignInTime;
	}

	public String getAfternoonSignInAddress() {
		return afternoonSignInAddress;
	}

	public String getAfternoonSignInState() {
		return afternoonSignInState;
	}

	public boolean isAfternoonSignInFlag() {
		return afternoonSignInFlag;
	}

	public String getAfternoonSignOut() {
		return afternoonSignOut;
	}

	public String getAfternoonSignOutTime() {
		return afternoonSignOutTime;
	}

	public String getAfternoonSignOutAddress() {
		return afternoonSignOutAddress;
	}

	public String getAfternoonSignOutState() {
		return afternoonSignOutState;
	}

	public boolean isAfternoonSignOutFlag() {
		return afternoonSignOutFlag;
	}

	public void setAttendDate(String attendDate) {
		this.attendDate = attendDate;
	}

	public void setMorningSignIn(String morningSignIn) {
		this.morningSignIn = morningSignIn;
	}

	public void setMorningSignInTime(String morningSignInTime) {
		this.morningSignInTime = morningSignInTime;
	}

	public void setMorningSignInAddress(String morningSignInAddress) {
		this.morningSignInAddress = morningSignInAddress;
	}

	public void setMorningSignInState(String morningSignInState) {
		this.morningSignInState = morningSignInState;
	}

	public void setMorningSignInFlag(boolean morningSignInFlag) {
		this.morningSignInFlag = morningSignInFlag;
	}

	public void setMorningSignOut(String morningSignOut) {
		this.morningSignOut = morningSignOut;
	}

	public void setMorningSignOutTime(String morningSignOutTime) {
		this.morningSignOutTime = morningSignOutTime;
	}

	public void setMorningSignOutAddress(String morningSignOutAddress) {
		this.morningSignOutAddress = morningSignOutAddress;
	}

	public void setMorningSignOutState(String morningSignOutState) {
		this.morningSignOutState = morningSignOutState;
	}

	public void setMorningSignOutFlag(boolean morningSignOutFlag) {
		this.morningSignOutFlag = morningSignOutFlag;
	}

	public void setAfternoonSignIn(String afternoonSignIn) {
		this.afternoonSignIn = afternoonSignIn;
	}

	public void setAfternoonSignInTime(String afternoonSignInTime) {
		this.afternoonSignInTime = afternoonSignInTime;
	}

	public void setAfternoonSignInAddress(String afternoonSignInAddress) {
		this.afternoonSignInAddress = afternoonSignInAddress;
	}

	public void setAfternoonSignInState(String afternoonSignInState) {
		this.afternoonSignInState = afternoonSignInState;
	}

	public void setAfternoonSignInFlag(boolean afternoonSignInFlag) {
		this.afternoonSignInFlag = afternoonSignInFlag;
	}

	public void setAfternoonSignOut(String afternoonSignOut) {
		this.afternoonSignOut = afternoonSignOut;
	}

	public void setAfternoonSignOutTime(String afternoonSignOutTime) {
		this.afternoonSignOutTime = afternoonSignOutTime;
	}

	public void setAfternoonSignOutAddress(String afternoonSignOutAddress) {
		this.afternoonSignOutAddress = afternoonSignOutAddress;
	}

	public void setAfternoonSignOutState(String afternoonSignOutState) {
		this.afternoonSignOutState = afternoonSignOutState;
	}

	public void setAfternoonSignOutFlag(boolean afternoonSignOutFlag) {
		this.afternoonSignOutFlag = afternoonSignOutFlag;
	}

}
