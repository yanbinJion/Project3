package com.powerriche.mobile.na.oa.activity;

import java.io.File;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

import android.widget.Toast;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.DataCleanManager;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.VersionInfo;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.PreferenceUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UpdateThread;
import com.powerriche.mobile.oa.tools.UserHelper;

/**
 * Filename : UserSettingActivity
 * 
 * @Description : 用户设置
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-28 15:00:00
 */
public class UserSettingActivity extends BaseActivity implements OnClickListener {

	private final static int DIALOG_VERSION = 5235;
	private final static int DIALOG_LOGOUT = 5236;

	private Context mContext;
	
	private TextView versionTextView;
	private RelativeLayout versionRelativeLayout;
	private TextView cacheSizeTextview;

	private int localVersionCode = Integer.MAX_VALUE;//本地APK的版本编号
	private String localVersionName = "1.0.0";//本地APK的版本名称

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.setting_userinfo_layout);
		// 初始化数据
		initData();
		// 初始化选择按钮
		initLaoutClick();

	}

	// 初始化数据
	public void initData() {
		
		cacheSizeTextview = (TextView) findViewById(R.id.cache_size_textview);
		versionTextView = (TextView) findViewById(R.id.version_size_textview);
		versionTextView.setText(getString(R.string.setting_version_maxnew));
		try {
			// 得到当前版本号
			PackageManager manager = this.getPackageManager();
			PackageInfo info = manager.getPackageInfo(this.getPackageName(), 0);
			localVersionCode = info.versionCode;
			localVersionName = info.versionName;
			// 得到缓存
			cacheSizeTextview.setText(DataCleanManager.getTotalCacheSize(this));
			getVersion();
		} catch (Exception e) {
			cacheSizeTextview.setText(getString(R.string.setting_cache_size));
			getVersion();
		}

	}

	/** 获取版本号 */
	public void getVersion() {
		ApiRequest request = OAServicesHandler.getAppVersion("android");
		helper.invokeWidthDialog(request, callBack, DIALOG_VERSION);
	}
	
	/** 注销登陆 */
	public void logout(){
		ApiRequest request = OAServicesHandler.portalLogout();
		request.setMessage(getString(R.string.setting_logicout_msg));
		helper.invokeWidthDialog(request, callBack, DIALOG_LOGOUT);
	}

	// 初始化选择按钮
	public void initLaoutClick() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(this.getString(R.string.setting_title));
		topActivity.setRightBtnVisibility(View.INVISIBLE);

		// 账号安全
		this.findViewById(R.id.tv_account_security).setOnClickListener(this);
		// 消息通告
		this.findViewById(R.id.tv_message).setOnClickListener(this);
		// 清楚缓存
		this.findViewById(R.id.clearcache_relativeLayout).setOnClickListener(this);
		// 版本更新
		versionRelativeLayout = (RelativeLayout) findViewById(R.id.version_relativeLayout);
		versionRelativeLayout.setOnClickListener(this);
		// 辅助功能
		this.findViewById(R.id.tv_auxiliary).setOnClickListener(this);
		//流量统计
		this.findViewById(R.id.tv_statistics).setOnClickListener(this);
		// 意见反馈
		this.findViewById(R.id.tv_feedback).setOnClickListener(this);
		// 关于OA
		this.findViewById(R.id.tv_about).setOnClickListener(this);
		// 注销
		this.findViewById(R.id.loginout_relativeLayout).setOnClickListener(this);
		this.findViewById(R.id.loginout_btn).setOnClickListener(this);
		this.findViewById(R.id.loginout_imgage).setOnClickListener(this);

	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
            if(what == DIALOG_LOGOUT){
                exit();
                return;
            }
			if(checkResult(item)){
				if(DIALOG_VERSION == what){
					String code = item.getString("code");
					String versionName = item.getString("vername");
					String localVersionInfo = "当前版本是" + localVersionName + "，" + versionName;
					// 操作成功
					if (Constants.SUCCESS_CODE.equals(code)) {
						int remoteVersionCode = item.getInt("vercode", -1);//远程APK的版本编号
						// 判断版本
						if (localVersionName.compareTo(versionName) < 0) {
							String downUrl = item.getString("url");
							String content = item.getString("content");
							String apkSize = item.getString("apksize");
							//int isforce = item.getInt("isforce", 0);	//是否强制升级
							if(!BeanUtils.isEmpty(apkSize)){
								content = content + "<br/>文件大小：" + apkSize;
							}
							VersionInfo bean = new VersionInfo();
							bean.setVersionCode(remoteVersionCode);
							bean.setVersionName(versionName);
							bean.setDownUrl(downUrl);
							bean.setContent(content);
							bean.setApkSize(apkSize);
							
							versionTextView.setTag(bean);
							versionTextView.setTextColor(Color.RED);//红色
							versionTextView.setText(localVersionInfo + getString(R.string.setting_version_new));//有更新版本
							versionRelativeLayout.setEnabled(true);
							
						} else {
							versionTextView.setText(localVersionInfo + getString(R.string.setting_version_maxnew));//已是最新版
							versionRelativeLayout.setEnabled(false);
						}
						
					} else {
						versionTextView.setText(localVersionInfo + getString(R.string.setting_version_maxnew));//已是最新版
						versionRelativeLayout.setEnabled(false);
					}
					
				} else {
					versionTextView.setText(getString(R.string.setting_version_maxnew));
					versionRelativeLayout.setVisibility(View.GONE);
					versionRelativeLayout.setEnabled(false);
				}
			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error, int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));

		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	public void onClick(View view) {
		// 返回
		if (view.getId() == R.id.system_back) {
			finish();
		} else if (view.getId() == R.id.tv_account_security) {
			// 账号安全
			UIHelper.forwardTargetActivity(this, UserAccountSecurityActivity.class, null, false);
		} else if (view.getId() == R.id.tv_message) {
			// 消息通告
			UIHelper.forwardTargetActivity(this, SetNotifyActivity.class, null, false);

		} else if (view.getId() == R.id.clearcache_relativeLayout) {
			// 清楚缓存
			DataCleanManager.cleanInternalCache(this);
			DataCleanManager.cleanExternalCache(this);
			showErrorMessage(getString(R.string.setting_cache_success));
			cacheSizeTextview.setText(getString(R.string.setting_cache_size));

		} else if (view.getId() == R.id.version_relativeLayout) {
			// 版本更新
			Object obj = versionTextView.getTag();
			if(obj!=null && obj instanceof VersionInfo){
				VersionInfo bean = (VersionInfo) obj;
				showTipsDialog(bean);
			}

		} else if (view.getId() == R.id.tv_auxiliary) {
			// 辅助功能
			UIHelper.forwardTargetActivity(this, StatisticsActivity.class, null, false);
		} else if (view.getId() == R.id.tv_statistics) {
			//流量统计
			UIHelper.forwardTargetActivity(this, StatisticsActivity.class, null, false);
		} else if (view.getId() == R.id.tv_feedback) {
			// 意见反馈
			UIHelper.forwardTargetActivity(this, FeedbackActivity.class, null, false);
		} else if (view.getId() == R.id.tv_about) {
			// 关于OA
			UIHelper.forwardTargetActivity(this, AboutOaActivity.class, null, false);
		} else if (view.getId() == R.id.loginout_relativeLayout
				|| view.getId() == R.id.loginout_imgage
				|| view.getId() == R.id.loginout_btn) {
			// 注销
//			showDialog(DIALOG_LOGOUT);
			showExitDialog();
		}
	}
	
	private void showExitDialog(){
		final SystemDialog chooseDialog = new SystemDialog(this);
		chooseDialog.setMessage("您确定要退出系统？");
		chooseDialog.setOnConfirmClickListener("确定", new View.OnClickListener() { // 确定按钮事件
			@Override
			public void onClick(View view) {
				logout();
			}
		});
		chooseDialog.setOnCancelClickListener("取消", new View.OnClickListener() { // 取消
			@Override
			public void onClick(View v) {
				if (chooseDialog != null) {
					chooseDialog.dismiss();
				}
			}
		});
		chooseDialog.show();
	}


	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}

	public void exit() {
        Toast.makeText(this, "注销成功,请重新登录", Toast.LENGTH_SHORT).show();
		SystemContext.clear();
		UserHelper userHelper = new UserHelper();
		userHelper.setAutoLogin(false);
		Intent logoutIntent = new Intent(UserSettingActivity.this, SystemLoginActivity.class);
		logoutIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(logoutIntent);
		finish();
	}

	
	/**强制安装 */
	private void showTipsDialog(final VersionInfo bean){
		final SystemDialog dialog = new SystemDialog(mContext);
		dialog.setTitle("新版本升级"+bean.getVersionName());
		dialog.showTitle();
		dialog.setMessage(bean.getContent());//设置更新日志
//		dialog.setCancelable(false);
		dialog.setGravity(Gravity.LEFT);
		dialog.setOnCancelClickListener("本次忽略", new OnClickListener(){
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.setOnConfirmClickListener("立即安装", new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
				String path = "";
				String status = Environment.getExternalStorageState();
				if (status.equals(Environment.MEDIA_MOUNTED)) {// 判断是否有SD卡
					path = Environment.getExternalStorageDirectory().getAbsolutePath();
				} else {
					path = mContext.getCacheDir().getAbsolutePath();
				}
				
				//apk命名
				String apkName = "GTOA_"+bean.getVersionCode()+".apk";
				
				//判断已安装的文件是否存在，存在直接安装，不存在，则下载
				String filePath = path + "/" + apkName;
				File checkFile = new File(filePath);
				if(checkFile!=null && checkFile.exists()){
					UIHelper.openApkFile(mContext, filePath);
					return;
				}
				
				ProgressDialog progressBar = new ProgressDialog(mContext);
				progressBar.setTitle("正在下载...");
				progressBar.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				progressBar.setCancelable(true);
				progressBar.setCanceledOnTouchOutside(false);
				progressBar.show();
				
				UpdateThread updateTask = new UpdateThread(mContext, bean.getDownUrl(), path, apkName, progressBar);
				updateTask.start();
			}
		});
		dialog.show();
	}
	
}
