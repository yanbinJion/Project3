package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * 类描述：<br> 
 * 意见
 * @author  Fitz
 * @date    2015年5月7日
 * @version v1.0
 */
public class SuggestInfo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2758953609415023756L;

	public SuggestInfo(){}
	
	public SuggestInfo(String noteId, String content){
		this.noteId = noteId;
		this.content = content;
	}
	
	String noteId;
	String content;
	int status;
	
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
