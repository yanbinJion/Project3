package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.MyTreeListViewAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.TreeListAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.NodeBean;
import com.powerriche.mobile.na.oa.treeview.util.Node;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 选择代理人
 * @author  Fitz
 * @date    2015年4月22日
 * @version v1.0
 */
public class SelectedPeopleActivity extends BaseActivity implements OnClickListener {

	private static final int GET_STAFF_TREE_REQ = 0;
	public static String KEY_USER_NAMES_STRING = "KEY_USER_NAMES_STRING"; // 退出界面时，返回所有选中的人员姓名。返回类型：String
	public static String KEY_USER_IDS_STRING = "KEY_USER_IDS_STRING"; // 退出界面时，返回所有选中的人员ID。返回类型：String

	private Context mContext;
	private ListView listView;
	private List<NodeBean> nodes;
	private TextView tv_selected_people;
	private MyTreeListViewAdapter<NodeBean> treeAdapter;
	private String name;
	private String userId;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		UIHelper.hideTitle(this);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.common_choose_people);
		initView();
		loading();
	}
	
	private void initView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.choose_people_title));// 默认标题
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("确认");
		tv_selected_people = (TextView) findViewById(R.id.tv_selected_people);
		listView = (ListView) findViewById(R.id.listView);
	}
	
	private void loading() {
		getStaffTree();
	}
	
	private void getStaffTree() {
        ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
        if (request != null){
            helper.invokeWidthDialog(request, callBack, GET_STAFF_TREE_REQ);
        }
    }
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch(id){
		case R.id.system_back:
			finish();
			break;
			
		case R.id.btn_top_right:
			returnResult();
			break;
		}
	}
	private void showStaffTree(List<ResultItem> item) {
		if (item == null) {
			return;
		}
		nodes = new ArrayList<NodeBean>();
		for (ResultItem resultItem : item) {
//			String dispOrder = resultItem.getString("DISP_ORDER");
//			String orderNo = resultItem.getString("ORDERNO");
			String realName = resultItem.getString("REAL_NAME");
//			String siteName = resultItem.getString("SITE_NAME");
			String siteNo = resultItem.getString("SITE_NO");
			String staffNo = resultItem.getString("STAFF_NO");
			NodeBean node = new NodeBean(staffNo, siteNo, realName);
			nodes.add(node);
		}
		treeAdapter = new MyTreeListViewAdapter<NodeBean>(listView, this, nodes, 0);
		treeAdapter.setOnTreeNodeClickListener(new TreeListAdapter.OnTreeNodeClickListener() {

			@Override
			public void onClick(Node node, int position) {
				
			}

			@Override
			public void onCheckChange(Node node, int position,
					List<Node> checkedNodes) {
				name = "";
				userId = "";
				for (Node n : checkedNodes) {
					if (n.isLeaf()) {
						if (!name.equals("")) {
							name += ",";
						}
						name += n.getName();
						if (!userId.equals("")) {
							userId += ",";
						}
						userId += n.getId();
					}
				}
				tv_selected_people.setText(name);
			}
		});
		listView.setAdapter(treeAdapter);
	}
	private void returnResult() {
		String selected_people = tv_selected_people.getText().toString().trim();
		
		if (BeanUtils.isEmptyStrs(selected_people)) {
			UIHelper.showMessage(mContext, "请至少选择一个人员");
			return;
		}
		Intent intent = new Intent();
		intent.putExtra(KEY_USER_IDS_STRING, userId == null ? "" : userId);
		intent.putExtra(KEY_USER_NAMES_STRING, selected_people == null ? "" : selected_people);
		setResult(Activity.RESULT_OK, intent);
		finish();
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {	
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String code = item.getString("code");
				String message = item.getString("message");
				if (!Constants.SUCCESS_CODE.equals(code)) {
					UIHelper.showMessage(mContext, message);
					return;
				}
				if (what == GET_STAFF_TREE_REQ) {
					List<ResultItem> items = item.getItems("data");
					showStaffTree(items);
				}
			}
		}
	};
	
}
