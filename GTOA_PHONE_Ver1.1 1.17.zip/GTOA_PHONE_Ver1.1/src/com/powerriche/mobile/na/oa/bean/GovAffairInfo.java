package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * 类描述：<br> 
 * 领导政务接口
 * @author  Fitz
 * @date    2015年4月28日
 * @version v1.0
 */
public class GovAffairInfo implements Serializable{

	private static final long serialVersionUID = 1739093160679901851L;
	
	String beginData;
	String endData;
	String beginTime;
	String endTime;
	String leaderName;
	String affairContent;	//活动
	String affairAddress;	//活动地址
	
	String affairId;
	
	int position;
	
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getBeginData() {
		return beginData;
	}
	public void setBeginData(String beginData) {
		this.beginData = beginData;
	}
	public String getEndData() {
		return endData;
	}
	public void setEndData(String endData) {
		this.endData = endData;
	}
	public String getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getAffairContent() {
		return affairContent;
	}
	public void setAffairContent(String affairContent) {
		this.affairContent = affairContent;
	}
	public String getLeaderName() {
		return leaderName;
	}
	public void setLeaderName(String leaderName) {
		this.leaderName = leaderName;
	}
	public String getAffairId() {
		return affairId;
	}
	public void setAffairId(String affairId) {
		this.affairId = affairId;
	}
	public String getAffairAddress() {
		return affairAddress;
	}
	public void setAffairAddress(String affairAddress) {
		this.affairAddress = affairAddress;
	}
	
}
