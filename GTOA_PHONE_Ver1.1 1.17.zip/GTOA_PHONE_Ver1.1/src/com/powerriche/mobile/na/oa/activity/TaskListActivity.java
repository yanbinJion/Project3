package com.powerriche.mobile.na.oa.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.TaskListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 任务管理：列表
 * 
 * @author 李运期
 * @date 2015年5月4日
 * @version v1.0
 */
public class TaskListActivity extends BaseActivity implements OnClickListener {

	private TaskListActivity acitvity;
	private View contextView;

	private PullToRefreshListView mPullView;
	private ListView mListView;
	private TextView tvNoDataMsg;

	public int pageIndex = 1;

	private static int OPT_TYPE = Constants.WHAT_REQUEST_RWGL;

	public Handler indexHandler;
	/** 任务管理 */
	public TaskListHelper taskListHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.task_list);

		acitvity = (TaskListActivity) this;
		contextView = findViewById(R.id.layout_rwgl);

		bindView();

		taskListHelper = new TaskListHelper(acitvity, contextView, tvNoDataMsg);
		//加载第一页的列表数据
		loadData();
	}

	void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.menu_task));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.GONE);// 隐藏右边按钮
		// topActivity.setRightBtnOnClickListener(this);
		// topActivity.setRightBtnStyle("", R.drawable.add_button,
		// false);//“新建”图标

		// 设置中部的列表区
		mPullView = (PullToRefreshListView) findViewById(R.id.pulllistview_rwgl);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);

		mListView = mPullView.getRefreshableView();
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(android.R.color.transparent);
		
		//添加“公共搜索框”：可以跟随列表数据一起滚动
		View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
		mListView.addHeaderView(header);

		mPullView.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 下拉加载数据
				pageIndex =  1;
				taskListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_RWGL,
						pageIndex,false);
			}

			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				taskListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_RWGL,
						pageIndex,false);
			}
		});
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);
	}

	/**
	 * 加载数据：任务管理列表
	 */
	public void loadData() {
		// 设置选中项
		OPT_TYPE = Constants.WHAT_REQUEST_RWGL;

		// 请求加载数据
		pageIndex = 1;
		taskListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_RWGL,
				pageIndex,true);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				onClickBack();
				break;
			case R.id.btn_top_right :// 新建任务
				// UIHelper.forwardTargetActivity(mContext, TaskDetailActivity.class, null, false);
				break;
		}

	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == Constants.WHAT_REQUEST_RWGL) {// 任务管理
					taskListHelper.process(response, what);
				}
			}
		}
	};
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			onClickBack();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private void onClickBack(){
		if(Constants.NOTIFY_DETAIL_BACK){
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(TaskListActivity.this, MainActivity.class, null, true);
	        
		}else{
			finish();
		}
	}

}
