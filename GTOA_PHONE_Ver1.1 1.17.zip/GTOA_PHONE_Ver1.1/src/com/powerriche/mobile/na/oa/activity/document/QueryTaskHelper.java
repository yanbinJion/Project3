package com.powerriche.mobile.na.oa.activity.document;

/**
 * 任务搜索帮助类
 * Created by root on 16-5-9.
 */
public class QueryTaskHelper {
}
