package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.SimpleTreeListViewAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.TreeListViewAdapter.OnTreeNodeClickListener;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.OrgBean;
import com.powerriche.mobile.na.oa.treeview.util.Node;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**			   
 * 类描述：<br>  
 * 选择代理人	   
 * @author  Fitz
 * @date    2015年4月22日
 * @version v1.0
 */			   
public class ChoosePeoplesActivity extends BaseActivity implements OnClickListener {
			   
	private static final int GET_STAFF_TREE_REQ = 0;
	public static String KEY_CUSTOM_TITLE = "KEY_CUSTOM_TITLE"; // 初始化界面时，自定义的界面标题。传参类型：string
	public static String KEY_IS_MULTIPLE_SELECT = "KEY_IS_MULTIPLE_SELECT"; // 初始化界面时，是否可以人员多选。传参类型：boolean
	public static String KEY_USER_IDS_INIT = "KEY_USER_IDS_INIT"; // 初始化界面时，默认选中的人员ID。传参类型：ArrayList<String>
	// public static String KEY_DEPARTMENT_IDS_INIT =
	// "KEY_DEPARTMENT_IDS_INIT";//初始化界面时，默认选中的部门ID。传参类型：ArrayList<String>
	public static String KEY_USER_NAMES = "KEY_USER_NAMES"; // 退出界面时，返回所有选中的人员姓名。返回类型：ArrayList<String>
	public static String KEY_USER_NAMES_STRING = "KEY_USER_NAMES_STRING"; // 退出界面时，返回所有选中的人员姓名。返回类型：String
	public static String KEY_USER_IDS = "KEY_USER_IDS"; // 退出界面时，返回所有选中的人员ID。返回类型：ArrayList<String>
	public static String KEY_USER_IDS_STRING = "KEY_USER_IDS_STRING"; // 退出界面时，返回所有选中的人员ID。返回类型：String
			 
	public static String KEY_USER_SITENAMES = "KEY_USER_SITENAMES"; // 退出界面时，返回所有选中的人员部门id。返回类型：ArrayList<String>
			 
	public static String KEY_USER_MOBILES = "KEY_USER_MOBILES"; // 退出界面时，返回所有选中的人员手机。返回类型：ArrayList<String>
			 
	private Context mContext;
			 
	public String customTitle = null; // 初始化界面时，自定义的界面标题
	public boolean isMultipleSelect = false; // 初始化界面时，是否可以人员多选
	public ArrayList<String> userIds4Init = null; // 初始化界面时，默认选中的人员ID
			 
	// public ArrayList<String> departmentIds4Init = null; //初始化界面时，默认选中的部门ID
			 
	public TextView tvSelectedPeople = null;// 初始化界面时，默认选中的人员姓名，以符号、分隔
	public Button btnSelectAll = null;// 当可以多选时，显示“全选”按钮
	private ListView listView;
	private SimpleTreeListViewAdapter<OrgBean> treeAdapter;
	private List<OrgBean> beans;
	private TextView tv_selected_people;
	private String userId;
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		UIHelper.hideTitle(this);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.common_choose_people);
		customTitle = getIntent().getStringExtra(KEY_CUSTOM_TITLE);
		isMultipleSelect = getIntent().getBooleanExtra(KEY_IS_MULTIPLE_SELECT,
				false);
		userIds4Init = getIntent().getStringArrayListExtra(KEY_USER_IDS_INIT);
			
		initView();
		loading();
	}		
			
	private void initView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		if (BeanUtils.isEmpty(customTitle)) {
			topActivity.setTopTitle(getString(R.string.choose_people_title));// 默认标题
		} else {
			topActivity.setTopTitle(customTitle);// 自定义标题
		}	
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("确认");
		tv_selected_people = (TextView) findViewById(R.id.tv_selected_people);
		listView = (ListView) findViewById(R.id.listView);
	}		
			
	private void loading(){
		getStaffTree();
	}		
			
			
	public InvokeHelper getInvokeHelper() {
		return helper;
	}		
			
	private void getStaffTree(){
        ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
        if (request != null){
            helper.invokeWidthDialog(request, callBack, GET_STAFF_TREE_REQ);
        }	
    }		
			
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch(id){
		case R.id.system_back:
			finish();
			break;
			
		case R.id.btn_top_right:
			returnResult();
			break;
		}	
	}		
			
			
	private void showStaffTree(List<ResultItem> item) {
		if(item == null) {
			return;
		}	
		beans = new ArrayList<OrgBean>();
		for (ResultItem resultItem : item) {
			String dispOrder = resultItem.getString("DISP_ORDER");
//			String orderNo = resultItem.getString("ORDERNO");
			String realName = resultItem.getString("REAL_NAME");
//			String siteName = resultItem.getString("SITE_NAME");
			String siteNo = resultItem.getString("SITE_NO");
			String staffNo = resultItem.getString("STAFF_NO");
//			org.setOrderNo(orderNo);
//			org.setSiteName(siteName);
			OrgBean org = new OrgBean(staffNo, siteNo, realName);
			org.setDispOrder(dispOrder);
			beans.add(org);
		}	
		if (!BeanUtils.isEmpty(beans)) {
			if (treeAdapter == null) {
				treeAdapter = new SimpleTreeListViewAdapter<OrgBean>(this, listView, beans, 0);
				listView.setAdapter(treeAdapter);
			} else {
				treeAdapter.notifyDataSetChanged();
			}
		}	
		treeAdapter.setOnTreeNodeClickLitener(new OnTreeNodeClickListener() {
			
			@Override
			public void onClick(Node node, int position) {
				if (node.isLeaf()) {
					userId = node.getId();
					String realName = node.getName();
					tv_selected_people.setText(realName);
				}
			}
		}); 
	}		
	private void returnResult() {
		String selected_people = tv_selected_people.getText().toString().trim();
			 
		if (BeanUtils.isEmptyStrs(selected_people)) {
			UIHelper.showMessage(mContext, "请选择代理人");
			return;
		}	  
		Intent intent = new Intent();
		intent.putExtra("staffNo", userId == null ? "" : userId);// 获取人员的ID
		intent.putExtra("name", selected_people == null ? "" : selected_people);// 获取人员的姓名
		Log.i("TEST", " staffNo "+userId+" name "+selected_people);
		setResult(Activity.RESULT_OK, intent);
		finish();
	}		 
			 
			 
			 
	private IRequestCallBack callBack = new BaseRequestCallBack() {	
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String code = item.getString("code");
				String message = item.getString("message");
				if (!Constants.SUCCESS_CODE.equals(code)) {
					UIHelper.showMessage(mContext, message);
					return;
				}
				if (what == GET_STAFF_TREE_REQ) {
					List<ResultItem> items = item.getItems("data");
					showStaffTree(items);
				}
			}
		}	
	};		
			
}			
			