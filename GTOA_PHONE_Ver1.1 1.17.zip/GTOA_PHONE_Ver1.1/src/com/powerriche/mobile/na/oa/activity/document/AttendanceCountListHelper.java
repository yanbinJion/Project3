package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.AttendanceCountActivity;
import com.powerriche.mobile.na.oa.activity.MyRecordActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
/**
 * @title  考勤统计
 * @author dir_wang
 * @date   2016-7-21下午3:28:45
 */
public class AttendanceCountListHelper {

	private ListView listView;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();

	private InvokeHelper helper = null;

	private Context mContext = null;

	private IRequestCallBack callBack = null;

	private ResultSimpleAdapter adapter;

	private PullToRefreshListView mPullView;
	private TextView tv_no_data_attendance_count;
	private EditText beginTime;
	private EditText endTime;
	private int pageIndex;


	public AttendanceCountListHelper(Context context, View contextView) {
		this.mContext = context;
		AttendanceCountActivity acitvity = (AttendanceCountActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		mPullView = (PullToRefreshListView) contextView.findViewById(R.id.lv_attendance_count);
		tv_no_data_attendance_count = (TextView) contextView.findViewById(R.id.tv_no_data_attendance_count);
		listView = (ListView) mPullView.getRefreshableView();
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				ResultItem result = resultItems.get(position);
				String staffNo = result.getString("STAFF_NO");
				Bundle data = new Bundle();
				data.putString("staffNo", staffNo);
				data.putString("beginTime", getBeginTime().getText().toString());
				data.putString("endTime", getEndTime().getText().toString());
				UIHelper.forwardTargetActivity(mContext, MyRecordActivity.class, data, false);
			}
		});
	}

	public void loadData(int what, int index, boolean isDialog) {
		this.pageIndex = index;
		// 清除数据
		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
		ApiRequest request = OAServicesHandler.getAttendanceStaffList(index);
		if (request != null) {
			if (isDialog) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}

	}

	public void process(HttpResponse response, int what) {
		if (pageIndex == 1) {
			resultItems.clear();
		}
		List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			resultItems.addAll(items);
		}
		if (adapter == null) {
			int[] txtids = { R.id.tv_real_name, R.id.tv_site_name };
			String[] keys = new String[] { "REAL_NAME", "SITE_NAME" };
			adapter = new ResultSimpleAdapter(mContext, resultItems,
					R.layout.attendance_count_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int positon) {

				}
			});
			listView.setAdapter(adapter);
			tv_no_data_attendance_count.setVisibility(View.VISIBLE);

		} else {
			adapter.notifyDataSetChanged();
			tv_no_data_attendance_count.setVisibility(View.GONE);
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items) || items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}
		
	}
	
	public EditText getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(EditText beginTime) {
		this.beginTime = beginTime;
	}

	public EditText getEndTime() {
		return endTime;
	}

	public void setEndTime(EditText endTime) {
		this.endTime = endTime;
	}
	

}
