package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.ExecutiveMeetItemHelper;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : ExecutiveMeetingDetailActivity
 * 
 * @Description : 常务会议详情
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-05-5 09:38:24
 */
public class ExecutiveMeetingDetailActivity extends BaseActivity implements OnClickListener {

	/** 查询单个数据标识 */
	public final static int WHAT_REQUEST_ITEM = 5457;
	
	private String meetingId;

	private ExecutiveMeetItemHelper execMeetItemHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.execmeet_item_detail);
		meetingId = getIntent().getStringExtra("meetingId"); // 会议ID
		bindView();
	}

	private void bindView() {
		TopActivity topActivity = (TopActivity) this.findViewById(R.id.top_activity);
		topActivity.setTopTitle(this.getString(R.string.execmeet_datail_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.INVISIBLE);
		
		execMeetItemHelper = new ExecutiveMeetItemHelper(
				ExecutiveMeetingDetailActivity.this,
				this.findViewById(R.id.layout_execmeet_detail));
		
		// 加载数据
		execMeetItemHelper.loadItem(meetingId, WHAT_REQUEST_ITEM);
	}

	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.system_back:// 返回
			onClickBack();
			break;
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == WHAT_REQUEST_ITEM) {
					execMeetItemHelper.process(response, what);
				}
			}
		}

		@Override
		public void finish(Object dialogObj, int what) {
			super.finish(dialogObj, what);
			if (what == 1236 || what == 1237) {

			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_request_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};


	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			onClickBack();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private void onClickBack(){
		if(Constants.NOTIFY_DETAIL_BACK){
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(ExecutiveMeetingDetailActivity.this, MainActivity.class, null, true);
	        
		}else{
			finish();
		}
	}

}
