package com.powerriche.mobile.na.oa.activity.adapter;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DESUtil;
import com.powerriche.mobile.oa.tools.FileDownHelper;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 附件下载-->Fitz -->已废弃， 不使用<br>
 * FileName    : OnFileDownListener.java
 * Description : 系统文件下载统一处理
 * @author     : 刘剑
 * @version    : 1.0
 * Create Date : 2011-06-18 下午22:20:07
 **/
public class FileDownListener {

	private Context context;
	private RoundProgressButton btnDown;
	private String filePath;
	private String url;
	private String currentPath;
	private int compeleteSize = -1;
	
	private boolean downThread = false;
	
	private static final int ERROR_CODE_NET 	 = 3245;
	private static final int ERROR_CODE_NOSDCARD = 4245;
	private static final int FILE_MESSAGE_WHAT = 1245;
	
	private String fileCode;	//用于保存下载唯一标识
	
	private Handler handler = null;
	private InputStream ins = null;
	
	private FileDownHelper downHelper;
	
	private int transparent;
	private int roundColor;
	private int roundProgressColor;
	
	
	private static final int INIT = 1;//定义三种下载的状态：初始化状态，正在下载状态，暂停状态
	private static final int DOWNLOADING = 2;
	private static final int PAUSE = 3;
	private static final int FINISH = 4;
	private int state = INIT;
	
	
	public FileDownListener(Context contextx, String url, String fileName, String fileCode, String fileType, String title, RoundProgressButton btnDown){
		this.context = contextx;
		this.btnDown = btnDown;
		this.fileCode = fileCode;
		this.transparent = context.getResources().getColor(R.color.transparent);
		this.roundColor = context.getResources().getColor(R.color.gray_split_line_bg);
		this.roundProgressColor = context.getResources().getColor(R.color.down_progress_color);	//设置进度条颜色;
		
		this.downHelper = new FileDownHelper(context);
		
		setRequest(fileName, fileCode, fileType, url, title);
		
		handler = new Handler(){

			@Override
			public void handleMessage(Message msg) {
				BaseActivity activity = null;
				if(context!=null && context instanceof BaseActivity){
					activity = (BaseActivity) context;
				}
				if(ERROR_CODE_NET == msg.what){
					if(activity!=null){
						activity.showErrorMessage(context.getString(R.string.down_file_error));
					}
					failDown();
					
				}else if(ERROR_CODE_NOSDCARD == msg.what){
					if(activity!=null){
						activity.showErrorMessage(context.getString(R.string.system_no_sdcard));
					}
					failDown();
					
				}else {
					FileDownListener.this.handleMessage(msg, 0);
				}
			}
			
		};
		this.context = contextx;
		this.url = url;
	}
	
	
	
	
	public void start(){
		
		//先判断SD卡是否存在，再判断SD卡是否还有空间
		boolean existSDCard = UIHelper.existSDCard();
		if(!existSDCard){
			UIHelper.showMessage(context, "SD卡不存在");
			return;
		}
		
		if(filePath == null){
			((BaseActivity) context).showErrorMessage(context.getString(R.string.system_file_not_found));
			return;
		}
		
		DocFileInfo docInfo = (DocFileInfo) this.btnDown.getTag();
		
		boolean flag = downHelper.isExistFile(fileCode);
		if(BeanUtils.isFileExist(filePath) && !flag){
			BeanUtils.deleteFile(filePath);
//			docInfo.setDown(false);
			this.btnDown.setTag(docInfo);
			this.compeleteSize = -1;
			start();	//重新下载
			
		}else if(BeanUtils.isFileExist(filePath) && flag && state==FINISH){
			this.onFinish(filePath);
			
		}else{
			
			if(state == DOWNLOADING){
				return;
			}
			state = DOWNLOADING;
			
			//开始下载
			btnDown.setCricleAndProgressColor(transparent, transparent);
			btnDown.setBackgroundResource(R.drawable.ic_down_start);	//开始状态
//				docInfo.setDown(true);	//正在下载
			this.btnDown.setTag(docInfo);
			
			new Thread(){
				public void run(){
					downFiles(url, filePath);
				}
			}.start();
		}
	}
	
	/**文件下载过程中的处理*/
	public void handleMessage(Message message, int what) {
		
		if(FILE_MESSAGE_WHAT == message.what){	//开始下载
			final int max = message.arg1;
			currentPath = message.obj.toString();
			this.btnDown.setFileSize(max);	//文件的大小
			this.btnDown.setMax(100);	//设置最大进度
			
			//开始下载监听
			startUpdateProcess(handler, currentPath, max);
			
		}else if(124568 == message.what){	//下载中
			int totalSize = btnDown.getFileSize();
			int dealtSize = message.arg1;
			
			Logger.e("handler--->里面", dealtSize+"<---------");
			
			//计算百分比
			float num = (float)dealtSize / (float)totalSize;
			int progress = (int)(num * 100);
			
			this.btnDown.setBackgroundResource(R.drawable.ic_down_ing);	//正在下载
			this.btnDown.setCricleAndProgressColor(roundColor, roundProgressColor);
			this.btnDown.setProgress(progress);
			
		}else if(124567 == message.what){	//下载完成
			btnDown.setCricleAndProgressColor(transparent, transparent);
			btnDown.setBackgroundResource(R.drawable.ic_down_finish);
			state=FINISH;	//下载完成
			this.onFinish(currentPath);
		}
	}
	
	public void startUpdateProcess(final Handler handler,final String filePath,final int maxlength){
		downThread = true;
		new Thread(){
			@Override
			public void run() {
				try{
					while(downThread){
						File file = new File(filePath);
						if(file.length() < maxlength){
							Message message = new Message();
							message.arg1 = (int)file.length();
							message.obj = "update process";
							message.what = 124568;
							handler.sendMessage(message);
							Thread.sleep(300);
						}else{
							Message message = new Message();
							message.obj = "finish process";
							message.what = 124567;
							handler.sendMessage(message);
							break;
						}
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	/**文件下载完成事件<br>
	 *PS: 如果下载的文件已经存在，但没有插入数据库，则有可能这文件时损坏的，需要重新下载(暂没有断点续传功能)
	 */
	public void onFinish(String filePath){
		try{
			String extend = FileUtils.getFileExtends(filePath);
			//word，ppt，xls，pdf都用wps打开，其他文件弹出文件选择器
			if("doc".equals(extend) || "docx".equals(extend) || "pdf".equals(extend) 
					|| "ppt".equals(extend) || "xlsx".equals(extend) || "xls".equals(extend) || "txt".equals(extend)){
				UIHelper.openWps(context, filePath, Constants.WPS_READ_ONLY);	//只读模式
				
			}else{
				Intent intent = new Intent();
				intent.setAction("android.intent.action.VIEW");
				int pointindex = filePath.lastIndexOf(".");
				intent.setDataAndType(Uri.fromFile(new File(filePath)),BeanUtils.getMimeType(filePath.substring(pointindex)));  
				context.startActivity(Intent.createChooser(intent, "请选择打开文件的程序"));
			}
			downHelper.insert(fileCode, "", filePath, "1");	//完成下载
			
		}catch(Exception e){
			Logger.e("FileDownListener", e.getMessage());
		}
	}
	
	/**取消下载事件*/
	public void onChanel(){
		btnDown.setBackgroundResource(R.drawable.ic_down_start);	//暂停状态
	}
	
	
	public boolean setRequest(String fileName, String fileCdoe, String fileType, String url, String title){
		boolean flag = true;
		try{
			String base = getDownBasePath(fileType);
			if(BeanUtils.isEmpty(base)){
				return false;
			}
			//如果拓展名为空，则从文件名上获得拓展名
			if(BeanUtils.isEmpty(fileType)){
				fileType = "."+FileUtils.getFileExtends(fileName);
			}
			this.filePath = base + (fileCdoe+fileType);	//(文件名称命名：fileCode+fileName)		+File.separator
			this.url = url;
		}catch(Exception e){
			
		}
		return flag;
	}
	
	public boolean setRequest(String fileName, String url){
		return setRequest(fileName, fileCode, url, "", "");
	}
	
	protected void downFiles(String durl,String filePath){
		try{
			
			/*String serviceUrl = "http://gtsoa.powerich.net.cn/demo/handler.ashx?XmlRequest=";
			serviceUrl = serviceUrl + setXmlDatas(fileCode);
			URL url = new URL(serviceUrl);*/
			
			URL url = new URL(durl);
	        URLConnection con = url.openConnection();	// 打开连接    
	        
	        
	        int contentLength = con.getContentLength();
	        
	        long freeSize = UIHelper.getSDFreeSize();
	        if(contentLength>freeSize){
	        	UIHelper.showMessage(context, "SD卡空间已满");
	        	return;
	        }
	        
	        // 输入流    
	        ins = con.getInputStream();   
	        Message message = new Message();
	        message.arg1 = contentLength;
			message.obj = filePath;
			message.what = FILE_MESSAGE_WHAT;
	        handler.sendMessage(message);
	        
	        OutputStream out = null;
			try{
				out =  new FileOutputStream(filePath);
				byte[] buffer = new byte[4096];
				int length = compeleteSize;
				Logger.e("---初始化大小---", compeleteSize+"<-----");
				while ((length = ins.read(buffer)) != -1) {
					out.write(buffer, 0, length);
					compeleteSize += length;
					if(state == PAUSE){
						Logger.e("---暂停后大小---", compeleteSize+"<-----");
						return;
					}
				}
				out.flush();
				out.close();
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				close(ins);
				close(out);
			}
	        
	        //保存文件
//	        saveFile(ins, filePath);
		}catch(Exception e){
			e.printStackTrace();
			handler.sendEmptyMessage(ERROR_CODE_NET);
		}finally{
			try {
				if(ins!=null){
					ins.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/**获取磁盘保存路径*/
	protected String getDownBasePath(String fileType){
		String path = "";
		if(Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())){
			//String extend = FileUtils.getFileExtends(fileName, "txt");
			//文件类型为空。默认
			if (BeanUtils.isEmpty(fileType)) {
				path = Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD;
			}else{
				if (".txt".equals(fileType.toLowerCase())) {
					path = Constants.SDCARD_DIR_TXT_DOWNLOAD;
				} else if (".jpg".equals(fileType.toLowerCase())
						|| ".png".equals(fileType.toLowerCase())
						|| ".gif".equals(fileType.toLowerCase())
						|| ".jpeg".equals(fileType.toLowerCase())) {
					path = Constants.SDCARD_DIR_IMAGE_DOWNLOAD;
				} else {
					path = Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD;
				}
			}
			//path = Environment.getExternalStorageDirectory().getPath()+File.separator+"Android/data/"+context.getPackageName()+"/download/";
		}else{
			handler.sendEmptyMessage(ERROR_CODE_NOSDCARD);
		}
		BeanUtils.checkFileExist(path);
		return path;
	}
	
	/**
	 * 文件保存
	 * @param message
	 */
	protected void saveFile(InputStream inps,String filePath){
		OutputStream out = null;
		try{
			out =  new FileOutputStream(filePath);

			//-------------begin------
			byte[] buffer = new byte[4096];
			int length = -1;
			while ((length = inps.read(buffer)) != -1) {
				out.write(buffer, 0, length);
			}
			
			//老方式
			/*int i = 0;
			while((i = inps.read())!=-1){
				out.write();
			}*/
			
			out.flush();
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			close(inps);
			close(out);
		}
	}
	
	public static void close(Closeable closeable){
		if(closeable!=null){
			try{
				closeable.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public void failDown(){
		try{
			downThread = false;
			//删除文件
			BeanUtils.deleteFile(filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	//设置暂停
	public void pause() {
		downThread = false;
		state = PAUSE;
	}
	
	//重置下载状态
	public void reset() {
		state = INIT;
	}
	
	
	/**
	 * 装载附件下载
	 * @param fileCode
	 * @return
	 */
	private String setXmlDatas(String fileCode){
		StringBuilder xmlDatas = new StringBuilder();
		xmlDatas.append("<Root>");
		xmlDatas.append("<Action>downloadAnnex</Action>");
		xmlDatas.append("<Parameter>");
		xmlDatas.append("<fileCode>").append(fileCode).append("</fileCode>");
		xmlDatas.append("<authToken>").append(SystemContext.getSessionId()).append("</authToken>");
		xmlDatas.append("</Parameter>");
		xmlDatas.append("</Root>");
		
		String XmlRequestValue = DESUtil.enctryXml(xmlDatas.toString());
		return XmlRequestValue;
	}

	public boolean isDownThread() {
		return downThread;
	}

	public void setDownThread(boolean downThread) {
		this.downThread = downThread;
	}
	
	
}
