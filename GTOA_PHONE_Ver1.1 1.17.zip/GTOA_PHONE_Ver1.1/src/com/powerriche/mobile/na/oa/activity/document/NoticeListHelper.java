package com.powerriche.mobile.na.oa.activity.document;
	
import java.util.ArrayList;
import java.util.List;
	
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
	
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.NoticeDetailActivity;
import com.powerriche.mobile.na.oa.activity.NoticeListActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshSwipeMenuListView;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
	
/** 
 * Filename : NoticeListHelper.java
 *  
 * @Description : 数据处理：通知公告
 * @Author : 李运期
 * @Version : 1.0
 * @Date : 2015年5月3日
 */	
public class NoticeListHelper implements onSearchListener {
	
	private PullToRefreshSwipeMenuListView mPullView;
	private SwipeMenuListView listView;
	private TextView tvNoDataMsg;
	
	private List<ResultItem> resultItems = new ArrayList<ResultItem>();
	
	private List<ResultItem> allResultItems = new ArrayList<ResultItem>();
	
	private int doucmentType = 0;
	
	private InvokeHelper helper = null;
	
	private Context mContext = null;
	
	private IRequestCallBack callBack = null;
	
	private ResultSimpleAdapter adapter;
	
	private SearchBarWidget mSearchBarWidget;
	
	private String searchText;
	
	private int pageIndex;
	
	public NoticeListHelper(Context context, View contextView, TextView tvNoDataMsg) {
		this.mContext = context;
		NoticeListActivity acitvity = (NoticeListActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		this.tvNoDataMsg = tvNoDataMsg;
		
		mSearchBarWidget = (SearchBarWidget) contextView.findViewById(R.id.search_bar_widget);
		mSearchBarWidget.setOnSearchListener(this);
		
		mPullView = (PullToRefreshSwipeMenuListView) contextView.findViewById(R.id.pulllistview_tzgg);
		listView = (SwipeMenuListView) mPullView.getRefreshableView();
		
		listView.setOnItemClickListener(new OnItemClickListener() {
			
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long arg3) {
				try {
					// 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
					int resultItemIndex = index;
					if(resultItemIndex == 0 && (R.id.layout_search_bar_top == listView.getChildAt(0).getId())){
						return;//跳过：被单击的是搜索栏
					}else{
						resultItemIndex = resultItemIndex - 1;
					}
					ResultItem item = resultItems.get(resultItemIndex);
					if(item == null){
						return;//空
					}

					String noticeId = item.getString("NOTICE_ID"); // 通知公告的ID
					String noticeType = item.getString("NOTICE_TYPE"); // 通知公告的类型

					if (noticeId == null || noticeType == null) {
						return;
					}

					// 封装交互数据
					Bundle data = new Bundle();
					data.putString("noticeId", BeanUtils.floatToInt4Str(noticeId));
					data.putString("noticeType", BeanUtils.floatToInt4Str(noticeType));

					// 跳转到详情页面
					UIHelper.forwardTargetActivity(mContext,
							NoticeDetailActivity.class, data, false);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void process(HttpResponse response, int what) {
		// resultItems.clear();//清除
		if (pageIndex == 1) {
			resultItems.clear();// 清除
			allResultItems.clear();
		}
		List<ResultItem> items = response.getResultItem(ResultItem.class)
				.getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			// for (ResultItem it : items) {
			// Logger.e(TAG, "通知公告的ID->" + it.getString("NOTICE_ID"));
			// }
			resultItems.addAll(items);
			allResultItems.addAll(items);
		}

		if (adapter == null) {
			int[] txtids = null;
			String[] keys = null;

			// AndroidUI的组件ID
			txtids = new int[]{R.id.list_item_text_field,
					R.id.list_item_text_field1, R.id.list_item_text_field2};
			// 显示的数据项：
			keys = new String[]{"NOTICE_TITLE", "NOTICE_PROMULGATOR",
					"RECIEVE_DATE"};
			adapter = new ResultSimpleAdapter(mContext, resultItems,
					R.layout.notice_list_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						// ResultItem item = resultItems.get(position);
						/**
						 * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
						 */
						if ("RECIEVE_DATE".equals(key) && currentobj != null) {
							DateUtils dateUtils = new DateUtils(mContext);
							return dateUtils.diffFromToNow(DateUtils
									.parseDate(currentobj.toString()));
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int position) {
					// 如果有搜索关键字，高亮显示
					if (!BeanUtils.isEmpty(searchText)) {
						TextView textView = (TextView) convertView
								.findViewById(R.id.list_item_text_field);
						SearchUtils.spannableResultItems(textView,
								(String) textView.getText(), searchText);
					}
				}
			});

			listView.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items) || items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
			
			if(pageIndex==1 && (BeanUtils.isEmpty(items) || items.size()==0)){
				mPullView.setVisibility(View.GONE);
				tvNoDataMsg.setVisibility(View.VISIBLE);
			}else{
				mPullView.setVisibility(View.VISIBLE);
				tvNoDataMsg.setVisibility(View.GONE);
			}
			
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}

	}

	public void loadData(int documentTye, int what, int pageIndex,boolean isDialog) {
		this.pageIndex = pageIndex;
		this.doucmentType = documentTye;

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}

		ApiRequest request = null;
		if (doucmentType == Constants.WHAT_REQUEST_TZGG) {// 通知公告：列表
			request = OAServicesHandler.getNoticeList(pageIndex);
		}

		if (request != null) {
			if (isDialog) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}
	}

	public void deleteData(int documentTye, int what, int position) {
		ResultItem item = resultItems.get(position);
		String noticeId = BeanUtils.floatToInt4Str(item.getString("NOTICE_ID")); // 通知公告的ID
		int noticeType = BeanUtils.floatToInt(item.getString("NOTICE_TYPE")); // 通知公告的类型
		if (!BeanUtils.isEmpty(noticeId)) {
			// 提交请求
			ApiRequest request = OAServicesHandler.deleteNotify(noticeId, noticeType);
			if (request != null) {
				helper.invoke(request, new BaseRequestCallBack() {
					@Override
					public void process(HttpResponse response, int what) {
						// 从ListView移除被删除的列表项
						resultItems.remove(what);
						adapter.notifyDataSetChanged();
					}
				}, position);
			}
		}
	}

	public int getDoucmentType() {
		return doucmentType;
	}

	@Override
	public void onSearchChange(String search) {
		searchText = search;
		resultItems.clear();// 清除
		if (allResultItems != null && allResultItems.size() > 0
				&& !BeanUtils.isEmpty(search)) {
			resultItems.addAll(SearchUtils.filterResults(allResultItems,
					search, "NOTICE_TITLE"));
		} else {
			resultItems.addAll(allResultItems);
		}

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
	}

}
