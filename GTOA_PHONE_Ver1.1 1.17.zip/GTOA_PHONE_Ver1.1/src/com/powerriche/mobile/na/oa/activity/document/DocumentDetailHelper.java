package com.powerriche.mobile.na.oa.activity.document;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.DocManagerInfo;
import com.powerriche.mobile.na.oa.bean.DocumentInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;

/**
 * 类描述：<br> 公文详情
 * 
 * @author Fitz
 * @date 2015年4月29日
 * @version v1.0
 */
public class DocumentDetailHelper {

	private Context				mContext;
	private IRequestCallBack	callBack	= null;
	private InvokeHelper		helper		= null;

	public DocumentDetailHelper(Context context, IRequestCallBack callBack, InvokeHelper helper) {
		this.mContext = context;
		this.callBack = callBack;
		this.helper = helper;
	}

	public void getDocumentDetail(String documentId, String wfNo, int what) {
		ApiRequest request = OAServicesHandler.getDocumentDetail(documentId, wfNo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	
	/**
	 * 加载数据，请求办理环节信息
	 * @param swfNo
	 * @param fpuNo
	 */
	public void loadTranceData(String swfNo, String fpuNo, int what){
        ApiRequest request = OAServicesHandler.getNextFpuAndStaffList(swfNo, fpuNo);
        if (request != null){
            helper.invokeWidthDialog(request, callBack, what);
        }
    }
	
	public Map<String, Object> process(HttpResponse response, int what) {
		Map<String, Object> map = new HashMap<String, Object>();

		ResultItem item = response.getResultItem(ResultItem.class);
		if (!BeanUtils.isEmpty(item)) {
			String code = item.getString("code");
			// 操作成功
			if (Constants.SUCCESS_CODE.equals(code)) {
				processDocInfo(item, map);
			}else{
				Toast.makeText(mContext,item.getString("message"), Toast.LENGTH_SHORT).show();
				((BaseActivity) mContext).finish();
			}
		}else{
			Toast.makeText(mContext,mContext.getString(R.string.document_detail_empty), Toast.LENGTH_SHORT).show();
			((BaseActivity) mContext).finish();
		}
		return map;
	}

	private void processDocInfo(ResultItem item, Map<String, Object> map) {
		ResultItem docItem = item.getItems("data").get(0);

		DocumentInfo docBean = new DocumentInfo();
		String wfNo = docItem.getString("WF_NO"); //流程编号
		String swfNo = docItem.getString("SWF_NO"); //系统流程编号
		String fpuNo = docItem.getString("FPU_NO"); //当前环节
		String docCode = docItem.getString("DOCUMENT_CODE"); //公文编号
		String title = docItem.getString("TITLE"); //标题
		String urgency = docItem.getString("URGENCY_DEGREE"); //缓急1:平件    2：平急    3：急件 4：加急   5：特急    6：特提
		String createDate = docItem.getString("CREATE_DATE"); //创建时间
		String summary = docItem.getString("SUMMARY"); //摘要
		String department = docItem.getString("DRAFT_DEPT");	//拟稿单位
		String userName = docItem.getString("DRAFTER");	//拟稿人
		String level = docItem.getString("IMPORTANCE_DEGREE");	//级别1：公开    2：国内    3：内部 	4：秘密    5：机密    6：绝密
		
		int exChangFlag = docItem.getInt("EXCHANGE_FLAG", 0);
		int isReceiptReplied = docItem.getInt("IS_RECEIPT_REPLIED", 0);
		int isFirstFpu = docItem.getInt("IS_FIRST_FPU", 0);
		int result = docItem.getInt("RESULT", 0);
		int isCallback = docItem.getInt("IS_CALLBACK", 0);
		
		docBean.setWfNo(wfNo);
		docBean.setSwfNo(swfNo);
		docBean.setDocCode(docCode);
		docBean.setTitle(title);
		docBean.setUrgency(BeanUtils.floatToInt4Str(urgency));
		docBean.setCreateDate(createDate);
		docBean.setSummary(summary);
		docBean.setDepartment(department);
		docBean.setLevel(String.valueOf(BeanUtils.floatToInt4Str(level)));
		docBean.setDrafter(userName);
		docBean.setExchangeFlag(exChangFlag);
		docBean.setIsReceiptReplied(isReceiptReplied);
		docBean.setIsFirstFpu(isFirstFpu);
		docBean.setResult(result);
		docBean.setIsCallback(isCallback);
		docBean.setFpuNo(fpuNo == null?"":fpuNo);
		map.put("docBean", docBean);

		processFileList(docItem, map);
		//办理信息封装到data里面去了
		processManager(docItem, map);
	}

	private void processFileList(ResultItem item, Map<String, Object> map) {
		List<DocFileInfo> fileList = new ArrayList<DocFileInfo>();
		//获取附件数据
		List<ResultItem> fileItems = item.getItems("File"); //文件列表
		if (fileItems != null && fileItems.size() > 0) {
			for (ResultItem fileItem : fileItems) {
				String fileCode = fileItem.getString("FK_FILE_CODE"); //文件编号
				String fileLog = fileItem.getString("FILE_CATALOG");
				String fileName = fileItem.getString("FILE_NAME"); //文件名称
				String fileType = fileItem.getString("FILE_TYPE"); //文件类型
				String filePath = fileItem.getString("FILE_PATH"); //文件路径
				String fileTitle = fileItem.getString("FILE_TITLE");//文件标题
				
//				long fileSize = fileItem.getLong("FILE_SIZE", -1);//文件大小
				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(fileItem.getString("FILE_SIZE"));//文件大小
				if(!BeanUtils.isEmpty(fileSizeStr)){
					fileSize = Integer.parseInt(fileSizeStr);
				}
				
				int logInt = BeanUtils.floatToInt(fileLog);
				DocFileInfo fileBean = new DocFileInfo(fileCode, fileType, fileName, logInt, fileSize);
				fileBean.setFileTitle(fileTitle);
				fileBean.setFilePath(filePath);
				fileList.add(fileBean);
			}
		}

		map.put("fileList", fileList);
	}

	private void processManager(ResultItem item, Map<String, Object> map) {
		List<DocManagerInfo> managerList = new ArrayList<DocManagerInfo>();
		//办理信息
		List<ResultItem> processItems = item.getItems("PROCESSDATA");
		if (processItems != null && processItems.size() > 0) {
			for (ResultItem processItem : processItems) {
				String processor = processItem.getString("PROCESSOR"); //办理人
				String department = processItem.getString("PROCESSOR_DEPT_NAME"); //办理人所在部门
				String datatime = processItem.getString("SAVE_DATE"); //办理时间
				String suggest = processItem.getString("DATA"); //办理意见

				DocManagerInfo bean = new DocManagerInfo(processor, department, datatime, suggest);
				managerList.add(bean);
			}
		}

		map.put("managerList", managerList);
	}
	
	
	public void downloadAnnex(String fileCode) {
		ApiRequest request = OAServicesHandler.downloadAnnex(fileCode);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, 62402);
		}
	}
	
	
	/**
	 * 上传正文
	 * @param documentId
	 * @param swfNo
	 * @param traceNo
	 */
	public void uploadDocFile(String documentId, String swfNo, String traceNo, File file, int what, Handler handler){
		UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadDocFile", documentId, swfNo, traceNo, what);
		List<File> files = new ArrayList<File>();
		files.add(file);
		params.setListFile(files);
		
		HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
		post.execute(params);
		
		/*ApiRequest request = OAServicesHandler.uploadDocFile(documentId, swfNo, traceNo, file);
		if (request != null){
			request.setMessage(mContext.getString(R.string.system_upload_file));
			helper.invokeWidthDialog(request, callBack, what);
		}*/
	}

}
