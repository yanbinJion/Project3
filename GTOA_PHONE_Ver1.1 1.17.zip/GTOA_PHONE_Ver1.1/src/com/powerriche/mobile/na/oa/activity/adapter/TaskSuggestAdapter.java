package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.TaskDetails;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 16-6-15.
 */
public class TaskSuggestAdapter extends BaseAdapter{

    private Context mContext;
    private ArrayList<TaskDetails.Suggest> data = new ArrayList<TaskDetails.Suggest>();

    public TaskSuggestAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        TaskDetails.Suggest suggest = data.get(i);
        ViewHolder holder = null;
        if (null == view) {
            holder = new ViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.task_detail_suggest_item, null);
            holder.processorTxt = (TextView) view.findViewById(R.id.task_suggest_processor_txt);
            holder.actionTxt = (TextView) view.findViewById(R.id.task_suggest_message_txt);
            holder.timeTxt = (TextView) view.findViewById(R.id.task_suggest_time_txt);
            holder.remarkTxt = (TextView) view.findViewById(R.id.task_suggest_remark_txt);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.processorTxt.setText(suggest.getProcessor());
        holder.actionTxt.setText(suggest.getAction());
        holder.timeTxt.setText(suggest.getBeginTime());
        holder.remarkTxt.setText(suggest.getRemark());
        return view;
    }

    class ViewHolder {
        public TextView processorTxt;
        public TextView actionTxt;
        public TextView timeTxt;
        public TextView remarkTxt;
    }

    /**
     * 添加数据
     */
    public void addData(List<TaskDetails.Suggest> dataList){
        if (null != dataList) {
            this.data.addAll(dataList);
        }
    }

    public void clearListData(){
        if(data!=null){
            data.clear();
        }
    }
}
