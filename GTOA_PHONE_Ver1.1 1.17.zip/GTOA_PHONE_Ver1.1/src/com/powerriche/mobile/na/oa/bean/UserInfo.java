package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * 类描述：<br> 
 * 组织成员实体描述类
 * @author  Fitz
 * @date    2015年4月22日
 * @version v1.0
 */
public class UserInfo implements Serializable{

	private static final long serialVersionUID = 1L;

	public UserInfo(){}

	public UserInfo(String staffNo, String realName){
		this.staffNo = staffNo;
		this.realName = realName;
	}

	public UserInfo(String staffNo, String realName, String mobile){
		this.staffNo = staffNo;
		this.realName = realName;
		this.mobile = mobile;
	}
	
	
	private String staffNo;		//用户ID
	private String realName;	//真实姓名
	private String sex;			//性别
	private String siteName;	//科室姓名(部门名称)
	private String position;	//职务
	private String phone;		//办公电话
	private String mobile;		//手机号码
	private String siteNo;		//部门编号
	private String uapStaffNo;
	
	
	private int status;	//选中状态 0未选择，1选中
	
	private int currPosition;	//位置
	
	public String getStaffNo() {
		return staffNo;
	}
	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	/**
	 * 0未选中，1选中
	 * @param status
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * 0未选中，1选中
	 * @param status
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	public int getCurrPosition() {
		return currPosition;
	}

	public void setCurrPosition(int currPosition) {
		this.currPosition = currPosition;
	}

	public String getUapStaffNo() {
		return uapStaffNo;
	}

	public void setUapStaffNo(String uapStaffNo) {
		this.uapStaffNo = uapStaffNo;
	}
	
}
