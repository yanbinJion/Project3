package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.ExecutiveMeetListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * Filename : ExecutiveMeetingActivity
 * 
 * @Description : 常务会议
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-05-5 09:38:24
 */
public class ExecutiveMeetingActivity extends BaseActivity implements OnClickListener{

	private ExecutiveMeetListHelper execMeetListHelper;

	private View systemView;

	public final static int EXECMEET_LIST = 1234;
	public final static int EXECMEET_DETAIL = 1235;
	/** 退出标识 */
	public final static int WHAT_PAGE_EXIT = 3460;

	private PullToRefreshListView mPullView;
	private ListView mListView;
	private TextView tvNoDataMsg;

	private Handler indexHandler;

	public int pageIndex = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		
		setContentView(R.layout.execmeet_list_layout);
		
		bindView();

		execMeetListHelper = new ExecutiveMeetListHelper(ExecutiveMeetingActivity.this, systemView, tvNoDataMsg);
		//加载第一页的列表数据
		execMeetListHelper.loadData(EXECMEET_LIST, pageIndex,true);

	}

	private void bindView() {
		TopActivity topActivity = (TopActivity) this.findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.execmeet_title));
		topActivity.setRightBtnVisibility(View.INVISIBLE);

		systemView = this.findViewById(R.id.layout_execmeet);

		mPullView = (PullToRefreshListView) this
				.findViewById(R.id.pull_listview);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);

		mListView = mPullView.getRefreshableView();
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		
		//添加“公共搜索框”：可以跟随列表数据一起滚动
		View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
		mListView.addHeaderView(header);

		mPullView.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 下拉加载数据
				pageIndex = 1;
				execMeetListHelper.loadData(EXECMEET_LIST, pageIndex,false);
			}

			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				execMeetListHelper.loadData(EXECMEET_LIST, pageIndex,false);
			}
		});
		
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);

	}

	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.system_back:// 返回
			finish();
			break;
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == EXECMEET_LIST) {
					execMeetListHelper.process(response, what);
				}
			}
		}

		@Override
		public void finish(Object dialogObj, int what) {
			super.finish(dialogObj, what);
			if (what == 1236 || what == 1237) {

			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	public Handler getIndexHandler() {
		return indexHandler;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

}
