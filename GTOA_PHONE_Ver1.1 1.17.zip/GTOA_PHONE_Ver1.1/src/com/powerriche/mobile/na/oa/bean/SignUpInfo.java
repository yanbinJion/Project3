package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br>
 * 报名信息
 * 
 * @author Fitz
 * @date 2015年5月10日
 * @version v1.0
 */
public class SignUpInfo {

	public SignUpInfo() {
	}

	public SignUpInfo(String bizId, String signUpId, String conventioner,
			String conventionerRole, String contactTel, String summary) {
		this.signUpId = signUpId;
		this.conventioner = conventioner;
		this.conventionerRole = conventionerRole;
		this.contactTel = contactTel;
		this.summary = summary;
	}

	// 会议id
	private String bizId = "";

	/** 报名信息Id */
	private String signUpId = "";

	/** 参会人 */
	private String conventioner = "";

	/** 参会人职务 */
	private String conventionerRole = "";

	/** 联系人电话 */
	private String contactTel = "";

	/** 备注 */
	private String summary = "";

	/** 流程编号 */
	private String wfNo = "";

	/** 流程编号 */
	private String traceNo = "";

	private int position; // 位置变化，永远删除功能

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getBizId() {
		return bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}

	public String getSignUpId() {
		return signUpId;
	}

	public void setSignUpId(String signUpId) {
		this.signUpId = signUpId;
	}

	public String getConventioner() {
		return conventioner;
	}

	public void setConventioner(String conventioner) {
		this.conventioner = conventioner;
	}

	public String getConventionerRole() {
		return conventionerRole;
	}

	public void setConventionerRole(String conventionerRole) {
		this.conventionerRole = conventionerRole;
	}

	public String getContactTel() {
		return contactTel;
	}

	public void setContactTel(String contactTel) {
		this.contactTel = contactTel;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getWfNo() {
		return wfNo;
	}

	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}

	public String getTraceNo() {
		return traceNo;
	}

	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}

}
