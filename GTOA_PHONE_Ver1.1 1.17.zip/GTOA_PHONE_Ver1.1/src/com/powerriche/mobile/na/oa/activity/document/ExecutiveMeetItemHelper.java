package com.powerriche.mobile.na.oa.activity.document;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.ExecutiveMeetingDetailActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : ExecutiveMeetItemHelper.java
 * 
 * @Description : 常务会议详情
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-24 09:38:24
 */
public class ExecutiveMeetItemHelper implements OnClickListener {

	/** 会议id */
	private String meetingId;

	/** 常务会议标题 */
	private TextView meetingTitle;

	/** 主持人 */
	private TextView presider;

	/** 会议地址 */
	private TextView meetingAddr;

	/** 开始时间 */
	private TextView meetingTime;

	private TextView tvTopicGroup;

	private LinearLayout llTopicWrap;

	private LinearLayout llFileWrap;

	private InvokeHelper helper = null;

	private Context context = null;

	private View contextView = null;

	private IRequestCallBack callBack = null;

	// private Handler handler;

	public ExecutiveMeetItemHelper(Context context, View contextView) {
		this.context = context;
		this.contextView = contextView;
		ExecutiveMeetingDetailActivity acitvity = (ExecutiveMeetingDetailActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		bindViews();
		// this.handler = acitvity.getIndexHandler();
	}

	private void bindViews() {
		// 常务会议标题
		meetingTitle = (TextView) contextView
				.findViewById(R.id.tv_meeting_title);
		// 开始时间
		meetingTime = (TextView) contextView.findViewById(R.id.tv_meeting_time);
		// 主持人
		presider = (TextView) contextView.findViewById(R.id.tv_meet_presider);
		// 会议地址
		meetingAddr = (TextView) contextView.findViewById(R.id.tv_meet_addr);

		// 会议议题
		tvTopicGroup = (TextView) contextView.findViewById(R.id.tv_topic_list);
		tvTopicGroup.setOnClickListener(this);
		tvTopicGroup.setTag(true);
		tvTopicGroup.setVisibility(View.GONE);
		llTopicWrap = (LinearLayout) contextView
				.findViewById(R.id.ll_topic_list);
		llTopicWrap.setVisibility(View.GONE);
	}

	public void loadItem(String id, int what) {
		this.meetingId = id;
		// 清空数据
		// 常务会议标题
		meetingTitle.setText(context.getString(R.string.execmeet_datail_title));

		// 开始时间
		meetingTime.setText(context.getString(R.string.execmeet_time));

		// 主持人
		presider.setText(context.getString(R.string.execmeet_presider));

		// 会议地址
		meetingAddr.setText(context.getString(R.string.execmeet_addr));

		helper.invokeWidthDialog(
				OAServicesHandler.getExecMeetDetail(meetingId), callBack, what);
	}

	public void process(HttpResponse response, int what) {
		try {
			List<ResultItem> items = response.getResultItem(ResultItem.class)
					.getItems("data");
			if (!BeanUtils.isEmpty(items)) {
				ResultItem item = items.get(0);
				// 常务会议标题
				String title = item.getString("MEETING_TITLE");
				meetingTitle.setText(title);

				// 开始时间
				String time = item.getString("BEGIN_TIME");
				meetingTime.setText(time);

				// 主持人
				String meetPresider = item.getString("PRESIDER");
				presider.setText(meetPresider);

				// 会议地址
				String addr = item.getString("MEETING_ADDR");
				meetingAddr.setText(addr);

				// 议题列表
				topicList(item);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***
	 * 议题列表的数据
	 * 
	 * @param item
	 */
	private void topicList(ResultItem item) {
		// 办理信息
		List<ResultItem> processItems = item.getItems("topicinfo");
		if (processItems != null && processItems.size() > 0) {
			for (ResultItem processItem : processItems) {
				String topicName = processItem.getString("TOPIC_NAME"); // 议题标题
				ViewHolder holder = new ViewHolder();

				View view = LayoutInflater.from(context).inflate(
						R.layout.leave_approval_item, null);
				llFileWrap = (LinearLayout) view
						.findViewById(R.id.ll_file_list);
				llFileWrap.setVisibility(View.GONE);

				holder.tvTopicTime = (TextView) view
						.findViewById(R.id.tv_topic_title);
				holder.tvTopicTime.setText(topicName);
				llTopicWrap.addView(view);
				List<ResultItem> fileItems = item.getItems("attachment"); // 文件列表
				foreachFiles(fileItems);
			}
			llTopicWrap.setVisibility(View.VISIBLE);
			tvTopicGroup.setVisibility(View.VISIBLE);
		}
	}

	/***
	 * 附件
	 * 
	 * @param item
	 */
	private void foreachFiles(List<ResultItem> fileItems) {
		if (fileItems == null || fileItems.size() == 0) {
			return;
		}
		for (ResultItem fileItem : fileItems) {
			ViewHolderFile holder = new ViewHolderFile();

			View view = LayoutInflater.from(context).inflate(
					R.layout.govaffair_file_item, null);
			holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
			holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
			holder.rlWrap = (RelativeLayout) view
					.findViewById(R.id.rl_item_wrap);

			holder.tvFileName.setText(fileItem.getString("FILE_NAME"));
			holder.rlWrap.setTag(fileItem.getString("FILE_CODE"));
			holder.rlWrap.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					// Toast.makeText(context, "暂未实现",
					// Toast.LENGTH_SHORT).show();
				}
			});

			llFileWrap.addView(view);
		}
		llFileWrap.setVisibility(View.VISIBLE);
	}

	private class ViewHolderFile {
		TextView tvFileName;
		ImageView ivType;
		RelativeLayout rlWrap;
	}

	private class ViewHolder {
		TextView tvTopicTime;
	}

	@Override
	public void onClick(View v) {

		if (v.getId() == R.id.system_back) {
			// finish();
		} else if (v.getId() == R.id.tv_topic_list) {
			isTopicGroup();
		}
	}

	public void isTopicGroup() {
		// 初始化时展开的
		boolean flag = (Boolean) tvTopicGroup.getTag();
		if (flag) {
			tvTopicGroup.setTag(false); // 关闭
			tvTopicGroup.setCompoundDrawables(null, null,
					UIHelper.openDrawable(context, R.drawable.ic_arrows_open), null);
			llTopicWrap.setVisibility(View.GONE);
		} else {
			tvTopicGroup.setTag(true);
			tvTopicGroup.setCompoundDrawables(null, null,
					UIHelper.closeDrawable(context, R.drawable.ic_arrows_close), null);
			llTopicWrap.setVisibility(View.VISIBLE);
		}
	}

	public String getMeetingId() {
		return meetingId;
	}

	public void setMeetingId(String meetingId) {
		this.meetingId = meetingId;
	}

}
