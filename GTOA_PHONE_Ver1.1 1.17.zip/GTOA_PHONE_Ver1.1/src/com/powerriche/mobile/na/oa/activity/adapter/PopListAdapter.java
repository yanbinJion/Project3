package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.AddTaskActivity;

import java.util.ArrayList;

/**
 * Created by root on 16-5-17.
 */
public class PopListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<PopContent> content;
    private Drawable mDrawable;

    public PopListAdapter(Context context, boolean editable, int length) {
        this.context = context;
        content = new ArrayList<PopContent>();
        String[] txt = null;
        int[] res = null;
        Class[] clss = null;
        if (editable) {
            txt = new String[]{context.getString(R.string.notice_right_edit), context.getString(R.string.task_pop_item_process),
                    context.getString(R.string.task_pop_item_dispatcher)};
            res = new int[]{R.drawable.system_icon_save, R.drawable.system_icon_handle, R.drawable.system_icon_assign};
            clss = new Class[] {AddTaskActivity.class, AddTaskActivity.class, AddTaskActivity.class};
        } else {
            txt = new String[]{context.getString(R.string.task_pop_item_upload), context.getString(R.string.task_pop_item_process)};
            res = new int[]{R.drawable.system_icon_report, R.drawable.system_icon_assign};
            clss = new Class[] {AddTaskActivity.class, AddTaskActivity.class};
        }
        if (length <= 0) {
            length = txt.length;
        }
        for (int i = 0; i < length; i++) {
            PopContent pop = new PopContent();
            pop.setImg(res[i]);
            pop.setTxt(txt[i]);
            content.add(pop);
        }
    }

    @Override
    public int getCount() {
        return content.size();
    }

    @Override
    public Object getItem(int i) {
        return content.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        PopContent pop = content.get(i);
        ViewHolder holder = null;
        if (null == view) {
//            view = LayoutInflater.from(context).inflate(R.layout.task_pop_list_item, null);
//            holder = new ViewHolder();
//            holder.txt = (TextView) view.findViewById(R.id.task_pop_txt);
//            AbsListView.LayoutParams lp = new AbsListView.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            view = new RelativeLayout(context);
            view.setPadding(20, 10, 0, 10);
            TextView txt = new TextView(context);
            txt.setCompoundDrawablePadding(10);
            txt.setGravity(Gravity.CENTER_VERTICAL);
            txt.setTextColor(context.getResources().getColor(R.color.black));
//            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            //            btnRight.setLayoutParams(lp);
//            tp.gravity = Gravity.CENTER;
            RelativeLayout.LayoutParams tp = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT, 70);
//            tp.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
            ((RelativeLayout) view).addView(txt, tp);
            holder = new ViewHolder();
            holder.txt = txt;
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        mDrawable = context.getResources().getDrawable(pop.getImg());
        mDrawable.setBounds(0, 0, mDrawable.getMinimumWidth(), mDrawable.getMinimumHeight());
        holder.txt.setText(pop.getTxt());
        holder.txt.setCompoundDrawables(mDrawable, null, null, null);
        return view;
    }

    class ViewHolder {
        public ImageView img;
        public TextView txt;
    }

    public class PopContent {
        private int img;
        private String txt;

        public int getImg() {
            return img;
        }

        public void setImg(int img) {
            this.img = img;
        }

        public String getTxt() {
            return txt;
        }

        public void setTxt(String txt) {
            this.txt = txt;
        }
    }
}
