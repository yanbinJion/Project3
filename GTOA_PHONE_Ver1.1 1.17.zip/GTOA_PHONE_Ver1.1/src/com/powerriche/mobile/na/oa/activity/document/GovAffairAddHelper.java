package com.powerriche.mobile.na.oa.activity.document;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.GovAffairAddActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.GovAffairInfo;
import com.powerriche.mobile.oa.api.ApiRequest;

/**
 * 类描述：<br> 
 * 新建领导政务
 * @author  Fitz
 * @date    2015年4月28日
 * @version v1.0
 */
public class GovAffairAddHelper {

	private Context context;
	
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;
	
	public GovAffairAddHelper(Context context, IRequestCallBack callBack){
		this.context = context;
		this.callBack = callBack;
		this.helper = ((GovAffairAddActivity) this.context).getInvokeHelper();
	}
	
	/**
	 * 保存公文
	 * @param bean
	 * @param what
	 */
	
	public void saveData(GovAffairInfo bean,int what){
		ApiRequest request = OAServicesHandler.editGovAffair(bean);
	    if (request != null){
	    	request.setMessage(context.getString(R.string.system_commit_message));
	    	helper.invokeWidthDialog(request, callBack, what);
	    }
	}

	/** 附件上传 */
	public void uploadFile(String documentId, String swfNo, LinearLayout llFileWrap, int what){
		if(llFileWrap!=null){
			int fileCount = llFileWrap.getChildCount();
			if(fileCount>0){
				List<File> files = new ArrayList<File>();
				for(int i=0; i<fileCount; i++){
					View view = llFileWrap.getChildAt(i);
					TextView tv = (TextView) view.findViewById(R.id.tv_file_name);
					String path = (String) tv.getTag();
					
					File file = new File(path);
					if(file!=null && file.exists()){
						files.add(file);
					}
				}
				ApiRequest request = OAServicesHandler.uploadFile(documentId, swfNo, "", files);
				if (request != null){
					request.setMessage(context.getString(R.string.system_upload_file));
					helper.invokeWidthDialog(request, callBack, what);
				}
				
			}
		}
	}
	
	
}
