package com.powerriche.mobile.na.oa.activity;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.oa.tools.BeanUtils;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class AlarmAlert extends Activity {

	private Vibrator vibrator;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d("AlarmAlert", "onCreate");
		ring();
		quake();
		final SystemDialog chooseDialog = new SystemDialog(
				AlarmAlert.this);
		View line = chooseDialog.findViewById(R.id.line);
		Button btn_cancel = (Button) chooseDialog.findViewById(R.id.btn_cancel);
		line.setVisibility(View.GONE);
		btn_cancel.setVisibility(View.GONE);
		BeanUtils.setAlarm(this);
		chooseDialog.setMessage("亲，记得打卡哦！");
		chooseDialog.setOnConfirmClickListener(new View.OnClickListener() { // 确定按钮事件
					@Override
					public void onClick(View view) {
						chooseDialog.dismiss();
					}
				});
		chooseDialog.show();
	}
	
	/**
	 * 调用系统铃声
	 */
	private void ring() {
		MediaPlayer mp = new MediaPlayer();
		try {
			mp.setDataSource(this, RingtoneManager
					.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
			mp.prepare();
			mp.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 调用系统震动声
	 * 想设置震动大小可以通过改变pattern来设定，如果开启时间太短，震动效果可能感觉不到
	 */
	private void quake() {
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		long[] pattern = { 100, 400, 100, 400 }; // 停止 开启 停止 开启
		vibrator.vibrate(pattern, -1);         //重复两次上面的pattern 如果只想震动一次，index设为-1   
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		if(vibrator != null) {
			vibrator.cancel();
		}
	}

}
