package com.powerriche.mobile.na.oa.bean;

import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;

/**
 * 请假对象
 * 
 * @author 高明峰
 *
 */
public class UserLeaveInfo {

	/** 请假业务编号 */
	public String leaveBizNo;

	/** 操作类型 （1添加(保存) 2：修改 */
	public String operateType;

	/** 请假类别（0请假，1调休） */
	public String leaveCatalog;

	/** 请假类型（0：年休假，1探亲假，2：婚假，3产假，4：丧假，5：病假，6：事假 */
	public String leaveType;

	/** 请假开始时间 */
	public String beginTime;

	/** 请假结束时间 */
	public String endTime;

	/** 请假理由 */
	public String leaveReason;
	
	/** 请假天数 */
	public String leaveTotalDays;
	
	/** 审核状态 （1：同意  2：不同意）*/
	public String passState;
	
	/** 跟踪编号*/
	public String traceNo;

	public String getLeaveBizNo() {
		return leaveBizNo;
	}

	public void setLeaveBizNo(String leaveBizNo) {
		this.leaveBizNo = leaveBizNo;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}

	public String getLeaveCatalog() {
		return leaveCatalog;
	}

	public void setLeaveCatalog(String leaveCatalog) {
		this.leaveCatalog = leaveCatalog;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getLeaveReason() {
		return leaveReason;
	}

	public void setLeaveReason(String leaveReason) {
		this.leaveReason = leaveReason;
	}

	public String getLeaveTotalDays() {
		return leaveTotalDays;
	}
	
	public String getTotalDays() {
		if(!BeanUtils.isEmpty(beginTime) && !BeanUtils.isEmpty(endTime)){
			String format ="yyyy-MM-dd HH:mm";
			return DateUtils.daysBetween(DateUtils.parseDate(beginTime, format), DateUtils.parseDate(endTime, format));
		}else{
			return "0";
		}
	}

	public void setLeaveTotalDays(String leaveTotalDays) {
		this.leaveTotalDays = leaveTotalDays;
	}

	public String getPassState() {
		return passState;
	}

	public void setPassState(String passState) {
		this.passState = passState;
	}

	public String getTraceNo() {
		return traceNo;
	}

	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}
	
	
	
}
