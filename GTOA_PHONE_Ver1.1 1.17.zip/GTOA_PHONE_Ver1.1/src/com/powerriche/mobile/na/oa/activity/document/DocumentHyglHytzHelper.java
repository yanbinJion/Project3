package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.DocumentDetailActivity;
import com.powerriche.mobile.na.oa.activity.MainActivity;
import com.powerriche.mobile.na.oa.activity.MeetDetailActivity;
import com.powerriche.mobile.na.oa.activity.TabMeetActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : DocumentGwglListHelper.java
 * 
 * @Description : 数据处理：会议管理-会议通知
 * @Author : 李运期
 * @Version : 1.0
 * @Date : 2015年6月2日
 */
public class DocumentHyglHytzHelper implements onSearchListener {


	private PullToRefreshListView mPullView;
	private ListView mListView;
	private TextView tvNoDataMsg;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();
	private List<ResultItem> allResultItems = new ArrayList<ResultItem>();


	private Context mContext = null;
	
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;

	private ResultSimpleAdapter adapter;
	private SearchBarWidget mSearchBarWidget;

	private int doucmentType = 0;
	
	private String searchText;
	private int pageIndex;

	/**
	 * 点击某个待办或者待阅item时，记下这个item索引号，并作出以下处理：
	 * 1、如果当前界面是待阅界面，调用标志已阅接口，将文档的待阅状态转成已阅状态。
	 * 2、传递相应参数，进入公文详情界面
	 * 当从公文详情界面再返回到当前界面时，作出以下处理：
	 * 1、如果当前界面是待阅界面，将其从ListView列表中移除（因为已阅了）。
	 * 2、如果当前界面是待办界面，并且在办理界面那里办理成功(dealwithFlag==1)，也将其从ListView列表中移除（因为已办了）。
	 * 3、如果当前界面是待办界面，并且在办理界面那里退件成功(retroversionFlag==1)，也将其从ListView列表中移除（因为退件了）。
	 * 4、如果当前界面是已办界面，并且在办理界面那里撤回成功(retracementFlag==1)，也将其从ListView列表中移除（因为撤回了）。
	 */
	private int prepareRemoveIndex = -1;

	public DocumentHyglHytzHelper(Context context, View contextView, TextView tvNoDataMsg, PullToRefreshListView pullView,
			ListView listView, MainActivity acitvity, IRequestCallBack callback) {
		
		this.mContext = context;
		this.tvNoDataMsg = tvNoDataMsg;
		this.mPullView = pullView;
		this.mListView = listView;

		this.helper = acitvity.getInvokeHelper();
		this.callBack = callback;

		mSearchBarWidget = (SearchBarWidget) contextView.findViewById(R.id.search_bar_widget);
		mSearchBarWidget.setOnSearchListener(this);

		this.mListView = (ListView) mPullView.getRefreshableView();

		this.mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long arg3) {
				try {
					// 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
					int resultItemIndex = index;
					if(resultItemIndex == 0 && (R.id.layout_search_bar_top == mListView.getChildAt(0).getId())){
						return;//跳过：被单击的是搜索栏
					}else{
						resultItemIndex = resultItemIndex - 1;
					}
					
					ResultItem item = resultItems.get(resultItemIndex);
					if(item == null){
						return;//空
					}

					String documentId = item.getString("DOCUMENT_ID"); // 文档编号
					String wfNo = item.getString("WF_NO"); // 流程编号
					String swfNo = item.getString("SWF_NO"); // 系统流程编号
					String fpuNo = item.getString("FPU_NO"); // 当前环节编号
					String traceNo = item.getString("TRACE_NO"); // 当前跟踪编号

					if (BeanUtils.isEmpty(documentId) || BeanUtils.isEmpty(wfNo)) {
						return;
					}
					
					prepareRemoveIndex = resultItemIndex;

					// 封装交互数据：需要去掉服务端返回的多余“.0”
					Bundle data = new Bundle();
					data.putString("documentId", BeanUtils.floatToInt4Str(documentId));//取整
					data.putString("wfNo", BeanUtils.floatToInt4Str(wfNo));//取整
					data.putString("fpuNo", BeanUtils.isEmpty4Get(fpuNo));
					data.putString("swfNo", BeanUtils.isEmpty4Get(swfNo));
					data.putString("traceNo", BeanUtils.floatToInt4Str(traceNo));//取整

					// 会议标识是已办会议，进行判断调转
					if (doucmentType == Constants.OPT_TYPE_HYGL_YBHY) {
						 // 当前已办会议是，主办会议还是会议通知,0主办会议,1是会议通知
						String meetingType = item.getString("MEETING_TYPE");
						if(!BeanUtils.isEmpty(meetingType)){
							int type = BeanUtils.floatToInt(item.getString("MEETING_TYPE"));
							data.putInt("doucmentType", type == Constants.MEETING_TYPE_ZBHY
									? Constants.OPT_TYPE_HYGL_ZBHY
											: Constants.OPT_TYPE_HYGL_HYTZ);
						}else{
							data.putInt("doucmentType", Constants.OPT_TYPE_HYGL_ZBHY);
						}
					} else {
						data.putInt("doucmentType", doucmentType);
					}

					// 跳转到详情页面
					UIHelper.forwardTargetActivity(mContext,
							MeetDetailActivity.class, data, false);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void process(HttpResponse response, int what) {
		// resultItems.clear();//清除
		if (pageIndex == 1) {
			resultItems.clear();// 清除
			allResultItems.clear();
		}
		List<ResultItem> items = response.getResultItem(ResultItem.class)
				.getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			// for (ResultItem it : items) {
			// Logger.e(TAG, "文档ID->" + it.getString("DOCUMENT_ID") + ",流水编号->"
			// + it.getString("WF_NO"));
			// }
			resultItems.addAll(items);
			allResultItems.addAll(items);
			if(items.size() > 0){
                TabMeetActivity.isFirst2 = false;
            }
		}
		if (adapter == null) {
			int[] txtids = null;
			String[] keys = null;

			// AndroidUI的组件ID
			txtids = new int[]{R.id.list_item_text_field,
					R.id.list_item_text_field1, R.id.list_item_text_field2};
			if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {// 会议管理：主办会议
				// 标题、传入人、传入时间
				keys = new String[]{"TITLE", "IN_STAFF", "BEGIN_TIME"};
			} else if (doucmentType == Constants.OPT_TYPE_HYGL_HYTZ) {// 会议管理：会议通知
				// 标题、传入人、传入时间
				keys = new String[]{"TITLE", "IN_STAFF", "BEGIN_TIME"};
			} else if (doucmentType == Constants.OPT_TYPE_HYGL_YBHY) {// 会议管理：已办会议
				// 标题、当前人、传入时间
				keys = new String[]{"TITLE", "START_STAFF_NAME", "BEGIN_TIME"};
			}

			adapter = new ResultSimpleAdapter(mContext, resultItems,
					R.layout.list_item_hygl, keys, txtids);
			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						ResultItem item = resultItems.get(position);
						String systemtime = item.getString("SYSTEM_TIME");// 系统时间

						/**
						 * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
						 */
						if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {// 会议管理：主办会议
							if ("BEGIN_TIME".equals(key) && currentobj != null) {
								DateUtils dateUtils = new DateUtils(mContext);
								return dateUtils.diffFromToNow(DateUtils
										.parseDate(currentobj.toString()),
										systemtime);
							}
						} else if (doucmentType == Constants.OPT_TYPE_HYGL_HYTZ) {// 会议管理：会议通知
							// 如果IN_STAFF为空，则显示SOURCE_ORG_ID字段
							if ("IN_STAFF".equals(key)
									&& (currentobj == null || currentobj
											.toString().trim().length() == 0)) {
								ResultItem item01 = resultItems.get(position);
								String SOURCE_ORG_ID = item01
										.getString("SOURCE_ORG_ID"); // 文档编号
								if (SOURCE_ORG_ID != null) {
									return SOURCE_ORG_ID;
								} else {
									return "";
								}
							}
							if ("BEGIN_TIME".equals(key) && currentobj != null) {
								return DateUtils.diffFromToNow(DateUtils
										.parseDate(currentobj.toString()),
										systemtime);
							}
						} else if (doucmentType == Constants.OPT_TYPE_HYGL_YBHY) {// 会议管理：已办会议
							if ("BEGIN_TIME".equals(key) && currentobj != null) {
								return DateUtils.diffFromToNow(DateUtils
										.parseDate(currentobj.toString()),
										systemtime);
							}
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int position) {
					// 如果有搜索关键字，高亮显示
					if (!BeanUtils.isEmpty(searchText)) {
						TextView textView = (TextView) convertView
								.findViewById(R.id.list_item_text_field);
						SearchUtils.spannableResultItems(textView,
								(String) textView.getText(), searchText);
					}
				}
			});
			mListView.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items)
				|| items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
			
			if(pageIndex==1 && (BeanUtils.isEmpty(items) || items.size()==0)){
				mPullView.setVisibility(View.GONE);
				tvNoDataMsg.setVisibility(View.VISIBLE);
			}else{
				mPullView.setVisibility(View.VISIBLE);
				tvNoDataMsg.setVisibility(View.GONE);
			}
			
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
			mPullView.setVisibility(View.VISIBLE);
			tvNoDataMsg.setVisibility(View.GONE);
		}

	}

	public void loadData(int documentTye, int what, int pageIndex,boolean isDialog) {
		this.pageIndex = pageIndex;
		this.doucmentType = documentTye;

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}

		ApiRequest request = null;
		if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {// 会议管理：主办会议
			request = OAServicesHandler.getSendMeetList(pageIndex);
		} else if (doucmentType == Constants.OPT_TYPE_HYGL_HYTZ) {// 公文管理：会议通知
			request = OAServicesHandler.getReceiveMeetList(pageIndex);
		} else if (doucmentType == Constants.OPT_TYPE_HYGL_YBHY) {// 会议管理：已办会议
			request = OAServicesHandler.getMeetFlowList(pageIndex);
		}

		if (request != null) {
			if (isDialog) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}
	}

	public int getDoucmentType() {
		return doucmentType;
	}

	@Override
	public void onSearchChange(String search) {
		searchText = search;
		resultItems.clear();// 清除
		if (allResultItems != null && allResultItems.size() > 0
				&& !BeanUtils.isEmpty(search)) {
			resultItems.addAll(SearchUtils.filterResults(allResultItems,
					search, "TITLE"));
		} else {
			resultItems.addAll(allResultItems);
		}

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
	}

	/**
	 * 当从公文详情界面返回当前界面时，将已阅项和已办项从待阅列表ListView和待办列表ListView中移除
	 */
	public void doRemoveItemById() {
		if (prepareRemoveIndex >= 0) {
			try {
				//2、如果当前界面是待办界面，并且在办理界面那里办理成功(dealwithFlag==1)，也将其从ListView列表中移除（因为已办了）。
				if ((doucmentType == Constants.OPT_TYPE_HYGL_ZBHY || doucmentType == Constants.OPT_TYPE_HYGL_HYTZ) 
						&& (DocumentDetailActivity.dealwithFlag == 1 || MeetDetailActivity.dealwithFlag == 1)) {// 会议管理：主办会议、会议通知
					if(resultItems != null && prepareRemoveIndex < resultItems.size()){
						resultItems.remove(prepareRemoveIndex);
						if (adapter != null) {
							adapter.notifyDataSetChanged();
						}
					}
				}
				//3、如果当前界面是待办界面，并且在办理界面那里退件成功(retroversionFlag==1)，也将其从ListView列表中移除（因为退件了）。
				if ((doucmentType == Constants.OPT_TYPE_HYGL_ZBHY || doucmentType == Constants.OPT_TYPE_HYGL_HYTZ) 
						&& (DocumentDetailActivity.retroversionFlag == 1 || MeetDetailActivity.retroversionFlag == 1)) {// 会议管理：主办会议、会议通知
					if(resultItems != null && prepareRemoveIndex < resultItems.size()){
						resultItems.remove(prepareRemoveIndex);
						if (adapter != null) {
							adapter.notifyDataSetChanged();
						}
					}
				}
				//4、如果当前界面是已办界面，并且在办理界面那里撤回成功(retracementFlag==1)，也将其从ListView列表中移除（因为撤回了）。
				if (doucmentType == Constants.OPT_TYPE_HYGL_YBHY 
						&& (DocumentDetailActivity.retracementFlag == 1 || MeetDetailActivity.retracementFlag == 1)) {// 会议管理：已办会议
					if(resultItems != null && prepareRemoveIndex < resultItems.size()){
						resultItems.remove(prepareRemoveIndex);
						if (adapter != null) {
							adapter.notifyDataSetChanged();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			DocumentDetailActivity.dealwithFlag = 0;//恢复
			DocumentDetailActivity.retroversionFlag = 0;//恢复
			DocumentDetailActivity.retracementFlag = 0;//恢复
			MeetDetailActivity.dealwithFlag = 0;//恢复
			MeetDetailActivity.retroversionFlag = 0;//恢复
			MeetDetailActivity.retracementFlag = 0;//恢复
			prepareRemoveIndex = -1;//恢复
		}
	}

}
