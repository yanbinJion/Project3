package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.AppLeaveActivity;
import com.powerriche.mobile.na.oa.activity.CommonSearchResultActivity;
import com.powerriche.mobile.na.oa.activity.DocumentDetailActivity;
import com.powerriche.mobile.na.oa.activity.LeaveDetailActivity;
import com.powerriche.mobile.na.oa.activity.MeetDetailActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : CommonSearchListHelper.java
 * 
 * @Description : 数据处理：综合查询
 * @Author : 李运期
 * @Version : 1.0
 * @Date : 2015年5月3日
 */
public class CommonSearchListHelper implements onSearchListener {

	private PullToRefreshListView mPullView;
	private ListView listView;
	private TextView tvNoDataMsg;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();

	private InvokeHelper helper = null;

	private Context mContext = null;

	private IRequestCallBack callBack = null;
	private ResultSimpleAdapter adapter;
	
	private int pageIndex;

	public CommonSearchListHelper(Context context, View contextView, TextView tvNoDataMsg) {
		this.mContext = context;
		CommonSearchResultActivity acitvity = (CommonSearchResultActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		this.tvNoDataMsg = tvNoDataMsg;

		mPullView = (PullToRefreshListView) contextView.findViewById(R.id.pulllistview_zhcxzg);
		listView = (ListView) mPullView.getRefreshableView();

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long arg3) {
				try {
					ResultItem item = resultItems.get(index);
					if(item == null){
						return;//空
					}

					String documentId = item.getString("DOCUMENT_ID"); // 文档编号
					String wfNo = item.getString("WF_NO"); // 流程编号
					String passreadId = item.getString("PASSREAD_ID"); // 待阅：传阅编号
					String swfNo = item.getString("SWF_NO"); // 系统流程编号
					String fpuNo = item.getString("FPU_NO"); // 当前环节编号
					String traceNo = item.getString("TRACE_NO"); // 当前跟踪编号
					String tempDocType = BeanUtils.isEmpty4Get(item.getString("DOCUMENT_TYPE")); // 文档类型

					if (BeanUtils.isEmpty(documentId) || BeanUtils.isEmpty(wfNo)) {
						return;
					}

					// 调用接口：标志已阅，将待阅状态改变为已阅状态
					if ("1".equals(((CommonSearchResultActivity)mContext).searchType) 
							&& "1".equals(((CommonSearchResultActivity)mContext).searchState) 
							&& !BeanUtils.isEmpty(passreadId)) {// 待阅
						ApiRequest request = OAServicesHandler.markPassreadState(passreadId);
						if (request != null) {
							new InvokeHelper(mContext).invoke(request, null, 12345);
						}
					}

					// 封装交互数据：需要去掉服务端返回的多余“.0”
					Bundle data = new Bundle();
					data.putString("documentId", BeanUtils.floatToInt4Str(documentId));//取整
					data.putString("wfNo", BeanUtils.floatToInt4Str(wfNo));//取整
					data.putString("passreadId", BeanUtils.floatToInt4Str(passreadId));//取整
					data.putString("fpuNo", BeanUtils.isEmpty4Get(fpuNo));
					data.putString("swfNo", BeanUtils.isEmpty4Get(swfNo));
					data.putString("traceNo", BeanUtils.floatToInt4Str(traceNo));//取整
					if ("1".equals(((CommonSearchResultActivity)mContext).searchType)) {// 阅件
						data.putInt("IS_PASS_READ", 1000);	//标识传阅进来的入口
					}

					// 如果是请假审批的，调转到审批页面
					if ("2014072509353877".equals(swfNo)) {// 业务类型：请假
						//UIHelper.forwardTargetActivity(mContext,
						//	AskleaveApprovalActivity.class, data, false);
						//查询请假详情
//						Constants.DOCUMENT_ID = documentId;
//						Constants.TRACE_NO = swfNo;
//						helper.invokeWidthDialog(OAServicesHandler.getAskLeaveDetail(BeanUtils.floatToInt4Str(documentId)), callBack, Constants.OPT_TYPE_LEAVE_DETAIL);
						UIHelper.forwardTargetActivity(mContext, LeaveDetailActivity.class, data, false);

					} else if("2006122705014455".equals(swfNo)){//主办会议
						data.putInt("doucmentType", Constants.OPT_TYPE_HYGL_ZBHY);
						// 跳转到界面：主办会议详情
						UIHelper.forwardTargetActivity(mContext, MeetDetailActivity.class, data, false);

					} else if(Constants.LW_CODE.equals(swfNo) 
							&& ("HY".equals(tempDocType) || "CWHY".equals(tempDocType))){//会议通知
						// 注意：当是来文时(swfNo=2006083005302033)，并且(DOCUMENT_TYPE=’HY’ or DOCUMENT_TYPE=’CWHY’)，代表接收到的会议通知
						data.putInt("doucmentType", Constants.OPT_TYPE_HYGL_HYTZ);
						// 跳转到界面：会议通知详情
						UIHelper.forwardTargetActivity(mContext, MeetDetailActivity.class, data, false);
						
					} else{
						// 跳转到界面：公文详情
						UIHelper.forwardTargetActivity(mContext, DocumentDetailActivity.class, data, false);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void process(HttpResponse response, int what) {
		// resultItems.clear();//清除
		List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			// for (ResultItem it : items) {
			// Logger.e(TAG, "文档ID->" + it.getString("DOCUMENT_ID") + ",流水编号->"
			// + it.getString("WF_NO"));
			// }
			resultItems.addAll(items);
		}

		if (adapter == null) {
			int[] txtids = null;
			String[] keys = null;

			// AndroidUI的组件ID
			txtids = new int[]{R.id.list_item_text_field,
					R.id.list_item_text_field1, R.id.list_item_text_field2};
			// 显示的数据项：
			keys = new String[]{"TITLE", "STAFF_NAME", "TIME"};
			adapter = new ResultSimpleAdapter(mContext, resultItems,
					R.layout.common_search_result_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						ResultItem item = resultItems.get(position);
						String systemtime = item.getString("SYSTEM_TIME");// 系统时间

						/**
						 * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
						 */
						if ("TIME".equals(key) && currentobj != null) {
							DateUtils dateUtils = new DateUtils(mContext);
							return dateUtils.diffFromToNow(
									DateUtils.parseDate(currentobj.toString()),
									systemtime);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int position) {
					// ResultItem item = resultItems.get(position);
				}
			});

			listView.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items)
				|| items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
			
			if(pageIndex==1 && (BeanUtils.isEmpty(resultItems) || resultItems.size()==0)){
				mPullView.setVisibility(View.GONE);
				tvNoDataMsg.setVisibility(View.VISIBLE);
			}else{
				mPullView.setVisibility(View.VISIBLE);
				tvNoDataMsg.setVisibility(View.GONE);
			}
			
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}

	}

	public void loadDataBySearch(int what, int pageIndex, String title,
			String swfNo, String beginTime, String endTime, int searchType, int state) {
		this.pageIndex = pageIndex;
		if (pageIndex == 1) {
			resultItems.clear();// 清除
		}

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}

		// 综合查询：接口
		ApiRequest request = OAServicesHandler.searchAllBiz(title, swfNo,
				beginTime, endTime, pageIndex, searchType, state);

		if (request != null) {
			if (pageIndex == 1) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}
	}

	@Override
	public void onSearchChange(String search) {
		if (BeanUtils.isEmpty(search)) {
			// 清除ListView的过滤
			listView.clearTextFilter();
		} else {
			// listView.setFilterText(search);
			// adapter.getFilter().filter(search);
		}
	}

}
