package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.DocManagerInfo;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br> 
 * 办理信息list
 * @author  Fitz
 * @date    2015年4月29日
 * @version v1.0
 */
public class DocumentTransactListAdapter extends BaseAdapter implements OnClickListener{

	private Context mContext = null;
	private LayoutInflater inflater;

	private List<DocManagerInfo> dataList;

	public DocumentTransactListAdapter(Context context) {
		this.mContext = context;
		this.inflater = LayoutInflater.from(this.mContext);
		this.dataList = new ArrayList<DocManagerInfo>();
	}

	
	@Override
	public void onClick(View v) {
		
	}
	

	@Override
	public int getCount() {
		return dataList.size();
	}

	@Override
	public Object getItem(int position) {
		return dataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		
		ViewHolder holder = null;
		
        if (view == null) {
        	holder = new ViewHolder();
        	view = inflater.inflate(R.layout.document_detail_transact_item, null);
        	holder.tvName = (TextView) view.findViewById(R.id.tv_user_name);
        	holder.tvDepartment = (TextView) view.findViewById(R.id.tv_department);
        	holder.tvContent = (TextView) view.findViewById(R.id.tv_content);
            holder.tvDatetime = (TextView) view.findViewById(R.id.tv_datetime);
            view.setTag(holder);
            
        } else {
        	holder = (ViewHolder) view.getTag();
        }
        
        DocManagerInfo bean = dataList.get(position);
        holder.tvDatetime.setText(bean.getDatatime());
        holder.tvContent.setText(BeanUtils.isEmptyStr(bean.getSuggest()));
        holder.tvDepartment.setText(bean.getDepartment());
        holder.tvName.setText(BeanUtils.isEmptyStr(bean.getName()));
		return view;
	}

	
	/**
	 * 添加数据
	 * @param groupList
	 * @param userList
	 */
	public void addData(List<DocManagerInfo> dataList){
		this.dataList.addAll(dataList);
	}
	
	
	public void clearListData(){
		if(dataList!=null){
			dataList.clear();
		}
	}
	
	public void removeData(int position){
		dataList.remove(position);
	}
	
	private class ViewHolder{
		TextView tvName, tvDepartment, tvDatetime, tvContent;
	}

	
}
