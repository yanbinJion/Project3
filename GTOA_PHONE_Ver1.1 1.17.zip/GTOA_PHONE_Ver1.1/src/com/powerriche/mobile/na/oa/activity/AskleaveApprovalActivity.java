package com.powerriche.mobile.na.oa.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.bean.UserLeaveInfo;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : AskleaveApprovalActivity
 * 
 * @Description : 请假审批
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-05-10 09:38:24
 */
public class AskleaveApprovalActivity extends BaseActivity implements
		OnClickListener {

	private AskLeaveItemHelper askLeaveItemHelper;

	/** 查询单个数据标识 */
	public final static int WHAT_REQUEST_ITEM = 5457;

	private final static int DIALOG_CHECK = 4234;
	/** 审批 */
	public final static int WHAT_REQUEST_APPROVAL = 5455;

	public Button agreeBtn;

	public Button refuseBtn;

	public String traceNo;

	public String documentId;

	public EditText content;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.askleave_item_approval);
		bindView();
	}

	private void bindView() {

		TopActivity topActivity = (TopActivity) this
				.findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.askleave_approval_approval));
		topActivity.setRightBtnVisibility(View.INVISIBLE);

		documentId =  Constants.DOCUMENT_ID;
		traceNo = Constants.TRACE_NO;//getIntent().getStringExtra("traceNo");

		askLeaveItemHelper = new AskLeaveItemHelper(
				AskleaveApprovalActivity.this,
				this.findViewById(R.id.layout_leave_detail),1);
		ResultItem item = (ResultItem) getIntent().getSerializableExtra("item");
		if (item != null) {
			askLeaveItemHelper.processBaseInfo(item);
		}else{
			askLeaveItemHelper.searhData(WHAT_REQUEST_ITEM);
		}

		agreeBtn = (Button) this.findViewById(R.id.btn_agree);
		agreeBtn.setOnClickListener(this);
		refuseBtn = (Button) this.findViewById(R.id.btn_refuse);
		refuseBtn.setOnClickListener(this);
		content = (EditText) this.findViewById(R.id.txt_content);

	}

	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.system_back:// 返回
			onClickBack();
			break;

		case R.id.btn_agree:
			// 同意
			//if (checkData()) {
				submitApproval("1");
			//} else {
				//showDialog(DIALOG_CHECK);
			//}
			break;

		case R.id.btn_refuse:
			// 拒绝
			if (checkData()) {
				submitApproval("2");
			} else {
				showDialog(DIALOG_CHECK);
			}
			break;
		}
	}

	private boolean checkData() {
		errorMessage = "";
		String reason = content.getText().toString();
		if (BeanUtils.isEmpty(reason)) {
			errorMessage = getString(R.string.askleave_approval_reason_empty);
			return false;
		}
		return true;
	}

	// 提交数据 type审核状态 （1：同意 2：不同意
	private void submitApproval(String appType) {
		UserLeaveInfo leaveInfo = new UserLeaveInfo();
		leaveInfo.setLeaveBizNo(documentId);
		leaveInfo.setTraceNo(traceNo);
		leaveInfo.setPassState(appType);
		leaveInfo.setLeaveReason(content.getText().toString());
		askLeaveItemHelper.approvalLeave(leaveInfo, WHAT_REQUEST_APPROVAL);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == WHAT_REQUEST_ITEM) {
					//askLeaveItemHelper.process(response, what);
				} else if (what == WHAT_REQUEST_APPROVAL) {
					exit();
				}
			}
		}

		@Override
		public void finish(Object dialogObj, int what) {
			super.finish(dialogObj, what);
			if (what == 1236 || what == 1237) {

			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
				showErrorMessage(getString(R.string.system_commit_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}
	};

	public void exit() {
		//UIHelper.forwardTargetActivity(this,
		//		AskleaveApprovalActivity.class, null, true);
		finish();
	};


	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_CHECK:
			return new AlertDialog.Builder(AskleaveApprovalActivity.this)
					.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(errorMessage)
					.setNegativeButton(R.string.system_dialog_confirm,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}
							}).create();
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			onClickBack();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private void onClickBack(){
		if(Constants.NOTIFY_DETAIL_BACK){
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(AskleaveApprovalActivity.this, MainActivity.class, null, true);
	        
		}else{
			finish();
		}
	}
	
}
