package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.widget.ExpandableListView;

import com.powerriche.mobile.na.oa.activity.ChoosePeopleActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ChoosePeopleAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.ContactInfo;
import com.powerriche.mobile.na.oa.bean.DepartmentInfo;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.ContactDbhelper;
import com.powerriche.mobile.oa.tools.SettingPreference;

/**
 * 类描述：<br>
 * 组织成员列表帮助类
 * 
 * @author Fitz
 * @date 2015年4月24日
 * @version v1.0
 */
public class ChoosePeopleHelper {

	private final static String TAG = "ChoosePeopleHelper";

	private Context context;
	private ChoosePeopleActivity activity;

	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;

	public ChoosePeopleAdapter adapter = null;
	private ExpandableListView exUserList;
    private ContactDbhelper contactHelper;

	public ChoosePeopleHelper(Context context, IRequestCallBack callBack,
			ExpandableListView exUserList, ContactDbhelper p) {
		this.context = context;
		this.activity = (ChoosePeopleActivity) context;
		this.callBack = callBack;
		this.exUserList = exUserList;
		this.helper = activity.getInvokeHelper();
        contactHelper = p;
	}

	public void loadData() {
            ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
            if (request != null) {
                helper.invokeWidthDialog(request, callBack);
        }
	}

	public void process(HttpResponse response, int what,
			boolean isMultipleSelect) {
		List<ResultItem> items = response.getResultItem(ResultItem.class)
				.getItems("data");
		if (!BeanUtils.isEmpty(items)) {
            if (null != contactHelper) {
                contactHelper.insertContactResult(items);
            }
            process(items, what, isMultipleSelect);
		}
	}

    public void process(List<ResultItem> contacts, int what, boolean isMultipleSelect) {
        if (!BeanUtils.isEmpty(contacts)) {
            adapter = new ChoosePeopleAdapter(this.activity, isMultipleSelect);
            exUserList.setAdapter(adapter);

            Map<String, List<?>> map = getContactBeanList(contacts);

            @SuppressWarnings("unchecked")
            List<DepartmentInfo> departmentList = (List<DepartmentInfo>) map
                    .get("groups");
            @SuppressWarnings("unchecked")
            List<List<UserInfo>> userList = (List<List<UserInfo>>) map
                    .get("users");

            adapter.addData(departmentList, userList);
            adapter.notifyDataSetChanged();
        }
    }

	/**
	 * 获取所有已经选中的人员
	 * 
	 * @return
	 */
	public List<UserInfo> getValueListSelected() {
		if (adapter != null) {
			return adapter.getValueListSelected();
		}
		return null;
	}

	/**
	 * 解析数据
	 * 
	 * @param resultItems
	 * @return
	 */
	private Map<String, List<?>> getContactBeanList(List<ResultItem> resultItems) {

		Map<String, List<?>> map = new HashMap<String, List<?>>();

		List<DepartmentInfo> departmentList = new ArrayList<DepartmentInfo>();
		List<List<UserInfo>> userList = new ArrayList<List<UserInfo>>();

		List<UserInfo> dataList = new ArrayList<UserInfo>();
		for (int i = 0; i < resultItems.size(); i++) {
			ResultItem item = resultItems.get(i);

			String siteNo = item.getString("SITE_NO"); // 部门编号
			String siteName = item.getString("SITE_NAME"); // 部门名称
			int siteStatus = 0;// 部门下的员工选中状态：0全部未选中，1全部选中，2部分选中
			int siteStaffSize = 0;
			int siteStaffSizeSelected = 0;

			// 部门下的人员数组
			List<ResultItem> childItems = item.getItems("STAFF");
			if (!BeanUtils.isEmpty(childItems)) {
				siteStaffSize = childItems.size();
				for (int j = 0; j < childItems.size(); j++) {
					ResultItem childItem = childItems.get(j);

					String staffNo = childItem.getString("STAFF_NO"); // 人员编号
					String realName = childItem.getString("STAFF_NAME"); // 人员名称
					String mobile = childItem.getString("MOBILE"); // 手机

					UserInfo userInfo = new UserInfo(staffNo, realName, mobile);
					userInfo.setSiteNo(siteNo);
					userInfo.setSiteName(siteName);
					if (activity.userIds4Init != null
							&& activity.userIds4Init.contains(staffNo)) {
						userInfo.setStatus(1);// 选中
						adapter.addToSelected(userInfo);// 添加到已选中项
						siteStaffSizeSelected++;
					} else {
						adapter.removeFromSelected(userInfo);// 从已选中项中移除
					}

					dataList.add(userInfo);
				}
			}

			if (siteStaffSizeSelected > 0) {
				siteStatus = (siteStaffSize == siteStaffSizeSelected) ? 1 : 2;
			}

			DepartmentInfo department = new DepartmentInfo(siteNo, siteName,
					siteStatus);
			departmentList.add(department);
		}

		// 把子项添加到组中，按索引
		for (DepartmentInfo group : departmentList) {
			List<UserInfo> tempList = new ArrayList<UserInfo>();
			for (UserInfo user : dataList) {
				if (group.getSiteNo().equals(user.getSiteNo())) {
					tempList.add(user);
				}
			}
			userList.add(tempList);
		}

		map.put("groups", departmentList);
		map.put("users", userList);

		return map;
	}

}
