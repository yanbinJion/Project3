package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 记录版本信息
 * @author  Fitz
 * @date    2015年7月9日
 * @version v1.0
 */
public class VersionInfo {

	private int versionCode;
	private String versionName;
	private String downUrl;
	private String content;
	private String apkSize;
	private int isforce;	//是否强制升级
	
	
	public int getVersionCode() {
		return versionCode;
	}
	public void setVersionCode(int versionCode) {
		this.versionCode = versionCode;
	}
	public String getVersionName() {
		return versionName;
	}
	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}
	public String getDownUrl() {
		return downUrl;
	}
	public void setDownUrl(String downUrl) {
		this.downUrl = downUrl;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getApkSize() {
		return apkSize;
	}
	public void setApkSize(String apkSize) {
		this.apkSize = apkSize;
	}
	public int getIsforce() {
		return isforce;
	}
	public void setIsforce(int isforce) {
		this.isforce = isforce;
	}
	
}
