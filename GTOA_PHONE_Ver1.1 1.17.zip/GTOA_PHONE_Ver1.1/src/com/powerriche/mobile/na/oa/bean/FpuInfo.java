package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 办理环节信息
 * @author  Fitz
 * @date    2015年5月4日
 * @version v1.0
 */
public class FpuInfo {

	String swfNo;	//系统流程编号
	String toFpuNo;		//到达的环节编号
	String toActionNo;	//到达的环节静态编号
	String toActionName;	//到达的环节名称
	
	int position;
	
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getSwfNo() {
		return swfNo;
	}
	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}
	public String getToFpuNo() {
		return toFpuNo;
	}
	public void setToFpuNo(String toFpuNo) {
		this.toFpuNo = toFpuNo;
	}
	public String getToActionNo() {
		return toActionNo;
	}
	public void setToActionNo(String toActionNo) {
		this.toActionNo = toActionNo;
	}
	public String getToActionName() {
		return toActionName;
	}
	public void setToActionName(String toActionName) {
		this.toActionName = toActionName;
	}
	
}
