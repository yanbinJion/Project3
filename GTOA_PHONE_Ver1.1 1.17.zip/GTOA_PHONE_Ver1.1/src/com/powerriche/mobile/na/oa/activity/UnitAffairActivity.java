package com.powerriche.mobile.na.oa.activity;
		
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.MyGridAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
		
/**		
 * @title  单位事务
 * @author dir_wang
 * @date   2016-7-25上午11:08:04
 */		
public class UnitAffairActivity extends BaseActivity implements View.OnClickListener {
	private Context mContext;
	private GridView gridView;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		mContext = this;
		setContentView(R.layout.unit_affair);
		bindViews();
		initData();
	}	
		
	private void bindViews() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.menu_unit_affair));
		topActivity.setBtnBackOnClickListener(this);
		gridView = (GridView) findViewById(R.id.gridView);
	}	
		
	private void initData() {
		MyGridAdapter adapter = new MyGridAdapter(UnitAffairActivity.this);
		gridView.setAdapter(adapter);
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				switch (position) {
				case 0:
					// 跳转到界面：个人任务
					UIHelper.forwardTargetActivity(mContext, MyTaskActivity.class, null, false);
					break;
				case 1:
					// 跳转到界面：申领管理
					UIHelper.forwardTargetActivity(mContext, ApplyManageActivity.class, null, false);
					break;
				case 2:
					// 跳转到界面：申购管理
					UIHelper.forwardTargetActivity(mContext, PurchaseListActivity.class, null, false);
					break;
				case 3:
					// 跳转到界面：请假申请
					UIHelper.forwardTargetActivity(mContext, AppLeaveActivity.class, null, false);
					break;
					
				default:
					break;
				}	
			}		
		});			
	}				
					
	@Override		
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				UnitAffairActivity.this.finish();
				break;
		}

	}

}
