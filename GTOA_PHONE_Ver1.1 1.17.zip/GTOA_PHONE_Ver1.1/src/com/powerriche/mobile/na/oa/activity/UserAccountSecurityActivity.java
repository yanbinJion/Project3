package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UserHelper;

/**
 * Filename : UserAccountSecurityActivity
 * 
 * @Description : 账户安全
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-30 10:00:00
 */
public class UserAccountSecurityActivity extends BaseActivity implements
		OnClickListener {

	private ResultItem pwdItem = null;

	private UserHelper userHelper = null;
	
	private TextView tvLockGesturespwd,tvGesturesPwd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.account_security_layout);
		// 初始化数据
		initData();
		// 初始化选择按钮
		initLaoutClick();
	}

	// 初始化数据
	public void initData() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity
				.setTopTitle(getString(R.string.setting_accountsecurity_titile));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.INVISIBLE);

		TextView userNameView = (TextView) findViewById(R.id.loginname_textview);
		userNameView.setText(SystemContext.getUserId());
		
		tvLockGesturespwd = (TextView) findViewById(R.id.tv_lockgesturespwd);
		tvGesturesPwd = (TextView) findViewById(R.id.tv_gesturespassword);
		
		userHelper = new UserHelper();
		pwdItem = userHelper.getLastGesturesCode();
		
		Drawable drawable = getResources().getDrawable(R.drawable.ic_off);
		if (pwdItem == null) {
			tvGesturesPwd.setVisibility(View.INVISIBLE);
			drawable = getResources().getDrawable(R.drawable.ic_off);
			//tvLockGesturespwd.setBackgroundResource(R.drawable.ic_off);
		} else {
			// 如果等于0，标识是未打开设置
			if (pwdItem.getInt("ISLOCK") == 1) {
				drawable = getResources().getDrawable(R.drawable.ic_on);
				tvGesturesPwd.setVisibility(View.VISIBLE);
			} else {
				tvGesturesPwd.setVisibility(View.INVISIBLE);
			}
		}
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
		tvLockGesturespwd.setCompoundDrawables(null, null, drawable, null);//画在右边
	}

	// 初始化选择按钮
	public void initLaoutClick() {
		// 修改密码
		findViewById(R.id.tv_modifiypwd).setOnClickListener(this);
		// 手势密码开关
		findViewById(R.id.tv_lockgesturespwd).setOnClickListener(this);
		// 修改手势密码
		findViewById(R.id.tv_gesturespassword).setOnClickListener(this);
	}

	public void onClick(View view) {
		// 返回
		if (view.getId() == R.id.system_back) {
			finish();
			
		} else if (view.getId() == R.id.tv_modifiypwd) {// 修改密码
			UIHelper.forwardTargetActivity(this, ModifyPasswordActivity.class, null, true);
			
		} else if (view.getId() == R.id.tv_gesturespassword) {// 修改手势密码
			UIHelper.forwardTargetActivity(this, ModGesturesPasswordActivity.class, null, true);
			
		} else if (view.getId() == R.id.tv_lockgesturespwd) {// 手机密码开关
			modifySettingsGesturesPassword();
		}
		
	}

	// 手机密码开关
	public void modifySettingsGesturesPassword() {
		Drawable drawable = getResources().getDrawable(R.drawable.ic_off);
		// 如果手机密码是为空，则进行设置
		if (pwdItem == null) {
			UIHelper.forwardTargetActivity(this,
					SetGesturesPasswordActivity.class, null, true);
		} else {
			// 如果显示，则隐藏
			if (tvGesturesPwd.getVisibility() == View.VISIBLE) {
				tvGesturesPwd.setVisibility(View.INVISIBLE);
				drawable = getResources().getDrawable(R.drawable.ic_off);
				userHelper.setIsLock(false);
			} else {
				tvGesturesPwd.setVisibility(View.VISIBLE);
				drawable = getResources().getDrawable(R.drawable.ic_on);
				userHelper.setIsLock(true);
			}
		}
		drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
		tvLockGesturespwd.setCompoundDrawables(null, null, drawable, null);//画在右边
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}
}
