package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.DepartmentInfo;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 传阅选人接口Adapter
 * @author  Fitz
 * @date    2015年5月13日
 * @version v1.0
 */
public class DocumentPassreadChooseAdapter extends BaseExpandableListAdapter implements OnClickListener {


	private Context	mContext = null;
	private LayoutInflater inflater;

	private List<DepartmentInfo> groupList = null;
	private List<List<UserInfo>> userList = null;
	private List<UserInfo> valueList = null;	//选中的值存放
	private TextView tvPeopel;
	private StringBuffer sbNames;


	public DocumentPassreadChooseAdapter(Context context, TextView tvPeople) {
		this.mContext = context;
		this.inflater = LayoutInflater.from(this.mContext);

		this.groupList = new ArrayList<DepartmentInfo>();
		this.userList = new ArrayList<List<UserInfo>>();
		this.valueList = new ArrayList<UserInfo>();
		this.tvPeopel = tvPeople;
		this.sbNames = new StringBuffer("");
	}

	/*
	 * 设置子节点对象，在事件处理时返回的对象，可存放一些数据
	 */
	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return userList.get(groupPosition).get(childPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		ChildHolder holder = null;
		if (convertView == null) {
			holder = new ChildHolder();
			convertView = inflater.inflate(R.layout.common_choose_people_item, null);
			holder.tvName = (TextView) convertView.findViewById(R.id.tv_name);
			holder.btnChoose = (Button) convertView.findViewById(R.id.btn_choose);
			holder.llItemWrap = (LinearLayout) convertView.findViewById(R.id.ll_item_wrap);
			
			convertView.setTag(holder);
		} else {
			holder = (ChildHolder) convertView.getTag();
		}

		UserInfo bean = userList.get(groupPosition).get(childPosition);

		holder.tvName.setText(bean.getRealName());
		holder.btnChoose.setTag(bean);
		holder.btnChoose.setOnClickListener(this);
		holder.llItemWrap.setTag(bean);
        holder.llItemWrap.setOnClickListener(this);

		if (bean.getStatus() == 1) {//选中
			holder.btnChoose.setSelected(true);
		} else {//未选中
			holder.btnChoose.setSelected(false);
		}

		return convertView;
	}

	/*
	 * 返回当前分组的字节点个数
	 */
	@Override
	public int getChildrenCount(int groupPosition) {
		return userList.get(groupPosition).size();
	}

	/*
	 * 返回分组对象，用于一些数据传递，在事件处理时可直接取得和分组相关的数据
	 */
	@Override
	public Object getGroup(int groupPosition) {
		return groupList.get(groupPosition);
	}

	/*
	 * 分组的个数
	 */
	@Override
	public int getGroupCount() {
		return groupList.size();
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		GroupHolder holder = null;
		if (convertView == null) {
			holder = new GroupHolder();
			convertView = inflater.inflate(R.layout.user_list_group, null);
			holder.tvGroup = (TextView) convertView.findViewById(R.id.tv_group_name);
			convertView.setTag(holder);
		} else {
			holder = (GroupHolder) convertView.getTag();
		}

		DepartmentInfo groupName = groupList.get(groupPosition);
		holder.tvGroup.setText(groupName.getSiteName());
		holder.tvGroup.setTag(groupPosition);

		if (groupName.getSiteStatus() == 0) {//0全部未选中
			// 在部门上使用未选中图标
		} else if (groupName.getSiteStatus() == 1) {//1全部选中
			// 在部门上使用全选中图标
		} else if (groupName.getSiteStatus() == 2) {//2部分选中
			// 在部门上使用部分选中图标
		}

		//设置箭头
		Drawable drawable = null;
		if (isExpanded) {
			drawable = UIHelper.closeDrawable(mContext, R.drawable.ic_arrows_close);
		} else {
			drawable = UIHelper.openDrawable(mContext, R.drawable.ic_arrows_open);
		}
		holder.tvGroup.setCompoundDrawables(null, null, drawable, null);

		return convertView;
	}

	/*
	 * 判断分组是否为空，本示例中数据是固定的，所以不会为空，我们返回false 如果数据来自数据库，网络时，可以把判断逻辑写到这个方法中，如果为空
	 * 时返回true
	 */
	@Override
	public boolean isEmpty() {
		return false;
	}

	/*
	 * 收缩列表时要处理的东西都放这儿
	 */
	@Override
	public void onGroupCollapsed(int groupPosition) {

	}

	/*
	 * 展开列表时要处理的东西都放这儿
	 */
	@Override
	public void onGroupExpanded(int groupPosition) {

	}

	/*
	 * Whether the child at the specified position is selectable.
	 */
	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	/**
	 * 添加数据
	 * @param groupList
	 * @param userList
	 */
	public void addData(List<DepartmentInfo> groupList, List<List<UserInfo>> userList) {
		this.groupList.addAll(groupList);
		this.userList.addAll(userList);
	}

	
	private class GroupHolder {
		TextView	tvGroup;
	}

	private class ChildHolder {
		LinearLayout llItemWrap;
		TextView	tvName;
		Button		btnChoose;
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id==R.id.btn_choose || id==R.id.ll_item_wrap) {

			String temp = tvPeopel.getText().toString();
			sbNames.append(temp);
			
			UserInfo bean = (UserInfo) v.getTag();
			if(bean.getStatus()==0){
				bean.setStatus(1);
				valueList.add(bean);
				sbNames.append(bean.getRealName()).append("、");
			}else{
				bean.setStatus(0);
				valueList.remove(bean);
				String str = sbNames.toString().replace(bean.getRealName().concat("、"), "");	//之前的选中的替换成空格
				sbNames = new StringBuffer(str);
			}
			
			this.notifyDataSetChanged();
			setTextStyle(tvPeopel, sbNames.toString());
			sbNames = new StringBuffer("");
		}
	}
	
	public List<List<UserInfo>> getTypeList(){
		return userList;
	}
	
	public List<UserInfo> getValueList(){
		return valueList;
	}
	
	public void setValueList(List<UserInfo> dataList){
		valueList.clear();
		valueList.addAll(dataList);
	}
	
	public void clearValueList(){
		valueList.clear();
	}
	
	public void setTextStyle(TextView tvPeopel, String names){
		tvPeopel.setText(names);
		/*
		if(tvPeopel.getLineCount()>2){
			tvPeopel.setLines(2);
			tvPeopel.setSingleLine(false);
			tvPeopel.setEllipsize(TruncateAt.END);
		}else{
			tvPeopel.setLines(1);
			tvPeopel.setSingleLine(true);
			tvPeopel.setEllipsize(TruncateAt.END);
		}*/
		if(BeanUtils.isEmpty(names)){
			tvPeopel.setVisibility(View.GONE);
		}else{
			tvPeopel.setVisibility(View.VISIBLE);
		}
		
	}

}
