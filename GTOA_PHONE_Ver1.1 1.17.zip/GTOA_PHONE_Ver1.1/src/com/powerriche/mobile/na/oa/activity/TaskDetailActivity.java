package com.powerriche.mobile.na.oa.activity;
		
import java.util.ArrayList;
import java.util.List;
		
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
		 
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.down.DownloadInfoBean;
import com.powerriche.mobile.na.oa.down.DownloadInfoDAO;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper.DownloadButtonListener;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
		
/**		
 * 类描述：<br>
 * 任务信息：查看详情
 * @author 李运期
 * @date 2015年5月4日
 * @version v1.0
 */		 
public class TaskDetailActivity extends BaseActivity implements OnClickListener, DownloadButtonListener {
		 
	public final static int CODE_REQUEST_SIGN = 11;
	public final static int CODE_REQUEST_DETAIL = 12;
		 
	private Context mContext;
	private TopActivity topActivity;
		 
	private String taskId;// 任务ID
	private String taskTitle;// 标题
	private String taskAddress;// 发生地点
	private String taskTime;// 发生时间
	private String taskContent;// 任务内容
	private String contacter;// 联系人
	private String contacterPhone;// 联系电话
	private String documentId;// 任务上报关联的ID
	private String taskStatus = "0";// 上报状态：0,未上报 1,已上报。注意：已上报的话就不能再次上报
	private String sign = "0";	//只有先签收后，才有上报功能
		 
	private TextView etTaskTitle, etTaskAddress, etTaskTime, etTaskContent, etContacter, etContacterPhone;
	private TextView tvFileGroup;
	private LinearLayout llFileWrap;
		 
		 
	private DownloadUIHelper downloadUIHelper = null;
	private DownloadInfoDAO dao = null;
		 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.task_detail);
		
		taskId = getIntent().getStringExtra("taskId");// 任务的ID
		
		bindViews();
		
		// 请求详情接口
		ApiRequest request = OAServicesHandler.getTaskDetail(taskId);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack, CODE_REQUEST_DETAIL);
		}
		
		this.downloadUIHelper = new DownloadUIHelper(mContext);
		this.downloadUIHelper.setEventListener(this);
		this.dao = new DownloadInfoDAO(mContext);
		
	}	
		
	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.task_detail_title));
		topActivity.setBtnBackOnClickListener(this);
		
		topActivity.setRightBtnVisibility(View.GONE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(getString(R.string.task_detail_report));// 右边按钮文字：编辑
		
		etTaskTitle = (TextView) findViewById(R.id.tv_task_title);
		etTaskAddress = (TextView) findViewById(R.id.tv_task_address);
		etTaskTime = (TextView) findViewById(R.id.tv_task_time);
		etTaskContent = (TextView) findViewById(R.id.tv_task_content);
		etContacter = (TextView) findViewById(R.id.tv_contacter);
		etContacterPhone = (TextView) findViewById(R.id.tv_contacter_phone);
		
		tvFileGroup = (TextView) findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		tvFileGroup.setVisibility(View.VISIBLE);
		
		llFileWrap = (LinearLayout) findViewById(R.id.ll_file_wrap);
		llFileWrap.setVisibility(View.GONE);
	}	
		
		
	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_back){
			finish();
			
		}else if(id == R.id.btn_top_right){
			if ("0".equals(sign) || "0.0".equals(sign)) {// 未签收
				signRequest();
				
			}else{
				if ("0".equals(taskStatus) || "0.0".equals(taskStatus)) {// 未上报
					// 封装交互数据
					Bundle data = new Bundle();
					data.putString("taskId", taskId);
					data.putString("documentId", documentId);
					data.putString("taskReportId", "");// 上报编号：为空添加，不为空修改

					// 跳转界面：结果上报
					UIHelper.forwardTargetActivity(mContext, TaskReplyActivity.class, data, true);
				}
			}
			
		} else if (id == R.id.tv_file_group) {
			UIHelper.isOpenFile(mContext, tvFileGroup, llFileWrap);
			
		} else if(id==R.id.btn_process || id==R.id.rl_item_wrap){	//附件下载
			UIHelper.downViewClick(mContext, v, downloadUIHelper, dao);
		}	
	}		
			
			
	@Override
	protected void onPause() {
		super.onPause();
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.unRegUiHandler();
	}		
			
	@Override
	protected void onResume() {
		super.onResume();
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.regUiHandler();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		mContext = null;
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.unRegUiHandler();
	}						
					       
						  
	/** 签收接口 */			  
	private void signRequest(){
		// 请求详情接口		  
		ApiRequest request = OAServicesHandler.getTaskSign(taskId);
		if (request != null) {
			helper.buildDialog(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, CODE_REQUEST_SIGN);
		}				 
	}					
						
						
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override		
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
						
				if(what == CODE_REQUEST_SIGN){	//签收返回
					String code = item.getString("code");
					if(Constants.SUCCESS_CODE.equals(code)){
						UIHelper.showMessage(mContext, mContext.getString(R.string.task_detail_sign_success));
						sign = "1";	//已签收
						topActivity.setRightBtnStyle(mContext.getString(R.string.task_detail_report));
						
					}else{
						UIHelper.showMessage(mContext, item.getString("message"));
					}
					
				}else if(what == CODE_REQUEST_DETAIL){	//详情
					// 解析返回的数据
					ResultItem noticeItem = response.getResultItem(ResultItem.class).getItems("data").get(0);
					
					taskTitle = BeanUtils.isEmpty4Get(noticeItem.getString("TASK_TITLE"));// 标题
					taskAddress = BeanUtils.isEmpty4Get(noticeItem.getString("TASK_ADDRESS"));// 发生地点
					taskTime = BeanUtils.isEmpty4Get(noticeItem.getString("TASK_TIME"));// 发生时间
					taskContent = BeanUtils.isEmpty4Get(noticeItem.getString("TASK_CONTENT"));// 任务内容
					contacter = BeanUtils.isEmpty4Get(noticeItem.getString("CONTACTER"));// 联系人
					contacterPhone = BeanUtils.isEmpty4Get(noticeItem.getString("CONTACTER_PHONE"));// 联系人电话
					documentId = BeanUtils.floatToInt4Str(noticeItem.getString("DOCUMENT_ID"));// 用于结果上报的ID
					taskStatus = BeanUtils.isEmpty4Get(noticeItem.getString("STATUS"));// 上报状态：0,未上报  // 1,已上报。注意：已上报的话就不能再次上报
					
					//TODO 任务签收，字段未返回
					sign = BeanUtils.isEmpty4Get("", "0");	//判断是否签收：0未签收，1已签收
					
					
					etTaskTitle.setText(taskTitle);
					etTaskAddress.setText(taskAddress);
					etTaskTime.setText(taskTime);
					etTaskContent.setText(taskContent);
					etContacter.setText(contacter);
					etContacterPhone.setText(contacterPhone);
					
					//判断是否签收->未签收操作
					if("0".equals(sign) || "0.0".equals(sign)){
						topActivity.setRightBtnVisibility(View.VISIBLE);
						topActivity.setRightBtnStyle("签收");
						
					}else{
						//判断是否已上报
						if ("0".equals(taskStatus) || "0.0".equals(taskStatus)) {// 未上报
							topActivity.setRightBtnVisibility(View.VISIBLE);//
						} else {// 已上报
							topActivity.setRightBtnVisibility(View.GONE);// 已上报的话就不能再次上报
						}
					}
					
					// 遍历所有附件
					List<DocFileInfo> fileList = processFileList(noticeItem);
					if (fileList != null && !fileList.isEmpty()) {
						foreachFiles(fileList);
					}
				}
			}	
		}		
	};			
				
	private List<DocFileInfo> processFileList(ResultItem item) {
		List<DocFileInfo> fileList = new ArrayList<DocFileInfo>();
		// 获取附件数据
		List<ResultItem> fileItems = item.getItems("File"); // 文件列表
		if (fileItems != null && !fileItems.isEmpty()) {
			for (ResultItem fileItem : fileItems) {
				if (fileItem == null) {
					continue;
				}
				
				String fileCode = fileItem.getString("FK_FILE_CODE"); // 文件编号
				String fileTitle = fileItem.getString("FILE_TITLE");// 文件标题
				String fileName = fileItem.getString("FILE_NAME"); // 文件名称
				String ftpPath = fileItem.getString("FTP_PATH"); // 文件路径
				
				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(fileItem.getString("FILE_SIZE"));//文件大小
				if(!BeanUtils.isEmpty(fileSizeStr)){
					fileSize = Integer.parseInt(fileSizeStr);
				}
				
				DocFileInfo fileBean = new DocFileInfo();
				fileBean.setFileCode(fileCode);
				fileBean.setFileTitle(fileTitle);
				fileBean.setFileName(fileName);
				fileBean.setFilePath(ftpPath);
				fileBean.setFileSize(fileSize);
				fileList.add(fileBean);
			}
		}	
		return fileList;
	}		
			
	/** 遍历所有附件 */
	private void foreachFiles(List<DocFileInfo> fileList) {
		for (int i = 0, len = fileList.size(); i < len; i++) {
			final DocFileInfo bean = fileList.get(i);
			ViewHolderFile holder = new ViewHolderFile();
			
			View view = LayoutInflater.from(mContext).inflate(R.layout.govaffair_file_item, null);
			holder.rlItemWrap = (RelativeLayout) view.findViewById(R.id.rl_item_wrap);
			holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
			holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
			
			holder.btnDownload = (RoundProgressButton) view.findViewById(R.id.btn_process);
			holder.rlRoundBtnWrap = (RelativeLayout) view.findViewById(R.id.rl_round_btn_wrap);
			
			String extend = FileUtils.getFileExtends(bean.getFileName());
			UIHelper.setFileTypeIcon(mContext, holder.ivType, extend); // 设置文件类型
			
			
			holder.tvFileName.setText(bean.getFileName());
			holder.tvFileName.setTag(bean.getFilePath());
			
			holder.btnDownload.setTag(bean);
			holder.btnDownload.setOnClickListener(this);
			
			//String url = UIHelper.downFileUrl(bean.getFileCode());//getString(R.string.system_servics_download).concat(bean.getFilePath());
			String url;
            //0,标识使用system_servics_download下载，1标识使用system_servics_url下载
            if("1".equals(getString(R.string.is_download_flag))){
                url = UIHelper.downFileUrl(bean.getFileCode());
            }else{
                url = getString(R.string.system_servics_download).concat(bean.getFilePath());
            }
			holder.rlRoundBtnWrap.setTag(url);//下载标识
			
			holder.rlItemWrap.setTag(bean);//长按删除
			holder.rlItemWrap.setOnClickListener(this);
			
			try{
				DownloadInfoBean downBean = dao.getAppBeanByCd(bean.getFileCode());
				if(downBean!=null){	//下载完成
					int state = downBean.getState();
					if(state == DownloadInfoDAO.DOWNLOAD_STATE_2){
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_finish); // 存在则打开
						
					}else if(state == DownloadInfoDAO.DOWNLOAD_STATE_3){
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_pause); // 暂停状态
						
					}else{
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
					}
				}else{
					holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
				}
				holder.btnDownload.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
						this.getResources().getColor(R.color.transparent));
			}catch(Exception e){
				
			}
			llFileWrap.addView(view);
		}
		if(llFileWrap.getChildCount()>0){
			llFileWrap.setVisibility(View.VISIBLE);
			tvFileGroup.setVisibility(View.VISIBLE);
		}
	}	
		
		
	private class ViewHolderFile {
		TextView tvFileName;
		ImageView ivType;
		RoundProgressButton btnDownload;
		RelativeLayout rlItemWrap, rlRoundBtnWrap;
	}	
		
		
	@Override
	public void onProgressUpdate(String url, long totalSize, long dealtSize) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap,url, true);
		if(btnDown == null)return;
		btnDown.cancelDown();
		btnDown.setBackgroundResource(R.drawable.ic_down_ing);	//正在下载
		btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.gray_split_line_bg), 
				this.getResources().getColor(R.color.down_progress_color));
		
		float num = (float)dealtSize / (float)totalSize;
		int result = (int)(num * 100);
		
		btnDown.setProgress(result);
	}

	@Override
	public void onDownloadComplete(String url) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);	//下载完成
		if(btnDown == null)return;
		btnDown.cancelDown();
		btnDown.setBackgroundResource(R.drawable.ic_down_finish);
		btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
				this.getResources().getColor(R.color.transparent));
		
		UIHelper.openFile(mContext, url);
	}

	@Override
	public void onDownloadStateChange(String url, int state) {
		switch (state) {
		case DownloadInfoDAO.DOWNLOAD_STATE_3:
			RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);	//暂停下载
			if(btnDown!=null){
				btnDown.cancelDown();
				btnDown.setBackgroundResource(R.drawable.ic_down_pause);
				btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
						this.getResources().getColor(R.color.transparent));
			}
			break;
		}
	}

	@Override
	public void onDownloadError(String url, int state) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);
		if(btnDown!=null){
			btnDown.setBackgroundResource(R.drawable.ic_down);
			btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.gray_split_line_bg), 
					this.getResources().getColor(R.color.down_progress_color));
		}
		UIHelper.showMessage(mContext, "下载错误");
	}
	
	

}
