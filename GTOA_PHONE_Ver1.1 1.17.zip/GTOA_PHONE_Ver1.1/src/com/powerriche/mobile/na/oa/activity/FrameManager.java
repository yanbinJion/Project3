package com.powerriche.mobile.na.oa.activity;
	
import java.util.ArrayList;
import java.util.List;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;

import com.powerriche.mobile.na.oa.R;
	
/** 
 * 类描述：<br> 选项卡初始化管理类
 * 
 * @author Fitz
 * @date 2015年4月23日
 * @version v1.0
 */	
public class FrameManager {
	
	public static FrameManager	manager;
	
	private int					currentItem	= -1;
	
	/** 帧ID：0-待办事宜 */
	public final static int		FRAME_0		= 0;
	/** 帧ID：1-公文管理 */
	public final static int		FRAME_1		= 1;
	/** 帧ID：2-会议管理 */
	public final static int		FRAME_2		= 2;
	
	private List<ViewGroup>		mViewGroups;
	private ViewPager			mTabPager;

	private MainActivity		mMainActivity;

	/** Tab选项卡：待办事宜 */
	private TabDbsyActivity		tabDbsyActivity;
	/** Tab选项卡：公文管理 */
	private TabOfficialActivity	tabOfficialActivity;
	/** Tab选项卡：会议管理 */
	private TabMeetActivity		tabMeetActivity;

	private FrameManager(MainActivity mainActivity) {
		this.mMainActivity = mainActivity;
		this.mTabPager = (ViewPager) this.mMainActivity.findViewById(R.id.vp_tab_main);

		this.mViewGroups = new ArrayList<ViewGroup>();
	}

	public void setCurrentItem(int currentItem) {
		this.currentItem = currentItem;
	}

	public int getCurrentItem() {
		return this.currentItem;
	}

	public static FrameManager instance(MainActivity mainActivity) {
		if (manager == null && mainActivity != null) {
			manager = new FrameManager(mainActivity);
		}
		return manager;
	}

	public static FrameManager instance() {
		return manager;
	}

	private void initDefaultFrame() {
		if (this.tabDbsyActivity == null) {//Tab选项卡：待办事宜
			this.tabDbsyActivity = new TabDbsyActivity(this.mMainActivity);
		}

		if (this.tabOfficialActivity == null) {//Tab选项卡：公文管理
			this.tabOfficialActivity = new TabOfficialActivity(this.mMainActivity);
		}
		
		if (this.tabMeetActivity == null) {//Tab选项卡：会议管理
			this.tabMeetActivity = new TabMeetActivity(this.mMainActivity);
		}
		
		this.mViewGroups.add(FrameManager.FRAME_0, this.tabDbsyActivity);
		this.mViewGroups.add(FrameManager.FRAME_1, this.tabOfficialActivity);
		this.mViewGroups.add(FrameManager.FRAME_2, this.tabMeetActivity);
		
		this.mTabPager.setOffscreenPageLimit(0);
		
		this.mTabPager.setAdapter(new MyViewPagerAdapter(this.mViewGroups));
		this.mTabPager.setOnPageChangeListener(new MyPageChangeListener());
	}
	
	private void showCurrentItem(int currentItem) {
		this.mTabPager.setCurrentItem(currentItem);
	}
	
	/**
	 * 恢复时自动触发此方法
	 */
	public void onResume() {
		switch (currentItem) {
			case FRAME_0://Tab选项卡：待办事宜
				if (this.tabDbsyActivity != null) {
					break;
				}
			case FRAME_1://Tab选项卡：公文管理
				if (this.tabOfficialActivity != null) {
					this.tabOfficialActivity.onResume();
					break;
				}

			case FRAME_2://Tab选项卡：会议管理
				if (this.tabMeetActivity != null) {
					this.tabMeetActivity.onResume();
					break;
				}
		}
	}

	public void showFrame(int frameFlag, Integer flag) {
		if (frameFlag == currentItem) {
			return;
		}

		this.mMainActivity.selectBottomItem(frameFlag);

		setCurrentItem(frameFlag);
		showCurrentItem(frameFlag);
		switchPageInitData(frameFlag);
	}

	private void switchPageInitData(int frameFlag) {
		switch (frameFlag) {
			case FrameManager.FRAME_0://Tab选项卡：待办事宜
				if (this.tabDbsyActivity == null) {
					this.tabDbsyActivity = new TabDbsyActivity(mMainActivity);
					this.mViewGroups.add(FrameManager.FRAME_0, this.tabDbsyActivity);
				}
				if (!this.tabDbsyActivity.isOnCreate) {
					this.tabDbsyActivity.onCreate(null);
					this.tabDbsyActivity.isOnCreate = true;
				}
				this.tabDbsyActivity.onShow(null);
				break;

			case FrameManager.FRAME_1://Tab选项卡：公文管理
				if (this.tabOfficialActivity == null) {
					this.tabOfficialActivity = new TabOfficialActivity(mMainActivity);
					this.mViewGroups.add(FrameManager.FRAME_1, this.tabOfficialActivity);
				}
				if (!this.tabOfficialActivity.isOnCreate) {
					this.tabOfficialActivity.onCreate(null);
					this.tabOfficialActivity.isOnCreate = true;
				}
				this.tabOfficialActivity.onShow(null);
				break;

			case FrameManager.FRAME_2://Tab选项卡：会议管理
				if (this.tabMeetActivity == null) {
					this.tabMeetActivity = new TabMeetActivity(mMainActivity);
					this.mViewGroups.add(FrameManager.FRAME_2, this.tabMeetActivity);
				}
				if (!this.tabMeetActivity.isOnCreate) {
					this.tabMeetActivity.onCreate(null);
					this.tabMeetActivity.isOnCreate = true;
				}
				this.tabMeetActivity.onShow(null);
				break;
		}
	}

	public void showDefaultPage(int page) {
		this.initDefaultFrame();
		showFrame(page, null);
	}

	/**
	 * 销毁时自动触发此方法
	 */
	public void onDestroy() {
		if (this.tabOfficialActivity != null) {
			this.tabOfficialActivity.onDestroy();
		}
		tabOfficialActivity = null;

		if (this.tabMeetActivity != null) {
			this.tabMeetActivity.onDestroy();
		}
		tabMeetActivity = null;

		if (this.tabDbsyActivity != null) {
			this.tabDbsyActivity.onDestroy();
		}
		tabDbsyActivity = null;

		manager = null;
	}

	/**
	 * @author Fitz 界面适配器
	 */
	public class MyViewPagerAdapter extends PagerAdapter {
		private List<ViewGroup>	mListViews;
		private int				size	= 0;

		public MyViewPagerAdapter(List<ViewGroup> mListViews) {
			this.mListViews = mListViews;// 构造方法，参数是页卡。
			this.size = mListViews.size();
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));// 删除页卡
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) { // 这个方法用来实例化页卡
			container.addView(mListViews.get(position), 0);// 添加页卡
			return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return size;// 返回页卡的数量
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}

	public class MyPageChangeListener implements ViewPager.OnPageChangeListener {

		public MyPageChangeListener() {
			super();
		}

		@Override
		public void onPageScrollStateChanged(int arg0) {
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		@Override
		public void onPageSelected(int position) {
			setCurrentItem(position);
			mMainActivity.selectBottomItem(position);
			switchPageInitData(position);
		}
	}

	public MainActivity getmMainActivity() {
		return mMainActivity;
	}

}
