package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.Date;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.DataCleanManager;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 流量统计
 * 
 * @author 高明峰
 * @date 2015年5月11日
 * @version v1.0
 */
public class StatisticsActivity extends BaseActivity implements OnClickListener {

	private Context mContext;
	private TopActivity topActivity;
	private Button				mBtnRight;

	private TextView totalDay;
	private TextView totalMonth;

	private TextView picDay;
	private TextView picMonth;

	private TextView textDay;
	private TextView textMonth;

	private TextView fileDay;
	private TextView fileMonth;
	
	private LinearLayout llPic;
	
	private LinearLayout llText;
	
	private LinearLayout llFile;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.traffic_statistics_layout);
		this.mContext = this;
		bindViews();
		
		// 初始化数据
		initData();
	}

	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		//topActivity.setBtnBackText("  " + getString(R.string.setting_title));
		topActivity.setTopTitle(getString(R.string.setting_traffic_statistics));
		topActivity.setBtnBackOnClickListener(this);
		
		mBtnRight = topActivity.getBtnRight();
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("清除");//右边按钮文字：发布
		llPic = (LinearLayout) findViewById(R.id.statistics_pic);
		llPic.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(final View v) {
				final SystemDialog chooseDialog = new SystemDialog(mContext);
				chooseDialog.setTitle("删除提示");
				chooseDialog.setMessage("确定删除所有的图片信息吗？");
				chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
					@Override
					public void onClick(View view) {
						deleteImgageFile();
					}
				});
				chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
					@Override
					public void onClick(View v) {
						if(chooseDialog!=null){
							chooseDialog.dismiss();
						}
					}
				});
				chooseDialog.show();
				return false;
			}
		});
		llText = (LinearLayout) findViewById(R.id.statistics_text);
		llText.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(final View v) {
				final SystemDialog chooseDialog = new SystemDialog(mContext);
				chooseDialog.setTitle("删除提示");
				chooseDialog.setMessage("确定删除所有的文本信息吗？");
				chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
					@Override
					public void onClick(View view) {
						deleteTxtFile();
					}
				});
				chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
					@Override
					public void onClick(View v) {
						if(chooseDialog!=null){
							chooseDialog.dismiss();
						}
					}
				});
				chooseDialog.show();
				return false;
			}
		});
		llFile = (LinearLayout) findViewById(R.id.statistics_file);
		llFile.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(final View v) {
				final SystemDialog chooseDialog = new SystemDialog(mContext);
				chooseDialog.setTitle("删除提示");
				chooseDialog.setMessage("确定删除所有的附件信息吗？");
				chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
					@Override
					public void onClick(View view) {
						deleteDocumentFile();
					}
				});
				chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
					@Override
					public void onClick(View v) {
						if(chooseDialog!=null){
							chooseDialog.dismiss();
						}
					}
				});
				chooseDialog.show();
				return false;
			}
		});
		
	}

	// 初始化数据
	public void initData() {

		totalDay = (TextView) findViewById(R.id.statistics_total_day);
		totalMonth = (TextView) findViewById(R.id.statistics_total_month);

		picDay = (TextView) findViewById(R.id.statistics_pic_day);
		picMonth = (TextView) findViewById(R.id.statistics_pic_month);

		textDay = (TextView) findViewById(R.id.statistics_text_day);
		textMonth = (TextView) findViewById(R.id.statistics_text_month);

		fileDay = (TextView) findViewById(R.id.statistics_file_day);
		fileMonth = (TextView) findViewById(R.id.statistics_file_month);
		
		//统计流量
		this.calculateFlowData();
	}

	/**
	 * 统计出流量
	 */
	public void calculateFlowData() {
		try {
			// 图片类
			File file = new File(Constants.SDCARD_DIR_IMAGE_DOWNLOAD);
			Date sysDate = new Date();

			long picDaySize = DataCleanManager.getDateFolderSize(sysDate, file,
					1);
			picDay.setText(DataCleanManager.getFormatSize(picDaySize));
			long picMonthSize = DataCleanManager.getDateFolderSize(sysDate,
					file, 30);
			picMonth.setText(DataCleanManager.getFormatSize(picMonthSize));

			// 文本类
			file = new File(Constants.SDCARD_DIR_TXT_DOWNLOAD);
			long textDaySize = DataCleanManager.getDateFolderSize(sysDate,
					file, 1);
			textDay.setText(DataCleanManager.getFormatSize(textDaySize));
			long textMonthSize = DataCleanManager.getDateFolderSize(sysDate,
					file, 30);
			textMonth.setText(DataCleanManager.getFormatSize(textMonthSize));

			// 附件类
			file = new File(Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD);
			long fileDaySize = DataCleanManager.getDateFolderSize(sysDate,
					file, 1);
			fileDay.setText(DataCleanManager.getFormatSize(fileDaySize));
			long fileMonthSize = DataCleanManager.getDateFolderSize(sysDate,
					file, 30);
			fileMonth.setText(DataCleanManager.getFormatSize(fileMonthSize));

			// 总计
			long totalDaySize = picDaySize + textDaySize + fileDaySize;
			long totalMonthSize = picMonthSize + textMonthSize + fileMonthSize;
			totalDay.setText(DataCleanManager.getFormatSize(totalDaySize));
			totalMonth.setText(DataCleanManager.getFormatSize(totalMonthSize));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:// 返回
			finish();
			break;
		case R.id.btn_top_right:// 标题栏的右边按钮
			doClearAllDown(); //清除所有下载
			break;
		}

	}
	
	/**
	 * 删除所有的附件信息
	 */
	public void deleteAllFile(){
		deleteImgageFile();
		deleteTxtFile();
		deleteDocumentFile();
	}
	
	/**
	 * 删除图片目录
	 */
	public void deleteImgageFile(){
		//File file = new File(Constants.SDCARD_DIR_IMAGE_DOWNLOAD);
		DataCleanManager.deleteFolderFile(Constants.SDCARD_DIR_IMAGE_DOWNLOAD,false);
		//统计流量
		StatisticsActivity.this.calculateFlowData();
	}
	
	/**
	 * 删除文本目录
	 */
	public void deleteTxtFile(){
		//File file = new File(Constants.SDCARD_DIR_TXT_DOWNLOAD);
		//DataCleanManager.deleteDir(file);
		DataCleanManager.deleteFolderFile(Constants.SDCARD_DIR_TXT_DOWNLOAD,false);
		//统计流量
		StatisticsActivity.this.calculateFlowData();
	}
	
	/**
	 * 删除附件目录
	 */
	public void deleteDocumentFile(){
		//File file = new File(Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD);
		//DataCleanManager.deleteDir(file);
		DataCleanManager.deleteFolderFile(Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD,false);
		//统计流量
		StatisticsActivity.this.calculateFlowData();
	}

	/** 清除所有下载 */
	public void doClearAllDown() {
		final SystemDialog chooseDialog = new SystemDialog(mContext);
		chooseDialog.setMessage("确定要删除所有的图片、文本、附件吗？");
		chooseDialog.setOnConfirmClickListener("确定", new View.OnClickListener() {//确定按钮事件
			@Override
			public void onClick(View view) {
				//删除所有已经下载
				StatisticsActivity.this.deleteAllFile();
			}
		});
		chooseDialog.setOnCancelClickListener("取消", new View.OnClickListener() {//取消
			@Override
			public void onClick(View v) {
				if(chooseDialog!=null){
					chooseDialog.dismiss();
				}
			}
		});
		chooseDialog.show();
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	public void exit() {
		finish();
	}

}
