package com.powerriche.mobile.na.oa.activity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AttendanceCountListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

public class AttendanceCountActivity extends BaseActivity implements View.OnClickListener {
	private Context mContext;
	private TopActivity topActivity;
	private View view;

	public final static int ATTENDANCE_COUNT_LIST = 1234;

	private PullToRefreshListView mPullView;

	private ListView mListView;

	public int pageIndex = 1;
	
	private AttendanceCountListHelper listHelper;
	private EditText et_attendance_count_begintime, et_attendance_count_endtime;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attendance_count_list);
		this.mContext = this;
		initView();
		initData();
	}
	
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.attendance_count));// 顶部栏的中间标题
		view = findViewById(R.id.layout_attendance_count);
		
		et_attendance_count_begintime = (EditText) findViewById(R.id.et_attendance_count_begintime);
		et_attendance_count_endtime = (EditText) findViewById(R.id.et_attendance_count_endtime);
		Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT);
		et_attendance_count_begintime.setText(sdf.format(calendar.getTime()));
		String dateStr = DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT);
		et_attendance_count_endtime.setText(dateStr);
		listHelper = new AttendanceCountListHelper(AttendanceCountActivity.this, view);
		listHelper.setBeginTime(et_attendance_count_begintime);
		listHelper.setEndTime(et_attendance_count_endtime);
		mPullView = (PullToRefreshListView) findViewById(R.id.lv_attendance_count);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);
		mListView = mPullView.getRefreshableView();
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(R.color.transparent);
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			String code = resultItem.getString("code");
			String message = resultItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(AttendanceCountActivity.this, message);
				return;
			}
			if (what == ATTENDANCE_COUNT_LIST) {
				listHelper.process(response, what);
			}
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};
	
	private void initData() {
		et_attendance_count_begintime.setOnClickListener(this);
		et_attendance_count_endtime.setOnClickListener(this);
		mPullView.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
				// 下拉加载数据
				pageIndex = 1;
				listHelper.loadData(ATTENDANCE_COUNT_LIST, pageIndex, false);
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				listHelper.loadData(ATTENDANCE_COUNT_LIST, pageIndex, false);
			}
		});
		listHelper.loadData(ATTENDANCE_COUNT_LIST, pageIndex, true);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			AttendanceCountActivity.this.finish();
			break;
		case R.id.et_attendance_count_begintime:
			UIHelper.showTimeSelect(mContext, et_attendance_count_begintime, DateUtils.DATE_FORMAT);
			break;
		case R.id.et_attendance_count_endtime:
			UIHelper.showTimeSelect(mContext, et_attendance_count_endtime, DateUtils.DATE_FORMAT);
			break;
		default:
			break;
		}
	}
	
	public InvokeHelper getInvokeHelper() {
		return helper;
	}
	
	public IRequestCallBack getCallBack() {
		return callBack;
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		// 恢复界面时，加载最新的第一页数据
		pageIndex = 1;
		listHelper.loadData(ATTENDANCE_COUNT_LIST, pageIndex, false);
	}
	
}
