package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : AgencyIndexActivity
 * 
 * @Description : 请假
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-21 09:38:24
 */
public class AskLeaveActivity extends BaseActivity implements OnClickListener {

	private Context					mContext;
	
	private AskLeaveListHelper askLeaveListHelper;

	private View systemView;

	public final static int ASKLEAVE_LIST = 1234;

	public final static int ASKLEAVE_DETAIL = 1235;

	/** 退出标识 */
	public final static int WHAT_PAGE_EXIT = 3460;

	/** 查询单个数据标识 */
	public final static int WHAT_REQUEST_ASKlEANE_ITEM = 5457;

	private PullToRefreshListView mPullView;

	private ListView mListView;

	private Handler indexHandler;

	public int pageIndex = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.askleave_list_layout);
		bindView();

	}

	private void bindView() {

		TopActivity topActivity = (TopActivity) this
				.findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.askleave_title));
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnStyle(R.drawable.add_button);
		topActivity.setRightBtnOnClickListener(this);

		systemView = this.findViewById(R.id.layout_leave);

		askLeaveListHelper = new AskLeaveListHelper(AskLeaveActivity.this,
				systemView);

		mPullView = (PullToRefreshListView) this
				.findViewById(R.id.pull_listview);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);

		mListView = mPullView.getRefreshableView();
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(R.color.transparent);

		mPullView.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 下拉加载数据
				pageIndex = 1;
				askLeaveListHelper.loadData(ASKLEAVE_LIST, pageIndex,false);
			}

			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				askLeaveListHelper.loadData(ASKLEAVE_LIST, pageIndex,false);
			}
		});
		askLeaveListHelper.loadData(ASKLEAVE_LIST, pageIndex,true);
	}

	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.system_back:// 返回
			finish();
			break;
		case R.id.btn_top_right:// 新建
			UIHelper.forwardTargetActivity(AskLeaveActivity.this,
					AskleaveAddActivity.class, null, false);
			break;
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == ASKLEAVE_LIST) {
					askLeaveListHelper.process(response, what);
				}
				else if(what == Constants.OPT_TYPE_LEAVE_DETAIL){
					//请假详情返回
					AskLeaveItemHelper leaveItemHelper= new AskLeaveItemHelper();
					leaveItemHelper.process(mContext, response, true);
				}
			}
		}
	};

	protected void buildHandler() {
		indexHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				int what = msg.what;
			}
		};
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}

	public Handler getIndexHandler() {
		return indexHandler;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	@Override
	protected void onResume() {
		try {
			// 恢复界面时，加载最新的第一页数据
			pageIndex = 1;
			askLeaveListHelper.loadData(ASKLEAVE_LIST, pageIndex, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.onResume();
	}

}
