package com.powerriche.mobile.na.oa.activity;
	
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
	
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
	
/**	
 * 类描述：<br> 通知公告：详情
 * 	
 * @author 李运期
 * @date 2015年5月5日
 * @version v1.0
 */	
public class NoticeDetailActivity extends BaseActivity implements OnClickListener {
	
	private final String	TAG	= "NoticeDetailActivity";
	
	private Context				mContext;
	
	private TopActivity			topActivity;
	
	//基本信息界面相关
	private TextView etNoticeTitle, etNoticeType, etNoticeToStaffNoName, etNoticeBeginTime, etNoticeEndTime;
	private EditText			etNoticeToStaffNo;
	private WebView				wvNoticeContent;
	private LinearLayout		llNoticeToStaffNo;
	
	private String				noticeId, noticeType;
	private String				noticeTitle;
//	private String				noticeContent;
	private String				noticeContentHtml;
	private String				noticeToStaffNo, noticeToStaffName;
	private String				noticeBeginTime, noticeEndTime;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.notice_detail);
		
		noticeId = getIntent().getStringExtra("noticeId");//通知公告的ID
		noticeType = getIntent().getStringExtra("noticeType");//通知公告的类型
		
		etNoticeTitle = (TextView) findViewById(R.id.et_notice_title);
		etNoticeType = (TextView) findViewById(R.id.et_notice_type);
		etNoticeToStaffNo = (EditText) findViewById(R.id.et_notice_to_staffno);
		etNoticeToStaffNoName = (TextView) findViewById(R.id.et_notice_to_staffno_name);
		etNoticeBeginTime = (TextView) findViewById(R.id.et_notice_begin_time);
		etNoticeEndTime = (TextView) findViewById(R.id.et_notice_end_time);
		wvNoticeContent = (WebView) findViewById(R.id.wv_notice_content);
		llNoticeToStaffNo = (LinearLayout) findViewById(R.id.ll_notice_to_staffno);
		
		if ("0".equals(noticeType)) {
			etNoticeType.setText("公告");
			llNoticeToStaffNo.setVisibility(View.GONE);
		} else {
			etNoticeType.setText("通知");
		}
		
		bindViews();
		
		//请求详情接口
		ApiRequest request = OAServicesHandler.getNoticeDetials(BeanUtils.floatToInt4Str(noticeId), BeanUtils.floatToInt(noticeType));
		if (request != null) {
			request.setMessage(getString(R.string.system_load_message));//请求中提示语
			helper.invokeWidthDialog(request, callBack, 1);
		}
		
	}	
		
	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.menu_notice));
		topActivity.setBtnBackOnClickListener(this);
		
		topActivity.setRightBtnVisibility(View.VISIBLE);
	}	
		
	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_back){
			finish();
			
		}else if(id == R.id.btn_top_right){
			if (noticeId == null || noticeType == null) {
				return;
			}
			Bundle data = new Bundle();
			data.putString("noticeId", noticeId);
			data.putString("noticeType", noticeType);
			UIHelper.forwardTargetActivity(mContext, NoticeEditActivity.class, data, true);
		}	
			
	}		
			
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				
				//解析返回的数据
				ResultItem noticeItem = response.getResultItem(ResultItem.class).getItems("data").get(0);
				
				noticeTitle = noticeItem.getString("NOTICE_TITLE");//标题
				noticeToStaffNo = noticeItem.getString("NOTICE_STAFF_NO");//被通知人的ID
				noticeToStaffName = noticeItem.getString("NOTICE_STAFF_NAME");//被通知人的姓名
				noticeBeginTime = noticeItem.getString("BEGIN_TIME");//开始时间
				noticeEndTime = noticeItem.getString("END_TIME");//结束时间
//				noticeContent = noticeItem.getString("NOTICE_CONTENT");//通知公告的内容（纯文本）
				noticeContentHtml = noticeItem.getString("NOTICE_CONTENT_CLOB");//通知公告的内容（HTML）
				
				etNoticeTitle.setText(noticeTitle == null ? "" : noticeTitle);
				etNoticeToStaffNo.setText(noticeToStaffNo == null ? "" : noticeToStaffNo);
				etNoticeToStaffNoName.setText(noticeToStaffName == null ? "" : noticeToStaffName);
				etNoticeBeginTime.setText(noticeBeginTime == null ? "" : noticeBeginTime);
				etNoticeEndTime.setText(noticeEndTime == null ? "" : noticeEndTime);
				wvNoticeContent.loadData((noticeContentHtml == null ? "" : noticeContentHtml), "text/html;charset=UTF-8", null);
			}   
		}		
	};			
				
}				
