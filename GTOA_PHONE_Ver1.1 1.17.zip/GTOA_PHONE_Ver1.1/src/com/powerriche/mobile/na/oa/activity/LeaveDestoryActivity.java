package com.powerriche.mobile.na.oa.activity;

import java.util.Date;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.LeaveDetail;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * @title  销假表单
 * @author dir_wang
 * @date   2016-7-12下午5:33:06
 */
public class LeaveDestoryActivity extends BaseActivity implements
		OnClickListener, OnCheckedChangeListener {

	private static final int REQUEST_LEAVE_DESTROY = 0;

	private RadioGroup leaveCatalogRg;

	private RadioButton leaveRb, paidRb;

	private TextView leaveType;

	private Context mContext;

	public static String LEAVE_OPERATETYPE = Constants.LEAVE_OPERATETYPE_ADD;

	private LeaveDetail detail;

	private TextView tv_leave_begin_time;
	private TextView tv_leave_end_time;
	private TextView tv_leave_total_days;
	private TextView tv_leave_people;
	private EditText et_leave_real_time;
	private TextView tv_leave_real_days;
	private Button btn_leave;

	private float totalDays;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.leave_destory);
		detail = (LeaveDetail) getIntent().getSerializableExtra("detail");
		bindViews();
	}

	private void bindViews() {

		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.leave_form));
		topActivity.setBtnBackOnClickListener(this);
		tv_leave_begin_time = (TextView) findViewById(R.id.tv_leave_begin_time);
		tv_leave_end_time = (TextView) findViewById(R.id.tv_leave_end_time);
		tv_leave_total_days = (TextView) findViewById(R.id.tv_leave_total_days);
		tv_leave_people = (TextView) findViewById(R.id.tv_leave_people);
		et_leave_real_time = (EditText) findViewById(R.id.et_leave_real_time);
		tv_leave_real_days = (TextView) findViewById(R.id.tv_leave_real_days);
		btn_leave = (Button) findViewById(R.id.btn_leave);
		et_leave_real_time.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_HOUR_FORMAT));
		et_leave_real_time.setOnClickListener(this);
		btn_leave.setOnClickListener(this);
		
		if (detail != null) {
			tv_leave_begin_time.setText(detail.getBeginTime());
			tv_leave_end_time.setText(detail.getEndTime());
			String leaveTotalDays = detail.getLeaveTotalDays();
			tv_leave_total_days.setText(BeanUtils.floatToInt4Str(leaveTotalDays) + "天");
			tv_leave_people.setText(detail.getLeaveRealName());
			// 检验时间范围
			getRealTotalDays();
			et_leave_real_time.addTextChangedListener(new TextWatcher() {
				
				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					getRealTotalDays();
				}
				
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count,
						int after) {
					
				}
				
				@Override
				public void afterTextChanged(Editable s) {
					
				}
			});
		}
		
	}
	// 获取实际的休假天数
	private void getRealTotalDays() {
		Date beginDate = DateUtils.parseDate(detail.getBeginTime() + ":00", DateUtils.DATETIME_FORMAT);
		Date endDate = DateUtils.parseDate(et_leave_real_time.getText().toString().trim() + ":00", DateUtils.DATETIME_FORMAT);
		totalDays = DateUtils.getTotalDays(beginDate, endDate);
		detail.setRealLeaveTotalDays(String.valueOf(totalDays));
		String realLeaveTotalDays = detail.getRealLeaveTotalDays();
		tv_leave_real_days.setText(realLeaveTotalDays.endsWith(".0") ? realLeaveTotalDays.replace(".0", "") + "天" : realLeaveTotalDays + "天");
	}
	// 销假
	private void destroyLeave() {
		ApiRequest request = OAServicesHandler.destroyLeave(detail.getLeaveId(), detail.getRealLeaveTotalDays(), et_leave_real_time.getText().toString().trim());
		helper.invokeWidthDialog(request, callBack, REQUEST_LEAVE_DESTROY);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {
			LeaveDestoryActivity.this.finish();
		} else if (id == R.id.et_leave_real_time) {
			UIHelper.showTimeSelect(mContext, et_leave_real_time, DateUtils.DATE_HOUR_FORMAT);
		} else if (id == R.id.btn_leave) {
			destroyLeave();
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup rg, int checkedId) {
		if (checkedId == leaveRb.getId()) {
			leaveCatalogRg.setTag(leaveRb.getTag().toString());
		} else if (checkedId == paidRb.getId()) {
			leaveCatalogRg.setTag(paidRb.getTag().toString());
		}
		//去除已经选择的请假类型
		leaveType.setText("");
		leaveType.setTag("");
	}


	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
            ResultItem item = response.getResultItem(ResultItem.class);
            if (checkResult(item)) {
                String code = item.getString("code");
                String message = item.getString("message");
                if (Constants.SUCCESS_CODE.equals(code)) {
                	if (what == REQUEST_LEAVE_DESTROY) {
                		UIHelper.showMessage(mContext, message);
	                    LeaveDestoryActivity.this.finish();
                	}
                } else {
                    UIHelper.showMessage(mContext, message);
                }
            }
        }

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			toAskLeaveList();
		}
		return super.onKeyDown(keyCode, event);
	}

	// 调转列表页面
	public void toAskLeaveList() {
		finish();
	}


}
