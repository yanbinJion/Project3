package com.powerriche.mobile.na.oa.activity.document;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.AskLeaveDetailActivity;
import com.powerriche.mobile.na.oa.activity.AskleaveAddActivity;
import com.powerriche.mobile.na.oa.activity.AskleaveApprovalActivity;
import com.powerriche.mobile.na.oa.activity.LeaveDetailActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.UserLeaveInfo;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : AskLeaveItemHelper.java
 * 
 * @Description : 请假详情
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-24 09:38:24
 */
public class AskLeaveItemHelper implements OnClickListener {

	// 请假id
	private String askLeaveId;

	/** 申请人 */
	private TextView applicantView;

	/** 申请日期 */
	private TextView applyDateView;

	/** 请假类别 */
	private TextView catalog;

	/** 请假类型 */
	private TextView leaveType;

	/** 请假原因 */
	private TextView leaveReason;

	/** 请假申请开始时间 */
	private TextView startTime;

	/** 请假申请结束时间 */
	private TextView endTime;

	/** 请假天数 */
	private TextView totalDays;

	private TextView tvApprovalGroup;

	private LinearLayout llApprovalWrap;

	private InvokeHelper helper = null;

	private Context context = null;

	private IRequestCallBack callBack = null;

	// private Handler handler;
	public AskLeaveItemHelper(){
		
	}
	
	public AskLeaveItemHelper(Context context, View contextView, int what) {
		this.context = context;
		// 等于1是审批，其他全是详情
		if (what == 1) {
			AskleaveApprovalActivity acitvity = (AskleaveApprovalActivity) context;
			this.helper = acitvity.getInvokeHelper();
			this.callBack = acitvity.getCallBack();
		} else {
			AskLeaveDetailActivity acitvity = (AskLeaveDetailActivity) context;
			this.helper = acitvity.getInvokeHelper();
			this.callBack = acitvity.getCallBack();
		}
		// this.handler = acitvity.getIndexHandler();
		// 申请人
		applicantView = (TextView) contextView
				.findViewById(R.id.tv_text_applicant);
		// 申请日期
		applyDateView = (TextView) contextView.findViewById(R.id.tv_apply_date);
		// 请假类别
		catalog = (TextView) contextView.findViewById(R.id.tv_leave_catalog);
		// 请假类型
		leaveType = (TextView) contextView.findViewById(R.id.tv_leave_type);
		// 请假原因
		leaveReason = (TextView) contextView.findViewById(R.id.tv_leave_reason);
		// 请假申请开始时间
		startTime = (TextView) contextView.findViewById(R.id.tv_leave_from);
		// 请假申请结束时间
		endTime = (TextView) contextView.findViewById(R.id.tv_leave_to);
		// 请假天数
		totalDays = (TextView) contextView.findViewById(R.id.tv_askleave_total);
		// 审批列表
		tvApprovalGroup = (TextView) contextView
				.findViewById(R.id.tv_approval_list);
		tvApprovalGroup.setOnClickListener(this);
		tvApprovalGroup.setTag(true);
		tvApprovalGroup.setVisibility(View.GONE);
		llApprovalWrap = (LinearLayout) contextView
				.findViewById(R.id.ll_approval_list);
		llApprovalWrap.setVisibility(View.GONE);

	}

	public void loadItem(String id,ResultItem item) {
		this.askLeaveId = id;
		// 清空数据
		// 申请人
		applicantView.setText("");
		// 申请日期
		applyDateView.setText("");
		// 请假类别
		catalog.setText("");
		// 请假类型
		leaveType.setText(Constants.LEAVE_TYPE_MAP.get(1));
		// 请假原因
		leaveReason.setText("");
		// 请假申请开始时间
		startTime.setText(DateUtils.getDateStr());
		// 请假申请结束时间
		endTime.setText(DateUtils.getDateStr());
		
		processBaseInfo(item);
		//
	}
	
	/**
	 * 
	 * @param what
	 */
	public void searhData(int what){
		this.askLeaveId = Constants.DOCUMENT_ID;
		helper.invokeWidthDialog(OAServicesHandler.getAskLeaveDetail(askLeaveId), callBack, what);
	}

	/**
	 * 审批
	 * 
	 * @param bean
	 * @param what
	 */
	public void approvalLeave(UserLeaveInfo bean, int what) {
		helper.invokeWidthDialog(OAServicesHandler.approvalLeave(bean),
				callBack, what);
	}

	/**
	 * 加载数据
	 * @param context
	 * @param response
	 * @param isApproval
	 * @param id
	 */
	public void process(Context context, HttpResponse response, boolean isApproval) {
		try {
			this.context = context;
			this.askLeaveId = Constants.DOCUMENT_ID;
			List<ResultItem> items = response.getResultItem(ResultItem.class)
					.getItems("data");
			if (!BeanUtils.isEmpty(items)) {
				ResultItem item = items.get(0);

				String canmodifyLeave = item.getString("CANMODIFYLEAVE");// 是否可以修改（0不可修改；1可修改）
				String result = item.getString("RESULT");//0:待办 退件（IS_FIRST_FPU==0）和送出;1:已办，只有撤回；
				String applyStaffno = item.getString("APPLY_STAFFNO");// 申请人编号
				
				String isLeavePass = BeanUtils.floatToInt4Str(item.getString("IS_LEAVE_PASS"));//审批状态（默认是0(申请中)，1是通过，-1是未通过）
				
				// 判断是否是进行修改
				int canmodify = BeanUtils.floatToInt(canmodifyLeave);
				//1可以修改，并且是自己的请假  -1 拒绝
				if ((canmodify == 1	|| "-1".equals(isLeavePass)) && SystemContext.getAccount().equals(applyStaffno)) {
					toModifyLeave(item);
					return;
				}else{
					//必须是自己的待办，并且是审批
					int resultCode = BeanUtils.floatToInt(result);
					//审批，申请中的数据
					if(isApproval && resultCode == 0 && "0".equals(isLeavePass)){
						toApprovalLeave(item);
					}else{
						toDetailLeave(item);
					}
					return;
				}
			}else{
				Toast.makeText(this.context, this.context.getString(R.string.system_net_error_message),
						Toast.LENGTH_SHORT).show();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 绑定基本信息
	 * @param item
	 */
	public void processBaseInfo(ResultItem item){
		
		this.askLeaveId = Constants.DOCUMENT_ID;
		// 申请人
		String applicant = item.getString("APPLY_REALNAME");
		applicantView.setText(applicant);

		// 申请日期
		String applyTime = item.getString("APPLY_TIME");
		applyDateView.setText(applyTime);

		// 请假类别 0请假，1调休
		String leaveCatalog = item.getString("LEAVE_CATALOG");
		catalog.setText(BeanUtils.floatToInt(leaveCatalog) == 0 ? "请假" : "调休");

		// 请假类型
		String type = item.getString("LEAVE_TYPE");
		leaveType.setText(Constants.LEAVE_TYPE_MAP.get(BeanUtils.floatToInt(type)));

		// 请假原因
		String reason = item.getString("LEAVE_REASON");
		leaveReason.setText(reason);

		// 请假申请开始时间
		String beginTime = item.getString("BEGIN_TIME");
		startTime.setText(context.getString(R.string.askleave_from)
				+ "  " + beginTime);

		// 请假申请结束时间
		String end_time = item.getString("END_TIME");
		endTime.setText(context.getString(R.string.askleave_to) + "  "
				+ end_time);

		// 请假天数
		String total_days = item.getString("LEAVE_TOTAL_DAYS");
		totalDays
				.setText(context.getString(R.string.askleave_total)
						+ total_days
						+ context.getString(R.string.askleave_day));

		// 审批列表
		processApprovalList(item);
	}
	/***
	 * 审批列表的数据
	 * 
	 * @param item
	 */
	public void processApprovalList(ResultItem item) {
		// 办理信息
		List<ResultItem> processItems = item.getItems("LeaveNotes");
		if (processItems != null && processItems.size() > 0) {
			for (ResultItem processItem : processItems) {
				String processor = processItem.getString("PROCESSOR"); // 审批人
				String department = processItem
						.getString("PROCESSOR_DEPT_NAME"); // 审批人所在部门
				String datatime = processItem.getString("SAVE_DATE"); // 审批时间
				String suggest = processItem.getString("DATA"); // 审批意见
				ViewHolder holder = new ViewHolder();

				View view = LayoutInflater.from(context).inflate(
						R.layout.leave_approval_item, null);

				holder.tvApproName = (TextView) view
						.findViewById(R.id.tv_appro_name);
				holder.tvLeaveSite = (TextView) view
						.findViewById(R.id.tv_leave_site);
				holder.tvApproTime = (TextView) view
						.findViewById(R.id.tv_appro_time);
				holder.tvApproReason = (TextView) view
						.findViewById(R.id.tv_appro_reason);

				holder.tvApproName.setText(processor);
				holder.tvLeaveSite.setText(department);
				holder.tvApproTime.setText(datatime);
				holder.tvApproReason.setText(suggest);
				llApprovalWrap.addView(view);
			}
			llApprovalWrap.setVisibility(View.VISIBLE);
			tvApprovalGroup.setVisibility(View.VISIBLE);
		}
	}

	private class ViewHolder {
		TextView tvApproName;
		TextView tvLeaveSite;
		TextView tvApproTime;
		TextView tvApproReason;
	}

	@Override
	public void onClick(View v) {

		if (v.getId() == R.id.system_back) {
			// finish();
		} else if (v.getId() == R.id.tv_approval_list) {
			isApprovalGroup();
		}
	}

	public void isApprovalGroup() {
		// 初始化时展开的
		boolean flag = (Boolean) tvApprovalGroup.getTag();
		if (flag) {
			tvApprovalGroup.setTag(false); // 关闭
			tvApprovalGroup.setCompoundDrawables(null, null,
					UIHelper.openDrawable(context, R.drawable.ic_arrows_open), null);
			llApprovalWrap.setVisibility(View.GONE);
		} else {
			tvApprovalGroup.setTag(true);
			tvApprovalGroup.setCompoundDrawables(null, null,
					UIHelper.closeDrawable(context, R.drawable.ic_arrows_close), null);
			llApprovalWrap.setVisibility(View.VISIBLE);
		}
	}

	/** 进行修改数据 */
	public void toModifyLeave(ResultItem item) {
		Intent mIntent = new Intent(this.context, AskleaveAddActivity.class);
		Bundle mBundle = new Bundle();
		item.addValue("leaveId", askLeaveId);
		mBundle.putSerializable("item", item);
		mIntent.putExtras(mBundle);
		mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
		this.context.startActivity(mIntent);
	}
	
	/** 进行审批 */
	public void toApprovalLeave(ResultItem item) {
		Intent mIntent = new Intent(this.context, AskleaveApprovalActivity.class);
		Bundle mBundle = new Bundle();
		item.addValue("leaveId", askLeaveId);
		mBundle.putSerializable("item", item);
		mIntent.putExtras(mBundle);
		mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
		this.context.startActivity(mIntent);
	}
	
	/** 进行详情 */
	public void toDetailLeave(ResultItem item) {
		Intent mIntent = new Intent(this.context, LeaveDetailActivity.class);
		Bundle mBundle = new Bundle();
		item.addValue("leaveId", askLeaveId);
		mBundle.putSerializable("item", item);
		mIntent.putExtras(mBundle);
		mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
		this.context.startActivity(mIntent);
	}

	public String getAskLeaveId() {
		return askLeaveId;
	}

	public void setAskLeaveId(String askLeaveId) {
		this.askLeaveId = askLeaveId;
	}

}
