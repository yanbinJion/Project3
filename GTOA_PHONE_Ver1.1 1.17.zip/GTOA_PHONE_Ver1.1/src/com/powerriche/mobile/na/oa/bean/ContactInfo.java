package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * Created by root on 16-5-27.
 */
public class ContactInfo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 4770099840720587827L;
	private String contactId;
    private String contactName;
    private String phone;
    private String siteId;
    private String siteName;

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer("contacts: ");
        String blank = "   ";
        buffer.append("siteId: ").append(siteId).append(blank);
        buffer.append("siteName: ").append(siteName).append(blank);
        buffer.append("contactId: ").append(contactId).append(blank);
        buffer.append("contactName: ").append(contactName).append(blank);
        buffer.append("phone: ").append(phone).append(blank);
        return buffer.toString();
    }
}
