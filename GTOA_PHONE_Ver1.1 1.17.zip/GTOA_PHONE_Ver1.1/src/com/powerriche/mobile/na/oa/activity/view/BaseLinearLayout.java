package com.powerriche.mobile.na.oa.activity.view;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.widget.LinearLayout;
/**
 * 类说明：<br>
 * LinearLayout基类，用于MainActivity布局基础该类 
 * @author Fitz
 */
public abstract class BaseLinearLayout extends LinearLayout{
	
	/**
	 * 是否已经调用OnCreate方法
	 */
	public boolean isOnCreate = false;
	
	public boolean isExit = true;
	
	public BaseLinearLayout(Context context) {
		super(context);
	}
	
	public BaseLinearLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	
	/**
	 * 系统退出时，被调用(必须实现)
	 */
	public abstract void onDestroy();
	
	/**
	 * 当页面第一次显示在前端时，被调用，用于查询并显示数据,仅仅调用一次(必须实现)
	 */
	public abstract void onCreate(Intent intent);
	
	/**
	 * 页面每次显示在前端时，都被调用，用于页面间传递数据  (必须实现)
	 */
	public abstract void onShow(Intent intent);
	
	public void onResume(){
		
	}
	
	public void onPause(){
		
	}
	
}
