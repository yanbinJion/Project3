package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.TaskDetails;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.na.oa.bean.TaskDetails.HistoryProgress;
import com.powerriche.mobile.na.oa.bean.TaskDetails.Materials;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;
import com.powerriche.mobile.oa.tools.UIHelper;

public class ProgressMaterialsActivity extends BaseActivity implements
		View.OnClickListener, View.OnLongClickListener{
	protected static final int BASIC_REQUEST = 10;
	protected static final int UPLOAD_FILE = 11;
	private String documentId;
	private String taskId;
	private Context mContext;
	private TopActivity topActivity;
	private EditText et_progress_from_date, et_progress_to_date,
			et_progress_content, et_progress_complete_degree,
			et_progress_complete_time, et_progress_sum_human_cost,
			et_progress_sum_money, et_progress_sum_quantity,
			et_progress_sum_time, et_exist_problem;
	private TextView tv_require_material;
	private LinearLayout ll_require_material;
	private Button btn_task_report_progress;
	private ImageView iv_material;
	private ArrayList<View> views = new ArrayList<View>();
	private LayoutInflater mInflater;
	private TaskDetails detail = new TaskDetails();
	int reportTaskProgress = 0;
	private HistoryProgress historyProgress;
	private EditText et_material_brand;
	private EditText et_material_quantity;
	private EditText et_material_unit;
	private LinearLayout layout;
	private ScrollView scrollView;
	private Button btn_upload;
	private LinearLayout ll_file_upload;
	private TextView tv_file_group;
	private boolean isClickable = false;
	private String from_date;
	private String to_date;
	private String complete_time;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.task_report_progress);
		Intent intent = getIntent();
		if (null != intent) {
			documentId = intent.getStringExtra("documentId");
			taskId = intent.getStringExtra("taskId");
			from_date = intent.getStringExtra("progress_from_date");
			to_date = intent.getStringExtra("progress_to_date");
			complete_time = intent.getStringExtra("complete_time");
		}
		mContext = this;
		initView();
		initData();
		mInflater = getLayoutInflater();
		et_progress_from_date.setText(from_date);
		et_progress_to_date.setText(to_date);
		et_progress_complete_time.setText(complete_time);
	}

	// 初始化控件
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.task_report_progress));// 顶部栏的中间标题
		et_progress_from_date = (EditText) findViewById(R.id.et_progress_from_date);
		et_progress_to_date = (EditText) findViewById(R.id.et_progress_to_date);
		et_progress_content = (EditText) findViewById(R.id.et_progress_content);
		et_progress_complete_degree = (EditText) findViewById(R.id.et_progress_complete_degree);
		et_progress_complete_time = (EditText) findViewById(R.id.et_progress_complete_time);
		et_progress_sum_human_cost = (EditText) findViewById(R.id.et_progress_sum_human_cost);
		et_progress_sum_money = (EditText) findViewById(R.id.et_progress_sum_money);
		et_progress_sum_quantity = (EditText) findViewById(R.id.et_progress_sum_quantity);
		et_progress_sum_time = (EditText) findViewById(R.id.et_progress_sum_time);
		et_exist_problem = (EditText) findViewById(R.id.et_exist_problem);
		tv_require_material = (TextView) findViewById(R.id.tv_require_material);
		ll_require_material = (LinearLayout) findViewById(R.id.ll_require_material);
		btn_task_report_progress = (Button) findViewById(R.id.btn_task_report_progress);
		scrollView = (ScrollView) findViewById(R.id.scrollView);
		btn_upload = (Button) findViewById(R.id.btn_upload);
		ll_file_upload = (LinearLayout) findViewById(R.id.ll_file_upload);
		tv_file_group = (TextView) findViewById(R.id.tv_file_group);
		tv_file_group.setTag(true);
		tv_file_group.setVisibility(View.VISIBLE);
	}

	List<TaskDetails.Materials> materialsList = new ArrayList<TaskDetails.Materials>();

	// 设置数据
	private void initData() {
		et_progress_from_date.setOnClickListener(this);
		et_progress_to_date.setOnClickListener(this);
		et_progress_complete_time.setOnClickListener(this);
		tv_require_material.setOnClickListener(this);
		btn_task_report_progress.setOnClickListener(this);
		btn_upload.setOnClickListener(this);
		tv_file_group.setOnClickListener(this);
	}

	/**
	 * 上报进度
	 * @param progress
	 * @param materials
	 */
	private void reportProgress(HistoryProgress progress,
			List<Materials> materials) {
		ApiRequest request = OAServicesHandler.reportProgress(taskId,
				documentId, progress, materials);
		if (request != null) {
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, reportTaskProgress);
		}
	}
	int reportTaskProgressMaterial = 1;
	private void reportTaskProgressMaterial(String materialId, List<Materials> materials) {
		ApiRequest request = OAServicesHandler.reportTaskProgressMaterial(materialId, materials);
		if (request != null) {
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, reportTaskProgressMaterial);
		}
	}

	// 新增一个view
	private void addProgressMaterialView(int index) {
		layout = (LinearLayout) mInflater.inflate(R.layout.task_materials_item,
				null);
		et_material_brand = (EditText) layout
				.findViewById(R.id.et_material_brand);
		et_material_quantity = (EditText) layout
				.findViewById(R.id.et_material_quantity);
		et_material_unit = (EditText) layout
				.findViewById(R.id.et_material_unit);
		iv_material = (ImageView) layout.findViewById(R.id.iv_material);
		views.add(layout);
		setRemoveListener(iv_material, index);
		ll_require_material.addView(layout);
		TaskDetails.Materials materials = detail.new Materials();
		materials.setBrand(et_material_brand.getText().toString().trim());
		materials.setQuantity(et_material_quantity.getText().toString().trim());
		materials.setUnit(et_material_unit.getText().toString().trim());
		materialsList.add(materials);
	}

	// 设置删除事件和删除后view的显示
	private void setRemoveListener(ImageView img, final int size) {
		img.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if(views.size() > size) {
					views.remove(size);
					ll_require_material.removeViewAt(size);
					changeIndex();
				}
			}
		});
	}
	
	//修改删除或新增后，提示的显示
    private void changeIndex() {
        LinearLayout layout = null;
        for (int i = 0; i < ll_require_material.getChildCount(); i++) {
            layout = ((LinearLayout) ll_require_material.getChildAt(i));
            ImageView img = (ImageView) layout.findViewById(R.id.iv_material);
            setRemoveListener(img, i);
        }
        scrollToBottom();
    }

	private Handler mHanlder = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			if (null == msg) {
				return;
			}
			if(msg.what == UPLOAD_FILE) {
				ResultItem item = (ResultItem) msg.obj;
                String message = item.getString("message");
                UIHelper.showMessage(mContext, message);
                UIHelper.deleteTempDoc();	//退出前，删掉临时文件
			}
		}
	};

	// 当view的个数变化时，到最底下显示
	private void scrollToBottom() {
		mHanlder.post(new Runnable() {
			@Override
			public void run() {
				scrollView.fullScroll(ScrollView.FOCUS_DOWN);
			}
		});
	}

	private boolean setReturnMsg(String msg) {
		Toast.makeText(mContext, msg, Toast.LENGTH_SHORT)
				.show();
		return false;
	}

	/*
	 * 
	 */
	private boolean validateProgress() {
		if (historyProgress == null) {
			return false;
		}
		if (BeanUtils.isNullOrEmpty(historyProgress.getFromDate())) {
			return setReturnMsg("开始时间不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getToDate())) {
			return setReturnMsg("结束时间不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getContent())) {
			return setReturnMsg("进度内容不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getDegree())) {
			return setReturnMsg("完成度不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getCompleteTime())) {
			return setReturnMsg("完成时间不能为空");
		} /*else if (BeanUtils.isNullOrEmpty(historyProgress.getSumHumanCost())) {
			return setReturnMsg("所耗人力不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getSumMoney())) {
			return setReturnMsg("所耗财力不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getSumQuantity())) {
			return setReturnMsg("数量总和不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getSumTime())) {
			return setReturnMsg("时长总和不能为空");
		} else if (BeanUtils.isNullOrEmpty(historyProgress.getRemark())) {
			return setReturnMsg("存在问题不能为空");
		}*/
		// 检验时间范围
		Date begindate = DateUtils.parseDate(historyProgress.getFromDate(), "yyyy-MM-dd");
		Date enddate = DateUtils.parseDate(historyProgress.getToDate(), "yyyy-MM-dd");
		if (enddate.before(begindate)) {
			return setReturnMsg("结束时间不能早于开始时间");
		}
		return true;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == SDCardFileExplorerActivity.REQUEST_CODE_FILE
				&& data != null) {
			String fileName = data.getStringExtra("FILE_NAME");
			String filePath = data.getStringExtra("FILE_PATH");
			UIHelper.setFileWrap(mContext,
					ll_file_upload, this, this, fileName, filePath, "", "");
			if (ll_file_upload != null && ll_file_upload.getChildCount() > 0) {
				tv_file_group.setVisibility(View.VISIBLE);
			}
		}
	}

	private void setReportProgress() {
		if (historyProgress == null) {
			historyProgress = detail.new HistoryProgress();
		}
		historyProgress.setFromDate(et_progress_from_date.getText().toString()
				.trim());
		historyProgress.setToDate(et_progress_to_date.getText().toString()
				.trim());
		historyProgress.setContent(et_progress_content.getText().toString()
				.trim());
		historyProgress.setDegree(et_progress_complete_degree.getText()
				.toString().trim());
		historyProgress.setCompleteTime(et_progress_complete_time.getText()
				.toString().trim());
		historyProgress.setSumHumanCost(et_progress_sum_human_cost.getText()
				.toString().trim());
		historyProgress.setSumMoney(et_progress_sum_money.getText().toString()
				.trim());
		historyProgress.setSumQuantity(et_progress_sum_quantity.getText()
				.toString().trim());
		historyProgress.setSumTime(et_progress_sum_time.getText().toString()
				.trim());
		historyProgress.setRemark(et_exist_problem.getText().toString().trim());
	}
	
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			if(checkResult(resultItem)){
				String code = resultItem.getString("code");
				String message = resultItem.getString("message");
				if (Constants.SUCCESS_CODE.equals(code)) {
					if (reportTaskProgress == what) {
					   ResultItem resultItem2 = resultItem.getItems("data").get(0);
						String materialId = resultItem2.getString("progressDetailId");
//						Log.i("TEST", " materialId "+materialId+" materialsList ");
						reportTaskProgressMaterial(materialId, materialsList);
						if (ll_file_upload.getChildCount() > 0) {
							uploadFile(documentId, "", ll_file_upload,
									mHanlder, UPLOAD_FILE, detail.getFileList());
						} else {
							UIHelper.showMessage(mContext, message);
						}
					}
					
	            } else {
	                UIHelper.showMessage(mContext, message);
	            }
				showProgressDialog();
			}
			
			
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};
	
	 /** 附件上传 */
    public void uploadFile(String documentId, String swfNo, LinearLayout llFileWrap, Handler handler, int what, ArrayList<TaskDetails.FileInfo> fileList){
        if(llFileWrap!=null){
            int fileCount = llFileWrap.getChildCount();
            if(fileCount>0){
                List<File> files = new ArrayList<File>();
                for(int i = 0; i < fileCount; i++){
                    View view = llFileWrap.getChildAt(i);
                    TextView tv = (TextView) view.findViewById(R.id.tv_file_name);
                    String path = (String) tv.getTag();

                    File file = new File(path);
                    if(file!=null && file.exists()){
                        if (!BeanUtils.isEmpty(fileList)) {
                            for (TaskDetails.FileInfo temp : fileList) {
                                if (tv.getText().toString().trim().equals(temp.getFileName())) {
                                    continue;
                                }
                            }
                        }
                        files.add(file);
                    }
                }

                UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadFile", documentId, swfNo, "", what);
                params.setListFile(files);
                HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
                post.execute(params);
            }
        }
    }

	@Override
	public void onClick(View view) {
		Button back = topActivity.getBtnBack();
		if (view == back) {
			finish();
		} else if (view == tv_require_material) {
			isClickable = true;
			addProgressMaterialView(ll_require_material.getChildCount());
			scrollToBottom();
		} else if (view == btn_task_report_progress) {
			setReportProgress();
			if (!validateProgress()) {
				return;
			}
			reportProgress(historyProgress, materialsList);
		} else if (view == et_progress_from_date) {
			UIHelper.showTimeSelect(this, et_progress_from_date,
					DateUtils.DATE_FORMAT);
		} else if (view == et_progress_to_date) {
			UIHelper.showTimeSelect(this, et_progress_to_date,
					DateUtils.DATE_FORMAT);
		} else if (view == et_progress_complete_time) {
			UIHelper.showTimeSelect(this, et_progress_complete_time,
					DateUtils.DATE_FORMAT);
		} else if (view == btn_upload) {
			UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
		} else if(view == tv_file_group) {
			UIHelper.isOpenFile(mContext, tv_file_group, ll_file_upload);
		}
	}

	/**
	 * 对话框的形式显示进度是否继续上传
	 */
	private void showProgressDialog() {
		final SystemDialog chooseDialog = new SystemDialog(
				mContext);
		chooseDialog.setMessage("是否继续上报进度");
		chooseDialog.setOnConfirmClickListener(new View.OnClickListener() { // 确定按钮事件
					@Override
					public void onClick(View view) {
						isClickable = true;
						clearViews();
					}
				});
		chooseDialog.setOnCancelClickListener(new View.OnClickListener() { // 取消
					@Override
					public void onClick(View v) {
						if (chooseDialog != null) {
							chooseDialog.dismiss();
							ProgressMaterialsActivity.this.finish();
						}
					}
				});
		chooseDialog.show();
	}

	/**
	 * 清除所有控件的值
	 */
	private void clearViews() {
		et_progress_from_date.setText("");
		et_progress_to_date.setText("");
		et_progress_content.setText("");
		et_progress_complete_degree.setText("");
		et_progress_complete_time.setText("");
		et_progress_sum_human_cost.setText("");
		et_progress_sum_quantity.setText("");
		et_progress_sum_time.setText("");
		et_progress_sum_money.setText("");
		if (isClickable && layout != null) {
			et_material_brand.setText("");
			et_material_quantity.setText("");
			et_material_unit.setText("");
		}
		et_exist_problem.setText("");
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (ll_require_material.getChildCount() > 0) {
			ll_require_material.removeAllViews();
		}
		if (views != null) {
			views.clear();
		}
	}

	/**
	 * 长按删除附件
	 */
	@Override
	public boolean onLongClick(final View v) {
        UIHelper.vibrate(mContext, 50);	//震动下
        if(v.getId() == R.id.rl_add_item_wrap){
            final SystemDialog chooseDialog = new SystemDialog(mContext);
            chooseDialog.setMessage("确定要删除这条附件？");
            chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
                @Override
                public void onClick(View view) {
                    int fileSize = ll_file_upload.getChildCount();
                    if(fileSize > 0){
                        DocFileInfo bean = (DocFileInfo) v.getTag();
                        if(bean==null) return;

                        for(int i=0; i<fileSize; i++){
                            View fileView = ll_file_upload.getChildAt(i);
                            if(fileView==null){
                                continue;
                            }
                            TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
                            String tempPath = (String) tvFileName.getTag();
                            if(bean.getFilePath().equals(tempPath)){	//如果按钮相等，则删除这条数据
                            	ll_file_upload.removeViewAt(i);
                            }
                        }
                    }
                }
            });
            chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
                @Override
                public void onClick(View v) {
                    if(chooseDialog!=null){
                        chooseDialog.dismiss();
                    }
                }
            });
            chooseDialog.show();
        }
        return false;
    }

}
