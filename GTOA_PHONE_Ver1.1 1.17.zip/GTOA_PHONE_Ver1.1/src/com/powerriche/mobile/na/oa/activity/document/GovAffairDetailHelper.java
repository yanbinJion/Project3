package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.GovAffairAddActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 领导政务详情
 * @author  Fitz
 * @date    2015年5月6日
 * @version v1.0
 */
public class GovAffairDetailHelper {

	private Context context;
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;
	
	public GovAffairDetailHelper(Context context, IRequestCallBack callBack){
		this.context = context;
		this.callBack = callBack;
		this.helper = ((GovAffairAddActivity) this.context).getInvokeHelper();
	}
	
	public void getGovAffairDetails(String affairId,int what){
		ApiRequest request = OAServicesHandler.getGovAffairDetails(affairId);
	    if (request != null){
	    	helper.invokeWidthDialog(request, callBack,what);
	    }
	}
	
	
	public Map<String, Object> process(HttpResponse response, int what) {
		Map<String, Object> map = new HashMap<String, Object>();

		ResultItem item = response.getResultItem(ResultItem.class);
		if (!BeanUtils.isEmpty(item)) {
			String code = item.getString("code");
			// 操作成功
			if (Constants.SUCCESS_CODE.equals(code)) {
				processGovAffairInfo(item, map);
			}else{
				UIHelper.showMessage(context, item.getString("message"));
				((BaseActivity) context).finish();
			}
		}else{
			UIHelper.showMessage(context, context.getString(R.string.document_detail_empty));
			((BaseActivity) context).finish();
		}
		return map;
	}
	
	private void processGovAffairInfo(ResultItem item, Map<String, Object> map){
		item = item.getItems("data").get(0);

		map.put("beginData",item.getString("BEGIN_DATE"));
		map.put("beginTime",item.getString("BEGIN_TIME"));
		map.put("endData",item.getString("END_DATE"));
		map.put("endTime",item.getString("END_TIME"));
		map.put("leaderName",item.getString("LEADER_NAME"));//出席领导
		map.put("content",item.getString("AFFAIR_CONTENT"));	//活动内容
		map.put("address",item.getString("AFFAIR_ADDRESS"));	//活动地址
		map.put("documentId",item.getString("DOCUMENT_ID"));	//公文ID（为取附件而存在）有附件时才有doucumen_id
		map.put("comment",item.getString("AFFAIR_COMMENT"));	//备注
		map.put("arranger",item.getString("ARRANGER"));	//主板单位
		
		//附件编号
		processFileList(item, map);
		
	}
	
	private void processFileList(ResultItem item, Map<String, Object> map) {
		List<DocFileInfo> fileList = new ArrayList<DocFileInfo>();
		//获取附件数据
		List<ResultItem> fileItems = item.getItems("File"); //文件列表
		if (fileItems != null && fileItems.size() > 0) {
			for (ResultItem fileItem : fileItems) {
				String fileCode = fileItem.getString("FK_FILE_CODE"); //文件编号
				String fileName = fileItem.getString("FILE_NAME"); //文件名称
				String fileType = fileItem.getString("FILE_TYPE"); //文件类型
				String filePath = fileItem.getString("FILE_PATH"); //文件路径
				String fileTitle = fileItem.getString("FILE_TITLE");//文件标题
				
				long fileSize = -1;
				String fileSizeStr = BeanUtils.floatToInt4Str(fileItem.getString("FILE_SIZE"));//文件大小
				if(!BeanUtils.isEmpty(fileSizeStr)){
					fileSize = Integer.parseInt(fileSizeStr);
				}
				
				DocFileInfo fileBean = new DocFileInfo(fileCode, fileType, fileName, 0,fileSize);
				fileBean.setFilePath(filePath);
				fileBean.setFileTitle(fileTitle);
				fileList.add(fileBean);
			}
		}
		map.put("fileList", fileList);
	}
	
}
