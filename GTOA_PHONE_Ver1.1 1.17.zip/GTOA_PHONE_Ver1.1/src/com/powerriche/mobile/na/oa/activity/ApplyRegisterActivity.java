package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.FileInfo;
import com.powerriche.mobile.na.oa.bean.GoodsApplyDetails;
import com.powerriche.mobile.na.oa.bean.GoodsApplyDetails.ApplyDetails;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @title  申领登记
 * @author dir_wang
 * @date   2016-6-30上午11:09:19
 */
public class ApplyRegisterActivity extends BaseActivity implements View.OnClickListener, View.OnLongClickListener {

    private static final int REQUEST_RECEIVE_GOODS = 0;
	private final int UPLOAD_FILE = 11;
    private final String TAG = ApplyRegisterActivity.class.getSimpleName();

    private int contentSize = 1;
    private ViewPager mViewPager;
    private ImageView imageView;
    private Context mContext;

    private List<View> views;// Tab页面列表
    private TextView tv1, tv2;
    private View view1, view2;

    private Button rightBtn;// 右边的按钮图标
    private Button backBtn;
    private int offset = 0;// 动画图片偏移量
    private int currIndex = 0;// 当前页卡编号
    private int bmpW;// 动画图片宽度
    private EditText et_apply_title;
    private TextView tv_apply_proposer;
    private TextView tv_apply_time;
    private TextView tv_apply_department;
    private TextView tv_apply_type;
    private LinearLayout ll_apply_type;
    private EditText et_apply_type;
    private EditText et_apply_detail;
    private TextView tv_add_goods_apply;
    private LinearLayout apply_list_lay;

    private Button btn_file_upload;
    private TextView tv_file_group;
    private LinearLayout ll_file_upload;

    private ScrollView scrollView;

    LayoutInflater mInflater;
    private GoodsApplyDetails detail;
    private List<View> mViews = new ArrayList<View>();

    private Handler mHanlder = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            if (null == msg) {
                return;
            }
            if (msg.what == UPLOAD_FILE) {
                ResultItem item = (ResultItem) msg.obj;
                String message = item.getString("message");
                UIHelper.showMessage(mContext, message);
                UIHelper.deleteTempDoc();	//退出前，删掉临时文件
                ApplyRegisterActivity.this.finish();
            }
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.apply_register);
        Intent intent = getIntent();
        detail = (GoodsApplyDetails) intent.getSerializableExtra("applyDetail");
        mContext = this;
        initView();
        initImageView();
        initTextView();
        initViewPager();
        if (null == detail) {
        	initContentView(contentSize);
        }
    }
    

    private void initView() {
        TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
        topActivity.setTopTitle(getString(R.string.apply_register));
        topActivity.setBtnBackOnClickListener(this);
        topActivity.setRightBtnVisibility(View.VISIBLE);
        topActivity.setRightBtnStyle(getString(R.string.btn_submit_save));
        topActivity.setRightBtnOnClickListener(this);
        rightBtn = topActivity.getBtnRight();
        backBtn = topActivity.getBtnBack();
        mInflater = getLayoutInflater();
    }
    
    /**
     * 初始化动画
     */
    private void initImageView() {
        imageView = (ImageView) findViewById(R.id.cursor);
        bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenW = dm.widthPixels;// 获取分辨率宽度
        offset = (screenW / 2 - bmpW) / 2;// 计算偏移量
        Matrix matrix = new Matrix();
        matrix.postTranslate(offset, 0);
        imageView.setImageMatrix(matrix);// 设置动画初始位置
    }

    /**
     * 初始化头标
     */
    private void initTextView() {
        tv1 = (TextView) findViewById(R.id.tv_apply_info);
        tv2 = (TextView) findViewById(R.id.tv_apply_details);

        tv1.setOnClickListener(new MyOnClickListener(0));
        tv2.setOnClickListener(new MyOnClickListener(1));
    }


    /**
     * 方法说明：<br>
     * 初始化 页卡
     */
    private void initViewPager() {
        mViewPager = (ViewPager) findViewById(R.id.vp_pager);
        views = new ArrayList<View>();

        view1 = mInflater.inflate(R.layout.apply_info, null);
        view2 = mInflater.inflate(R.layout.apply_goods_details, null);

        views.add(view1);
        views.add(view2);
        mViewPager.setAdapter(new MyViewPagerAdapter(views));
        mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
        et_apply_title = (EditText) view1.findViewById(R.id.et_apply_title);
        tv_apply_proposer = (TextView) view1.findViewById(R.id.tv_apply_proposer);
        tv_apply_time = (TextView) view1.findViewById(R.id.tv_apply_time);    
        tv_apply_department = (TextView) view1.findViewById(R.id.tv_apply_department);
        tv_apply_type = (TextView) view1.findViewById(R.id.tv_apply_type);
        ll_apply_type = (LinearLayout) view1.findViewById(R.id.ll_apply_type);
        et_apply_type = (EditText) view1.findViewById(R.id.et_apply_type);
        et_apply_detail = (EditText) view1.findViewById(R.id.et_apply_detail);
        tv_file_group = (TextView) view1.findViewById(R.id.tv_file_group);
		tv_file_group.setTag(true);
		tv_file_group.setVisibility(View.VISIBLE);
		ll_file_upload = (LinearLayout) view1.findViewById(R.id.ll_file_upload);
        btn_file_upload = (Button) view1.findViewById(R.id.btn_file_upload);
        
        tv_apply_proposer.setText(SystemContext.getUserName());
        tv_apply_department.setText(SystemContext.getSiteName());
        tv_apply_type.setText(UIHelper.getGoodsApplyType(ApplyRegisterActivity.this,String.valueOf(tv_apply_type.getTag())));
        tv_apply_time.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT));
        tv_apply_time.setOnClickListener(this);
        tv_apply_type.setOnClickListener(this);
        tv_file_group.setOnClickListener(this);
        btn_file_upload.setOnClickListener(this);
        
        scrollView = (ScrollView) view2.findViewById(R.id.scrollView);
        tv_add_goods_apply = (TextView) view2.findViewById(R.id.tv_add_goods_apply);
        apply_list_lay = (LinearLayout) view2.findViewById(R.id.apply_list_lay);
        tv_add_goods_apply.setOnClickListener(this);
        
        if (detail != null) {
        	et_apply_title.setText(detail.getReceiveTitle());
        	String type = BeanUtils.floatToInt4Str(detail.getReceiveType());
        	if (type.equals("0") || type.equals("1") || type.equals("2")) {
    			tv_apply_type.setText(UIHelper.getGoodsApplyType(ApplyRegisterActivity.this,type));
    			tv_apply_type.setTag(type);
    		} else {
    			tv_apply_type.setText(detail.getReceiveTypeName());
    			tv_apply_type.setTag(type);
    			et_apply_type.setText(detail.getReceiveTypeName());
    		}
        	et_apply_detail.setText(detail.getGoodsDetail());
        	
        	if (detail.getApplyDetails() != null) {
    			int size = detail.getApplyDetails().size();
    			showGoodsDetail(detail.getApplyDetails());
    			for (int i = 0; i < size; i++) {
    				LinearLayout child = (LinearLayout) apply_list_lay.getChildAt(i);
    				EditText et_goods_name = (EditText) child.findViewById(R.id.et_goods_name);
    				EditText et_goods_remark = (EditText) child.findViewById(R.id.et_goods_remark);
    				EditText et_goods_counts = (EditText) child.findViewById(R.id.et_goods_counts);
    				List<GoodsApplyDetails.ApplyDetails> applyDetails = detail.getApplyDetails();
    				et_goods_name.setText(applyDetails.get(i).getGoods());
    				et_goods_remark.setText(applyDetails.get(i).getRemark());
    				et_goods_counts.setText(applyDetails.get(i).getCounts());
    			}
    		}
        	
			if (null != detail.getFileList()) {
				for (DocFileInfo file : detail.getFileList()) {
					UIHelper.setFileWrap(mContext, ll_file_upload, this, this, file.getFileName(), "", file.getFileCode(), "");
					if (ll_file_upload != null && ll_file_upload.getChildCount() > 0) {
						ll_file_upload.setVisibility(View.VISIBLE);
					}
				}
			}
        }
        
    }
    
    /**
	 * 保存申领
	 * @param progress
	 * @param materials
	 */
	private void saveReceiveGoods(GoodsApplyDetails apply) {
		ApiRequest request = OAServicesHandler.saveReceiveGoods(apply);
		if (request != null) {
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, REQUEST_RECEIVE_GOODS);
		}
	}


    private class MyOnClickListener implements View.OnClickListener {
        private int index=0;
        public MyOnClickListener(int i){
            index=i;
        }
        public void onClick(View v) {
            mViewPager.setCurrentItem(index);
        }
    }


    public class MyViewPagerAdapter extends PagerAdapter {
        private List<View> mListViews;

        public MyViewPagerAdapter(List<View> mListViews){
            this.mListViews = mListViews;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object){
            container.removeView(mListViews.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(mListViews.get(position), 0);

            if(currIndex==0){
                UIHelper.setTabTextHighlight(mContext, tv1, tv2);
            }

            return mListViews.get(position);
        }

        @Override
        public int getCount() {
            return  mListViews.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0==arg1;
        }
    }



    public class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {
        int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

        public void onPageScrollStateChanged(int arg0) {

        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        public void onPageSelected(int arg0) {
            Animation animation = new TranslateAnimation(one*currIndex, one*arg0, 0, 0);
            currIndex = arg0;
            animation.setFillAfter(true);// True:图片停在动画结束位置
            animation.setDuration(300);
            imageView.startAnimation(animation);

            if(currIndex==0){
                UIHelper.setTabTextHighlight(mContext, tv1, tv2);

            }else if(currIndex==1){
                UIHelper.hideKeyboard(ApplyRegisterActivity.this);	//隐藏软键盘
                UIHelper.setTabTextHighlight(mContext, tv2, tv1);
            }
        }
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            ResultItem item = response.getResultItem(ResultItem.class);
            if (checkResult(item)) {
                String code = item.getString("code");
                String message = item.getString("message");
                if (Constants.SUCCESS_CODE.equals(code)) {
                    if (ll_file_upload.getChildCount() > 0 && REQUEST_RECEIVE_GOODS == what) {
                        String documentId = null;
                        String swfNo = null;
                        List<DocFileInfo> fileList = null;
                        if (null != detail) {
                            documentId = detail.getDocumentId();
                            fileList = detail.getFileList();
                        } else {
                        	List<ResultItem> items = item.getItems("data");
							documentId = items.get(0).getString("DOCUMENT_ID");
							swfNo = items.get(0).getString("SWF_NO");
//                            documentId = item.getString("document_id");
                        }
                        uploadFile(documentId,swfNo, ll_file_upload, mHanlder, UPLOAD_FILE, fileList);
                    }
                    UIHelper.showMessage(mContext, message);
                    ApplyRegisterActivity.this.finish();
                } else {
                    rightBtn.setEnabled(true);
                    UIHelper.showMessage(mContext, message);
                }
            }
        }

        @Override
        public void onReturnError(HttpResponse response, ResultItem error,
                                  int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_data_error_message));
        }

        @Override
        public void onNetError(int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_net_error_message));
        }

    };

    @Override
    public void onClick(View view) {
        if (backBtn == view) {
            UIHelper.deleteTempDoc();	//退出前，删掉临时文件
            finish();
        } else if(rightBtn == view) {
        	setApplyInfo();
			if (!validateApply()) {
				return;
			}
        	saveReceiveGoods(goodsApplyDetails);
        } else if(tv_apply_type == view) {
        	UIHelper.showGoodsApplyType(mContext, tv_apply_type,ll_apply_type);
        } else if(tv_add_goods_apply == view) {
        	 addContent(apply_list_lay.getChildCount(), null);
             scrollToBottom();
        } else if (btn_file_upload == view) {
            //点击添加附件
            UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
        } else if (tv_file_group == view) {
        	UIHelper.isOpenFile(mContext, tv_file_group, ll_file_upload);
        }
    }

    @Override
    public boolean onLongClick(final View v) {
        UIHelper.vibrate(mContext, 50);	//震动下
        if(v.getId() == R.id.rl_add_item_wrap){
            final SystemDialog chooseDialog = new SystemDialog(mContext);
            chooseDialog.setMessage("确定要删除这条附件？");
            chooseDialog.setOnConfirmClickListener(new View.OnClickListener() {	//确定按钮事件
                @Override
                public void onClick(View view) {
                    int fileSize = ll_file_upload.getChildCount();
                    if(fileSize > 0){
                        DocFileInfo bean = (DocFileInfo) v.getTag();
								if (bean == null)
									return;
								for (int i = 0; i < fileSize; i++) {
									View fileView = ll_file_upload.getChildAt(i);
									if (fileView == null) {
										continue;
									}
									TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
									String tempPath = (String) tvFileName.getTag();
									if (bean.getFilePath().equals(tempPath)) { // 如果按钮相等，则删除这条数据
										ll_file_upload.removeViewAt(i);
									}
								}
                    }
                }
            });
            chooseDialog.setOnCancelClickListener(new View.OnClickListener() {		//取消
                @Override
                public void onClick(View v) {
                    if(chooseDialog!=null){
                        chooseDialog.dismiss();
                    }
                }
            });
            chooseDialog.show();
        }
        return false;
    }

    @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == SDCardFileExplorerActivity.REQUEST_CODE_FILE
				&& data != null) {
			String fileName = data.getStringExtra("FILE_NAME");
			String filePath = data.getStringExtra("FILE_PATH");
			UIHelper.setFileWrap(mContext, ll_file_upload, this, this, fileName, filePath, "", "");
			if (ll_file_upload != null && ll_file_upload.getChildCount() > 0) {
				tv_file_group.setVisibility(View.VISIBLE);
			}
		}
	}
    
    /** 附件上传 */
    private void uploadFile(String documentId, String swfNo, LinearLayout llFileWrap, Handler handler, int what, List<DocFileInfo> fileList){
        if(llFileWrap!=null){
            int fileCount = llFileWrap.getChildCount();
            if(fileCount>0){
                List<File> files = new ArrayList<File>();
                for(int i = 0; i < fileCount; i++){
                    View view = llFileWrap.getChildAt(i);
                    TextView tv = (TextView) view.findViewById(R.id.tv_file_name);
                    String path = (String) tv.getTag();

                    File file = new File(path);
					if (file != null && file.exists()) {
                        if (!BeanUtils.isEmpty(fileList)) {
                            for (DocFileInfo temp : fileList) {
                                if (tv.getText().toString().trim().equals(temp.getFileName())) {
                                    continue;
                                }
                            }
                        }
                        files.add(file);
                    }
                }

                UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadFile", documentId, swfNo, "", what);
                params.setListFile(files);
                HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
                post.execute(params);
            }
        }
    }

    private boolean validateApply() {
    	if(null == goodsApplyDetails) {
    		return false;
    	}
    	if (BeanUtils.isNullOrEmpty(goodsApplyDetails.getReceiveTitle())) {
            return setReturnMsg("标题不能为空");
        }
    	if (apply_list_lay.getChildCount() < 0) {
            if (BeanUtils.isEmpty(apply_list_lay)) {
                return setReturnMsg(getString(R.string.apply_detail_not_null));
            }
        }
    	applyDetails = new ArrayList<GoodsApplyDetails.ApplyDetails>();
        for (int i = 0; i < apply_list_lay.getChildCount(); i++) {
        	LinearLayout child = (LinearLayout) apply_list_lay.getChildAt(i);
        	EditText et_goods_name = (EditText) child.findViewById(R.id.et_goods_name);
        	EditText et_goods_remark = (EditText) child.findViewById(R.id.et_goods_remark);
        	EditText et_goods_counts = (EditText) child.findViewById(R.id.et_goods_counts);
        	String goods_name = et_goods_name.getText().toString().trim();
        	String goods_remark = et_goods_remark.getText().toString().trim();
        	String goods_counts = et_goods_counts.getText().toString().trim();
        	if (BeanUtils.isNullOrEmpty(goods_name)) {
                Toast.makeText(this, R.string.goods_name_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
            if (BeanUtils.isNullOrEmpty(goods_remark)) {
                Toast.makeText(this, R.string.goods_remark_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
            if (BeanUtils.isNullOrEmpty(goods_counts)) {
                Toast.makeText(this, R.string.goods_counts_not_null, Toast.LENGTH_SHORT).show();
                return false;
            }
        	GoodsApplyDetails.ApplyDetails details =  goodsApplyDetails.new ApplyDetails();
        	details.setGoods(goods_name);
        	details.setCounts(goods_counts);
        	details.setRemark(goods_remark);
        	applyDetails.add(details);
        	goodsApplyDetails.setApplyDetails(applyDetails);
		}
        return true;
    }

    private boolean setReturnMsg(String msg){
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
        return false;
    }
    private GoodsApplyDetails goodsApplyDetails;
	private List<GoodsApplyDetails.ApplyDetails> applyDetails;
    private void setApplyInfo() {
        if (null == goodsApplyDetails) {
        	goodsApplyDetails = new GoodsApplyDetails();
        }
        goodsApplyDetails.setReceiveId(detail == null ? "0" : detail.getReceiveId());
        goodsApplyDetails.setReceiveTitle(et_apply_title.getText().toString().trim());
        goodsApplyDetails.setReceiveType((String) tv_apply_type.getTag());
        goodsApplyDetails.setReceiveTypeName(et_apply_type.getText().toString().trim());
        goodsApplyDetails.setGoodsDetail(et_apply_detail.getText().toString().trim());
    }

    //编辑界面，显示已有的工作列表信息
    private void showGoodsDetail(List<GoodsApplyDetails.ApplyDetails> list) {
        if (BeanUtils.isEmpty(list)) {
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            addContent(i, list.get(i));
        }
    }

    //初始化显示view
    private void initContentView(int count) {
        if (apply_list_lay.getChildCount() > 0) {
        	apply_list_lay.removeAllViews();
        }
        for (int i = 0; i < count; i++) {
            addContent(i, null);
        }
        scrollToBottom();
    }

    //新增一个view
    private void addContent(int index, ApplyDetails apply) {
        LinearLayout layout = (LinearLayout) mInflater.inflate(R.layout.apply_goods_detail_item, null);
        TextView tv_goods = (TextView) layout.findViewById(R.id.tv_goods);
        ImageView iv_delete = (ImageView) layout.findViewById(R.id.iv_delete);
        tv_goods.setText(getString(R.string.goods) + (index + 1));
        mViews.add(layout);
        setRemoveListener(iv_delete, index);
        apply_list_lay.addView(layout);
    }

    //当view的个数变化时，到最底下显示
    private void scrollToBottom() {
        mHanlder.post(new Runnable() {
            @Override
            public void run() {
            	scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    //修改删除或新增后，提示的显示
    private void changeIndex() {
        LinearLayout layout = null;
        for (int i = 0; i < apply_list_lay.getChildCount(); i++) {
            layout = ((LinearLayout) apply_list_lay.getChildAt(i));
            ImageView img = (ImageView) layout.findViewById(R.id.iv_delete);
            setRemoveListener(img, i);
        }
        scrollToBottom();
    }

    //设置删除事件和删除后view的显示
    private void setRemoveListener(ImageView img, final int size) {
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mViews.size() > size && size > 0) {
                    Logger.d(TAG, "remove index: " + size + "   " + view.getRootView());
					mViews.remove(size);
					apply_list_lay.removeViewAt(size);
					changeIndex();
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (apply_list_lay.getChildCount() > 0) {
        	apply_list_lay.removeAllViews();
        }
        if (null != mViews) {
        	mViews.clear();
        }
        if (null != views) {
            views.clear();
        }
    }
}
