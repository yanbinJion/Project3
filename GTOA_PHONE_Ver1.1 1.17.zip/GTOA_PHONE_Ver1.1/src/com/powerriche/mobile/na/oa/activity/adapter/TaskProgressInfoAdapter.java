package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.TaskDetails;
import com.powerriche.mobile.oa.tools.BeanUtils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by root on 16-5-24.
 */
public class TaskProgressInfoAdapter extends BaseAdapter {

    private Context mContext;
    private OnTextClickListener mListener;
    private int index = 0;
    private ArrayList<TaskDetails.ProgressInfo> mData = new ArrayList<TaskDetails.ProgressInfo>();
    private HashMap<String, ArrayList<TaskDetails.HistoryProgress>> map = new HashMap<String, ArrayList<TaskDetails.HistoryProgress>>();

    public TaskProgressInfoAdapter(Context context, OnTextClickListener listener) {
        this.mContext = context;
        this.mListener = listener;
    }

    public void updateData(ArrayList<TaskDetails.ProgressInfo> data) {
        mData.clear();
        if (!BeanUtils.isEmpty(data)) {
            mData.addAll(data);
            mData.get(0).setExpand(true);
        }
        notifyDataSetChanged();
    }

    public void setChildData(HashMap<String, ArrayList<TaskDetails.HistoryProgress>> map) {
        if (BeanUtils.isEmpty(map)) {
            return;
        }
        this.map.putAll(map);
    }

    public void destoryAdapter() {
        if (!BeanUtils.isEmpty(mData)) {
            mData.clear();
            mData = null;
        }
        if (!BeanUtils.isEmpty(map)) {
            map.clear();
            map = null;
        }
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        final TaskDetails.ProgressInfo progressInfo = mData.get(i);
        final String progressNo = progressInfo.getProcessNo();
        if (null == view) {
            view = LayoutInflater.from(mContext).inflate(R.layout.task_progress_list_item, null);
            holder = new ViewHolder();
            holder.contentLay = (LinearLayout) view.findViewById(R.id.task_progress_content_lay);
            holder.reportNameTxt = (TextView) view.findViewById(R.id.tv_report_name);
            holder.repportContent = (TextView) view.findViewById(R.id.tv_progress_content);
            holder.fromDateTxt = (TextView) view.findViewById(R.id.et_from_date);
            holder.toDateTxt = (TextView) view.findViewById(R.id.et_to_date);
            holder.degreeTxt = (TextView) view.findViewById(R.id.tv_progress_complete_degree);
            holder.completeTxt = (TextView) view.findViewById(R.id.tv_progress_complete_time);
            holder.humanCostTxt = (TextView) view.findViewById(R.id.tv_progress_sum_human_cost);
            holder.quantityTxt = (TextView) view.findViewById(R.id.tv_progress_sum_quantity);
            holder.sumTimeTxt = (TextView) view.findViewById(R.id.tv_progress_sum_time);
            holder.sumMoneyTxt = (TextView) view.findViewById(R.id.tv_progress_sum_money);
            holder.historyTxt = (TextView) view.findViewById(R.id.tv_check_history);
            holder.historyList = (ListView) view.findViewById(R.id.history_progress_lst);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.reportNameTxt.setText(progressInfo.getReportName());
        holder.repportContent.setText(progressInfo.getProgressContent());
        holder.fromDateTxt.setText(progressInfo.getFromDate());
        holder.toDateTxt.setText(progressInfo.getToDate());
        holder.degreeTxt.setText(progressInfo
                .getProgerssCompleteDegree());
        holder.completeTxt.setText(progressInfo.getCompleteTime());
        holder.humanCostTxt.setText(progressInfo.getCost());
        holder.quantityTxt.setText(progressInfo.getQuantity());
        holder.sumTimeTxt.setText(progressInfo.getSumTime());
        holder.sumMoneyTxt.setText(progressInfo.getSumMoney());
        holder.historyList.setVisibility(mData.get(i).isShowHistory() ? View.VISIBLE : View.GONE);
        holder.contentLay.setVisibility(mData.get(i).isExpand() ? View.VISIBLE : View.GONE);
        if (null != map) {
            if (null == holder.adapter) {
                holder.adapter = new TaskHistoryAdapter(mContext);
                holder.historyList.setAdapter(holder.adapter);
            }
            holder.adapter.updateData(map.get(progressNo));
            holder.adapter.notifyDataSetChanged();
        }
        holder.historyTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (null != mListener) {
                    progressInfo.setShowHistory(!progressInfo.isShowHistory());
                    mListener.onTextClick(view, progressNo);
                }
            }
        });
        holder.reportNameTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (i == index) {
                    progressInfo.setExpand(!progressInfo.isExpand());
                } else {
                    mData.get(index).setExpand(false);
                    progressInfo.setExpand(true);
                }
                mData.get(index).setShowHistory(false);
                index = i;
                notifyDataSetChanged();
            }
        });
        return view;
    }

    class ViewHolder {
        LinearLayout contentLay;
        TextView reportNameTxt;
        TextView repportContent;
        TextView fromDateTxt;
        TextView toDateTxt;
        TextView degreeTxt;
        TextView completeTxt;
        TextView humanCostTxt;
        TextView quantityTxt;
        TextView sumTimeTxt;
        TextView sumMoneyTxt;

        TextView historyTxt;
        ListView historyList;
        TaskHistoryAdapter adapter;
    }

    public interface OnTextClickListener {
        public void onTextClick(View v, String no);
    }
}
