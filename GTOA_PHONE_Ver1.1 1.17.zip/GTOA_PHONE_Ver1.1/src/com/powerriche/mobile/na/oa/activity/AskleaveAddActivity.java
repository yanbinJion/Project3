package com.powerriche.mobile.na.oa.activity;

import java.util.Date;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentDetailHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocumentParams;
import com.powerriche.mobile.na.oa.bean.UserLeaveInfo;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 新建请假单
 * 
 * @author 高明峰
 * @date 2015年5月4日
 * @version v1.0
 */
public class AskleaveAddActivity extends BaseActivity implements
		OnClickListener, OnCheckedChangeListener {

	private final static int DIALOG_MESSAGE = 2234;

	private final static int DIALOG_CHECK = 4234;
	
	public static final int CODE_TRANCE = 10;	//流程数据

	// 新增请假相关控件
	private EditText leaveReason, leaveStarttime, leaveEndTime;

	private RadioGroup leaveCatalogRg;

	private RadioButton leaveRb, paidRb;

	private TextView etUserName, applyDate, leaveType;// leaveType

	// private WheelView leaveType;
	// private Spinner leaveTypeSpinner;

	private Context mContext;

	public static String LEAVE_OPERATETYPE = Constants.LEAVE_OPERATETYPE_ADD;

	public String leaveId;
	
	public static String documentId;
	private String wfNo, fpuNo, swfNo, traceNo;
	// 基本信息界面相关
	private DocumentDetailHelper detailHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.askleave_item_add);
		bindViews();
	}

	private void bindViews() {

		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.askleave_apply_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(getString(R.string.system_dialog_submit));
		ResultItem item = (ResultItem) getIntent().getSerializableExtra("item");
		if (item != null) {
			bindModifyValue(item);
		} else {
			bindAddValue();
		}
		
		detailHelper = new DocumentDetailHelper(mContext, callBack, helper);
	}

	/**
	 * 绑定新增数据
	 */
	public void bindAddValue() {
		LEAVE_OPERATETYPE = Constants.LEAVE_OPERATETYPE_ADD;
		leaveId = null;
		String datestr = DateUtils.getDateStr(new Date(), DateUtils.DATE_HOUR_FORMAT);
		etUserName = (TextView) findViewById(R.id.tv_text_applicant);
		etUserName.setText(SystemContext.getUserName()); // 登录人系统登录用户
		applyDate = (TextView) findViewById(R.id.tv_apply_date);
		applyDate.setText(datestr); // 当前系统时间

		leaveRb = (RadioButton) this.findViewById(R.id.radio_leave);
		paidRb = (RadioButton) this.findViewById(R.id.radio_paid);
		leaveRb.setChecked(true);
		leaveCatalogRg = (RadioGroup) findViewById(R.id.radioGroup);
		leaveCatalogRg.setTag(leaveRb.getTag().toString());
		leaveCatalogRg.setOnCheckedChangeListener(this);
		leaveType = (TextView) findViewById(R.id.tv_leave_type);
		leaveType.setOnClickListener(this);

		leaveReason = (EditText) findViewById(R.id.tv_leave_reason);

		leaveStarttime = (EditText) findViewById(R.id.tv_leave_starttime);
		leaveStarttime.setText(datestr);
		leaveStarttime.setOnClickListener(this);
		leaveEndTime = (EditText) findViewById(R.id.tv_leave_endTime);
		leaveEndTime.setOnClickListener(this);
		leaveEndTime.setText(datestr);
	}

	/**
	 * 绑定修改数据
	 */
	public void bindModifyValue(ResultItem item) {

		// 修改为修改状态
		LEAVE_OPERATETYPE = Constants.LEAVE_OPERATETYPE_MOD;

		// 获取id
		leaveId = item.getString("leaveId");

		// 申请人
		String applicant = item.getString("APPLY_REALNAME");
		etUserName = (TextView) findViewById(R.id.tv_text_applicant);
		etUserName.setText(applicant);

		// 申请日期
		String applyTime = item.getString("APPLY_TIME");
		applyDate = (TextView) findViewById(R.id.tv_apply_date);
		applyDate.setText(applyTime);

		leaveRb = (RadioButton) this.findViewById(R.id.radio_leave);//请假类别：请假
		paidRb = (RadioButton) this.findViewById(R.id.radio_paid);//请假类别：休假

		// 请假类别 0请假，1调休
		String leaveCatalog = item.getString("LEAVE_CATALOG");
		if (BeanUtils.floatToInt(leaveCatalog) == 0) {
			leaveRb.setChecked(true);
		} else {
			paidRb.setChecked(true);
		}

		// 请假天数
		// String total_days = item.getString("LEAVE_TOTAL_DAYS");

		leaveCatalogRg = (RadioGroup) findViewById(R.id.radioGroup);
		leaveCatalogRg.setTag(leaveCatalog);
		leaveCatalogRg.setOnCheckedChangeListener(this);

		// 请假类型
		String type = item.getString("LEAVE_TYPE");
		leaveType = (TextView) findViewById(R.id.tv_leave_type);
		leaveType.setOnClickListener(this);
		leaveType.setText(Constants.LEAVE_TYPE_MAP.get(BeanUtils
				.floatToInt(type)));

		leaveType.setTag(BeanUtils.floatToInt4Str(type, "0"));
		// 请假原因
		String reason = item.getString("LEAVE_REASON");
		leaveReason = (EditText) findViewById(R.id.tv_leave_reason);
		leaveReason.setText(reason);

		// 请假申请开始时间
		String beginTime = item.getString("BEGIN_TIME");
		leaveStarttime = (EditText) findViewById(R.id.tv_leave_starttime);
		leaveStarttime.setOnClickListener(this);
		leaveStarttime.setText(beginTime);

		// 请假申请结束时间
		String end_time = item.getString("END_TIME");
		leaveEndTime = (EditText) findViewById(R.id.tv_leave_endTime);
		leaveEndTime.setOnClickListener(this);
		leaveEndTime.setText(end_time);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {
			toAskLeaveList();
		} else if (id == R.id.btn_top_right) { // 提交
			submit();
		} else if (id == R.id.tv_leave_type) { // 选择请假选项
			//0请假弹出类别
			if(BeanUtils.floatToInt(leaveCatalogRg.getTag()+"") == 0 ){
				UIHelper.showLeaveType(mContext, leaveType);
			}else{
				//1调休弹出类别
				UIHelper.showLeavePaidType(mContext, leaveType);
			}
		} else if (id == R.id.tv_leave_starttime) {
			UIHelper.showTimeSelect(mContext, leaveStarttime, DateUtils.DATE_HOUR_FORMAT);
		} else if (id == R.id.tv_leave_endTime) {
			UIHelper.showTimeSelect(mContext, leaveEndTime, DateUtils.DATE_HOUR_FORMAT);
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup rg, int checkedId) {
		if (checkedId == leaveRb.getId()) {
			leaveCatalogRg.setTag(leaveRb.getTag().toString());
		} else if (checkedId == paidRb.getId()) {
			leaveCatalogRg.setTag(paidRb.getTag().toString());
		}
		//去除已经选择的请假类型
		leaveType.setText("");
		leaveType.setTag("");
	}

	/**
	 * 提交：验证通过才提交数据
	 */
	public void submit() {
		//先验证数据
		if (checkInput()) {
			UserLeaveInfo bean = new UserLeaveInfo();
			if (!BeanUtils.isEmpty(leaveId)) {
				bean.setLeaveBizNo(leaveId);
			}
			bean.setOperateType(LEAVE_OPERATETYPE);
			String leaveCatalog = leaveCatalogRg.getTag().toString();
			bean.setLeaveCatalog(leaveCatalog);
			bean.setLeaveType(leaveType.getTag().toString());
			bean.setLeaveReason(leaveReason.getText().toString());
			bean.setBeginTime(leaveStarttime.getText().toString());
			bean.setEndTime(leaveEndTime.getText().toString());

			/*ApiRequest request = OAServicesHandler.saveLeave(bean);
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack);*/
		} else {
			showDialog(DIALOG_CHECK);
		}
	}

	/**
	 * 验证输入
	 * @return
	 */
	private boolean checkInput() {
		errorMessage = "";
		if (BeanUtils.isEmpty(leaveCatalogRg.getTag())) {
			errorMessage = getString(R.string.askleave_catalog_isempty);
			return false;
		}

		if (BeanUtils.isEmpty(leaveType.getTag())) {
			errorMessage = getString(R.string.askleave_type_isempty);
			return false;
		}

		String reason = leaveReason.getText().toString();//请假原因
		if (BeanUtils.isEmpty(reason)) {
			errorMessage = getString(R.string.askleave_reason_isempty);
			return false;
		}

		String starttime = leaveStarttime.getText().toString(); //开始时间
		if (BeanUtils.isEmpty(starttime)) {
			errorMessage = getString(R.string.askleave_starttime_isempty);
			return false;
		}

		String endTime = leaveEndTime.getText().toString(); //结束时间
		if (BeanUtils.isEmpty(endTime)) {
			errorMessage = getString(R.string.askleave_endtime_isempty);
			return false;
		}

		// 检验时间范围
		Date begindate = DateUtils.parseDate(leaveStarttime.getText()
				.toString() + ":00", "yyyy-MM-dd HH:mm:ss");
		if (begindate == null) {
			errorMessage = getString(R.string.error_tip_askleave_begin_time);
			return false;
		}
		Date enddate = DateUtils.parseDate(leaveEndTime.getText().toString()
				+ ":59", "yyyy-MM-dd HH:mm:ss");
		if (enddate == null) {
			errorMessage = getString(R.string.error_tip_askleave_end_time);
			return false;
		}
		if (enddate.before(begindate)) {
			errorMessage = getString(R.string.error_tip_between_askleave_time);
			return false;
		}
		
		return true;
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if(what == CODE_TRANCE){	//是否有办理信息可到达的环节
					DocumentParams params = new DocumentParams(swfNo, fpuNo, wfNo, traceNo, documentId);
					Bundle data = new Bundle();
					data.putSerializable("DOCUMENT_PARAMS", params);
					params.setResultItem(item);
					UIHelper.forwardTargetActivity(AskleaveAddActivity.this,
							DocumentTransactorActivity.class, data, true);
				}else{
					String swfNo = item.getString("SWFNO");
					String fpuNo = item.getString("FPUNO");
					String wfNo = item.getString("WFNO");
					String traceNo = item.getString("TRACENO");
					String documentId = item.getString("LEAVE_BIZ_NO");
					// showErrorMessage(getString(R.string.askleave_opt_success));
					// errorMessage = getString(R.string.askleave_opt_success);
					toTransactor(swfNo, fpuNo, wfNo, traceNo, documentId);
					return;
				}
				// 操作成功
				// toAskLeaveList();
			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}
	};

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {

		case DIALOG_CHECK:
			return new AlertDialog.Builder(AskleaveAddActivity.this)
					.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(errorMessage)
					.setNegativeButton(R.string.system_dialog_confirm,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

								}
							}).create();
		case DIALOG_MESSAGE:
			return new AlertDialog.Builder(AskleaveAddActivity.this)
					.setIcon(R.drawable.icon)
					.setTitle(R.string.app_name)
					.setMessage(errorMessage)
					.setNegativeButton(R.string.system_dialog_confirm,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
								}
							}).create();
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			toAskLeaveList();
		}
		return super.onKeyDown(keyCode, event);
	}

	// 调转列表页面
	public void toAskLeaveList() {
		// UIHelper.forwardTargetActivity(AskleaveAddActivity.this,
		// AskLeaveActivity.class, null, true);
		finish();
	}

	// 调转到选人环节
	public void toTransactor(String swfNo, String fpuNo, String wfNo,
			String traceNo, String documentId) {
		this.documentId = documentId;
		this.swfNo = swfNo;
		this.fpuNo = fpuNo;
		this.wfNo = wfNo;
		this.traceNo = traceNo;
		detailHelper.loadTranceData(swfNo, fpuNo, CODE_TRANCE);
		//Bundle data = new Bundle();
		//data.putString("SWF_NO", swfNo); // 系统流程编号
		//data.putString("FPU_NO", fpuNo); // 当前环节编号
		//data.putString("WF_NO", wfNo); // 文档流程编号
		//data.putString("TRACE_NO", traceNo); // 流程编号
		//data.putString("DOCUMENT_ID", documentId);
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

}
