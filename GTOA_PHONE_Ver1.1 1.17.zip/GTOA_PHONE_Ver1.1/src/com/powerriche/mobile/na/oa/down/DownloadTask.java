package com.powerriche.mobile.na.oa.down;

import java.io.File;

import android.content.Context;

import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br> 
 * UI控件画面的重绘(更新)是由主线程负责处理的，如果在子线程中更新UI控件的值，更新后的值不会重绘到屏幕上<br>
 * 一定要在主线程里更新UI控件的值，这样才能在屏幕上显示出来，不能在子线程中更新UI控件的值
 * @author  Miter
 * @date    2013-12-11
 */
public final class DownloadTask implements Runnable {

	private Context context;
	
	/** 下载地址 */
	private String path;

	/** 程序包名 */
	private String fileCode;

	/** 文件类型 */
	private String fileType;
	
	/** 原始文件长度 */
    private int fileSize = 0;
	
	/** 保存磁盘路径 */
	private File saveDir;
	
	/** 文件下载器 */
	private FileDownloader loader;
	
	/** 下载管理类 */
	private DownloadManager downloadManager = null;
	
	/** 线程数 */
	private Integer threadNum = 1;

	public DownloadTask(Context context, String path, File saveDir, String fileCode, String fileType, long fileSize) {
		this.path = path;
		this.saveDir = saveDir;
		this.context = context;
		this.fileCode = fileCode;
		this.fileType = fileType;
		this.downloadManager = DownloadManager.getInstance();
		this.fileSize = new Long(fileSize).intValue();
	}


	/**
	 * 暂停下载
	 */
	public void exit() {
		if (loader != null)
			loader.exit();
	}
	
	public Integer getFileSize(){
		if(loader!=null){
			return loader.getFileSize();
		}
		return 0;
	}
	
	public String getFileDir(){
		if(loader!=null){
			return loader.getFileDir();
		}
		return "";
	}

	public void run() {
		try {
			loader = new FileDownloader(context.getApplicationContext(), path, saveDir, threadNum, fileCode, fileType, fileSize);
			final int fileSize = loader.getFileSize();// 设置进度条的最大刻度
			
			updApp(path, DownloadInfoDAO.DOWNLOAD_STATE_1, null);
			
			Log.d("开始下载....");
			loader.download(new DownloadProgressListener() {
				public void onDownloadSize(int size) {
					if(size>=fileSize){
						
						Log.d("完成下载.");
						//完成最后进度下载，不然，进度条总是没填满
						downloadManager.onProgressUpdate(path, size, fileSize);
						
						updApp(path, DownloadInfoDAO.DOWNLOAD_STATE_2, loader.getFileDir());
						
						downloadManager.onDownloadStateChange(path, DownloadInfo.STATE_COMPLE);
						
					}else{
						//照样是更新进度条
						downloadManager.onProgressUpdate(path, size, fileSize);
					}
				}
			});
		} catch (Exception e) {
			Log.e(this.getClass(),e);
			downloadManager.onDownloadError(path, 0);
			updApp(path,DownloadInfoDAO.DOWNLOAD_STATE_0,null);
		}
	}
	
	
	
	
	/**
	 * 方法说明：<br>
	 * 更改app下载状态
	 * @param url 下载地址
	 * @param state 状态
	 * @param downDir 下载路径
	 */
	private void updApp(String url, int state,String downDir){
		Log.d("Download.updApp.......state-->"+state);
		try {
			 DownloadInfoDAO dao = new DownloadInfoDAO(context);
			 DownloadInfoBean software = dao.getDownloadInfoByUrl(url);
			
			if(software ==null ) return;
			
			int tmpState  = software.getState();
			
			if(tmpState == DownloadInfoDAO.DOWNLOAD_STATE_1 && state == DownloadInfoDAO.DOWNLOAD_STATE_2){
				
			}
			
			if(!BeanUtils.isEmpty(downDir))
				software.setDownDir(downDir);
			
			software.setState(state);
			dao.updStateByUrl(software);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}