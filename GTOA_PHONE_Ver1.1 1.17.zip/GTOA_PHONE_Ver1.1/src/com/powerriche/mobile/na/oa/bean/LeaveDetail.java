package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;
import java.util.List;


public class LeaveDetail implements Serializable {
	private static final long serialVersionUID = 9161436746365974952L;
	private String leaveId;
	private String operateType;
	private String leaveStaffNo;
	private String leaveRealName;
	private String leaveTime;
	private String leaveCatalog;
	private String leaveType;
	private String beginTime;
	private String endTime;
	private String leaveTotalDays;
	private String isLeavePass;
	private String leaveReason;
	private String leaveYearDays;
	private String wfNo;
	private String leaveBizCode;
	private String realEndTime;
	private String realLeaveTotalDays;
	private String destoryState;
	private String destoryTime;
	private String result;
	private String actionNo;
	private String fpuNo;
	private String saveButton;
	private String sendButton;
	private String agreeButton;
	private String refuseButton;
	private String destoryButton;
	private String finishButton;
	private List<TransactSuggestion> suggestion;
	private List<TransactInfo> info;

	public String getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(String leaveId) {
		this.leaveId = leaveId;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}

	public String getLeaveStaffNo() {
		return leaveStaffNo;
	}

	public void setLeaveStaffNo(String leaveStaffNo) {
		this.leaveStaffNo = leaveStaffNo;
	}

	public String getLeaveRealName() {
		return leaveRealName;
	}

	public void setLeaveRealName(String leaveRealName) {
		this.leaveRealName = leaveRealName;
	}

	public String getLeaveTime() {
		return leaveTime;
	}

	public void setLeaveTime(String leaveTime) {
		this.leaveTime = leaveTime;
	}

	public String getLeaveCatalog() {
		return leaveCatalog;
	}

	public void setLeaveCatalog(String leaveCatalog) {
		this.leaveCatalog = leaveCatalog;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getLeaveTotalDays() {
		return leaveTotalDays;
	}

	public void setLeaveTotalDays(String leaveTotalDays) {
		this.leaveTotalDays = leaveTotalDays;
	}

	public String getIsLeavePass() {
		return isLeavePass;
	}

	public void setIsLeavePass(String isLeavePass) {
		this.isLeavePass = isLeavePass;
	}

	public String getLeaveReason() {
		return leaveReason;
	}

	public void setLeaveReason(String leaveReason) {
		this.leaveReason = leaveReason;
	}

	public String getLeaveYearDays() {
		return leaveYearDays;
	}

	public void setLeaveYearDays(String leaveYearDays) {
		this.leaveYearDays = leaveYearDays;
	}

	public String getWfNo() {
		return wfNo;
	}

	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}

	public String getLeaveBizCode() {
		return leaveBizCode;
	}

	public void setLeaveBizCode(String leaveBizCode) {
		this.leaveBizCode = leaveBizCode;
	}

	public String getRealEndTime() {
		return realEndTime;
	}

	public void setRealEndTime(String realEndTime) {
		this.realEndTime = realEndTime;
	}

	public String getRealLeaveTotalDays() {
		return realLeaveTotalDays;
	}

	public void setRealLeaveTotalDays(String realLeaveTotalDays) {
		this.realLeaveTotalDays = realLeaveTotalDays;
	}

	public String getDestoryState() {
		return destoryState;
	}

	public void setDestoryState(String destoryState) {
		this.destoryState = destoryState;
	}

	public String getDestoryTime() {
		return destoryTime;
	}

	public void setDestoryTime(String destoryTime) {
		this.destoryTime = destoryTime;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getActionNo() {
		return actionNo;
	}

	public void setActionNo(String actionNo) {
		this.actionNo = actionNo;
	}

	public String getFpuNo() {
		return fpuNo;
	}

	public void setFpuNo(String fpuNo) {
		this.fpuNo = fpuNo;
	}

	public String getSaveButton() {
		return saveButton;
	}

	public void setSaveButton(String saveButton) {
		this.saveButton = saveButton;
	}

	public String getSendButton() {
		return sendButton;
	}

	public void setSendButton(String sendButton) {
		this.sendButton = sendButton;
	}

	public String getAgreeButton() {
		return agreeButton;
	}

	public void setAgreeButton(String agreeButton) {
		this.agreeButton = agreeButton;
	}

	public String getRefuseButton() {
		return refuseButton;
	}

	public void setRefuseButton(String refuseButton) {
		this.refuseButton = refuseButton;
	}

	public String getDestoryButton() {
		return destoryButton;
	}

	public void setDestoryButton(String destoryButton) {
		this.destoryButton = destoryButton;
	}

	public String getFinishButton() {
		return finishButton;
	}

	public void setFinishButton(String finishButton) {
		this.finishButton = finishButton;
	}
	
	public List<TransactSuggestion> getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(List<TransactSuggestion> suggestion) {
		this.suggestion = suggestion;
	}

	public List<TransactInfo> getInfo() {
		return info;
	}

	public void setInfo(List<TransactInfo> info) {
		this.info = info;
	}


}
