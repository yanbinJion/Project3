package com.powerriche.mobile.na.oa.activity;

import android.content.Intent;
import android.database.DatabaseUtils;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @title  申领查询
 * @author dir_wang
 * @date   2016-6-30下午2:15:07
 */
public class ApplyQueryResultActivity extends BaseActivity {

    private PullToRefreshListView listView;
    private ListView mListView;
    private TopActivity topActivity;
    private Button backBtn;
    public static final int RECEIVE_SEARCH = 0;
    public static final int PURCHASE_SEARCH = 1;
    public static final String PAGER_TYPE = "pagerType";
    private int pagerType;

    private List<ResultItem> resultItems = new ArrayList<ResultItem>();

    private String searchTitle;
    private String applyTitle;
    private String applyBeginTime;
    private String applyEndTime;
    private String applyHandle;
    private String applyPass;
    private String type;
    
    private TextView tvNoDataMsg;
    private InvokeHelper helper;

    private ResultSimpleAdapter adapter;
    private int index = 1;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.task_search_result_layout);
        Intent intent = getIntent();
        searchTitle = intent.getStringExtra("searchTitle");
        applyTitle = intent.getStringExtra("applyTitle");
        applyBeginTime = intent.getStringExtra("applyBeginTime");
        applyEndTime = intent.getStringExtra("applyEndTime");
        applyHandle = intent.getStringExtra("applyHandle");
        applyPass = intent.getStringExtra("applyPass");
        //物品申购查询中的申购类型
        type = intent.getStringExtra("type");
        pagerType = intent.getIntExtra(PAGER_TYPE, RECEIVE_SEARCH);
        initView();
    }

    private void initView() {
        topActivity = (TopActivity) findViewById(R.id.top_activity);
        int titleRes = R.string.apply_query_title;
        if (PURCHASE_SEARCH == pagerType) {
            titleRes = R.string.purchase_query_title;
        }
        topActivity.setTopTitle(getString(titleRes));// 顶部栏的中间标题
        topActivity.setRightBtnVisibility(View.VISIBLE);// 隐藏右边按钮
        topActivity.setRightBtnVisibility(View.INVISIBLE);//显示右边按钮
        topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
        backBtn = topActivity.getBtnBack();

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        listView = (PullToRefreshListView) findViewById(R.id.my_task_pulllistview);
        mListView = listView.getRefreshableView();
        listView.setPullRefreshEnabled(true);
        listView.setPullLoadEnabled(false);
        listView.setScrollLoadEnabled(true);
        UIHelper.setListViewAttribute(mListView);

        listView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
                index = 1;
                loadData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
                index = index + 1;
                loadData();
            }
        });
        tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
        tvNoDataMsg.setVisibility(View.GONE);
        mListView.setDivider(null);
        mListView.setCacheColorHint(Color.TRANSPARENT);
        mListView.setFadingEdgeLength(0);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
                int resultItemIndex = position;
//                if(resultItemIndex == 0 && (R.id.layout_search_bar_top == mListView.getChildAt(0).getId())){
//                    return;//跳过：被单击的是搜索栏
//                }else{
//                    resultItemIndex = resultItemIndex - 1;
//                }

                ResultItem item = resultItems.get(resultItemIndex);
                if(item == null){
                    return;//空
                }
               
                if (PURCHASE_SEARCH == pagerType) {
                	 //这里进入详情界面
                    String purchaseId = item.getString("PURCHASE_ID");
                    String swfNo = item.getString("SWF_NO");
                    String wfNo = item.getString("WF_NO");
                    if (null == wfNo || wfNo.length() <= 0) {
                        return;
                    }
                    //这里进入详情界面
                    Bundle data = new Bundle();
                    data.putString("purchaseId", purchaseId);
                    data.putString("swfNo", swfNo);
                    data.putString("wfNo", wfNo);
                    UIHelper.forwardTargetActivity(ApplyQueryResultActivity.this, PurchaseDetailActivity.class, data, false);
                } else {
                	 //这里进入详情界面
                    String receiveId = item.getString("RECEIVE_ID");
                    String swfNo = item.getString("SWF_NO");
                    String wfNo = item.getString("WF_NO");
                    if (null == wfNo || wfNo.length() <= 0) {
                        return;
                    }
                    //这里进入详情界面
                    Bundle data = new Bundle();
                    data.putString("receiveId", receiveId);
                    data.putString("swfNo", swfNo);
                    data.putString("wfNo", wfNo);
                    UIHelper.forwardTargetActivity(ApplyQueryResultActivity.this, ApplyDetailActivity.class, data, false);
                }
            }
        });
        loadData();
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            if (index == 1) {
                resultItems.clear();// 清除
            }
            List<ResultItem> result = response.getResultItem(ResultItem.class).getItems("data");
            if (!BeanUtils.isEmpty(result)) {
                resultItems.addAll(result);
            }
            if (BeanUtils.isEmpty(result)) {
                tvNoDataMsg.setVisibility(View.VISIBLE);
            } else {
                tvNoDataMsg.setVisibility(View.GONE);
            }
            if (null == adapter) {
            	// AndroidUI的组件ID
                int[] txtids = { R.id.list_item_text_field, R.id.list_item_text_field1, R.id.list_item_text_field2 };
                String[] keys = { "GOODS_USAGE", "IS_PASS", "RECEIVE_TIME" };
                if (PURCHASE_SEARCH == pagerType) {
                    keys = new String[]{ "PURCHASE_TITLE", "APPLY_TIME", "PASS_STATE" };
                }
                adapter = new ResultSimpleAdapter(ApplyQueryResultActivity.this, resultItems, R.layout.list_item_gwgl, keys, txtids);
                adapter.setHelper(new ResultSimpleAdapter.ISimpleAdapterHelper() {
                    @Override
                    public Object parseValue(Object currentobj, List<?> items, int position, String key, View view) {
                        try {
                            ResultItem item = resultItems.get(position);
                            if (PURCHASE_SEARCH == pagerType) {
                                if ("PASS_STATE".equals(key) && currentobj != null) {
                                	String state = String.valueOf(currentobj);
                                    String result = "";
                                    if ("0".equals(state)) {
                                    	result = getString(R.string.applying);
                                    } else if ("1".equals(state)) {
                                    	result = getString(R.string.apply_pass);
                                    } else {
                                    	result = getString(R.string.apply_refuse);
                                    }
                                    return result;
                                }
                            } else {
                                String systemtime = item.getString("RECEIVE_TIME");// 系统时间
                                if ("RECEIVE_TIME".equals(key) && currentobj != null) {
                                	DateUtils dateUtils = new DateUtils(ApplyQueryResultActivity.this);
                                    return dateUtils.diffFromToNow(DateUtils.parseDate(currentobj.toString()), systemtime);
                                } else if ("IS_PASS".equals(key) && currentobj != null) {
                                	String state = String.valueOf(currentobj);
                                    String result = "";
                                    if ("0".equals(state)) {
                                    	result = getString(R.string.applying);
                                    } else if ("1".equals(state)) {
                                    	result = getString(R.string.apply_pass);
                                    } else {
                                    	result = getString(R.string.apply_refuse);
                                    }
                                    return result;
                                }
                            }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                        return (currentobj == null || "null".equals(currentobj
                                .toString().toLowerCase())) ? "" : currentobj;
                    }

                    @Override
                    public void apply(View convertView, Object obj, int position) {
                        // 如果有搜索关键字，高亮显示
                        if (!BeanUtils.isEmpty(searchTitle)) {
                            TextView textView = (TextView) convertView
                                    .findViewById(R.id.list_item_text_field);
                            SearchUtils.spannableResultItems(textView,
                                    (String) textView.getText(), searchTitle);
                        }
                    }
                });
                mListView.setAdapter(adapter);
            } else {
                adapter.notifyDataSetChanged();
            }

            /**
             * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
             */
            if (BeanUtils.isEmpty(result) || result.size() < Constants.COMMON_PAGE_SIZE) {
                // 已经全部加载完成，关闭UI组件的下拉加载更多功能
                listView.onPullDownRefreshComplete();
                listView.onPullUpRefreshComplete();
                listView.setHasMoreData(false);

                if(index ==1 && (BeanUtils.isEmpty(result) || result.size()==0)){
//                    listView.setVisibility(View.GONE);
                    tvNoDataMsg.setVisibility(View.VISIBLE);
                    listView.getFooterLoadingLayout().show(false);
                }else{
                    listView.setVisibility(View.VISIBLE);
                    tvNoDataMsg.setVisibility(View.GONE);
                }

            } else {
                // 还有更多数据，继续打开“下拉加载更多”功能
                listView.onPullDownRefreshComplete();
                listView.onPullUpRefreshComplete();
                listView.setHasMoreData(true);
                listView.setVisibility(View.VISIBLE);
                tvNoDataMsg.setVisibility(View.GONE);
            }
        }
    };

    private void loadData() {
        helper = new InvokeHelper(this);
        ApiRequest request = OAServicesHandler.getReceiveGoodsGeneralList("", applyTitle, applyBeginTime, applyEndTime, applyHandle, applyPass, index);
        if (PURCHASE_SEARCH == pagerType) {
            request = OAServicesHandler.getPurchaseGeneralList(applyHandle, "", applyTitle, applyPass, type, applyBeginTime, applyEndTime, index);
        }
        request.setMessage(getString(R.string.system_load_message));
        helper.invokeWidthDialog(request, callBack);
    }

}
