package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils.TruncateAt;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.DocumentTransactListAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.MeetingSignupListAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.PassreadListAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentAddHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentHelper;
import com.powerriche.mobile.na.oa.activity.document.MeetDetailHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.DocManagerInfo;
import com.powerriche.mobile.na.oa.bean.DocumentInfo;
import com.powerriche.mobile.na.oa.bean.DocumentParams;
import com.powerriche.mobile.na.oa.bean.MeetInfo;
import com.powerriche.mobile.na.oa.bean.PassreadInfo;
import com.powerriche.mobile.na.oa.bean.SignUpInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.na.oa.down.DownloadInfoBean;
import com.powerriche.mobile.na.oa.down.DownloadInfoDAO;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper.DownloadButtonListener;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TextDialog;
import com.powerriche.mobile.na.oa.view.TipsDialog;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.FileDownUtil;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;
import com.powerriche.mobile.oa.tools.TextBodyUtile;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 会议详情
 * 
 * @author Fitz
 * @date 2015年5月8日
 * @version v1.0
 */
public class MeetDetailActivity extends BaseActivity implements OnClickListener, OnLongClickListener, DownloadButtonListener {

	public static final int CODE_BASIC = 0; // 基本信息
	public static final int SIGN_UP_DEL = 2; // 删除报名
	public static final int CODE_RETURN = 3;//操作码：退回
	public static final int CODE_CALLBACK = 4;//操作码：撤回
	public static final int CODE_DELETE_FILE = 5;// 操作码：删除文件
	public static final int CODE_INPUT_SUGGEST = 7;
	public static final int CODE_UPLOAD_TEXT_FILE = 8;//操作码：上传文件
	public static final int CODE_REPLAY_PASSREAD = 9;
	public static final int CODE_MODFLY = 10;	//修改正文保存
	public static final int CODE_TRANCE = 11;	//请求办理信息数据返回
	public static final int CODE_MODIFY_UPLOAD_FILE = 12;	//附件上传
	public static final int CODE_DELETE_SIGNUP = 13;	//删除报名信息
	public static final int CODE_PASS_READ = 14;//操作码：传阅
	
	public static final int CODE_PASS_READ_TAG = 1000;
	
	private static final int DIALOG_SIGNUP = 5423; // 跳转到代理人
	private static final int SIGNUP_SAVE = 5424; // 报名保存

	private Context mContext;

	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片

	private TextView tv1, tv2, tv3, tv4;
	private View view1, view2, view3, view4;

	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度

	// ****************会议基本信息*************
	private TextView tvBeginTime, tvEndTime, tvTitle, tvContent, tvAddress,
			tvPresider;
	// ****************公文基本信息*************
	private EditText etTitle, etTextNo, etDepartment, etUserName, etZhaiyao;
	private TextView tvHuanji, tvLevel;
	
	// ****************展开按钮***************
	private TextView tvExtend;

	// ****************附件相关***************
	private TextView tvFileGroup;
	private LinearLayout llFileWrap;

	// ****************办理信息界面相关***************
	private ListView listViewManager;

	public static String meetingId;
	private String wfNo, fpuNo, swfNo, traceNo;
	
	
	private boolean isFirst1 = true, isFirst3 = true; // 此处判断是否第一次加载

	// ****************报名信息界面相关***************
	private boolean isDel = true;
	private ImageView addSignUpBtn; // 添加按钮
	private ListView listViewSignUp;
	private MeetingSignupListAdapter adapterSignup;
	private LinearLayout llEmpty;
	
	// ****************传阅信息界面相关***************
	private PassreadListAdapter adapterPassread;
	
	// ****************正文界面相关*****************
	private TextView tvNoTextBody; // 无正文提示
	private Button btnOpenFile; // 打开正文按钮
	private DocFileInfo bodyBean;
	private boolean isFirstOpen = true;

	private MeetDetailHelper meetHelper;

	// 附件上传相关
	private Button btnUpload;
	private String mdfFilePath, mdfFileName;	//附件上传成功临时变量
	private String deleteFilePath;
//	private FileDownHelper downHelper;
	
	/**
	 * 如果是主办会议，就初始化主办会议的基本信息 ，如果是会议通知，则显示公文详情基本信息
	 */
	private int doucmentType, isFirstFpu, resultType, exChangeFlag, isReceiptReplied,isCallback;
	private String documentId;
	
	/** 0打开菜单，1传阅，2撤回 */
	private int goWhere;
	private String passreadId = null;// 传阅编号

	
	// 逻辑菜单相关
	private PopupWindow mPop;
	private Button rightBtn, btnBaoming;
	
	//传阅信息相关
	private EditText etPassreadContent;
	private int passreadTag = -1; // 如果passread不等于1000，则初始话办理信息view，否则初始化传阅信息view
	private int passreadType = -1;//PASS_READ_TYPE 取消”已传件“的回复功能

	private boolean isNewDoc = false; // 是否需要new一个新的word
	
	/** 已办的公文或者会议都不能删除增加附件<br> true可以删除新增*/
	private boolean isDeleteAddToken = true;
	
	/** 这个参数是办理界面的返回值：办理结果标志：1-办理成功（返回待办列表需要移除当前待办项），0-未办理、办理失败（返回待办列表不需要移除当前待办项） */
	public static int dealwithFlag = 0;
	/** 撤回结果标题：1-撤回成功（返回已办列表需要移除当前已办项），0-未撤回、撤回失败（返回已办列表不需要移除当前已办项） */
	public static int retracementFlag = 0;
	/** 退件结果标题：1-退件成功（返回待办列表需要移除当前待办项），0-未退件、退件失败（返回待办列表不需要移除当前待办项） */
	public static int retroversionFlag = 0;


	private DownloadUIHelper downloadUIHelper = null;
	private DownloadInfoDAO dao = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.meet_detail);

		meetingId = getIntent().getStringExtra("documentId"); // 公文ID
		wfNo = getIntent().getStringExtra("wfNo"); // 流程编号
		fpuNo = getIntent().getStringExtra("fpuNo"); // 当前环节编号
		swfNo = getIntent().getStringExtra("swfNo"); // 系统流程编号
		traceNo = getIntent().getStringExtra("traceNo"); // 跟踪编号
		doucmentType = getIntent().getIntExtra("doucmentType", 0); // 标示会议通知
		passreadId = getIntent().getStringExtra("passreadId"); // 传阅编号
		// postReadFlag = getIntent().getIntExtra("postReadFlag", 0);
		passreadTag = getIntent().getIntExtra("IS_PASS_READ", -1); // 传阅入口标示
		passreadType = getIntent().getIntExtra("PASS_READ_TYPE", -1);
		dealwithFlag = getIntent().getIntExtra("DEAL_WITH_FLAG", 0); // 这个参数是办理界面的返回值：办理结果标志：1-办理成功，0-未办理或办理失败
		isDeleteAddToken = getIntent().getBooleanExtra("isDeleteAddToken", true);	//已办公文参数标志，已办公文附件，不可以新增跟删除

		bindViews();
		
		meetHelper = new MeetDetailHelper(mContext, callBack, helper);
//		downHelper = new FileDownHelper(mContext);
		registerBroadcast();
		
		this.downloadUIHelper = new DownloadUIHelper(mContext);
		this.downloadUIHelper.setEventListener(this);
		this.dao = new DownloadInfoDAO(mContext);
	}

	private void bindViews() {
		findViewById(R.id.system_back).setOnClickListener(this);
		TextView tvTitle = (TextView) findViewById(R.id.tv_top_title);
		tvTitle.setText(getString(R.string.meet_detail_title));
		rightBtn = (Button) findViewById(R.id.btn_top_right);
		rightBtn.setOnClickListener(this);
		btnBaoming = (Button) findViewById(R.id.btn_top_baoming);
		btnBaoming.setOnClickListener(this);

		initImageView();
		initTextView();
		initViewPager();

		// 如果是主板会议，就初始化主板会议的基本信息 ，如果是会议通知，则显示公文详情基本信息
		if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {
			initView1Zbhy();//第1部分：基本信息-主办会议
		} else {
			initView1Hytz();//第1部分：基本信息-会议通知
		}
		
		tvExtend = (TextView) view1.findViewById(R.id.tv_extend);
		tvExtend.setOnClickListener(this);
		tvExtend.setTag(false);//默认收起
		tvExtend.setVisibility(View.GONE);
		
		// 初始化传阅相关按钮
		if (passreadTag == CODE_PASS_READ_TAG) {
			if(passreadType == Constants.OPT_TYPE_GWCY_YC){	//已传列表跳转到详情，没有回复功能点
				view1.findViewById(R.id.ll_sign_wrap).setVisibility(View.GONE); // 传阅下角回复GONE
			}else{
				view1.findViewById(R.id.ll_sign_wrap).setVisibility(View.VISIBLE); // 传阅下角回复VISIBLE
			}
			view1.findViewById(R.id.btn_reply).setOnClickListener(this); // 传阅回复按钮
			view1.findViewById(R.id.btn_input).setOnClickListener(this); // 导入常用建议按钮
			etPassreadContent = (EditText) view1.findViewById(R.id.et_content);
		}
		
		initView2();//第2部分：正文
		
		//如果是传阅入口，则没有办理信息列表，如果是会议入口，这有办理信息入口
		if (passreadTag!=CODE_PASS_READ_TAG) {
		}
		
		initView3();//第3部分：办理信息
		initView4();//第4部分：报名信息
	}

	private void initView1Zbhy() {
		tvTitle = (TextView) view1.findViewById(R.id.tv_title);
		tvPresider = (TextView) view1.findViewById(R.id.tv_meet_presider);
		tvContent = (TextView) view1.findViewById(R.id.tv_meet_content);
		tvAddress = (TextView) view1.findViewById(R.id.tv_meet_address);
		tvBeginTime = (TextView) view1.findViewById(R.id.tv_begin_time);
		tvEndTime = (TextView) view1.findViewById(R.id.tv_end_time);

		tvFileGroup = (TextView) view1.findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		tvFileGroup.setVisibility(View.VISIBLE);
		llFileWrap = (LinearLayout) view1.findViewById(R.id.ll_file_wrap);
		llFileWrap.setVisibility(View.GONE);
		
		btnUpload = (Button) view1.findViewById(R.id.btn_upload);
		btnUpload.setOnClickListener(this);
		btnUpload.setVisibility(View.GONE);
	}

	private void initView1Hytz() {
		etTitle = (EditText) view1.findViewById(R.id.tv_title);
		etTextNo = (EditText) view1.findViewById(R.id.tv_text_no);
		etDepartment = (EditText) view1.findViewById(R.id.tv_department);
		etUserName = (EditText) view1.findViewById(R.id.tv_user_name);
		etZhaiyao = (EditText) view1.findViewById(R.id.tv_zhaiyao);

		tvHuanji = (TextView) view1.findViewById(R.id.tv_huanji);
		tvHuanji.setOnClickListener(this);
		tvLevel = (TextView) view1.findViewById(R.id.tv_level);
		tvLevel.setOnClickListener(this);
		
		tvFileGroup = (TextView) view1.findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		llFileWrap = (LinearLayout) view1.findViewById(R.id.ll_file_wrap);

		btnUpload = (Button) view1.findViewById(R.id.btn_upload);
		btnUpload.setOnClickListener(this);
		btnUpload.setVisibility(View.GONE);
	}

	private void initView2() {
		tvNoTextBody = (TextView) view2.findViewById(R.id.tv_no_text_body);
		tvNoTextBody.setOnClickListener(this);
		btnOpenFile = (Button) view2.findViewById(R.id.btn_new_file);
		btnOpenFile.setOnClickListener(this);
	}

	private void initView3() {
		listViewManager = (ListView) view3.findViewById(R.id.lv_document_transact);
		listViewManager.setDivider(null);
		listViewManager.setCacheColorHint(Color.TRANSPARENT);
		listViewManager.setFadingEdgeLength(0);
		listViewManager.setSelector(android.R.color.transparent);
		
		//适配器 适配数据 UI task_banli_info_listview_item.xml
		
		
	}

	void initView4() {
		listViewSignUp = (ListView) view4.findViewById(R.id.lv_signup_list);
		listViewSignUp.setDivider(null);
		listViewSignUp.setCacheColorHint(Color.TRANSPARENT);
		listViewSignUp.setFadingEdgeLength(0);
		listViewSignUp.setSelector(android.R.color.transparent);
		addSignUpBtn = (ImageView) view4.findViewById(R.id.im_add_line);
		//tvEmpty = (TextView) view4.findViewById(R.id.tv_empty);
		//imEmpty = (ImageView) view4.findViewById(R.id.im_empty);
		llEmpty = (LinearLayout) view4.findViewById(R.id.ll_empty);
		// 如果不等于会议通知，则不能新增
		if (doucmentType != Constants.OPT_TYPE_HYGL_HYTZ) {
			addSignUpBtn.setVisibility(View.GONE);
			btnBaoming.setVisibility(View.GONE); // 隐藏报名按钮
		} else {
			addSignUpBtn.setVisibility(View.VISIBLE);
			addSignUpBtn.setOnClickListener(this);
			btnBaoming.setVisibility(View.VISIBLE); // 显示报名按钮
		}
	}

	/**
	 * 初始化菜单分2总情况，一种是主办会议，会议通知按公文详情来做
	 */
	private void initPopup() {
		// 根据条件来初始化菜单
		if (mPop == null) {
			View view = null;

			// 传阅过来，只有传阅和回复
			if (passreadTag == CODE_PASS_READ_TAG) {
				rightBtn.setText("传阅");
				rightBtn.setBackgroundResource(R.drawable.btn_back_selector);
				rightBtn.setVisibility(View.VISIBLE);
				goWhere = 1;
				isNewDoc = false;// 是否正文可以新建
				
			} else if (resultType == 0 && exChangeFlag == 0
					&& isReceiptReplied == 0 && Constants.LW_CODE.equals(swfNo)) {
				// resultType=0,是待办，EXCHANGE_FLAG=0交换来文，IS_RECEIPT_REPLIED0：未签收
				// swfNo是来文的 2006083005302033
				// 只能进行签收和拒收
				isNewDoc = false;// 是否正文可以新建
				view = LayoutInflater.from(mContext).inflate(R.layout.document_detail_top_right_menu_sign, null);
				view.findViewById(R.id.tv_document_sign).setOnClickListener(this); // 签收
				view.findViewById(R.id.tv_document_rejection).setOnClickListener(this); // 拒绝
				mPop = new PopupWindow(view, LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
				goWhere = 0;
				UIHelper.setBtnStyle(mContext, rightBtn, R.drawable.ic_more_menu);
				final TipsDialog dialog = new TipsDialog(mContext);
				dialog.setMessage("请先签收公文或拒绝");
				dialog.setOnOkClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View arg0) {
						dialog.dismiss();
					}
				});
				dialog.show();
				
			} else if (isReceiptReplied == 2 || resultType == -1) {
				// 拒收的和 -1：只读页 （没有撤回、退件、送出等按钮）
				if (doucmentType != Constants.OPT_TYPE_HYGL_HYTZ) {
					btnBaoming.setVisibility(View.GONE);
					rightBtn.setVisibility(View.INVISIBLE);
				} else {
					btnBaoming.setVisibility(View.VISIBLE);
					rightBtn.setVisibility(View.GONE);
				}
				isNewDoc = false;// 是否正文可以新建
				
			} else if (resultType == 1) {
				// 已办-->只有撤回
				//IS_CALLBACK 0 不能撤回（不显示撤回按钮）	1 可以撤回（显示撤回按钮）
				if(isCallback == 1){
					rightBtn.setText("撤回");
					rightBtn.setBackgroundResource(R.drawable.btn_back_selector);
					rightBtn.setVisibility(View.VISIBLE);
				}
				goWhere = 2;
				isNewDoc = false;// 是否正文可以新建
				
			} else if (isFirstFpu == 1) { // 第一环节：只有送出跟传阅
				rightBtn.setText("传阅");
				rightBtn.setBackgroundResource(R.drawable.btn_back_selector);
				rightBtn.setVisibility(View.VISIBLE);
				Button btnSend = (Button) view1.findViewById(R.id.btn_send); // 送出按钮
				btnSend.setOnClickListener(this);
				btnSend.setVisibility(View.VISIBLE);
				goWhere = 1;
				isNewDoc = true;// 是否正文可以新建
				tvNoTextBody.setText(getString(R.string.document_new_file_text));
				showBtnUpload();
				
			} else { // 退件，传阅，送出操作
				view = LayoutInflater.from(mContext).inflate(R.layout.document_detail_top_right_menu, null);
				view.findViewById(R.id.tv_document_return).setOnClickListener(this); // 退件
				view.findViewById(R.id.tv_document_look).setOnClickListener(this); // 传阅
				mPop = new PopupWindow(view, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				Button btnSend = (Button) view1.findViewById(R.id.btn_send); // 送出按钮
				btnSend.setOnClickListener(this);
				btnSend.setVisibility(View.VISIBLE);
				goWhere = 0;
				rightBtn.setVisibility(View.VISIBLE);
				UIHelper.setBtnStyle(mContext, rightBtn, R.drawable.ic_more_menu);
				isNewDoc = true;// 是否正文可以新建
				tvNoTextBody.setText(getString(R.string.document_new_file_text));
				showBtnUpload();
			}
		}
		
		//已办公文，不能新增附件
		if(!isDeleteAddToken){
			this.btnUpload.setVisibility(View.GONE);
		}
		
		//只要是来文：都不可以正文编辑，如果没有正文时，页面提示：也就是说：在来文的情况下，正文只是显示用的，不需要编辑和上传
		//来文，在没有正文时，页面提示内容：“没有录入正文，正文见原件”
		if(Constants.LW_CODE.equals(swfNo)){
			isNewDoc = false;
			tvNoTextBody.setText(getString(R.string.document_not_create_file));
		}

	}

	private void showPopup() {
		if (mPop != null) {
			if (mPop.isShowing()) {
				mPop.dismiss();
			} else {
				mPop.showAsDropDown(rightBtn);
			}
		}
	}
	
	private void showBtnUpload(){
		this.btnUpload.setVisibility(View.VISIBLE);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {//　返回
			onClickBack();

		} else if (id == R.id.btn_top_right) {
			if (goWhere == 0) {
				showPopup();// 菜单show
			} else if (goWhere == 1) { // 传阅
				goPassread();
			} else if (goWhere == 2) {
				showDocumentRecall(); // 撤回操作
			}

		} else if (id == R.id.tv_file_group) {
			UIHelper.isOpenFile(mContext, tvFileGroup, llFileWrap);
		} else if (id == R.id.tv_document_return) {// 退件操作
			showDocumentReturnDialog();
		} else if (id == R.id.btn_send) { // 去办理送出界面
			goTransactorActivity();
		} else if (id == R.id.tv_document_look) { // 传阅
			goPassread();

		} else if (id == R.id.im_add_line) { // 调转到选择报名人页面
			Bundle data = new Bundle();
			data.putString(ChoosePeopleActivity.KEY_CUSTOM_TITLE, "请选择报名人员");
			data.putBoolean(ChoosePeopleActivity.KEY_IS_MULTIPLE_SELECT, true);
			UIHelper.forwardTargetActivityForResult(this,
					ChoosePeopleActivity.class, data, false, DIALOG_SIGNUP);

		} else if (id == R.id.btn_top_baoming) { // 保存报名信息
			checkSignUpData();

		} else if (id == R.id.tv_file_group) {
			UIHelper.isOpenFile(mContext, tvFileGroup, llFileWrap);

		} else if (id == R.id.btn_new_file || id == R.id.tv_no_text_body) { // 打开正文
			Object tag = v.getTag();
			if(tag!=null){
				if(tag instanceof DocFileInfo){
					DocFileInfo tempBean = (DocFileInfo) tag;
					if (tempBean != null) {
						//String url = UIHelper.downFileUrl(tempBean.getFileCode());//getString(R.string.system_servics_download).concat(tempBean.getFilePath());
					    String url;
	                    //0,标识使用system_servics_download下载，1标识使用system_servics_url下载
	                    if("1".equals(getString(R.string.is_download_flag))){
	                        url = UIHelper.downFileUrl(bodyBean.getFileCode());
	                    }else{
	                        url = getString(R.string.system_servics_download).concat(bodyBean.getFilePath());
	                    }
	                  
	                    //来文只能是阅读模式
			            String readModel = Constants.WPS_NORMAL;
			            if(Constants.LW_CODE.equals(swfNo)){
			            	readModel = Constants.WPS_READMODE;
			            }
	                    
						FileDownUtil downUtil = new FileDownUtil(mContext, url, tempBean.getFileName(), tempBean.getFileCode(), tempBean.getFileType(), 
								tempBean.getFileSize(), "正文正在下载", readModel);
						downUtil.start();
					}
				}else if(tag instanceof String){
					String tagStr = tag.toString();
					String filePath = "";
					if(Constants.TAG_TEMP_FILE.equals(tagStr)){
						filePath = Constants.SDCARD_DIR_NEW_FILE.concat(Constants.SDCARD_TEMP_FILE);
					}else{
						filePath = Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD.concat(tagStr).concat(".doc");
					}
					UIHelper.openWps(mContext, filePath, Constants.WPS_NORMAL); // 新建一个正文
				}
				
			}else{
				// 不等于传阅才可以进行操作
				if (isNewDoc) {
					UIHelper.openWps(mContext, null, Constants.WPS_NORMAL); // 新建一个正文
				}
			}
			
		} else if (id == R.id.tv_document_sign) { // 签收
			goSignActivity(true);
			
		} else if (id == R.id.tv_document_rejection) { // 拒绝
			goSignActivity(false);
			
		} else if (id == R.id.btn_reply) { // 传阅回复
			String passreadContent = etPassreadContent.getText().toString();// 回复内容
			if (BeanUtils.isEmpty(passreadContent)) {
				UIHelper.showMessage(mContext, getString(R.string.required_tip_passread_content));
				return;
			} else {
				ApiRequest request = OAServicesHandler.replyPassread(passreadId, passreadContent);
				if (request != null) {
					request.setMessage(getString(R.string.system_commit_message));
					new InvokeHelper(mContext).invokeWidthDialog(request, callBack, CODE_REPLAY_PASSREAD);
				}
			}
		} else if (id == R.id.btn_input) { // 传阅导入常用建议按钮
			//doLoadUserNotesList();
			UIHelper.forwardTargetActivityForResult(this,
					DocumentTransactorSuggestActivity.class, null, false, CODE_INPUT_SUGGEST);
			
		}else if(id == R.id.btn_upload){	//附件上传
			UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, 
					false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
			
		}else if(id == R.id.tv_extend){	//单机摘要展开按钮
			expand();
			
		}else if(id==R.id.btn_process || id==R.id.rl_item_wrap || id==R.id.rl_add_item_wrap){	//下载按钮
			UIHelper.downViewClick(mContext, v, downloadUIHelper, dao);
		}
	}
	
	
	void expand(){
		boolean isExpand = (Boolean) tvExtend.getTag();
		Drawable drawable;
		if(!isExpand){
			int lineCount;
			if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {
				lineCount = tvContent.getLineCount();//获取最大行数
				tvContent.setMaxLines(lineCount);
			}else{
				lineCount = etZhaiyao.getLineCount();//获取最大行数
				etZhaiyao.setMaxLines(lineCount);
			}
			
			drawable = UIHelper.closeDrawable(mContext, R.drawable.btn_packup);	//更改为收起按钮
			isExpand = true;//已经展开了
		}else{
			if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {
				tvContent.setLines(3);//只显示3行
			}else{
				etZhaiyao.setLines(3);//只显示3行
			}
			drawable = UIHelper.openDrawable(mContext, R.drawable.btn_expand);	//更换为展开按钮
			isExpand = false;
		}
		tvExtend.setCompoundDrawables(null, null, drawable, null);
		tvExtend.setTag(isExpand);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String message = item.getString("message");
				if (what == CODE_BASIC) {
					Map<String, Object> map = meetHelper.process(meetingId, response, doucmentType);
					if (map != null && map.size() > 0) {

						if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) { // 主办会议基本信息
							MeetInfo bean = (MeetInfo) map.get("docBean");
							if (bean != null) {
								resultType = bean.getResult();
								isFirstFpu = bean.getIsFirstFpu();
								exChangeFlag = bean.getExchangeFlag();
								isReceiptReplied = bean.getIsReceiptReplied();
								isCallback = bean.getIsCallback();
								documentId = bean.getDocumentId();	//-->用到附件上传
								
								setViewZbhyValue(bean);
								initPopup();
							}

						} else { // 会议通知基本信息(公文详情的基本信息)
							DocumentInfo docInfo = (DocumentInfo) map.get("docBean");
							if (docInfo != null) {
								resultType = docInfo.getResult();
								isFirstFpu = docInfo.getIsFirstFpu();
								exChangeFlag = docInfo.getExchangeFlag();
								isReceiptReplied = docInfo.getIsReceiptReplied();
								isCallback = docInfo.getIsCallback();
								//如果当前环节为空，则取详情返回的
								if(fpuNo == null || "".equals(fpuNo.trim())){
									fpuNo = docInfo.getFpuNo();
								}
								setViewHytzValue(docInfo);
								initPopup();
							}
						}

						// 文件附件
						@SuppressWarnings("unchecked")
						List<DocFileInfo> fileList = (List<DocFileInfo>) map.get("fileList");
						if (fileList != null && fileList.size() > 0) {
							foreachFiles(fileList);
						}

						// 办理信息
						@SuppressWarnings("unchecked")
						List<DocManagerInfo> docManagerList = (List<DocManagerInfo>) map.get("managerList");
						if (docManagerList != null && docManagerList.size() > 0) {
							DocumentTransactListAdapter adapterManager = new DocumentTransactListAdapter(mContext);
							listViewManager.setAdapter(adapterManager);
							adapterManager.addData(docManagerList);
							adapterManager.notifyDataSetChanged();
						} else {
							listViewManager.setVisibility(View.GONE);
						}


						//如果是传阅入口：报名信息跟传阅信息共用一个adapter跟listView；
						if (passreadTag != CODE_PASS_READ_TAG) {
							// 报名信息
							@SuppressWarnings("unchecked")
							List<SignUpInfo> dataList = (List<SignUpInfo>) map.get("signUpList");
							fillingSignUpData(dataList);
						}					}

				} else if (what == SIGNUP_SAVE) {
					// 保存报名成功
					message = getString(R.string.meet_signup_success);
					// 如果返回id，则把id设置到页面上
					String ids = response.getResultItem(ResultItem.class).getString("meeting_sign_up_id");
					if (!BeanUtils.isEmpty(ids)) {
						setSignUpIds(ids);
					}
					UIHelper.showMessage(mContext, message);

				} else if (what == CODE_DELETE_FILE) {//删除文件返回
					UIHelper.removeFileView(llFileWrap, deleteFilePath);
					deleteFilePath = null;

				}else if(what == CODE_REPLAY_PASSREAD){	//传阅提交返回
					etPassreadContent.setText("");
					etPassreadContent.setHint("你已经回复了");
					if (message != null) {
						UIHelper.showMessage(mContext, message);
					} else {
						UIHelper.showMessage(mContext, getString(R.string.system_operation_success_message));
					}
					
				}else if(what == CODE_RETURN){	//退回提交返回
					retroversionFlag = 1;//退回成功
					
				}else if(what == CODE_CALLBACK){	//撤回提交返回
					retracementFlag = 1;//撤回成功
					showBackMsg(response);
					
				}else if(what == CODE_TRANCE){
					DocumentParams params = new DocumentParams(swfNo, fpuNo, wfNo, traceNo, meetingId);
					params.setPassreadId(passreadId);
					params.setIsBackFlag(passreadTag);
					params.setIsBackFlag(1);
					params.setResultItem(item);

					Bundle data = new Bundle();
					data.putSerializable("DOCUMENT_PARAMS", params);
					UIHelper.forwardTargetActivityForResult(mContext, DocumentTransactorActivity.class, data, false, DocumentTransactorActivity.CODE_REQUEST_TRANS);
					
					//如果是会议通知，则提交当前修改的公文内容
					if (doucmentType == Constants.OPT_TYPE_HYGL_HYTZ) {
						modifyDocument();
					}	
					
				}else if(what == CODE_DELETE_SIGNUP){	//报名信息删除返回
					//不做任何处理
					
				}else if(what == CODE_PASS_READ){	//传阅信息列表
					proceePassreadData(response);
				}
				
			}
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}
		
		@Override
        public void onReturnError(HttpResponse response, ResultItem error,
                int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_data_error_message));
        }

        @Override
        public void onNetError(int what) {
            rightBtn.setClickable(true);
            showErrorMessage(getString(R.string.system_net_error_message));
        }
	};

	// 绑定报名数据
	private void fillingSignUpData(List<SignUpInfo> signUpList) {
		// 如果报名信息为空，主办会议详情隐藏报名项
		if (signUpList == null || signUpList.size() < 1) {
			//tvEmpty.setVisibility(View.VISIBLE); // 显示暂无信息
			//imEmpty.setVisibility(View.VISIBLE); 
		    llEmpty.setVisibility(View.VISIBLE); 

		} else {
			// 如果是会议通知，则可以删除当前报名数据,其他不可以删除
			if (doucmentType != Constants.OPT_TYPE_HYGL_HYTZ) {
				isDel = false;
			}

			adapterSignup = new MeetingSignupListAdapter(mContext, isDel, meetHelper);
			listViewSignUp.setAdapter(adapterSignup);
			adapterSignup.addData(signUpList);
			adapterSignup.notifyDataSetChanged();
		}
	}

	
	/** 显示传阅列表 */
	private void proceePassreadData(HttpResponse response) {
		String code = response.getResultItem(ResultItem.class).getString("code");
		// 操作成功
		if (Constants.SUCCESS_CODE.equals(code)) {
			List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
			if (!BeanUtils.isEmpty(items)) {
				List<PassreadInfo> dataList = new ArrayList<PassreadInfo>();
				for (ResultItem item : items) {
					String name = item.getString("REAL_NAME");
					String datetime = item.getString("SEND_TIME");
					String remark = item.getString("REPLY_CONTENT");
					String department = item.getString("SITE_NAME");
					String status = item.getString("READ_STATE");

					PassreadInfo bean = new PassreadInfo(name, department, datetime, remark, status);
					dataList.add(bean);
				}

				if(dataList.size()>0){
					adapterPassread = new PassreadListAdapter(mContext);
					listViewSignUp.setAdapter(adapterPassread);
					adapterPassread.addData(dataList);
					adapterPassread.notifyDataSetChanged();
					
				}else{
					llEmpty.setVisibility(View.VISIBLE); 	// 显示无信息提示
				}
				
			} else {
				llEmpty.setVisibility(View.VISIBLE);	// 显示无信息提示 
			}
		}
	}
	

	private void setViewZbhyValue(MeetInfo bean) {
		tvTitle.setText(bean.getTitle());
		tvBeginTime.setText(bean.getBeginTime());
		tvEndTime.setText(bean.getEndTime());
		tvPresider.setText(bean.getPersider());
		tvAddress.setText(bean.getAddress());
		tvContent.setText(bean.getContent());
		int line = tvContent.getLineCount();
		if(line>3){
			tvContent.setLines(3);
//			tvContent.setEllipsize(TruncateAt.END);
			tvExtend.setVisibility(View.VISIBLE);
		}
		
		//传阅不可以删除附件，不可以修改内容，主办会议本就不可以修改
		/*if(passreadTag == CODE_PASS_READ_TAG){
			tvTitle.setEnabled(false);
			tvBeginTime.setEnabled(false);
			tvEndTime.setEnabled(false);
			tvPresider.setEnabled(false);
			tvContent.setEnabled(false);
			tvAddress.setEnabled(false);
		}*/
	}

	private void setViewHytzValue(DocumentInfo bean) {
		etTitle.setText(bean.getTitle());
		etTitle.setEnabled(false);
		etTextNo.setText(bean.getDocCode());
		etTextNo.setEnabled(false);
		etDepartment.setText(bean.getDepartment());
		etDepartment.setEnabled(false);
		etUserName.setText(bean.getDrafter());
		etUserName.setEnabled(false);
		String huanji = DocumentHelper.getHj(BeanUtils.floatToInt(bean.getUrgency()));// 缓急
		tvHuanji.setText(huanji);
		String miji = DocumentHelper.getMj(BeanUtils.floatToInt(bean.getLevel()));// 密级
		tvLevel.setText(miji);
		etZhaiyao.setText(bean.getSummary()); // 摘要
		etZhaiyao.setEnabled(false);
		int line = etZhaiyao.getLineCount();
		if(line>3){
			etZhaiyao.setLines(3);
			etZhaiyao.setEllipsize(TruncateAt.END);
			tvExtend.setVisibility(View.VISIBLE);
		}
		
		//传阅不可以删除附件，不可以修改内容
		if(passreadTag == CODE_PASS_READ_TAG){
			etTitle.setEnabled(false);
			etTextNo.setEnabled(false);
			etDepartment.setEnabled(false);
			etUserName.setEnabled(false);
			tvHuanji.setEnabled(false);
			tvLevel.setEnabled(false);
		}
	}

	/** 循环附件列表PS:方法有点蠢 */
	@SuppressLint("InflateParams")
	void foreachFiles(List<DocFileInfo> fileList) {
		for (int i = 0, len = fileList.size(); i < len; i++) {
			final DocFileInfo bean = fileList.get(i);
			ViewHolderFile holder = new ViewHolderFile();

			View view = LayoutInflater.from(mContext).inflate(R.layout.govaffair_file_item, null);
			holder.rlItemWrap = (RelativeLayout) view.findViewById(R.id.rl_item_wrap);
			holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
			holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
			
			holder.btnDownload = (RoundProgressButton) view.findViewById(R.id.btn_process);
			holder.rlRoundBtnWrap = (RelativeLayout) view.findViewById(R.id.rl_round_btn_wrap);

			String extend = FileUtils.getFileExtends(bean.getFileName());
			UIHelper.setFileTypeIcon(mContext, holder.ivType, extend); // 设置文件类型

			// 判断正文操作
			if (bean.getFileCataLog() == 0) { // 【0:正文】 【1：附件】
				bodyBean = bean;
				btnOpenFile.setTag(bean);
				btnOpenFile.setVisibility(View.VISIBLE);
				tvNoTextBody.setText(getString(R.string.document_open_file));
				tvNoTextBody.setTag(bean);
				continue; // 正文不显示在附件列表中
			}
//			holder.tvFileName.setText(bean.getFileName());
			holder.tvFileName.setText(bean.getFileTitle());
			holder.tvFileName.setTag(bean.getFilePath());
			
			holder.btnDownload.setTag(bean);
			holder.btnDownload.setOnClickListener(this);
			
			//String url = UIHelper.downFileUrl(bean.getFileCode());//getString(R.string.system_servics_download).concat(bean.getFilePath());
			String url;
            //0,标识使用system_servics_download下载，1标识使用system_servics_url下载
            if("1".equals(getString(R.string.is_download_flag))){
                url = UIHelper.downFileUrl(bean.getFileCode());
            }else{
                url = getString(R.string.system_servics_download).concat(bean.getFilePath());
            }
			holder.rlRoundBtnWrap.setTag(url);//下载标识
			
			holder.rlItemWrap.setTag(bean);
			holder.rlItemWrap.setOnClickListener(this);
			
			if(isDeleteAddToken){
				holder.rlItemWrap.setOnLongClickListener(this);
			}
			
			try{
				DownloadInfoBean downBean = dao.getAppBeanByCd(bean.getFileCode());
				if(downBean!=null){	//下载完成
					int state = downBean.getState();
					if(state == DownloadInfoDAO.DOWNLOAD_STATE_2){
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_finish); // 存在则打开
						
					}else if(state == DownloadInfoDAO.DOWNLOAD_STATE_3){
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_pause); // 暂停状态
						
					}else{
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
					}
				}else{
					holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
				}
				holder.btnDownload.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
						this.getResources().getColor(R.color.transparent));
			}catch(Exception e){
				
			}

			llFileWrap.addView(view);
		}
		if(llFileWrap.getChildCount()>0){
			llFileWrap.setVisibility(View.VISIBLE);
			tvFileGroup.setVisibility(View.VISIBLE);
		}
	}


	@Override
	public boolean onLongClick(final View v) {
		if (v.getId() == R.id.rl_item_wrap) {
			//传阅没有删除附件
			if(passreadTag != CODE_PASS_READ_TAG){
				UIHelper.vibrate(mContext, 50); // 震动下
				if (llFileWrap != null) {
					final DocFileInfo bean = (DocFileInfo) v.getTag();
					String message = bean.getFileName();
					final SystemDialog chooseDialog = new SystemDialog(mContext);
					chooseDialog.setMessage("确定要删除这条“" + message + "”附件？");
					chooseDialog.setOnConfirmClickListener("删除", new View.OnClickListener() { // 确定按钮事件
						@Override
						public void onClick(View view) {
							deleteFilePath = bean.getFilePath();
							UIHelper.deleteFile(mContext, callBack, helper, bean.getFileCode(), CODE_DELETE_FILE);
						}
					});
					chooseDialog.setOnCancelClickListener("放弃", new View.OnClickListener() { // 取消
						@Override
						public void onClick(View v) {
							if (chooseDialog != null) {
								chooseDialog.dismiss();
							}
						}
					});
					chooseDialog.show();
				}
			}
			
		}else if(v.getId() == R.id.rl_add_item_wrap){
			UIHelper.vibrate(mContext, 50); // 震动下
			final SystemDialog chooseDialog = new SystemDialog(mContext);
			chooseDialog.setMessage("确定要删除这条附件？");
			chooseDialog.setOnConfirmClickListener("删除", new View.OnClickListener() {	//确定按钮事件
				@Override
				public void onClick(View view) {
					if(llFileWrap!=null){
						int fileSize = llFileWrap.getChildCount();
						if(fileSize>0){
							DocFileInfo bean = (DocFileInfo) v.getTag();
							if(bean==null) return;
							
							for(int i=0; i<fileSize; i++){
								View fileView = llFileWrap.getChildAt(i);
								if(fileView==null){
									continue;
								}
								TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
								String tempPath = (String) tvFileName.getTag();
								if(bean.getFilePath().equals(tempPath)){	//如果按钮相等，则删除这条数据
									llFileWrap.removeViewAt(i);
								}
							}
						}
					}
				}
			});
			chooseDialog.setOnCancelClickListener("放弃", new View.OnClickListener() {		//取消
				@Override
				public void onClick(View v) {
					if(chooseDialog!=null){
						chooseDialog.dismiss();
					}
				}
			});
			chooseDialog.show();
		}
		return false;
	}

	private class ViewHolderFile {
		TextView tvFileName;
		ImageView ivType;
		RoundProgressButton btnDownload;
		RelativeLayout rlItemWrap, rlRoundBtnWrap;
	}

	
	private Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(msg.what == CODE_MODIFY_UPLOAD_FILE){//附件上传返回
				ResultItem item = (ResultItem) msg.obj;
				String code = item.getString("code");
				String message = item.getString("message");
				String fileCode = item.getString("file_code");
				
				if (Constants.SUCCESS_CODE.equals(code)) {//上传成功
					UIHelper.showMessage(mContext, "附件上传成功");
					//将附件复制到下载目录
					if(UIHelper.copeChildFile(fileCode, mdfFilePath)){
						
						String newPath = UIHelper.getDownNewFilePath(fileCode, mdfFilePath);
						//添加这个附件到附件列表中
						UIHelper.setFileWrap(mContext, llFileWrap, MeetDetailActivity.this, 
								MeetDetailActivity.this, mdfFileName, mdfFilePath, fileCode, newPath);
					}
					mdfFileName = null; 
					mdfFilePath = null;
					
				}else{//上传失败
					UIHelper.showMessage(mContext, "附件上传失败");
				}
				
			}else if(msg.what == CODE_UPLOAD_TEXT_FILE){//上传正文返回
				ResultItem item = (ResultItem) msg.obj;
				String code = item.getString("code");
				String message = item.getString("message");
				UIHelper.showMessage(mContext, message);
				String fileCode = item.getString("file_code");
				
				if(Constants.SUCCESS_CODE.equals(code)){//操作成功
					
					if(UIHelper.copeTextBodyFile(fileCode)){
						//删除临时文件
						UIHelper.deleteTempDoc();
						//改变打开正文
						tvNoTextBody.setText(getString(R.string.document_open_file)); // 显示打开正文
						btnOpenFile.setTag(fileCode);
						tvNoTextBody.setTag(fileCode);
					}
				}
				
			}else{
				if(!BeanUtils.isEmpty(msg.obj)){
					UIHelper.showMessage(mContext, msg.obj.toString());
				}else{
					UIHelper.showMessage(mContext, "未知错误");
				}
			}
		}
	};
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// 选择人员返回
		if (DIALOG_SIGNUP == requestCode && data != null) {
			try {
				ArrayList<String> names = data
						.getStringArrayListExtra(ChoosePeopleActivity.KEY_USER_NAMES);
				ArrayList<String> ids = data
						.getStringArrayListExtra(ChoosePeopleActivity.KEY_USER_IDS);
				ArrayList<String> siteNames = data
						.getStringArrayListExtra(ChoosePeopleActivity.KEY_USER_SITENAMES);
				ArrayList<String> userMobiles = data
						.getStringArrayListExtra(ChoosePeopleActivity.KEY_USER_MOBILES);
				if (names != null && names.size() > 0) {
					List<SignUpInfo> tempList = new ArrayList<SignUpInfo>();
					int size = names.size();
					for (int i = 0; i < size; i++) {
						SignUpInfo bean = new SignUpInfo();
						//bean.setSignUpId(BeanUtils.isEmptyStr(ids.get(i))); // 参会人ID
						bean.setConventioner(BeanUtils.isEmptyStr(names.get(i))); // 参会人
						bean.setConventionerRole(BeanUtils.isEmptyStr(siteNames.get(i))); // 参会人职位(部门？)
						bean.setContactTel(BeanUtils.isEmptyStr(userMobiles.get(i))); // 联系电话
						tempList.add(bean);
					}
					if (adapterSignup == null) {
						adapterSignup = new MeetingSignupListAdapter(mContext, isDel, meetHelper);
						listViewSignUp.setAdapter(adapterSignup);
						//tvEmpty.setVisibility(View.GONE);
						//imEmpty.setVisibility(View.GONE);
						llEmpty.setVisibility(View.GONE); 
						listViewSignUp.setVisibility(View.VISIBLE);
					}
					adapterSignup.addData(tempList);
					adapterSignup.notifyDataSetChanged();
				}

			} catch (Exception e) {
				Log.e("======返回异常======", e.getMessage());
			}
		}else if (requestCode == CODE_INPUT_SUGGEST && data != null) {
			try {
				String content = data.getStringExtra("SUGGEST_CONTENT");
				if (!BeanUtils.isEmpty(content)) {
					etPassreadContent.setText(content);
				}
			} catch (Exception e) {

			}
			
		}else if(requestCode == DocumentTransactorActivity.CODE_REQUEST_TRANS && data!=null){
			int opType = data.getIntExtra(DocumentTransactorActivity.KEY_BACK, 0);
			if(opType==1){	//如果办理信息进行处理了，则关闭当前公文详情，否则，证明在办理信息中，没有进行任何流程上操作
				finish();
			}
			
		}else if(requestCode==SDCardFileExplorerActivity.REQUEST_CODE_FILE && data!=null){
			
			String fileName = data.getStringExtra("FILE_NAME");
			String filePath = data.getStringExtra("FILE_PATH");
			//更改附件选择，然后是选择一个附件就上传
			List<File> files = new ArrayList<File>();
			File file = new File(filePath);
			if(file!=null && file.exists()){
				files.add(file);
				mdfFilePath = filePath; 
				mdfFileName = fileName;
				UploadParams params;
				if (doucmentType != Constants.OPT_TYPE_HYGL_HYTZ) {
					params = new UploadParams(getString(R.string.system_servics_url), "uploadFile", meetingId, swfNo, "", CODE_MODIFY_UPLOAD_FILE);
				}else{
					params = new UploadParams(getString(R.string.system_servics_url), "uploadFile", meetingId, swfNo, "", CODE_MODIFY_UPLOAD_FILE);
				}
				params.setListFile(files);
				HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
				post.execute(params);
				
				//老方式上传附件
//				UIHelper.modifyFileUpload(mContext, callBack, helper, CODE_MODIFY_UPLOAD_FILE, meetingId, "", files);
			}else{
				UIHelper.showMessage(mContext, getString(R.string.upload_file_not_exist));
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * 验证报名表的数据，验证通过就提交报名数据 
	 */
	protected void checkSignUpData() {
		if (adapterSignup == null) {
			UIHelper.showMessage(mContext, "请添加报名人员");
			return;
		}
		List<SignUpInfo> tempList = adapterSignup.getSignUpList();
		if (tempList != null && tempList.size() > 0) {
			for (int i = 0; i < tempList.size(); i++) {
				String mobile = tempList.get(i).getContactTel();
				if (BeanUtils.isEmpty(mobile)) {
					UIHelper.showMessage(mContext, "第" + (i + 1) + "行"
							+ "手机号码不能为空");
					return;
				}
				if (!BeanUtils.isMobileNO(mobile)) {
					UIHelper.showMessage(mContext, "第" + (i + 1) + "行"
							+ "手机号码错误");
					return;
				}
			}
			
			/** 提交报名数据 */
			saveMeetSignUp(tempList);

		} else {
			UIHelper.showMessage(mContext, "请添加报名人员");
		}
	}

	/**
	 * 保存页面修改后的或者新增的所有报名信息
	 */
	protected void saveMeetSignUp(List<SignUpInfo> tempList) {
		StringBuffer sbId = new StringBuffer();
		StringBuffer sbTel = new StringBuffer();
		StringBuffer sbName = new StringBuffer();
		StringBuffer sbRole = new StringBuffer();
		StringBuffer sbSummary = new StringBuffer();
		
		for (int i = 0; i < tempList.size(); i++) {
			SignUpInfo bean = tempList.get(i);
			if (BeanUtils.isEmpty(bean.getSignUpId())) {
				sbId.append("").append("$");//新增的
			} else {
				sbId.append(bean.getSignUpId()).append("$");//编辑的
			}
			sbTel.append(bean.getContactTel()).append("$");
			sbName.append(bean.getConventioner()).append("$");
			sbRole.append(bean.getConventionerRole()).append("$");
			sbSummary.append(bean.getSummary()).append("$");
		}
		
		SignUpInfo signUpInfo = new SignUpInfo();
		signUpInfo.setBizId(meetingId);// 会议ID
		signUpInfo.setWfNo(wfNo);// 跟踪编号
		signUpInfo.setTraceNo(traceNo);// 流程编号
		signUpInfo.setSignUpId(sbId.substring(0, sbId.length() - 1)); // 报名信息ID："1&2"，新增时ID为空
		signUpInfo.setContactTel(sbTel.substring(0, sbTel.length() - 1)); // 联系人电话："13500000000&13500000000"
		signUpInfo.setConventioner(sbName.substring(0, sbName.length() - 1)); // 参会人："张三&李四"
		signUpInfo
				.setConventionerRole(sbRole.substring(0, sbRole.length() - 1)); // 参会人职务："科长&职员"
		signUpInfo.setSummary(sbSummary.substring(0, sbSummary.length() - 1)); // 备注："备注&备注"
		
		/** 提交数据 */
		meetHelper.saveSignUp(signUpInfo, SIGNUP_SAVE);
	}

	/**
	 * 设置页面的报名id
	 * @param item
	 */
	protected void setSignUpIds(String ids) {
		String[] idArray = ids.split(",");
		List<SignUpInfo> tempList = adapterSignup.getSignUpList();
		for (int i = 0; i < idArray.length; i++) {
			// 把回去到的id，设置到页面上,包括已经存在的列表
			String id = idArray[i];
			tempList.get(i).setSignUpId(id);
		}
	}

	/** 去办理送出界面 */
	void goTransactorActivity() {
		meetHelper.loadTranceData(swfNo, fpuNo, CODE_TRANCE);
	}
	
	/** 送出时，得保存修改后的公文 */
	void modifyDocument(){
		etTitle.setTag(meetingId);
		DocumentAddHelper addHelper = new DocumentAddHelper(mContext, callBack, helper, 1);
		addHelper.submit(etTitle, etTextNo, etDepartment, etUserName, tvHuanji, tvLevel, etZhaiyao, CODE_MODFLY,rightBtn);
	}

	/** 退件 */
	void showDocumentReturnDialog() {
		final TextDialog dialog = new TextDialog(mContext);
		dialog.setTvTips(getString(R.string.return_tips));
		dialog.setOnConfirmClickListener(getString(R.string.system_dialog_confirm), new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String reason = dialog.getMessage();
				ApiRequest request = OAServicesHandler.rejectWorkFlow(traceNo,
						wfNo, swfNo, meetingId, reason);
				if (request != null) {
					request.setMessage(getString(R.string.system_commit_message));
					helper.invokeWidthDialog(request, callBack, CODE_RETURN);
				}
			}
		});
		dialog.setOnCancelClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	/** 撤回 */
	void showDocumentRecall() {
		final TextDialog dialog = new TextDialog(mContext);
		dialog.setTvTips(getString(R.string.recall_tips));
		dialog.setOnConfirmClickListener(getString(R.string.system_dialog_confirm), new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String reason = dialog.getMessage();
				ApiRequest request = OAServicesHandler.callBackWorkFlow(
						traceNo, meetingId, reason);
				if (request != null) {
					request.setMessage(getString(R.string.system_commit_message));
					helper.invokeWidthDialog(request, callBack, CODE_CALLBACK);
				}
			}
		});
		dialog.setOnCancelClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	private void goPassread() {
		Bundle data = new Bundle();
		data.putString("documentId", meetingId);
		data.putString("wfNo", wfNo);
		UIHelper.forwardTargetActivity(mContext, PassReadChoosePeopleActivity.class, data, false);
	}

	/** 注册广播 */
	private void registerBroadcast() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(TextBodyUtile.ACTION_SAVE_FILE);
		registerReceiver(saveFileBroadcast, filter);
	}

	@Override
	protected void onPause() {
		super.onPause();
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.unRegUiHandler();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.regUiHandler();//界面恢复调用
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		mContext = null;
		if (saveFileBroadcast != null) {
			unregisterReceiver(saveFileBroadcast);
		}
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.unRegUiHandler();
	}

	private BroadcastReceiver saveFileBroadcast = new BroadcastReceiver() {
		@Override
		public void onReceive(final Context context, Intent intent) {
			// 接收到的参数
			final String filePath = intent.getExtras().getString("filePath"); // 文件路径
			// if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) { //
			// 主办会议没有正文编辑后上传，会议通知有（公文详情）
			// return;
			// }
			// 只有可以新建的时候可以进行上传
			if (isNewDoc) {
				// 证明已经做了保存操作
				if (TextBodyUtile.IS_SAVE_FILE && TextBodyUtile.FILE_PATH.equals(filePath)) {
					tvNoTextBody.setText(getString(R.string.document_open_file)); // 显示打开正文
					btnOpenFile.setTag(Constants.TAG_TEMP_FILE);	//再次打开，则打开临时文件
					tvNoTextBody.setTag(Constants.TAG_TEMP_FILE);//再次打开，则打开临时文件
					final SystemDialog sysDialog = new SystemDialog(context);
					sysDialog.setTitle(context.getString(R.string.upload_title));
					sysDialog.setMessage(context.getString(R.string.upload_text_body));
					sysDialog
							.setOnCancelClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									sysDialog.dismiss();
								}
							});
					sysDialog.setOnConfirmClickListener(context.getString(R.string.upload_text_btn),
							new View.OnClickListener() {
								@Override
								public void onClick(View v) {
									File file = new File(filePath);
									if (file != null && file.exists()) {
										meetHelper.uploadDocFile(meetingId, swfNo, traceNo, file, CODE_UPLOAD_TEXT_FILE, handler);
									} else {
										UIHelper.showMessage(mContext, context.getString(R.string.upload_file_lose));
									}
									sysDialog.dismiss();
								}
							});
					sysDialog.show();
					TextBodyUtile.IS_SAVE_FILE = false;
					TextBodyUtile.FILE_PATH = "";
				}
			}
		}
	};

	/**
	 * 初始化动画
	 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		if (passreadTag==CODE_PASS_READ_TAG) {
			offset = (screenW / 3 - bmpW) / 2;// 计算偏移量-->3个选项卡
		}else{
			offset = (screenW / 4 - bmpW) / 2;// 计算偏移量-->4个选项卡
		}
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}

	/**
	 * 初始化头标
	 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.tv_1);
		tv2 = (TextView) findViewById(R.id.tv_2);
		
		tv3 = (TextView) findViewById(R.id.tv_3);
		tv4 = (TextView) findViewById(R.id.tv_4);
		if (passreadTag == CODE_PASS_READ_TAG) {
			tv3.setVisibility(View.GONE);
			tv4.setText(getString(R.string.pass_read_title));	//传阅信息;
		}

		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
		tv3.setOnClickListener(new MyOnClickListener(2));
		tv4.setOnClickListener(new MyOnClickListener(3));
	}

	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	@SuppressLint("InflateParams")
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_pager);
		views = new ArrayList<View>();
		LayoutInflater inflater = getLayoutInflater();

		if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {
			view1 = inflater.inflate(R.layout.meet_detail_basic, null); // 加载主板会议
		} else {
			view1 = inflater.inflate(R.layout.document_detail_basic, null); // 公文详情数据展示
		}

		view2 = inflater.inflate(R.layout.document_detail_body, null);
		view3 = inflater.inflate(R.layout.document_detail_transact, null);
		view4 = inflater.inflate(R.layout.meet_sign_up, null);

		view2.findViewById(R.id.btn_new_file).setOnClickListener(this);

		views.add(view1);
		views.add(view2);
		
		//是否是传阅标示
		if (passreadTag!=CODE_PASS_READ_TAG) {
			views.add(view3);
		}
		
		views.add(view4);

		viewPager.setAdapter(new MyViewPagerAdapter(views));
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}

	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}

	public class MyViewPagerAdapter extends PagerAdapter {
		private List<View> mListViews;

		public MyViewPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(mListViews.get(position), 0);

			if (currIndex == 0) {
				UIHelper.setTabTextHighlight(mContext, tv1);
				if (isFirst1) {
					// 主办会议查询的是会议详情接口，会议通知查询的是公文详情
					if (doucmentType == Constants.OPT_TYPE_HYGL_ZBHY) {
						meetHelper.getMeetDetail(meetingId, wfNo, CODE_BASIC);
					} else {
						meetHelper.getDocumentDetail(meetingId, wfNo, CODE_BASIC);
					}
					isFirst1 = false;
					showBaomingBtn(false);
				}
			}

			return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);// True:图片停在动画结束位置
			animation.setDuration(300);
			imageView.startAnimation(animation);

			if (currIndex == 0) {
				UIHelper.setTabTextHighlight(mContext, tv1, tv2, tv3, tv4);
				showBaomingBtn(false);

			} else if (currIndex == 1) {	//打开正文
				UIHelper.hideKeyboard(MeetDetailActivity.this);	//隐藏软键盘
				UIHelper.setTabTextHighlight(mContext, tv2, tv1, tv3, tv4);
				showBaomingBtn(false);
				
				if (bodyBean != null && isFirstOpen) {
					isFirstOpen = false;
					//String url = UIHelper.downFileUrl(bodyBean.getFileCode());//getString(R.string.system_servics_download).concat(bodyBean.getFilePath());
					String url;
		            //0,标识使用system_servics_download下载，1标识使用system_servics_url下载
		            if("1".equals(getString(R.string.is_download_flag))){
		                url = UIHelper.downFileUrl(bodyBean.getFileCode());
		            }else{
		                url = getString(R.string.system_servics_download).concat(bodyBean.getFilePath());
		            }
		            
		            //来文只能是阅读模式
		            String readModel = Constants.WPS_NORMAL;
		            if(Constants.LW_CODE.equals(swfNo)){
		            	readModel = Constants.WPS_READMODE;
		            }
					FileDownUtil downUtil = new FileDownUtil(mContext, url, bodyBean.getFileName(), bodyBean.getFileCode(), bodyBean.getFileType(),
							bodyBean.getFileSize(),  "正文正在下载", readModel);
					downUtil.start();
				}

			} else if (currIndex == 2) {
				if (passreadTag==CODE_PASS_READ_TAG) {	//如果是传阅入口，则没有报名信息
					UIHelper.hideKeyboard(MeetDetailActivity.this);	//隐藏软键盘
					showBaomingBtn(false);
					UIHelper.setTabTextHighlight(mContext, tv4, tv1, tv2, tv3);
					
				}else{
					UIHelper.hideKeyboard(MeetDetailActivity.this);	//隐藏软键盘
					UIHelper.setTabTextHighlight(mContext, tv3, tv1, tv2, tv4);
					showBaomingBtn(false);
				}
				
				if (isFirst3) {
					if (passreadTag == CODE_PASS_READ_TAG) {
						UIHelper.getPassreadInfo(mContext, callBack, helper, CODE_PASS_READ, wfNo);
					}
					isFirst3 = false;
				}

			} else if (currIndex == 3) {
				showBaomingBtn(true);
				UIHelper.setTabTextHighlight(mContext, tv4, tv1, tv2, tv3);
			}
		}
	}

	void goSignActivity(boolean flag) {
		Bundle data = new Bundle();
		data.putString("documentId", meetingId);
		data.putString("wfNo", wfNo);
		data.putString("traceNo", traceNo);
		data.putString("fpuNo", fpuNo); // 当前环节编号
		data.putString("swfNo", swfNo); // 系统流程编号
		data.putString("passreadId", passreadId); // 传阅编号
		data.putInt("IS_PASS_READ", passreadTag); // 传阅入口标示
		data.putBoolean("isSign", flag);
		data.putInt("isBackFlag", 2);
		UIHelper.forwardTargetActivity(mContext,
				DocumentSignRejectActivity.class, data, true);
	}

	private void showBaomingBtn(boolean show) {
		if (show) {
			if (doucmentType != Constants.OPT_TYPE_HYGL_HYTZ) {
				btnBaoming.setVisibility(View.GONE);
				rightBtn.setVisibility(View.VISIBLE);
			} else {
				btnBaoming.setVisibility(View.VISIBLE);
				rightBtn.setVisibility(View.GONE);
			}
		} else {
			btnBaoming.setVisibility(View.GONE);
			rightBtn.setVisibility(View.VISIBLE);
		}
	}

	@Override
	public void onProgressUpdate(String url, long totalSize, long dealtSize) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);
		if(btnDown == null)return;
		btnDown.setBackgroundResource(R.drawable.ic_down_ing);	//正在下载
		btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.gray_split_line_bg), 
				this.getResources().getColor(R.color.down_progress_color));
		
		float num = (float)dealtSize / (float)totalSize;
		int result = (int)(num * 100);
		
		btnDown.setProgress(result);
	}

	@Override
	public void onDownloadComplete(String url) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);	//下载完成
		if(btnDown == null)return;
		btnDown.setBackgroundResource(R.drawable.ic_down_finish);
		btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
				this.getResources().getColor(R.color.transparent));
		
		UIHelper.openFile(mContext, url);
	}

	@Override
	public void onDownloadStateChange(String url, int state) {
		switch (state) {
		case DownloadInfoDAO.DOWNLOAD_STATE_3:
			RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);	//暂停下载
			if(btnDown!=null){
				btnDown.setBackgroundResource(R.drawable.ic_down_pause);
				btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
						this.getResources().getColor(R.color.transparent));
			}
			break;
		}
	}

	@Override
	public void onDownloadError(String url, int state) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);
		if(btnDown!=null){
			btnDown.setBackgroundResource(R.drawable.ic_down);
			btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.gray_split_line_bg), 
					this.getResources().getColor(R.color.down_progress_color));
		}
		UIHelper.showMessage(mContext, "下载错误");
	}
	
	/*private RoundProgressButton showDownBtn(String url, int backDerbale, boolean enabled){
		View btntmp = llFileWrap.findViewWithTag(url);
		RoundProgressButton btn = null;
		if(btntmp != null && btntmp instanceof RelativeLayout)
			btn = (RoundProgressButton)btntmp.findViewById(R.id.btn_process);
		
		if(btn!=null){
			btn.setEnabled(enabled);
			btn.setBackgroundResource(backDerbale);
		}
		return btn;
	}*/
	
	/** 显示系统返回操作的信息 */
    private void showBackMsg(HttpResponse response) {
        String code = response.getResultItem(ResultItem.class).getString("code");
        // 操作成功
        String message = response.getResultItem(ResultItem.class).getString("message");
        UIHelper.showMessage(mContext, message);
        // 当成功的时候，刷新下自己
        if (Constants.SUCCESS_CODE.equals(code)) {
            //refreshSelf();
            finish();
        }
       // finish();
    }
    
    /**
     * 刷新自己
     */
    private void refreshSelf() {
        
     // 封装交互数据：需要去掉服务端返回的多余“.0”
        Bundle data = new Bundle();
        data.putString("documentId", documentId);//公文ID
        data.putString("wfNo", wfNo);//流程编号
        data.putString("fpuNo", fpuNo);//当前环节编号
        data.putString("swfNo", swfNo);// 系统流程编号
        data.putString("traceNo", traceNo);//// 跟踪编号
        data.putInt("doucmentType", doucmentType);// 标示会议通知
        data.putInt("IS_PASS_READ", passreadTag);   //传阅入口标示
        data.putString("passreadId", passreadId);/// 传阅编号
        data.putInt("PASS_READ_TYPE", passreadType);//
        data.putInt("DEAL_WITH_FLAG", dealwithFlag);/// 这个参数是办理界面的返回值：办理结果标志：1-办理成功，0-未办理或办理失败
        
        // 跳转到详情页面
        UIHelper.forwardTargetActivity(mContext,
                MeetDetailActivity.class, data, true);
    }
    
    
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			onClickBack();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private void onClickBack(){
		if(Constants.NOTIFY_DETAIL_BACK){
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(mContext, MainActivity.class, null, true);
	        
		}else{
			UIHelper.deleteTempDoc();
			finish();
		}
	}

}
