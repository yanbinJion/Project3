package com.powerriche.mobile.na.oa.down;


/**
 * 类描述：<br> 
 * 下载信息字段
 * @author  Alex
 * @date    2014-2-18
 */
public class DownloadInfoField {
	
	/**
	 * 表名
	 */
	public static final String TABLE_NAME = "t_download_info";

	/**
	 * 主键ID
	 */
	public final static String ID = "id";
	
	/**
	 * 下载地址
	 */
	public final static String URL = "url";
	
	/**
	 * 文件code
	 */
	public final static String FILECODE = "fileCode";

	/**
	 * 文件类型
	 */
	public final static String FILETYPE = "fileType";
	
	/**
     * 文件大小
     */
    public final static String FILESIZE = "fileSize";
	
	/**
	 * 状态
	 */
	public final static String STATE = "state";
	
	/**
	 * 上报状态
	 */
	public final static String REPORTSTATE = "reportstate";
	
	/**
	 * 路径
	 */
	public final static String DOWNDIR = "downDir";
	
	/**
	 * 创建时间
	 */
	public final static String CREATETIME = "createtime";
	
	public final static String NAME = "name";
	
	
	public static String getCreateSQL() {

		StringBuffer sql = new StringBuffer();
		sql.append("CREATE TABLE  IF NOT EXISTS ").append(TABLE_NAME).append('(');
		sql.append(ID).append(" INTEGER PRIMARY KEY  , ");
		sql.append(FILECODE).append(" TEXT,");
		sql.append(URL).append(" TEXT,");
		sql.append(FILETYPE).append(" TEXT,");
		sql.append(FILESIZE).append(" LONG,");
		sql.append(STATE).append(" INT,");
		sql.append(DOWNDIR).append(" TEXT,");
		sql.append(NAME).append(" TEXT,");
		sql.append(REPORTSTATE).append(" INT,");
		sql.append(CREATETIME).append(" INT);");

		return sql.toString();
	}

	public static String getDropSQL() {
		return "DROP TABLE  IF EXISTS " + TABLE_NAME;
	}
}
