package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.Attendance;
import com.powerriche.mobile.oa.tools.DateUtils;

import java.util.List;


public class RecordListAdapter extends BaseAdapter {

	private Context mContext = null;
	private LayoutInflater inflater;

	private List<Attendance> mDataList;

	public RecordListAdapter(Context context,List<Attendance> dataList) {
		this.mContext = context;
		this.inflater = LayoutInflater.from(this.mContext);
		this.mDataList = dataList;
	}

	
	@Override
	public int getCount() {
		return mDataList.size();
	}

	@Override
	public Object getItem(int position) {
		return mDataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		ViewHolder holder = null;
        if (view == null) {
        	holder = new ViewHolder();
        	view = inflater.inflate(R.layout.record_item, null);
        	holder.tv_now_day = (TextView) view.findViewById(R.id.tv_now_day);
        	holder.tv_now_week = (TextView) view.findViewById(R.id.tv_now_week);
        	holder.tv_morning_sign_in_time = (TextView) view.findViewById(R.id.tv_morning_sign_in_time);
        	holder.tv_morning_sign_in_working = (TextView) view.findViewById(R.id.tv_morning_sign_in_working);
        	holder.tv_morning_sign_in_location = (TextView) view.findViewById(R.id.tv_morning_sign_in_location);
        	holder.tv_morning_sign_out_time = (TextView) view.findViewById(R.id.tv_morning_sign_out_time);
        	holder.tv_morning_sign_out_working = (TextView) view.findViewById(R.id.tv_morning_sign_out_working);
        	holder.tv_morning_sign_out_location = (TextView) view.findViewById(R.id.tv_morning_sign_out_location);
        	holder.tv_afternoon_sign_in_time = (TextView) view.findViewById(R.id.tv_afternoon_sign_in_time);
        	holder.tv_afternoon_sign_in_working = (TextView) view.findViewById(R.id.tv_afternoon_sign_in_working);
        	holder.tv_afternoon_sign_in_location = (TextView) view.findViewById(R.id.tv_afternoon_sign_in_location);
        	holder.tv_afternoon_sign_out_time = (TextView) view.findViewById(R.id.tv_afternoon_sign_out_time);
        	holder.tv_afternoon_sign_out_working = (TextView) view.findViewById(R.id.tv_afternoon_sign_out_working);
        	holder.tv_afternoon_sign_out_location = (TextView) view.findViewById(R.id.tv_afternoon_sign_out_location);
            view.setTag(holder);
        } else {
        	holder = (ViewHolder) view.getTag();
        }
        Attendance data = mDataList.get(position);
        int color1 = mContext.getResources().getColor(R.color.text_color_bdb76b);
		int color2 = mContext.getResources().getColor(R.color.text_color_ff2525);
        holder.tv_now_day.setText(data.getAttendDate());
        holder.tv_now_week.setText(DateUtils.dayForWeek(data.getAttendDate()));
        // 上午签到签退
        if (data.getMorningSignIn().equals("1")) {
        	
        	holder.tv_morning_sign_in_time.setText(DateUtils.getDateStr(data.getMorningSignInTime(), DateUtils.HOUR_MINUTE_FORMAT));
        	holder.tv_morning_sign_in_location.setText(data.getMorningSignInAddress());
        } else {
        	holder.tv_morning_sign_in_time.setText("未签到");
        	holder.tv_morning_sign_in_location.setText("未签到");
        }
        holder.tv_morning_sign_in_working.setText(data.getMorningSignInState());
        holder.tv_morning_sign_in_working.setTextColor(!data.isMorningSignInFlag() ? color1 : color2);
        if (data.getMorningSignOut().equals("1")) {
        	holder.tv_morning_sign_out_time.setText(DateUtils.getDateStr(data.getMorningSignOutTime(), DateUtils.HOUR_MINUTE_FORMAT));
            holder.tv_morning_sign_out_location.setText(data.getMorningSignOutAddress());
        } else {
        	holder.tv_morning_sign_out_time.setText("未签退");
            holder.tv_morning_sign_out_location.setText("未签退");
        }
        holder.tv_morning_sign_out_working.setText(data.getMorningSignOutState());
        holder.tv_morning_sign_out_working.setTextColor(data.isMorningSignOutFlag() ? color1 : color2);
        // 下午签到签退
        if (data.getAfternoonSignIn().equals("1")) {
        	holder.tv_afternoon_sign_in_time.setText(DateUtils.getDateStr(data.getAfternoonSignInTime(), DateUtils.HOUR_MINUTE_FORMAT));
        	holder.tv_afternoon_sign_in_location.setText(data.getAfternoonSignInAddress());
        } else {
        	holder.tv_afternoon_sign_in_time.setText("未签到");
        	holder.tv_afternoon_sign_in_location.setText("未签到");
        }
        holder.tv_afternoon_sign_in_working.setText(data.getAfternoonSignInState());
        holder.tv_afternoon_sign_in_working.setTextColor(!data.isAfternoonSignInFlag() ? color1 : color2);
        if (data.getAfternoonSignOut().equals("1")) {
        	holder.tv_afternoon_sign_out_time.setText(DateUtils.getDateStr(data.getAfternoonSignOutTime(), DateUtils.HOUR_MINUTE_FORMAT));
        	holder.tv_afternoon_sign_out_location.setText(data.getAfternoonSignOutAddress());
        } else {
        	holder.tv_afternoon_sign_out_time.setText("未签退");
        	holder.tv_afternoon_sign_out_location.setText("未签退");
        }
        holder.tv_afternoon_sign_out_working.setText(data.getAfternoonSignOutState());
        holder.tv_afternoon_sign_out_working.setTextColor(data.isAfternoonSignOutFlag() ? color1 : color2);
		return view;
	}

	
	private class ViewHolder {
		private TextView tv_now_day;
		private TextView tv_now_week;
		private TextView tv_morning_sign_in_time;
		private TextView tv_morning_sign_in_working;
		private TextView tv_morning_sign_in_location;
		private TextView tv_morning_sign_out_time;
		private TextView tv_morning_sign_out_working;
		private TextView tv_morning_sign_out_location;
		private TextView tv_afternoon_sign_in_time;
		private TextView tv_afternoon_sign_in_working;
		private TextView tv_afternoon_sign_in_location;
		private TextView tv_afternoon_sign_out_time;
		private TextView tv_afternoon_sign_out_working;
		private TextView tv_afternoon_sign_out_location;
	}

	
}
