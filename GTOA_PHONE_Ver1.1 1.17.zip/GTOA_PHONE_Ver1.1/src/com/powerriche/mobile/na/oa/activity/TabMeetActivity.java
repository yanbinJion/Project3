package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.DocumentHyglHytzHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentHyglYbhyHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentHyglZbhyHelper;
import com.powerriche.mobile.na.oa.activity.view.BaseLinearLayout;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 会议管理
 * 
 * @author 李运期
 * @date 2015年4月25日
 * @version v1.0
 */
public class TabMeetActivity extends BaseLinearLayout implements OnClickListener{

	private static final String	TAG	= "TabMeetActivity";

	private Context mContext;
	private MainActivity mainActivity;
	
	//********************页卡相关变量************************
	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片

	private TextView tv1, tv2, tv3;
	private View view1, view2, view3;

	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度
	
	
	
	//---------主办会议相关控件及变量-------------
	private PullToRefreshListView pullViewZbhy;
	private ListView listViewZbhy;
	private TextView tvNoDataMsgZbhy;
	private int pageIndexZbhy = 1;
	public static boolean isFirst1 = true;
	private DocumentHyglZbhyHelper zbhyHelper;

	//---------会议通知相关控件及变量-------------
	private PullToRefreshListView pullViewHytz;
	private ListView listViewHytz;
	private TextView tvNoDataMsgHytz;
	private int pageIndexHytz = 1;
	public static boolean isFirst2 = true;
	private DocumentHyglHytzHelper hytzHelper;

	//---------已办会议相关控件及变量-------------
	private PullToRefreshListView pullViewYbhy;
	private ListView listViewYbhy;
	private TextView tvNoDataMsgYbhy;
	private int pageIndexYbhy = 1;
	public static boolean isFirst3 = true;
	private DocumentHyglYbhyHelper ybhyHelper;
	

	public TabMeetActivity(Context context) {
		super(context);
		this.mContext = context;
		LayoutInflater.from(context).inflate(R.layout.main_meet, this, true);
		mainActivity = (MainActivity) context;
	}

	public TabMeetActivity(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.mContext = context;
	}

	@Override
	public void onCreate(Intent intent) {
		bindView();
		loadData4SendMeet();//第一个加载项
	}

	private void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackVisibility(View.INVISIBLE);
		topActivity.setTopTitle(mainActivity.getString(R.string.menu_hygl));//顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.INVISIBLE);//隐藏右边按钮
		//topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
		//topActivity.setRightBtnOnClickListener(this);
		
		initImageView();
		initTextView();
		initViewPager();
		
		initZbhyView();
		initHytzView();
		initYbhyView();
	}

	/**
	 * 初始化主办会议控件 
	 */
	void initZbhyView(){
		pullViewZbhy = (PullToRefreshListView) view1.findViewById(R.id.pulllistview_zbhy);
		pullViewZbhy.setPullRefreshEnabled(true);
		pullViewZbhy.setPullLoadEnabled(false);
		pullViewZbhy.setScrollLoadEnabled(true);

		listViewZbhy = pullViewZbhy.getRefreshableView();
		UIHelper.setListViewAttribute(listViewZbhy);

		pullViewZbhy.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexZbhy = 1;
				zbhyHelper.loadData(Constants.OPT_TYPE_HYGL_ZBHY, Constants.WHAT_REQUEST_HYGL_ZBHY, pageIndexZbhy, false);
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexZbhy = pageIndexZbhy + 1;
				zbhyHelper.loadData(Constants.OPT_TYPE_HYGL_ZBHY, Constants.WHAT_REQUEST_HYGL_ZBHY, pageIndexZbhy, false);
			}
		});
		tvNoDataMsgZbhy = (TextView) view1.findViewById(R.id.tv_no_data_msg);
		tvNoDataMsgZbhy.setVisibility(View.GONE);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		listViewZbhy.addHeaderView(header);
		
		//初始化帮助类
		zbhyHelper = new DocumentHyglZbhyHelper(mContext, header, tvNoDataMsgZbhy, pullViewZbhy, listViewZbhy, mainActivity, callBack);
	}
	
	
	/**
	 * 初始化会议通知控件
	 */
	void initHytzView(){
		pullViewHytz = (PullToRefreshListView) view2.findViewById(R.id.pulllistview_hytz);
		pullViewHytz.setPullRefreshEnabled(true);
		pullViewHytz.setPullLoadEnabled(false);
		pullViewHytz.setScrollLoadEnabled(true);
		
		listViewHytz = pullViewHytz.getRefreshableView();
		UIHelper.setListViewAttribute(listViewHytz);
		
		pullViewHytz.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexHytz = 1;
				hytzHelper.loadData(Constants.OPT_TYPE_HYGL_HYTZ, Constants.WHAT_REQUEST_HYGL_HYTZ, pageIndexHytz, false);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexHytz = pageIndexHytz + 1;
				hytzHelper.loadData(Constants.OPT_TYPE_HYGL_HYTZ, Constants.WHAT_REQUEST_HYGL_HYTZ, pageIndexHytz, false);
			}
		});
		tvNoDataMsgHytz = (TextView) view2.findViewById(R.id.tv_no_data_msg);
		tvNoDataMsgHytz.setVisibility(View.GONE);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		listViewHytz.addHeaderView(header);
		
		hytzHelper = new DocumentHyglHytzHelper(mContext, header, tvNoDataMsgHytz, pullViewHytz, listViewHytz, mainActivity, callBack);
	}
	
	
	/**
	 * 初始化已办会议控件
	 */
	void initYbhyView(){
		pullViewYbhy = (PullToRefreshListView) view3.findViewById(R.id.pulllistview_ybhy);
		pullViewYbhy.setPullRefreshEnabled(true);
		pullViewYbhy.setPullLoadEnabled(false);
		pullViewYbhy.setScrollLoadEnabled(true);
		
		listViewYbhy = pullViewYbhy.getRefreshableView();
		UIHelper.setListViewAttribute(listViewYbhy);
		
		pullViewYbhy.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndexYbhy = 1;
				ybhyHelper.loadData(Constants.OPT_TYPE_HYGL_YBHY, Constants.WHAT_REQUEST_HYGL_YBHY, pageIndexYbhy, false);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndexYbhy = pageIndexYbhy + 1;
				ybhyHelper.loadData(Constants.OPT_TYPE_HYGL_YBHY, Constants.WHAT_REQUEST_HYGL_YBHY, pageIndexYbhy, false);
			}
		});
		tvNoDataMsgYbhy = (TextView) view3.findViewById(R.id.tv_no_data_msg);
		tvNoDataMsgYbhy.setVisibility(View.GONE);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		listViewYbhy.addHeaderView(header);
		
		ybhyHelper = new DocumentHyglYbhyHelper(mContext, header, tvNoDataMsgYbhy, pullViewYbhy, listViewYbhy, mainActivity, callBack);
	}
	
	
	/**
	 * 加载数据：主办会议
	 */
	public void loadData4SendMeet() {
		pageIndexZbhy = 1;
		zbhyHelper.loadData(Constants.OPT_TYPE_HYGL_ZBHY, Constants.WHAT_REQUEST_HYGL_ZBHY, pageIndexZbhy, true);
	}

	/**
	 * 加载数据：会议通知
	 */
	public void loadData4ReceiveMeet() {
		pageIndexHytz = 1;
		hytzHelper.loadData(Constants.OPT_TYPE_HYGL_HYTZ, Constants.WHAT_REQUEST_HYGL_HYTZ, pageIndexHytz, true);
	}

	/**
	 * 加载数据：已办会议
	 */
	public void loadData4DoneMeet() {
		pageIndexYbhy = 1;
		ybhyHelper.loadData(Constants.OPT_TYPE_HYGL_YBHY, Constants.WHAT_REQUEST_HYGL_YBHY, pageIndexYbhy, true);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.btn_top_right://新建会议
			// 跳转到新建会议页面
			break;
		}

	}

	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (mainActivity.checkResult(item)) {
				if (what == Constants.WHAT_REQUEST_HYGL_ZBHY) {	//主办会议
					zbhyHelper.process(response, what);
					
				}else if(what == Constants.WHAT_REQUEST_HYGL_HYTZ){	//会议通知
					hytzHelper.process(response, what);
					
				}else if(what == Constants.WHAT_REQUEST_HYGL_YBHY){	//已办会议
					ybhyHelper.process(response, what);
				}
			}
		}
	};
	
	
	@Override
	public void onShow(Intent intent) {

	}
	
	@Override
	public void onResume() {
		super.onResume();
		zbhyHelper.doRemoveItemById();
		hytzHelper.doRemoveItemById();
		ybhyHelper.doRemoveItemById();
	}

	@Override
	public void onDestroy() {
		mContext = null;
	}

	
	/** 初始化动画 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();// 获取图片宽度

		DisplayMetrics dm = new DisplayMetrics();
		mainActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}
	
	/** 初始化头标 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.btn_zbhy);
		tv2 = (TextView) findViewById(R.id.btn_hytz);
		tv3 = (TextView) findViewById(R.id.btn_ybhy);

		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
		tv3.setOnClickListener(new MyOnClickListener(2));
	}

	/**
	 * 方法说明：<br>
	 * 初始化 页卡
	 */
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_meet);
		views = new ArrayList<View>();
		LayoutInflater inflater = mainActivity.getLayoutInflater();

		view1 = inflater.inflate(R.layout.main_meet_zbhy, null);
		view2 = inflater.inflate(R.layout.main_meet_hytz, null);
		view3 = inflater.inflate(R.layout.main_meet_ybhy, null);
		views.add(view1);
		views.add(view2);
		views.add(view3);
		viewPager.setAdapter(new MyViewPagerAdapter(views));
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}

	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}

	public class MyViewPagerAdapter extends PagerAdapter {
		private List<View> mListViews;

		public MyViewPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(mListViews.get(position), 0);
			/*if (currIndex == 0) {
				if (isFirst1) {
					loadSendDocData();//第一个加载项
					isFirst1 = false;
				}
			}*/
			return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return mListViews.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}

	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one * arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);
			animation.setDuration(300);
			imageView.startAnimation(animation);

			if (currIndex == 0) {
				tv1.setBackgroundResource(R.drawable.system_icon_hygl_zbhy_s);//“主办会议”是选中项
				tv2.setBackgroundResource(R.drawable.system_icon_hygl_hytz);
				tv3.setBackgroundResource(R.drawable.system_icon_hygl_ybhy);

			} else if (currIndex == 1) {
				tv1.setBackgroundResource(R.drawable.system_icon_hygl_zbhy);
				tv2.setBackgroundResource(R.drawable.system_icon_hygl_hytz_s);//“会议通知”是选中项
				tv3.setBackgroundResource(R.drawable.system_icon_hygl_ybhy);
				if (isFirst2) {
					loadData4ReceiveMeet();
					//isFirst2 = false;
				}

			} else if (currIndex == 2) {
				tv1.setBackgroundResource(R.drawable.system_icon_hygl_zbhy);
				tv2.setBackgroundResource(R.drawable.system_icon_hygl_hytz);
				tv3.setBackgroundResource(R.drawable.system_icon_hygl_ybhy_s);//“已办会议”是选中项
				if (isFirst3) {
					loadData4DoneMeet();
					//isFirst3 = false;
				}
			}
		}
	}
	

}
