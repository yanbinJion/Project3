package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 通知公告：编辑
 * 
 * @author 李运期
 * @date 2015年5月3日
 * @version v1.0
 */
public class NoticeEditActivity extends BaseActivity implements OnClickListener {

	private static final String TAG = "NoticeEditActivity";

	private static final int REQUEST_WHAT_TO_CHOOSE_PERSON = 1001;

	private Context mContext;

	private TopActivity topActivity;
	private Button mBtnRight;

	// 基本信息界面相关
	private EditText etNoticeTitle;
	private TextView etNoticeType;
	private EditText etNoticeToStaffNo;
	private EditText etNoticeToStaffNoName;
	private EditText etNoticeBeginTime;
	private EditText etNoticeEndTime;
	private EditText etNoticeContent;
	private LinearLayout llNoticeToStaffNo;

	private String noticeId, noticeType;
	private String noticeTitle;
	private String noticeContent;
	private String noticeContentHtml;
	private String noticeToStaffNo, noticeToStaffName;
	private String noticeBeginTime, noticeEndTime;

	private String alertMessage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.notice_edit);

		noticeId = getIntent().getStringExtra("noticeId");// 通知公告的ID
		noticeType = getIntent().getStringExtra("noticeType");// 通知公告的类型

		etNoticeTitle = (EditText) findViewById(R.id.et_notice_title);
		etNoticeType = (TextView) findViewById(R.id.et_notice_type);
		etNoticeToStaffNo = (EditText) findViewById(R.id.et_notice_to_staffno);
		etNoticeToStaffNoName = (EditText) findViewById(R.id.et_notice_to_staffno_name);
		etNoticeToStaffNoName.setOnClickListener(this);
		etNoticeBeginTime = (EditText) findViewById(R.id.et_notice_begin_time);
		etNoticeBeginTime.setOnClickListener(this);
		etNoticeEndTime = (EditText) findViewById(R.id.et_notice_end_time);
		etNoticeEndTime.setOnClickListener(this);
		etNoticeContent = (EditText) findViewById(R.id.et_notice_content);
		llNoticeToStaffNo = (LinearLayout) findViewById(R.id.ll_notice_to_staffno);

		if ("0".equals(noticeType)) {// 类型：公告
			etNoticeType.setText("公告");
			llNoticeToStaffNo.setVisibility(View.GONE);
		} else {// 类型：通知
			etNoticeType.setText("通知");
		}

		bindViews();

		// 请求详情接口
		ApiRequest request = OAServicesHandler.getNoticeDetials(BeanUtils.floatToInt4Str(noticeId),
				BeanUtils.floatToInt(noticeType));
		if (request != null) {
			helper.invokeWidthDialog(request, loadcallBack, 1001);
		}

	}

	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.menu_notice));
		topActivity.setBtnBackText(getString(R.string.notice_right_cancel));
		topActivity.setBtnBackOnClickListener(this);

		mBtnRight = topActivity.getBtnRight();
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("保存");// 右边按钮文字：保存
	}

	/** 提交数据 */
	public void doSubmitData() {
		if (noticeId == null || noticeType == null) {
			return;
		}

		noticeTitle = etNoticeTitle.getText().toString();// 标题
		noticeToStaffNo = etNoticeToStaffNo.getText().toString();// 被通知人的ID
		noticeBeginTime = etNoticeBeginTime.getText().toString();// 开始时间
		noticeEndTime = etNoticeEndTime.getText().toString();// 结束时间
		noticeContent = etNoticeContent.getText().toString();// 通知公告的内容

		if ("0".equals(noticeType)) {// 类型：公告，被通知人的ID传空值
			// 提交请求
			ApiRequest request = OAServicesHandler.editNoticeDetials(noticeId,
					0, noticeTitle, null, noticeBeginTime, noticeEndTime,
					noticeContent, Constants.OPT_TYPE_TZGG_EDIT);
			request.setMessage(getString(R.string.system_commit_message));//请求中提示语
			helper.invokeWidthDialog(request, savecallBack, 1002);
		} else {// 类型：通知
			// 提交请求
			ApiRequest request = OAServicesHandler.editNoticeDetials(noticeId,
					1, noticeTitle, noticeToStaffNo, noticeBeginTime,
					noticeEndTime, noticeContent, Constants.OPT_TYPE_TZGG_EDIT);
			request.setMessage(getString(R.string.system_commit_message));//请求中提示语
			helper.invokeWidthDialog(request, savecallBack, 1003);
		}

	}

	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		if (BeanUtils.isEmpty(etNoticeTitle.getText().toString())) {// 标题
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.required_tip_notice_title),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if ("1".equals(noticeType)) {// 类型：通知
			if (BeanUtils.isEmpty(etNoticeToStaffNo.getText().toString())) {// 被通知人的ID
				Toast.makeText(NoticeEditActivity.this,
						getString(R.string.required_tip_notice_to_staffno),
						Toast.LENGTH_SHORT).show();
				return false;
			}
		}
		if (BeanUtils.isEmpty(etNoticeBeginTime.getText().toString())) {// 开始时间
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.required_tip_notice_begin_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if (BeanUtils.isEmpty(etNoticeEndTime.getText().toString())) {// 结束时间
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.required_tip_notice_end_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if (BeanUtils.isEmpty(etNoticeContent.getText().toString())) {// 通知内容
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.required_tip_notice_content),
					Toast.LENGTH_SHORT).show();
			return false;
		}

		// 检验时间范围
		Date begindate = DateUtils.parseDate(etNoticeBeginTime.getText()
				.toString() + " 00:00:00", "yyyy-MM-dd HH:mm:ss");
		if (begindate == null) {
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.error_tip_notice_begin_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		Date enddate = DateUtils.parseDate(etNoticeEndTime.getText().toString()
				+ " 23:59:59", "yyyy-MM-dd HH:mm:ss");
		if (enddate == null) {
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.error_tip_notice_end_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if (enddate.before(begindate)) {
			Toast.makeText(NoticeEditActivity.this,
					getString(R.string.error_tip_between_notice_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}

		return true;// 验证通过
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				// 跳转到界面：通知公告的列表
				gotoDetailPage();
				break;
			case R.id.btn_top_right :// 标题栏的右边按钮
				if ("保存".equals(mBtnRight.getText())) {
					if (doCheckData()) {// 验证
						doSubmitData();
					}
				}
				break;
			case R.id.et_notice_to_staffno_name :// 通知公告：被通知人
				// 封装交互参数
				Bundle data = new Bundle();
				data.putString(ChoosePeopleActivity.KEY_CUSTOM_TITLE, "请选择被通知人");
				data.putBoolean(ChoosePeopleActivity.KEY_IS_MULTIPLE_SELECT,
						true); // 可以多选
				String selectedUserIds = etNoticeToStaffNo.getText().toString();// 当前已经选中的人员ID
				ArrayList<String> selectedUserIdList = new ArrayList<String>(
						Arrays.asList(selectedUserIds.split(",")));
				data.putStringArrayList(ChoosePeopleActivity.KEY_USER_IDS_INIT,
						selectedUserIdList); // 初始化界面时，已经选中的人员ID
				// 跳转到选人界面
				UIHelper.forwardTargetActivityForResult(this,
						ChoosePeopleActivity.class, data, false,
						REQUEST_WHAT_TO_CHOOSE_PERSON);
				break;
			case R.id.et_notice_begin_time :// 通知公告：开始时间
				UIHelper.showTimeSelect(mContext, etNoticeBeginTime,DateUtils.DATE_FORMAT);
				break;
			case R.id.et_notice_end_time :// 通知公告：结束时间
				UIHelper.showTimeSelect(mContext, etNoticeEndTime,DateUtils.DATE_FORMAT);
				break;
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// 选择被通知人返回
		if (REQUEST_WHAT_TO_CHOOSE_PERSON == requestCode && data != null) {
			try {
				String ids = data
						.getStringExtra(ChoosePeopleActivity.KEY_USER_IDS_STRING);
				String names = data
						.getStringExtra(ChoosePeopleActivity.KEY_USER_NAMES_STRING);
				// 验证返回的数据是否正确
				if (names == null || ids == null || names.isEmpty()
						|| ids.isEmpty()) {// 不正确
					etNoticeToStaffNo.setText("");// 被通知人的ID
					etNoticeToStaffNoName.setText("");// 被通知人的姓名
				} else {// 正确
					etNoticeToStaffNo.setText(ids);// 被通知人的ID
					etNoticeToStaffNoName.setText(names);// 被通知人的姓名
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}


	private IRequestCallBack loadcallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				// 解析返回的数据
				ResultItem noticeItem = response
						.getResultItem(ResultItem.class).getItems("data")
						.get(0);

				noticeTitle = noticeItem.getString("NOTICE_TITLE");// 标题
				noticeToStaffNo = noticeItem.getString("NOTICE_STAFF_NO");// 被通知人的ID
				noticeToStaffName = noticeItem.getString("NOTICE_STAFF_NAME");// 被通知人的姓名
				noticeBeginTime = noticeItem.getString("BEGIN_TIME");// 开始时间
				noticeEndTime = noticeItem.getString("END_TIME");// 结束时间
				noticeContent = noticeItem.getString("NOTICE_CONTENT");// 通知公告的内容（纯文本）
				noticeContentHtml = noticeItem.getString("NOTICE_CONTENT_CLOB");// 通知公告的内容（HTML）

				etNoticeTitle.setText(noticeTitle == null ? "" : noticeTitle);
				etNoticeToStaffNo.setText(noticeToStaffNo == null
						? ""
						: noticeToStaffNo);
				etNoticeToStaffNoName.setText(noticeToStaffName == null
						? ""
						: noticeToStaffName);
				etNoticeBeginTime.setText(noticeBeginTime == null
						? ""
						: noticeBeginTime);
				etNoticeEndTime.setText(noticeEndTime == null
						? ""
						: noticeEndTime);
				// 清除HTML代码
				Spanned noticeText = Html.fromHtml(noticeContent == null
						? ""
						: noticeContent);
				etNoticeContent.setText(noticeText);

			}
		}
	};

	private IRequestCallBack savecallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String message = item.getString("message");
				if (message != null) {
					Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(
							context,
							getString(R.string.system_operation_success_message),
							Toast.LENGTH_SHORT).show();
				}
				// 跳转到界面：通知公告的列表
				gotoDetailPage();

			}
		}
	};

	/**
	 * 跳转到界面：通知公告的详情
	 */
	public void gotoDetailPage() {

		// 封装交互数据
		Bundle data = new Bundle();
		data.putString("noticeId", noticeId);
		data.putString("noticeType", noticeType);

		// 跳转到详情页面
		UIHelper.forwardTargetActivity(mContext, NoticeDetailActivity.class,
				data, true);

		finish();
	}

}
