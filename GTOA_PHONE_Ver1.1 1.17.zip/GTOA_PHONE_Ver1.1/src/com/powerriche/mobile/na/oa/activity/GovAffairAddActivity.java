package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.GovAffairAddHelper;
import com.powerriche.mobile.na.oa.activity.document.GovAffairDetailHelper;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.GovAffairInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.na.oa.down.DownloadInfoBean;
import com.powerriche.mobile.na.oa.down.DownloadInfoDAO;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper.DownloadButtonListener;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 新增领导政务管理
 * 
 * @author Fitz
 * @date 2015年4月28日
 * @version v1.0
 */
public class GovAffairAddActivity extends BaseActivity implements OnClickListener, OnLongClickListener, DownloadButtonListener{

	private static final int REQUEST_CODE_CHOOSE = 1000;
	public static final int REQUEST_CODE_ADD = 0;
	public static final int REQUEST_CODE_DETAIL = 1;
	public static final int REQUEST_CODE_UPLOAD_FILE = 2;
	public static final int CODE_DELETE_FILE = 5;
	public static final int CODE_MODIFY_UPLOAD_FILE = 6;

	public static final String FORWARDER_KEY = "affairId";

	private Context mContext;

	private EditText tvBeginTime, tvEndTime;
	private EditText tvLeaderId, tvLeader;
	private EditText etContent, etAddress;

	private GovAffairAddHelper govHelper;
	private GovAffairDetailHelper govDetailHelper;

	//编辑用到变量
	private String affairId;	//以该ID判断是否正确是编辑
	private String mdfFilePath, mdfFileName;	//附件上传成功临时变量
	private String mifDocumentId;	//公文文档ID

	private TextView tvFileGroup;
	private LinearLayout llFileWrap;
//	private FileDownHelper downHelper;

	private String oldLeaderNames;
	private String deleteFilePath;

	
	private DownloadUIHelper downloadUIHelper = null;
	private DownloadInfoDAO dao = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		
		setContentView(R.layout.govaffair_add);
		
		bindView();
		
//		downHelper = new FileDownHelper(mContext);
		this.downloadUIHelper = new DownloadUIHelper(mContext);
		this.downloadUIHelper.setEventListener(this);
		this.dao = new DownloadInfoDAO(mContext);
	}

	void bindView() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.gov_add_title));

		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(getString(R.string.btn_submit_save));// 右边按钮文字：保存
		
		String datestr = DateUtils.getDateStr(new Date(), DateUtils.DATE_HOUR_FORMAT);
		
		tvBeginTime = (EditText) findViewById(R.id.tv_begin_time);
		tvBeginTime.setOnClickListener(this);
		tvBeginTime.setText(datestr); // 当前系统时间
		tvEndTime = (EditText) findViewById(R.id.tv_end_time);
		tvEndTime.setOnClickListener(this);
		tvEndTime.setText(datestr); // 当前系统时间
		tvLeaderId = (EditText) findViewById(R.id.tv_leader_id);
		tvLeader = (EditText) findViewById(R.id.tv_leader);
		tvLeader.setOnClickListener(this);

		etContent = (EditText) findViewById(R.id.et_content);
		etAddress = (EditText) findViewById(R.id.et_address);

		tvFileGroup = (TextView) this.findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		llFileWrap = (LinearLayout) this.findViewById(R.id.ll_file_wrap);

		findViewById(R.id.btn_upload).setOnClickListener(this);
		
		govHelper = new GovAffairAddHelper(this, callback);

		affairId = getIntent().getStringExtra(FORWARDER_KEY);//领导政务ID：无ID是新增，有ID是修改
		if (!BeanUtils.isEmpty(affairId)) {//修改
			affairId = BeanUtils.floatToInt4Str(affairId);
			topActivity.setTopTitle(getString(R.string.gov_mod_title));
			govDetailHelper = new GovAffairDetailHelper(this, callback);
			govDetailHelper.getGovAffairDetails(affairId, REQUEST_CODE_DETAIL);
			//tvFileGroup.setVisibility(View.GONE);
			//llFileWrap.setVisibility(View.GONE);
		}
	}

	/**
	 * 绑定修改数据
	 */
	public void bindModifyValue(Map<String, Object> map) {
		if(map!=null && map.size()>0){
			String startTime = (map.get("beginData") + " " + map.get("beginTime") + "");
			tvBeginTime.setText(DateUtils.getDateStr(DateUtils.parseDate(startTime, "yyyy-MM-dd HH:mm"), "yyyy-MM-dd HH:mm"));

			String endTime = (map.get("endData") + " " + map.get("endTime") + "");
			tvEndTime.setText(DateUtils.getDateStr(DateUtils.parseDate(endTime, "yyyy-MM-dd HH:mm"), "yyyy-MM-dd HH:mm"));

			oldLeaderNames = map.get("leaderName") + "";
			tvLeader.setText(oldLeaderNames);// 出席领导的姓名

			etContent.setText(map.get("content") + "");
			etAddress.setText(map.get("address") + "");
			
			//修改时需要documentID
			mifDocumentId = map.get("documentId").toString();

			@SuppressWarnings("unchecked")
			List<DocFileInfo> fileList = (List<DocFileInfo>) map.get("fileList");
			if (fileList != null && fileList.size() > 0) {
				foreachFiles(fileList);
			}
		}
	}

	/**
	 * 循环附件列表
	 * @param fileList
	 */
	private void foreachFiles(List<DocFileInfo> fileList) {
		for (int i = 0, len = fileList.size(); i < len; i++) {
			final DocFileInfo bean = fileList.get(i);
			ViewHolderFile holder = new ViewHolderFile();

			View view = LayoutInflater.from(mContext).inflate(R.layout.govaffair_file_item, null);
			holder.rlItemWrap = (RelativeLayout) view.findViewById(R.id.rl_item_wrap);
			holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
			holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
			
			holder.btnDownload = (RoundProgressButton) view.findViewById(R.id.btn_process);
			holder.rlRoundBtnWrap = (RelativeLayout) view.findViewById(R.id.rl_round_btn_wrap);

			String extend = FileUtils.getFileExtends(bean.getFileName());
			UIHelper.setFileTypeIcon(mContext, holder.ivType, extend); // 设置文件类型

			//领导政务没有正文
			holder.tvFileName.setText(bean.getFileName());
			holder.tvFileName.setTag(bean.getFilePath());
			
			holder.btnDownload.setTag(bean);
			holder.btnDownload.setOnClickListener(this);
			
			//String url = UIHelper.downFileUrl(bean.getFileCode());//getString(R.string.system_servics_download).concat(bean.getFilePath());
			String url;
            //0,标识使用system_servics_download下载，1标识使用system_servics_url下载
            if("1".equals(getString(R.string.is_download_flag))){
                url = UIHelper.downFileUrl(bean.getFileCode());
            }else{
                url = getString(R.string.system_servics_download).concat(bean.getFilePath());
            }
			holder.rlRoundBtnWrap.setTag(url);//下载标识
			
			holder.rlItemWrap.setTag(bean);
			holder.rlItemWrap.setOnClickListener(this);
			holder.rlItemWrap.setOnLongClickListener(this);
			
			try{
				DownloadInfoBean downBean = dao.getAppBeanByCd(bean.getFileCode());
				if(downBean!=null){	//下载完成
					int state = downBean.getState();
					if(state == DownloadInfoDAO.DOWNLOAD_STATE_2){
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_finish); // 存在则打开
						
					}else if(state == DownloadInfoDAO.DOWNLOAD_STATE_3){
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down_pause); // 暂停状态
						
					}else{
						holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
					}
					
				}else{
					holder.btnDownload.setBackgroundResource(R.drawable.ic_down); // 否则下载
				}
				holder.btnDownload.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
						this.getResources().getColor(R.color.transparent));
			}catch(Exception e){
				
			}

			llFileWrap.addView(view);
		}
		llFileWrap.setVisibility(View.VISIBLE);
		tvFileGroup.setVisibility(View.VISIBLE);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_back){	// 返回
			exit();
			
		}else if(id == R.id.btn_top_right){	// 保存
			if (doCheckData()) {// 验证
				doSaveData();
			}
			
		}else if(id == R.id.tv_leader){	 // 去组织成员选择人
			// 封装交互参数
			Bundle data = new Bundle();
			data.putString(ChoosePeopleActivity.KEY_CUSTOM_TITLE, "请选择出席人员");
			data.putBoolean(ChoosePeopleActivity.KEY_IS_MULTIPLE_SELECT, true); // 可以多选
			String selectedUserIds = tvLeaderId.getText().toString();// 当前已经选中的人员ID
			ArrayList<String> selectedUserIdList = new ArrayList<String>(Arrays.asList(selectedUserIds.split(",")));
			data.putStringArrayList(ChoosePeopleActivity.KEY_USER_IDS_INIT, selectedUserIdList); // 初始化界面时，已经选中的人员ID
			// 跳转到选人界面
//			UIHelper.forwardTargetActivityForResult(this, ChoosePeopleActivity.class, data, false, REQUEST_CODE_CHOOSE);
			UIHelper.forwardTargetActivityForResult(this, SelectedPeopleActivity.class, data, false, REQUEST_CODE_CHOOSE);
			
		}else if(id == R.id.tv_begin_time){	 // 开始时间
			UIHelper.showTimeSelect(mContext, tvBeginTime, DateUtils.DATE_HOUR_FORMAT);
			
		}else if(id == R.id.tv_end_time){	 // 结束时间
			UIHelper.showTimeSelect(mContext, tvEndTime, DateUtils.DATE_HOUR_FORMAT);
			
		}else if(id == R.id.tv_file_group){	//
			UIHelper.isOpenFile(mContext, tvFileGroup, llFileWrap);
			
		}else if(id == R.id.btn_upload){		//选择附件
			UIHelper.forwardTargetActivityForResult(this, SDCardFileExplorerActivity.class, null, 
					false, SDCardFileExplorerActivity.REQUEST_CODE_FILE);
			
		}else if(id==R.id.rl_item_wrap || id==R.id.btn_process || id==R.id.rl_add_item_wrap){
			UIHelper.downViewClick(mContext, v, downloadUIHelper, dao);
		}
	}

	@Override
	public boolean onLongClick(final View v) {
		UIHelper.vibrate(mContext, 50);	//震动下
		if(v.getId() == R.id.rl_item_wrap){
			if(llFileWrap!=null){
				final DocFileInfo bean = (DocFileInfo) v.getTag();
				String message = bean.getFileName();
				final SystemDialog chooseDialog = new SystemDialog(mContext);
				chooseDialog.setMessage("确定要删除这条“"+message+"”附件？");
				chooseDialog.setOnConfirmClickListener("删除", new View.OnClickListener() {	//确定按钮事件
					@Override
					public void onClick(View view) {
						deleteFilePath = bean.getFilePath();
						UIHelper.deleteFile(mContext, callback, helper, bean.getFileCode(), CODE_DELETE_FILE);
					}
				});
				chooseDialog.setOnCancelClickListener("放弃", new View.OnClickListener() {		//取消
					@Override
					public void onClick(View v) {
						if(chooseDialog!=null){
							chooseDialog.dismiss();
						}
					}
				});
				chooseDialog.show();
			}
			
		}else if(v.getId() == R.id.rl_add_item_wrap){
			
			final SystemDialog chooseDialog = new SystemDialog(mContext);
			chooseDialog.setMessage("确定要删除这条附件？");
			chooseDialog.setOnConfirmClickListener("删除", new View.OnClickListener() {	//确定按钮事件
				@Override
				public void onClick(View view) {
					if(llFileWrap!=null){
						int fileSize = llFileWrap.getChildCount();
						if(fileSize>0){
							
							DocFileInfo bean = (DocFileInfo) v.getTag();
							if(bean==null) return;
							
							for(int i=0; i<fileSize; i++){
								View fileView = llFileWrap.getChildAt(i);
								if(fileView==null){
									continue;
								}
								TextView tvFileName = (TextView) fileView.findViewById(R.id.tv_file_name);
								String tempPath = (String) tvFileName.getTag();
								if(bean.getFilePath().equals(tempPath)){	//如果按钮相等，则删除这条数据
//									llFileWrap.removeViewAt(i);
									deleteFilePath = bean.getFilePath();
									UIHelper.deleteFile(mContext, callback, helper, bean.getFileCode(), CODE_DELETE_FILE);
								}
							}
						}
					}
				}
			});
			chooseDialog.setOnCancelClickListener("放弃", new View.OnClickListener() {		//取消
				@Override
				public void onClick(View v) {
					if(chooseDialog!=null){
						chooseDialog.dismiss();
					}
				}
			});
			chooseDialog.show();
		}
		return false;
	}
	
	/** 保存数据 */
	public void doSaveData() {

		String beginTime = tvBeginTime.getText().toString();
		String endTime = tvEndTime.getText().toString();
		String leaderName = tvLeader.getText().toString();
		String content = etContent.getText().toString();
		String address = etAddress.getText().toString();

		GovAffairInfo bean = new GovAffairInfo();
		bean.setAffairId(affairId);
		bean.setBeginTime(beginTime);// 格式：yyyy-MM-dd HH:mm
		bean.setEndTime(endTime);// 格式：yyyy-MM-dd HH:mm
		bean.setAffairAddress(address);
		bean.setAffairContent(content);
		bean.setLeaderName(leaderName);

		govHelper.saveData(bean, REQUEST_CODE_ADD);
	}

	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		String beginTime = tvBeginTime.getText().toString();
		if (BeanUtils.isEmpty(beginTime)) {
			setReturnMsg(tvBeginTime, getString(R.string.required_tip_gov_begin_time));
			return false;
		}

		String endTime = tvEndTime.getText().toString();
		if (BeanUtils.isEmpty(endTime)) {
			setReturnMsg(tvEndTime, getString(R.string.required_tip_gov_end_time));
			return false;
		}

		if (BeanUtils.isEmpty(tvLeader.getText().toString())) {
			setReturnMsg(tvLeader, getString(R.string.required_tip_gov_leader));
			return false;
		}

		if (BeanUtils.isEmpty(etContent.getText().toString())) {
			setReturnMsg(etContent, getString(R.string.required_tip_gov_content));
			return false;
		}

		if (BeanUtils.isEmpty(etAddress.getText().toString())) {
			setReturnMsg(etAddress, getString(R.string.required_tip_gov_address));
			return false;
		}

		// 检验时间范围
		Date begindate = DateUtils.parseDate(tvBeginTime.getText().toString() + ":00", "yyyy-MM-dd HH:mm:ss");
		if (begindate == null) {
			UIHelper.showMessage(mContext, getString(R.string.error_tip_gov_begin_time));
			return false;
		}
		Date enddate = DateUtils.parseDate(tvEndTime.getText().toString() + ":59", "yyyy-MM-dd HH:mm:ss");
		if (enddate == null) {
			UIHelper.showMessage(mContext, getString(R.string.error_tip_gov_end_time));
			return false;
		}
		if (enddate.before(begindate)) {
			UIHelper.showMessage(mContext, getString(R.string.error_tip_between_gov_time));
			return false;
		}

		return true;// 验证通过
	}

	private boolean setReturnMsg(TextView view, String msg) {
		// view.setText("");
		view.requestFocus();
		UIHelper.showMessage(mContext, msg);
		return false;
	}

	
	@Override
	protected void onPause() {
		super.onPause();
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.unRegUiHandler();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.regUiHandler();//界面恢复调用
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		mContext = null;
		if(this.downloadUIHelper!=null)
			this.downloadUIHelper.unRegUiHandler();
	}
	

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// 选择代理人返回
		if (REQUEST_CODE_CHOOSE == requestCode && data != null) {
			try {
				String ids = data.getStringExtra(ChoosePeopleActivity.KEY_USER_IDS_STRING);
				String names = data.getStringExtra(ChoosePeopleActivity.KEY_USER_NAMES_STRING);
				// 验证返回的数据是否正确
				if (names == null || ids == null || names.isEmpty() || ids.isEmpty()) {// 不正确
					tvLeaderId.setText("");// 出席领导的ID
					tvLeader.setText(oldLeaderNames);// 出席领导的姓名
				} else {// 正确
					tvLeaderId.setText(ids);// 出席领导的ID
					if (BeanUtils.isEmpty(oldLeaderNames)) {
						tvLeader.setText(names);// 出席领导的姓名
					} else {
						tvLeader.setText(names + "," + oldLeaderNames);// 出席领导的姓名
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		//添加附件返回
		}else if(requestCode==SDCardFileExplorerActivity.REQUEST_CODE_FILE && data!=null){
			
			String fileName = data.getStringExtra("FILE_NAME");
			String filePath = data.getStringExtra("FILE_PATH");
			if (BeanUtils.isEmpty(affairId)) {	//新增政务附件，点击提交按钮再上传
				UIHelper.setFileWrap(mContext, llFileWrap, this, this, fileName, filePath, "", "");//没有下载按钮
				
			//更改附件选择，然后是选择一个附件就上传
			}else{
				List<File> files = new ArrayList<File>();
				File file = new File(filePath);
				if(file!=null && file.exists()){
					files.add(file);
					
					mdfFilePath = filePath; 
					mdfFileName = fileName;
					
					UploadParams params = new UploadParams(getString(R.string.system_servics_url), "uploadFile", mifDocumentId, "", "", CODE_MODIFY_UPLOAD_FILE);
					params.setListFile(files);
					HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
					post.execute(params);
					
					//老方法
//					UIHelper.modifyFileUpload(mContext, callback, helper, CODE_MODIFY_UPLOAD_FILE, mifDocumentId, "", files);
				}else{
					UIHelper.showMessage(mContext, "该文件不存在");
				}
			}
		}
		
		super.onActivityResult(requestCode, resultCode, data);
	}

	
	private Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(msg.what == CODE_MODIFY_UPLOAD_FILE){
				ResultItem item = (ResultItem) msg.obj;
				String code = item.getString("code");
				String fileCode = item.getString("file_code");
				if (Constants.SUCCESS_CODE.equals(code)) {
					UIHelper.showMessage(mContext, "附件上传成功");
					//将附件复制到下载目录
					if(UIHelper.copeChildFile(fileCode, mdfFilePath)){
						
						String newPath = UIHelper.getDownNewFilePath(fileCode, mdfFilePath);
						//添加这个附件到附件列表中
						UIHelper.setFileWrap(mContext, llFileWrap, GovAffairAddActivity.this, 
								GovAffairAddActivity.this, mdfFileName, mdfFilePath, fileCode, newPath);
					}
					mdfFileName = null; 
					mdfFilePath = null;
				}
				
			}else{
				if(!BeanUtils.isEmpty(msg.obj)){
					UIHelper.showMessage(mContext, msg.obj.toString());
				}else{
					UIHelper.showMessage(mContext, "不明确的错误");
				}
			}
		}
	};
	
	
	private IRequestCallBack callback = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String msg = item.getString("message");
				if (REQUEST_CODE_ADD == what) {
					// 操作成功
					GovAffairActivity.OP_REFRESH = 1;	//返回的时候，公文列表刷新
					// 新增成功
					UIHelper.showMessage(mContext, getString(R.string.system_operation_success_message));
					// 判断有没有附件
					if (llFileWrap != null && llFileWrap.getChildCount() > 0) {
						String documentId = item.getString("DOCUMENT_ID");
						govHelper.uploadFile(documentId, "", llFileWrap, REQUEST_CODE_UPLOAD_FILE);	//新增领导政务上传附件

					} else {
						exit();
					}


				} else if (REQUEST_CODE_DETAIL == what) {
					Map<String, Object> itemMap = govDetailHelper.process(response, what);
					bindModifyValue(itemMap);
					return;

				} else if (REQUEST_CODE_UPLOAD_FILE == what) { // 新增领导政务-附件上传返回
					UIHelper.showMessage(mContext, msg);
					exit();
					
				}else if(CODE_DELETE_FILE == what){
					UIHelper.removeFileView(llFileWrap, deleteFilePath);
					deleteFilePath = null;
				}
			}
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(mContext, message);
		}
	};

	private class ViewHolderFile {
		TextView tvFileName;
		ImageView ivType;
		RoundProgressButton btnDownload;
		RelativeLayout rlItemWrap, rlRoundBtnWrap;
	}

	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) { 
        if (keyCode == KeyEvent.KEYCODE_BACK) { 
        	finish();
            return false; 
        } 
        return false; 
    }
	
	
	public void exit() {
		//finish();
		UIHelper.forwardTargetActivity(mContext, GovAffairActivity.class, null, true);
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	
	@Override
	public void onProgressUpdate(String url, long totalSize, long dealtSize) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);
		if(btnDown == null)return;
		btnDown.setBackgroundResource(R.drawable.ic_down_ing);	//正在下载
		btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.gray_split_line_bg), 
				this.getResources().getColor(R.color.down_progress_color));
		
		float num = (float)dealtSize / (float)totalSize;
		int result = (int)(num * 100);
		
		btnDown.setProgress(result);
	}

	@Override
	public void onDownloadComplete(String url) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);	//下载完成
		if(btnDown == null)return;
		btnDown.setBackgroundResource(R.drawable.ic_down_finish);
		btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
				this.getResources().getColor(R.color.transparent));
		
		UIHelper.openFile(mContext, url);
	}

	@Override
	public void onDownloadStateChange(String url, int state) {
		switch (state) {
		case DownloadInfoDAO.DOWNLOAD_STATE_3:
			RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);	//暂停下载
			if(btnDown!=null){
				btnDown.setBackgroundResource(R.drawable.ic_down_pause);
				btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.transparent), 
						this.getResources().getColor(R.color.transparent));
			}
			break;
		}
	}

	@Override
	public void onDownloadError(String url, int state) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url, true);
		if(btnDown!=null){
			btnDown.setBackgroundResource(R.drawable.ic_down);
			btnDown.setCricleAndProgressColor(this.getResources().getColor(R.color.gray_split_line_bg), 
					this.getResources().getColor(R.color.down_progress_color));
		}
		UIHelper.showMessage(mContext, "下载错误");
	}
	
	/*private RoundProgressButton showDownBtn(String url, int backDerbale, boolean enabled){
		View btntmp = llFileWrap.findViewWithTag(url);
		RoundProgressButton btn = null;
		if(btntmp != null && btntmp instanceof RelativeLayout)
			btn = (RoundProgressButton)btntmp.findViewById(R.id.btn_process);
		
		if(btn!=null){
			btn.setEnabled(enabled);
			btn.setBackgroundResource(backDerbale);
		}
		return btn;
	}*/

}
