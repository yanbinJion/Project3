package com.powerriche.mobile.na.oa.down;

import java.io.File;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;

import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * UI下载帮助类
 * @author  Miter
 * @date    2013-12-13
 */
public final class DownloadUIHelper {

	private Context context;

	public DownloadUIHelper(Context context) {
		this.context = context;
	}
	
	private DownloadButtonListener mListener = null;

	public interface DownloadButtonListener {

		/**
		 * 方法说明：<br>
		 * 下载进度更新
		 * @param url 地址
		 * @param totalSize
		 * @param dealtSize
		 */
		void onProgressUpdate(String url, long totalSize, long dealtSize);
		
		/**
		 * 方法说明：<br>
		 * 下载完成之后调用
		 * @param url
		 */
		void onDownloadComplete(String url);

		/**
		 * 下载状态更新
		 */
		void onDownloadStateChange(String url, int state);
		
		/**
		 * 下载异常(错误)
		 */
		void onDownloadError(String url, int state);

		/**
		 * 启动\打开 事件
		 */
		//void onLaunchClick(View v, String url);

		/**
		 * 卸载
		 */
		//void onUnInstallClick(View v, String url);

		/**
		 * 卸载成功
		 */
		//void onUnInstallFinish(String url);

		/**
		 * 安装事件
		 */
		//void onInstallBtnClick(View v, String url);

		/**
		 * 安装成功
		 */
		//void onInstallFinish(String url);

		/**
		 * 继续, 下载
		 * @param v
		 */
		//void onStartBtnClick(View v, String url);

		/**
		 * 暂停
		 * @param v
		 */
		//void onPauseBtnClick(View v, String url);

		/**
		 * 在安装时，发现安装文件不存在后，刷新UI的回调
		 */
		//void onFileNotExist(DownloadInfo dinfo);
	}
	
	
	
	/** 
	 * 下载进度状态改变的Handler
	 */
	private Handler mUiHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			
			String url;
			
			switch (msg.what) {
			case DownloadManager.MSG_DOWNLOAD_STATE_ERROR:
				Object[] tObjsf = (Object[]) msg.obj;
				url = (String) tObjsf[0];
				int statef = ((Long) tObjsf[1]).intValue();
				onDownloadError(url, statef);
				break;
			case DownloadManager.MSG_DOWNLOAD_STATE_CHANGE:
				Object[] tObjs = (Object[]) msg.obj;
				url = (String) tObjs[0];
				int state = ((Long) tObjs[1]).intValue();
				onDownloadStateChange(url, state);
				break;
			
			// 刷新下载进度
			case DownloadManager.MSG_DOWNLOAD_UPDATE_PROGRESS:
				Object[] tObj = (Object[]) msg.obj;
				url = (String) tObj[0];
				long totalSize = (Long) tObj[1];
				long dealtSize = (Long) tObj[2];
				onProgressUpdate(url, totalSize, dealtSize);
				break;
			
			//完成下载(下载成功)
			case DownloadInfo.STATE_COMPLE:
				Object[] tObj2 = (Object[]) msg.obj;
				url = (String) tObj2[0];
				onDownloadComplete(url);
				
				DownloadManager.getInstance().removeDownloadTaskByUrl(url);
				
				addDownLoadQueue();
				
				break;
				
			default:
				break;
			}
		}
	};
	
	private void addDownLoadQueue(){
		
		DownloadInfoDAO dao = new DownloadInfoDAO(context);
		
		Integer downingSize = dao.qryDowningGameSize(DownloadInfoDAO.DOWNLOAD_STATE_1);
		
		if(downingSize >=Constants.DOWNLOAD_MAX_SIZE)return;
		
		List<DownloadInfoBean> beans = dao.qryDowningGame(DownloadInfoDAO.DOWNLOAD_STATE_00);
		
		if(beans == null || beans.size() <= 0)return;
		
		int size = beans.size();
		for(int i=0;i<size;i++){
			
			DownloadInfoBean bean = beans.get(i);
			if(bean == null)continue;
			
			bean.setState(DownloadInfoDAO.DOWNLOAD_STATE_1);
			dao.updStateByCd(bean);
			
			startDownload(bean.getUrl(), bean.getFileCode(), bean.getFileType(), bean.getName(),bean.getFileSize());
			downingSize++;
			if(downingSize >=Constants.DOWNLOAD_MAX_SIZE)break;
		}
		
	}


	public void setEventListener(DownloadButtonListener mListener) {
		this.mListener = mListener;
	}

	/**
	 * View的点击最终处理
	 */
	public void onViewClick(View view, String url, String fileCode, String fileType, String fileName, long fileSize) {

		if(!UIHelper.isNetWork(context)){
			UIHelper.showMessage(context, "无法连接网络，请确认网络正常");
			((Button)view).setEnabled(false);
			return;
		}
		
		DownloadInfoDAO dao = new DownloadInfoDAO(context);		
		DownloadInfoBean software = dao.getDownloadInfoByUrl(url);
		
		Integer size = dao.qryDowningGameSize(DownloadInfoDAO.DOWNLOAD_STATE_1);
		
		int state = 0;//0：停止下载，1：开始下载，2：下载完成，3暂停下载，4：已安装
		String downDir = null;
		
		if (software == null) {
			if(size >=Constants.DOWNLOAD_MAX_SIZE){//等待下载
				state = DownloadInfoDAO.DOWNLOAD_STATE_00;
				dao.insert(fileCode, url, fileType, fileSize, DownloadInfoDAO.DOWNLOAD_STATE_00, System.currentTimeMillis(), fileName);
				
			}else{
				dao.insert(fileCode, url, fileType, fileSize, DownloadInfoDAO.DOWNLOAD_STATE_0, System.currentTimeMillis(), fileName);
			}
			
		}else{
			state = software.getState();
			Log.d("start--onViewClick -----software.fileCode:"+software.getFileCode());
		}
		
		Log.d("onViewClick---state-->"+state);
		
		switch (state) {
		case DownloadInfoDAO.DOWNLOAD_STATE_00:
			UIHelper.showMessage(context, "已加入下载队列，等待下载！");
			break;
			
		case DownloadInfoDAO.DOWNLOAD_STATE_0:
			if(UIHelper.existSDCard()){
				startDownload(url, fileCode, fileType, fileName, fileSize);
				
			}else{
				UIHelper.showMessage(context, "没有SD卡");
			}
			break;
		
		//如果正在下载，那么点击下载按钮，则暂停下载：
		case DownloadInfoDAO.DOWNLOAD_STATE_1:
			stopDownLoad(url, fileCode, fileType);
			break;
		
		//下载完成
		case DownloadInfoDAO.DOWNLOAD_STATE_2:
			downDir = software.getDownDir();
			if(!BeanUtils.isEmpty(downDir)){
				if(FileUtils.exists(downDir)){
					Logger.e("DownloadUIHelper", "下载完成， 文件路径-->"+downDir);
					try{
						String extend = FileUtils.getFileExtends(downDir).toLowerCase();
						//word，ppt，xls，pdf都用wps打开，其他文件弹出文件选择器
						if("doc".equals(extend) || "docx".equals(extend) || "pdf".equals(extend) 
								|| "ppt".equals(extend) || "xlsx".equals(extend) || "xls".equals(extend) || "txt".equals(extend)){
							UIHelper.openWps(context, downDir, Constants.WPS_READ_ONLY);	//只读模式
							
						}else{
							int pointindex = downDir.lastIndexOf(".");
							if(pointindex == -1){
								UIHelper.showMessage(context, "未知的文件，没有可选择的程序可以打开！");
								
							}else{
								Intent intent = new Intent();
								intent.setAction("android.intent.action.VIEW");
								intent.setDataAndType(Uri.fromFile(new File(downDir)),BeanUtils.getMimeType(downDir.substring(pointindex)));  
								context.startActivity(Intent.createChooser(intent, "请选择打开文件的程序"));
							}
						}
						
					}catch(Exception e){
						Logger.e("DownloadUIHelper", e.getMessage());
					}
					
				}else{
					startDownload(url, fileCode, fileType, fileName, fileSize);
				}
			}else{
				startDownload(url, fileCode, fileType, fileName, fileSize);
			}
			break;
		
		//如果是暂停下载，那么点击下载按钮，继续下载
		case DownloadInfoDAO.DOWNLOAD_STATE_3:
			startDownload(url, fileCode, fileType, fileName, fileSize);
			break;
		}
		
	}
	
	/**
	 * 暂停下载
	 */
	public void stopDownLoad(String url, String packageName, String gameName){
		Log.d("stopDownLoad..url-->"+url);
		
		DownloadTask downloadTask = DownloadManager.getInstance().getDownloadTaskByUrl(url);
		Log.d("stopDownLoad..downloadTask-->"+downloadTask);
		
		DownloadInfoDAO dao = new DownloadInfoDAO(context);
		DownloadInfoBean bean = dao.getDownloadInfoByUrl(url);
		bean.setState(DownloadInfoDAO.DOWNLOAD_STATE_3);
		dao.updStateByUrl(bean);
		onDownloadStateChange(url, DownloadInfoDAO.DOWNLOAD_STATE_3);
		
		if(downloadTask!=null){ 
			downloadTask.exit();//暂停任务
			DownloadManager.getInstance().removeDownloadTaskByUrl(url);
			downloadTask = null;
		}else{
			//当没找到任务的时候,不再重新下载liangfei
			//startDownload(url, packageName);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 开始下载
	 * @param url
	 */
	public void startDownload(String url, String fileCode, String fileType, String fileName, long fileSize) {
		DownloadTask downloadTask = DownloadManager.getInstance().getDownloadTaskByUrl(url);
		Log.e("startDownload..downloadTask-->"+downloadTask);
		
		if(downloadTask!=null){ 
			downloadTask.exit();//暂停任务
			downloadTask = null;
		}
		String path = UIHelper.getDownBasePath(fileType, fileName);
		File saveDir = new File(path);
		
		if(BeanUtils.isEmpty(fileType)){
			fileType = "."+FileUtils.getFileExtends(fileName);
			if(fileType.equals(".null")){
				fileType = "";
			}
		}
		
		downloadTask = new DownloadTask(context,url, saveDir, fileCode, fileType, fileSize);
		
		DownloadManager.getInstance().addDownloadTaskByUrl(url, downloadTask);
		
		new Thread(downloadTask).start();
	}


	/**
	 * 同步界面的状态, 在OnPause中调用
	 */
	public void unRegUiHandler() {
		DownloadManager.getInstance().removeHandler(mUiHandler);
	}

	/**
	 * 同步界面的状态, 在OnResume中调用
	 */
	public void regUiHandler() {
		DownloadManager.getInstance().addHandler(mUiHandler);
	}

	/**
	 * 方法说明：<br>
	 * 更改下载进度<br>
	 * @param url
	 * @param totalSize
	 * @param dealtSize
	 */
	private void onProgressUpdate(String url, long totalSize, long dealtSize) {
		if (mListener != null) {
			mListener.onProgressUpdate(url, totalSize, dealtSize);
		}
	}
	
	private void onDownloadError(String url, int state){
		if (mListener != null) {
			mListener.onDownloadError(url, state);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 完成下载
	 * @param url
	 */
	private void onDownloadComplete(String url){
		if (mListener != null) {
			mListener.onDownloadComplete(url);
		}
	}

	/**
	 * 方法说明：<br>
	 * 改变下载状态的
	 * @param url 下载地址
	 * @param state 下载状态
	 */
	private void onDownloadStateChange(String url, int state) {
		if (mListener != null) {
			mListener.onDownloadStateChange(url,state);
		}
	}

	/**
	 * 方法说明：<br>
	 * 销毁下载
	 */
	public void destroy() {
		mListener = null;
		mUiHandler = null;
	}
	
}