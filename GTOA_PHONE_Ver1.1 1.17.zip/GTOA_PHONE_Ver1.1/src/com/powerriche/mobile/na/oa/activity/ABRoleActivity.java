package com.powerriche.mobile.na.oa.activity;
	
import java.util.List;
			
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
	
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
	
/**	
 * Filename : ABRoleActivity
 * 	
 * @Description : AB角
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-21 11:50:00
 */	
public class ABRoleActivity extends BaseActivity implements OnClickListener {
	
	// ab角色查询
	private final static int DIALOG_QUERYABROLE = 6001;
	
	// ab角色删除
	private final static int DIALOG_DELABROLE = 6002;
	
	// ab角色新增
	private final static int DIALOG_ADDABROLE = 6003;
	
	// 跳转到代理人
	private final static int DIALOG_TOADDABROLE = 6004;
	
	private TopActivity topActivity;
	//private Button mBtnRight;
	
	// 显示的用户头像
	private ImageView userImage;
	
	// 显示的名称
	private TextView nameView;
		
	// 设置的roleId
	private String roleId = "-1";
		
	private String addUserName;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.abrole_layout);
		userImage = (ImageView) findViewById(R.id.userImage);
		nameView = (TextView) findViewById(R.id.userName);
		
		bindViews();
		
		// 调用查询是否有AB角的接口
		queryAbRole();
	}	
		
	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.abrole_title));
		topActivity.setBtnBackOnClickListener(this);
		
		//mBtnRight = topActivity.getBtnRight();
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		//topActivity.setRightBtnStyle(R.drawable.add_button);// 右边按钮文字：编辑
	}	
		
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			// 查询返回
			if (what == DIALOG_QUERYABROLE) {
				ResultItem item = response.getResultItem(ResultItem.class);
				List<ResultItem> items = item.getItems("data");
				String code = item.getString("code");
				// 是否为空判断
				if (!BeanUtils.isEmpty(items)
						&& Constants.SUCCESS_CODE.equals(code)) {
					try {
						// 查询设置AB角色
						// 成功，显示头像数据
						item = items.get(0);
						// 返回的名称
						String dlgtToName = item.getString("DLGT_TO_NAME");
						//
						String id = item.getString("DLGT_ID");
						setSelectUser(dlgtToName);
						roleId = id;
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					setDefaultUser();
					return;
				}
			} else if (what == DIALOG_DELABROLE) {
				// 删除AB角色
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					// 操作成功
					setDefaultUser();
					return;
				}
		
			} else if (what == DIALOG_ADDABROLE) {
				// 新增AB角色
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					// 操作成功
						final String id = item.getString("dlgt_id");
						roleId = id;
						setSelectUser(addUserName);
						return;
				}
			}	
		}		
		
		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			if (what == DIALOG_QUERYABROLE) {
				showErrorMessage(getString(R.string.system_request_error_message));
			} else {
				showErrorMessage(getString(R.string.system_commit_error_message));
			}	
		}		
		
		@Override
		public void onNetError(int what) {
			if (what == DIALOG_QUERYABROLE) {
				showErrorMessage(getString(R.string.system_net_error_message));
			} else {
				showErrorMessage(getString(R.string.system_net_error_message));
			}
		}
	};
	
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				setResult(RESULT_OK);
				finish();
				break;
			case R.id.btn_top_right :// 编辑
				if (!"-1".equals(roleId)) {
					showDialog(DIALOG_DELABROLE);
				} else {
					toAddAbRole();
				}
				break;
		}
	
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}
	
	/** 查询用户是否设置了AB角 */
	public void queryAbRole() {
		ApiRequest request = OAServicesHandler.queryAbRole();
		helper.invokeWidthDialog(request, callBack, DIALOG_QUERYABROLE);
	}
	
	/** 跳转到AB角 */
	public void toAddAbRole() {
		// Intent intent = new Intent(this, AgencyIndexActivity.class);
		// startActivityForResult(intent, DIALOG_TOADDABROLE);
		// 以下是写死的数据
		// setSelectUser("");
		// roleId = 0;
		Bundle data = new Bundle();
		data.putString(ChoosePeoplesActivity.KEY_CUSTOM_TITLE, "选择代理人");
		data.putBoolean(ChoosePeoplesActivity.KEY_IS_MULTIPLE_SELECT, false); //
		UIHelper.forwardTargetActivityForResult(this,
				ChoosePeoplesActivity.class, data, false, DIALOG_TOADDABROLE);
	}
	
	/** 添加AB角 */
	public void addAbRole(String staffNo, String StaffName) {
		ApiRequest request = OAServicesHandler.addAbRole(staffNo, StaffName);
		request.setMessage(getString(R.string.system_commit_message));
		helper.invokeWidthDialog(request, callBack, DIALOG_ADDABROLE);
	}
	
	/** 删除AB角 */
	public void delAbRole() {
		ApiRequest request = OAServicesHandler.delAbRole(roleId);
		request.setMessage(getString(R.string.system_commit_message));
		helper.invokeWidthDialog(request, callBack, DIALOG_DELABROLE);
	}
	
	/** 设置选择的用户 */
	public void setSelectUser(String userName) {
		userImage.setImageResource(R.drawable.user_ba);// 头像
		nameView.setText(userName);// 名称
		// 设置右上角的图片
		//mBtnRight.setBackgroundResource(R.drawable.editor_button);
		topActivity.setRightBtnStyle(R.drawable.editor_button);
	}
	
	/** 设置默认的显示 */
	public void setDefaultUser() {
		roleId = "-1";
		userImage.setImageResource(R.drawable.user_ab);// 头像
		nameView.setText(R.string.abrole_not_setting);// 名称
		// 设置右上角的图片
		//mBtnRight.setBackgroundResource(R.drawable.add_button);
		topActivity.setRightBtnStyle(R.drawable.add_button);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// 选择代理人返回
		if (DIALOG_TOADDABROLE == requestCode && data != null) {
			try {
				Bundle b = data.getExtras(); // data为回传的Intent
				String userName = b.getString("name");
				String userId = b.getString("staffNo");
				if (!BeanUtils.isEmpty(userId)) {
					if (userId.equals(SystemContext.getAccount())) {
						Toast.makeText(this, "自己不能作为自己的代理人！", Toast.LENGTH_SHORT)
								.show();
					} else {
						addUserName = userName;
						// 提交服务器
						addAbRole(userId, userName);
					}
				}
			} catch (Exception e) {
				Log.e("======返回异常======", e.getMessage());
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
			case DIALOG_DELABROLE :
				return new AlertDialog.Builder(ABRoleActivity.this)
						.setIcon(R.drawable.icon)
						.setTitle(R.string.app_name)
						.setMessage(R.string.abrole_del_confirm)
						.setPositiveButton(R.string.system_dialog_cancel,
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int whichButton) {
	 
									}
								})
						.setNegativeButton(R.string.system_dialog_confirm,
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int whichButton) {
										delAbRole();
									}
								}).create();
		}
		return super.onCreateDialog(id);
	}
	
	public IRequestCallBack getCallBack() {
		return callBack;
	}
	
	public InvokeHelper getInvokeHelper() {
		return helper;
	}
}	
	