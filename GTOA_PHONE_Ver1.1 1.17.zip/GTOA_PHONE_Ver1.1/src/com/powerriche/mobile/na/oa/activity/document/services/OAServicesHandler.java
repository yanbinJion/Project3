package com.powerriche.mobile.na.oa.activity.document.services;

import java.io.File;
import java.util.List;

import com.powerriche.mobile.na.oa.bean.DocumentInfo;
import com.powerriche.mobile.na.oa.bean.GoodsApplyDetails;
import com.powerriche.mobile.na.oa.bean.GovAffairInfo;
import com.powerriche.mobile.na.oa.bean.LeaveDetail;
import com.powerriche.mobile.na.oa.bean.PurchaseApply;
import com.powerriche.mobile.na.oa.bean.SignUpInfo;
import com.powerriche.mobile.na.oa.bean.TaskDetails.HistoryProgress;
import com.powerriche.mobile.na.oa.bean.TaskDetails.Materials;
import com.powerriche.mobile.na.oa.bean.TaskInfo;
import com.powerriche.mobile.na.oa.bean.UserLeaveInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * Filename : OAServicesHandler.java
 * 
 * @Description : 接口的统一处理
 * @Author : 刘剑
 * @Version : 1.0
 * @Date : 2012-06-04 下午09:38:24
 */
public class OAServicesHandler {

	/**
	 * 登陆用户<br>
	 * 老版本OA系统接口，软件版本 versionCode=5 已弃用
	 */
	@Deprecated
	public static ApiRequest mobileLogin(String userId, String passWd) {
		ApiRequest request = new ApiRequest("Login");
		request.addParam("staffName", userId);
		request.addParam("password", passWd);
		return request;
	}

	/** 登陆接口，用户从门户系统上登陆 */
	public static ApiRequest portalLogin(String staffName, String password) {
		ApiRequest request = new ApiRequest("login");
		request.setServiceUrlType(2);
		request.addParam("staffName", staffName);
		request.addParam("password", password);
		return request;
	}

	/** 注销登陆 */
	public static ApiRequest portalLogout() {
		ApiRequest request = new ApiRequest("logout");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(2);
			request.addParam("authToken", SystemContext.getSessionIdProtal());
		} else {// 采用OA接口
			request.addParam("authToken", SystemContext.getSessionId());
		}
		return request;
	}

	/**
	 * 获取个人信息<br>
	 * 组织机构的个人信息接口
	 */
	public static ApiRequest getUserInfo(String staffNo) {
		ApiRequest request = new ApiRequest("getUserInfo");
//		if (Constants.IS_USER_PORTAL) {// 采用门户接口
//			request.setServiceUrlType(2);
//			request.addParam("staffNo", staffNo);
//			request.addParam("authToken", SystemContext.getSessionIdProtal());
//		} else {// 采用OA接口
//			request.addParam("staffNo", staffNo);
//			request.addParam("authToken", SystemContext.getSessionId());
//		}
		request.addParam("staffNo", staffNo);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/**
	 * 编辑个人信息 sex(0：女 1：男)<br>
	 * 请求门户接口
	 */
	public static ApiRequest editUserInfo(String realName, String sex,
			String phone, String mobile) {
		ApiRequest request = new ApiRequest("editUserInfo");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(2);
			request.addParam("staffNo", SystemContext.getAccountProtal());
			request.addParam("authToken", SystemContext.getSessionIdProtal());
			request.addParam("realName", realName);
			request.addParam("sex", sex);
			request.addParam("phone", phone);
			request.addParam("mobile", mobile);
		} else {// 采用OA接口
			request.addParam("staffNo", SystemContext.getAccount());
			request.addParam("authToken", SystemContext.getSessionId());
			request.addParam("realName", realName);
			request.addParam("sex", sex);
			request.addParam("phone", phone);
			request.addParam("mobile", mobile);
		}
		return request;
	}

	/**
	 * 修改密码<br>
	 * 调用门户接口
	 */
	public static ApiRequest modifyPassword(String oldPassword, String password) {
		ApiRequest request = new ApiRequest("updatePassword");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(2);
			request.addParam("staffNo", SystemContext.getAccountProtal());
			request.addParam("authToken", SystemContext.getSessionIdProtal());
			request.addParam("oldPassword", oldPassword);
			request.addParam("newPassword", password);
		} else {// 采用OA接口
			request.addParam("staffNo", SystemContext.getAccount());
			request.addParam("authToken", SystemContext.getSessionId());
			request.addParam("oldPassword", oldPassword);
			request.addParam("newPassword", password);
		}
		return request;
	}

	/**
	 * 判断登录密码是否正确
	 * 
	 * @param password
	 * @return
	 */
	public static ApiRequest checkPassword(String password) {
		ApiRequest request = new ApiRequest("checkUserAndPassword");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(2);
			request.addParam("staffNo", SystemContext.getAccountProtal());
			request.addParam("authToken", SystemContext.getSessionIdProtal());
			request.addParam("staffName", SystemContext.getUserId());
			request.addParam("password", password);
		} else {// 采用OA接口
			request.addParam("staffNo", SystemContext.getAccount());
			request.addParam("authToken", SystemContext.getSessionId());
			request.addParam("staffName", SystemContext.getUserId());
			request.addParam("password", password);
		}
		return request;
	}

	/**
	 * 根据门户的StaffNo获取OA上对应的StaffNo和Token值<br>
	 * 因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
	 * 
	 * @param protalStaffNo
	 *            门户的StaffNo
	 * @return
	 */
	public static ApiRequest getStaffNoAndTokenForOA(String protalStaffNo) {
		ApiRequest request = new ApiRequest("GetStaffNoAndToken");
		request.addParam("uapStaffNo", protalStaffNo);
		return request;
	}

	/** 待办事宜：待办列表 */
	public static ApiRequest getWaitList(int pageIndex) {
		ApiRequest request = new ApiRequest("getWaitList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 待办事宜：待阅列表，state：1：待阅，2：已阅，3：已传 */
	public static ApiRequest getPassreadList(int pageIndex, int state) {
		ApiRequest request = new ApiRequest("getPassreadList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		request.addParam("state", state);
		return request;
	}

	/** 公文传阅：办理信息列表 */
	public static ApiRequest getPassreadListByBanLi(int pageIndex) {
		ApiRequest request = new ApiRequest("getPassreadList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		request.addParam("state", Constants.PASSREAD_STATE_NOTREAD);
		return request;
	}

	/** 查询设置AB角色 */
	public static ApiRequest queryAbRole() {
		ApiRequest request = new ApiRequest("getDelegateWorks");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 添加AB角色 */
	public static ApiRequest addAbRole(String staffNo, String StaffName) {
		ApiRequest request = new ApiRequest("editDelegateWorks");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("dlgtId", "");

		request.addParam("dlgtStaffNo", staffNo);
		// 0新增
		request.addParam("operateType", 0);
		return request;
	}

	/** 删除AB角色 */
	public static ApiRequest delAbRole(String dlgtId) {
		ApiRequest request = new ApiRequest("deleteDelegateWorks");
		request.addParam("dlgtId", dlgtId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 组织机构列表 */
	public static ApiRequest getSiteStaffTreeList() {
		ApiRequest request = new ApiRequest("getSiteStaffTree");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 新建公文保存接口 */
	public static ApiRequest saveDocument(DocumentInfo document) {
		ApiRequest request = new ApiRequest("saveDocument");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("title", document.getTitle());
		request.addParam("distributeCharacters", document.getCharacters());
		request.addParam("draftDept", document.getDepartment());
		request.addParam("drafter", document.getDrafter());
		request.addParam("urgencyDegree", document.getUrgency());
		request.addParam("importanceDegree", document.getLevel());
		request.addParam("summary", document.getSummary());
		request.addParam("remark", document.getRemark());
		// 添加参数
		request.addParam("documentId", document.getDocumentId());
		request.addParam("operateType", document.getOperateType());
		return request;
	}

	/** 查询请假列表 */
	public static ApiRequest getAskLeaveList(int pageIndex) {
		ApiRequest request = new ApiRequest("getLeaveWaitList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 查询请假详情 */
	public static ApiRequest getAskLeaveDetail(String documentId) {
		ApiRequest request = new ApiRequest("getLeaveDetails");
		request.addParam("documentId", documentId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}
	
	/** 查询请假详情 */
	public static ApiRequest getLeaveDetails(String documentId) {
		ApiRequest request = new ApiRequest("getLeaveDetails");
		request.addParam("documentId", documentId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}
	
	/** 请假查询 */
	public static ApiRequest getLeaveGeneralList(String completeState, String leaveType, String isLeavePass, String beginTime, String endTime, int pageIndex) {
		ApiRequest request = new ApiRequest("getLeaveGeneralList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("completeState", completeState);
		request.addParam("leaveType", leaveType);
		request.addParam("isLeavePass", isLeavePass);
		request.addParam("beginTime", beginTime);
		request.addParam("endTime", endTime);
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	} 

	/** 保存请假申请 */
	/*public static ApiRequest saveLeave(UserLeaveInfo bean) {
		ApiRequest request = new ApiRequest("saveLeave");
		request.addParam("documentId", bean.getLeaveBizNo());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("operateType", bean.getOperateType());// 1保存 2修改
		request.addParam("leaveCatalog", bean.getLeaveCatalog());// 请假类别（0请假，1调休）
		request.addParam("leaveType", bean.getLeaveType());// 请假类型（0：年休假，1探亲假，2：婚假，3产假，4：丧假，5：病假，6：事假）
		request.addParam("beginTime", bean.getBeginTime());
		request.addParam("endTime", bean.getEndTime());
		request.addParam("leaveReason", bean.getLeaveReason());
		request.addParam("leaveTotalDays", bean.getTotalDays());
		return request;
	}*/
	
	/** 保存请假申请 */
	public static ApiRequest saveLeave(LeaveDetail detail) {
		ApiRequest request = new ApiRequest("saveLeave");
		request.addParam("documentId", detail.getLeaveId());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("operateType", detail.getOperateType());// 1保存 2修改
		request.addParam("leaveCatalog", detail.getLeaveCatalog());// 请假类别（0请假，1调休）
		request.addParam("leaveType", detail.getLeaveType());// 请假类型（0：年休假，1探亲假，2：婚假，3产假，4：丧假，5：病假，6：事假）
		request.addParam("beginTime", detail.getBeginTime());
		request.addParam("endTime", detail.getEndTime());
		request.addParam("leaveReason", detail.getLeaveReason());
		request.addParam("leaveTotalDays", detail.getLeaveTotalDays());
		return request;
	}
	
	/** 请假送出 */
	public static ApiRequest sendNextLeave(String documentId, String nextFpuNo, String nextStaffNo, String notes, String isSendMessage) {
        ApiRequest request = new ApiRequest("sendNextLeave");
        request.addParam("documentId", documentId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("nextFpuNo", nextFpuNo);
        request.addParam("nextStaffNo", nextStaffNo);
        request.addParam("notes", notes);
        request.addParam("isSendMessage", isSendMessage);
        return request;
    }
	
	/** 请假审批 */
	public static ApiRequest auditLeave(String documentId, String notes, String passState, String isSendMessage) {
        ApiRequest request = new ApiRequest("auditLeave");
        request.addParam("documentId", documentId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("notes", notes);
        request.addParam("passState", passState);
        request.addParam("isSendMessage", isSendMessage);
		return request;
	}
	
	/** 请假销假 */
	public static ApiRequest destroyLeave(String documentId, String realLeaveTotalDays, String realEndTime) {
        ApiRequest request = new ApiRequest("destroyLeave");
        request.addParam("documentId", documentId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("realLeaveTotalDays", realLeaveTotalDays);
        request.addParam("realEndTime", realEndTime);
		return request;
	}
	
	/** 请假办结 */
	public static ApiRequest finishLeaveWorkFlow(String documentId) {
        ApiRequest request = new ApiRequest("finishLeaveWorkFlow");
        request.addParam("documentId", documentId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}
	

	/** 请假审批 */
	public static ApiRequest approvalLeave(UserLeaveInfo bean) {
		ApiRequest request = new ApiRequest("auditingLeave");
		request.addParam("documentId", bean.getLeaveBizNo());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("passState", bean.getPassState());
		request.addParam("traceNo", bean.getTraceNo());
		request.addParam("notes", bean.getLeaveReason());
		request.addParam("isSendMessage", 0);// 默认为不发送
		return request;
	}

	/** 公文管理：发文列表 */
	public static ApiRequest getSendDocList(int pageIndex) {
		ApiRequest request = new ApiRequest("getSendDocList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		// request.addParam("state", state);//0：综合查询，1：待办查询，2：跟踪或已办，5：办结查询
		return request;
	}

	/** 公文管理：来文列表 */
	public static ApiRequest getReceiveDocList(int pageIndex) {
		ApiRequest request = new ApiRequest("getReceiveDocList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		// request.addParam("state", state);//0：综合查询，1：待办查询，2：跟踪或已办，5：办结查询
		return request;
	}

	/** 公文管理：已办列表 */
	public static ApiRequest getDoneList(int pageIndex) {
		ApiRequest request = new ApiRequest("getDoneList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		// request.addParam("state", state);//0：综合查询，1：待办查询，2：跟踪或已办，5：办结查询
		return request;
	}

	/** 领导政务：列表 */
	public static ApiRequest getGovAffairList(int state, int pageIndex) {
		ApiRequest request = new ApiRequest("getGovAffairList");
		request.addParam("state", state);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 领导政务：详情 */
	public static ApiRequest getGovAffairDetails(String affairId) {
		ApiRequest request = new ApiRequest("getGovAffairDetails");
		request.addParam("affairId", affairId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--任务信息：详情 */
	public static ApiRequest getTaskDetail(String taskId, String wfNo) {
		ApiRequest request = new ApiRequest("getTaskDetails");
		request.addParam("taskId", taskId);
		request.addParam("WfNo", wfNo);
		request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}

	/** 个人任务--进度信息 **/
	public static ApiRequest getTaskProgressInfo(String taskId) {
		ApiRequest request = new ApiRequest("getTaskProgressInfo");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--历史进度信息 **/
	public static ApiRequest getTaskHistoryProgressInfo(String taskId, String processNo) {
		ApiRequest request = new ApiRequest("getTaskProgressHistory");
		request.addParam("taskId", taskId);
		request.addParam("ProcessNo", processNo);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--进度物料信息 **/
	public static ApiRequest getProgressMaterials(String progressDetailsId) {
		ApiRequest request = new ApiRequest("getProgressMaterials");
		request.addParam("progressDetailsId", progressDetailsId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}
	
	/** 个人任务-- 上传进度物料 **/
	public static ApiRequest reportTaskProgressMaterial(String materialId, List<Materials> materials) {
		ApiRequest request = new ApiRequest("reportTaskProgressMaterial");
		if (BeanUtils.isNullOrEmpty(materialId)) {
			materialId = "";
		}
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("progressDetailId", materialId);
		request.addParam("<progressMaterials>", "");
		if (!BeanUtils.isEmpty(materials)) {
			for (Materials material : materials) {
				request.addParam("<ROW>", "");
				request.addParam("BRAND", material.getBrand());
				request.addParam("UNIT", material.getUnit());
				request.addParam("QUANTITY", material.getQuantity());
				request.addParam("</ROW>", "");
			}
		} else {
			request.addParam("<ROW>", "");
			request.addParam("BRAND", "");
			request.addParam("UNIT", "");
			request.addParam("QUANTITY", "");
			request.addParam("</ROW>", "");
		}
		request.addParam("</progressMaterials>", "");
		return request;
	}

	/** 个人任务--事件信息 **/
	public static ApiRequest getTaskWorkContent(String taskId) {
		ApiRequest request = new ApiRequest("getTaskWorkContent");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--任务办理 **/
	public static ApiRequest finishWorkFlow(String taskId) {
		ApiRequest request = new ApiRequest("finishWorkFlow");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--任务签收 **/
	public static ApiRequest taskSignUp(String taskId) {
		ApiRequest request = new ApiRequest("taskSignUp");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--任务送出 **/
	public static ApiRequest sendTaskServer(String traceNo, String documentId,
			String wfNo, String swfNo, String nextFpuNo, String toStaffNos,
			String notes, String isSendMessage, String taskId) {
		// ApiRequest request = new ApiRequest("sendNextWorkFlow");
		ApiRequest request = new ApiRequest("sendTaskServer");
		request.addParam("traceNo", traceNo);
		request.addParam("taskId", taskId);
		request.addParam("documentId", documentId);
		request.addParam("wfNo", wfNo);
		request.addParam("swfNo", swfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("nextFpuNo", nextFpuNo);
		request.addParam("toStaffNos", toStaffNos);
		request.addParam("notes", notes);
		request.addParam("isSendMessage", isSendMessage);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--分派任务 **/
	public static ApiRequest assignTask(String taskId) {
		ApiRequest request = new ApiRequest("assignTask");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}
	
	/** 任务上报进度 **/
	public static ApiRequest reportProgress(String taskId, String documentId,HistoryProgress progress,List<Materials> materialsList) {
		ApiRequest request = new ApiRequest("reportTaskProgress");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("taskId", taskId);
		request.addParam("documentId", documentId);
		request.addParam("remark", progress.getRemark());
		request.addParam("<progress>", "");
		request.addParam("<progress_write>", "");
		request.addParam("PROGRESS_FROM_TIME_SEQ", "");
		request.addParam("PROGRESS_TO_TIME_SEQ", "");
		request.addParam("PROGRESS_FROM_DATE", progress.getFromDate());
		request.addParam("PROGRESS_TO_DATE", progress.getToDate());
		request.addParam("PROGRESS_CONTENT", progress.getContent());
		request.addParam("PROGRESS_COMPLETE_DEGREE", progress.getDegree());
		request.addParam("PROGRESS_COMPLETE_TIME", progress.getCompleteTime());
		request.addParam("PROGRESS_SUM_HUMAN_COST", progress.getSumHumanCost());
		request.addParam("PROGRESS_SUM_QUANTITY", progress.getSumQuantity());
		request.addParam("PROGRESS_SUM_TIME", progress.getSumTime());
		request.addParam("PROGRESS_SUM_MONEY", progress.getSumMoney());
		request.addParam("<PROGRESS_MATERIALS>", "");
		for (Materials materials : materialsList) {
			request.addParam("<ROW>", "");
			request.addParam("BRAND", materials.getBrand());
			request.addParam("UNIT", materials.getUnit());
			request.addParam("QUANTITY", materials.getQuantity());
			request.addParam("</ROW>", "");
		}

		request.addParam("</PROGRESS_MATERIALS>", "");
		request.addParam("</progress_write>", "");
		request.addParam("</progress>", "");
		return request;
	}
	
	/** 考勤--获取当前考勤信息 **/
	public static ApiRequest getCurrentAttendance() {
		ApiRequest request = new ApiRequest("getCurrentAttendance");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}
	
	/** 考勤--获取当前用户可以查看的考勤人员列表 **/
	public static ApiRequest getAttendanceStaffList(int pageIndex) {
		ApiRequest request = new ApiRequest("getAttendanceStaffList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}
	
	/** 考勤--查看当前人的考勤列表 **/
	public static ApiRequest getAttendanceList(String beginTime, String endTime, String searchStaffNo,int pageIndex) {
		ApiRequest request = new ApiRequest("getAttendanceList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("beginTime", beginTime);
		request.addParam("endTime", endTime);
		request.addParam("searchStaffNo", searchStaffNo);
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.RECORD_PAGE_SIZE);
		return request;
	}
	
	/** 考勤-考勤签到或签退 **/
	public static ApiRequest signAttendance(String attendAddress, String signState, String signType) {
		ApiRequest request = new ApiRequest("signAttendance");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("attendAddress", attendAddress);
		request.addParam("signState", signState);
		request.addParam("signType", signType);
		return request;
	}
	
	/** 考勤-获取当前考勤配置信息 **/
	public static ApiRequest getAttendanceConfig() {
		ApiRequest request = new ApiRequest("getAttendanceConfig");
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务--获取进度附件关联的编号Document_ID **/
	public static ApiRequest getTaskProgressDocumentId() {
		ApiRequest request = new ApiRequest("getTaskProgressDocumentId");
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}
	
	 /** 个人任务-- 任务审批或者审核 **/
    public static ApiRequest auditSendTask(String taskId, String remark, String isAgree) {
        ApiRequest request = new ApiRequest("auditSendTask");
        request.addParam("taskId", taskId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("notes", remark);
        //1 同意 -1 不同意
        request.addParam("passState", isAgree);
        return request;
    }

	// public static ApiRequest GetFileListByDocumentId(String documentId, int
	// fileCatalog, IDbCommand oComm) {
	/** 获取领导政务附件列表。file_catalog标识 0:正文word 1:附件 2:ceb */
	public static ApiRequest getFileListByDocumentId(String documentId,
			int fileCatalog) {
		ApiRequest request = new ApiRequest("GetFileListByDocumentId");
		request.addParam("documentId", documentId);
		request.addParam("fileCatalog", fileCatalog);
		request.addParam("oComm", "IDbCommand");// 最后一个参数需要修改
		return request;
	}

	/** 常用意见：列表 */
	public static ApiRequest getUserNotesList() {
		ApiRequest request = new ApiRequest("getUserNotesList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 任务管理：列表 */
	public static ApiRequest getTaskList(int pageIndex) {
		ApiRequest request = new ApiRequest("getTaskList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 任务管理：详情 */
	public static ApiRequest getTaskDetail(String taskId) {
		ApiRequest request = new ApiRequest("getTaskDetail");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 个人任务列表 */
	public static ApiRequest getPersonalTaskList(int pageIndex, int type) {
		ApiRequest request = new ApiRequest("getTaskList");
		/** taskType: 0 表示发送，1 表示接收 */
		request.addParam("TaskType", type);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 个人任务:新增 */
	public static ApiRequest getAddTask(TaskInfo task) {
		ApiRequest request = new ApiRequest("saveTaskInfo");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("taskId", task.getTaskId());
		request.addParam("title", task.getTitle());
		request.addParam("taskYear", task.getTaskYear());
		request.addParam("submitToNo", task.getSubmitToNo());
		request.addParam("copyToNo", task.getCopyToNo());
		request.addParam("limitTime", task.getLimitTime());
		request.addParam("itemName", task.getItemName());
		request.addParam("itemType", task.getItemType());
		request.addParam("itemAddress", task.getItemAddress());
		request.addParam("itemContent", task.getItemContent());
		request.addParam("itemAssign", task.getItemAssign());
		request.addParam("itemRemark", task.getItemRemark());
		return request;
	}

	/** 个人任务：查询 */
	public static ApiRequest searchTask(String taskId, String taskTitle,
			String beginTime, String endTime, String direct, String taskState,
			String workflow, int curIndex) {
		ApiRequest request = new ApiRequest("getTaskGeneralList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("taskCode", taskId);
		request.addParam("taskTitle", taskTitle);
		request.addParam("beginTime", beginTime);
		request.addParam("endTime", endTime);
		request.addParam("taskDirection", direct);
		request.addParam("taskState", taskState);
		request.addParam("workflowState", workflow);
		request.addParam("pageIndex", curIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 任务管理：签收 */
	public static ApiRequest getTaskSign(String taskId) {
		ApiRequest request = new ApiRequest("getTaskSign");
		request.addParam("taskId", taskId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 任务管理：上报 */
	public static ApiRequest reportTask(String taskId, String taskReportId,
			String documentId, String reportContent) {
		ApiRequest request = new ApiRequest("reportTask");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("taskReportId", taskReportId);
		request.addParam("taskId", taskId);
		request.addParam("documentId", documentId);
		request.addParam("reportContent", reportContent);
		return request;
	}

	/**
	 * 常用意见：编辑
	 * 
	 * @param noteId
	 *            意见ID
	 * @param note
	 *            意见内容
	 * @param operateType
	 * @return
	 */
	public static ApiRequest editUserNotes(String noteId, String note,
			int operateType) {
		ApiRequest request = new ApiRequest("editUserNotes");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("noteId", noteId);
		request.addParam("note", note);
		request.addParam("operateType", operateType);
		return request;
	}

	/**
	 * 常用意见：删除
	 * 
	 * @param noteId
	 *            意见ID
	 * @return
	 */
	public static ApiRequest deleteUserNotes(String noteId) {
		ApiRequest request = new ApiRequest("deleteUserNotes");
		request.addParam("noteId", noteId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/**
	 * 领导政务：增加修改接口
	 */
	public static ApiRequest editGovAffair(GovAffairInfo bean) {

		ApiRequest request = new ApiRequest("editGovAffair");

		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("affairId", bean.getAffairId());
		request.addParam("operateType",
				BeanUtils.isEmpty(bean.getAffairId()) ? "0" : "1");// 0：添加1：编辑
		request.addParam("arranger", SystemContext.getSiteName()); // 主办单位
		request.addParam("startTime", bean.getBeginTime());
		request.addParam("finishTime", bean.getEndTime());
		request.addParam("leaderName", bean.getLeaderName());
		request.addParam("affairContent", bean.getAffairContent());
		request.addParam("affairAddress", bean.getAffairAddress());
		request.addParam("affairComment", "");
		return request;
	}

	/**
	 * 删除领导政务接口
	 * 
	 * @param pageIndex
	 * @return
	 */
	public static ApiRequest deleteGovAffair(String affairId) {
		ApiRequest request = new ApiRequest("deleteGovAffair");
		request.addParam("affairId", affairId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/**
	 * 通知公告：列表
	 * 
	 * @param pageIndex
	 *            分页查询的索引号，从1开始
	 * @return
	 */
	public static ApiRequest getNoticeList(int pageIndex) {
		ApiRequest request = new ApiRequest("getNoticeList");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(3);
			request.addParam("staffNo", SystemContext.getAccountProtal());
			request.addParam("authToken", SystemContext.getSessionIdProtal());
		} else {// 采用OA接口
			request.addParam("staffNo", SystemContext.getAccount());
			request.addParam("authToken", SystemContext.getSessionId());
		}
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
		
	}

	/**
	 * 通知公告：详情
	 * 
	 * @param noticeId
	 *            通知公告的ID
	 * @param noticeType
	 *            通知公告的类型：0：公告，1：通知
	 * @return
	 */
	public static ApiRequest getNoticeDetials(String noticeId, int noticeType) {
		ApiRequest request = new ApiRequest("getNoticeDetials");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(3);
			request.addParam("staffNo", SystemContext.getAccountProtal());
			request.addParam("authToken", SystemContext.getSessionIdProtal());
		} else {// 采用OA接口
			request.addParam("staffNo", SystemContext.getAccount());
			request.addParam("authToken", SystemContext.getSessionId());
		}
//		request.addParam("staffNo", SystemContext.getAccount());
//		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("noticeId", noticeId);
		request.addParam("noticeType", noticeType);
		return request;
	}

	/**
	 * 通知公告：新增或编辑
	 * 
	 * @param noticeId
	 *            通知公告的ID，新增时为空值
	 * @param noticeType
	 *            通知公告的类型：0：公告，1：通知
	 * @param noticeTitle
	 *            通知公告的标题
	 * @param noticeStaffNo
	 *            被通知人（当为公告时（noticeType=0），传空值）
	 * @param noticeBeginTime
	 *            通知公告的开始时间
	 * @param noticeEndTime
	 *            通知公告的结束时间
	 * @param noticeContent
	 *            通知公告的内容
	 * @param operateType
	 *            操作类型：0：新增，1：编辑
	 * @return
	 */
	public static ApiRequest editNoticeDetials(String noticeId, int noticeType,
			String noticeTitle, String noticeStaffNo, String noticeBeginTime,
			String noticeEndTime, String noticeContent, int operateType) {
		ApiRequest request = new ApiRequest("editNoticeDetials");
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(3);
			request.addParam("staffNo", SystemContext.getAccountProtal());
			request.addParam("authToken", SystemContext.getSessionIdProtal());
		} else {// 采用OA接口
			request.addParam("staffNo", SystemContext.getAccount());
			request.addParam("authToken", SystemContext.getSessionId());
		}
//		request.addParam("staffNo", SystemContext.getAccount());
//		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("noticeId", noticeId);
		request.addParam("noticeType", noticeType);
		request.addParam("noticeTitle", noticeTitle);
		request.addParam("noticeStaffNo", noticeStaffNo);
		request.addParam("beginTime", noticeBeginTime);
		request.addParam("endTime", noticeEndTime);
		request.addParam("noticeContent", noticeContent);
		request.addParam("operateType", operateType);
		return request;
	}

	/**
	 * 通知公告：删除
	 * 
	 * @param noticeId
	 *            通知公告的ID
	 * @param noticeType
	 *            通知公告的类型：0：公告，1：通知
	 * @return
	 */
	public static ApiRequest deleteNotify(String noticeId, int noticeType) {
		ApiRequest request = new ApiRequest("deleteNotify");
		// request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("noticeId", noticeId);
		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			request.setServiceUrlType(3);
			request.addParam("authToken", SystemContext.getSessionIdProtal());
		} else {// 采用OA接口
			request.addParam("authToken", SystemContext.getSessionId());
		}
//		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("noticeType", noticeType);
		return request;
	}

	/** 公文详情信息：来文、发文都可以使用 */
	public static ApiRequest getDocumentDetail(String documentId, String wfNo) {
		ApiRequest request = new ApiRequest("getDocumentDetail");
		request.addParam("documentId", documentId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("wfNo", wfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}

	/** 获取传阅信息 */
	public static ApiRequest getPassreadInfo(String wfNo) {
		ApiRequest request = new ApiRequest("getPassreadInfo");
		request.addParam("wfNo", wfNo);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 标记已阅接口 */
	public static ApiRequest markPassreadState(String passreadId) {
		ApiRequest request = new ApiRequest("markPassreadState");
		request.addParam("passreadId", passreadId);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 综合查询 */
	public static ApiRequest searchAllBiz(String title, String bizType,
			String beginTime, String endTime, int pageIndex, int searchType,
			int state) {
		ApiRequest request = new ApiRequest("searchAllBiz");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("title", title);
		request.addParam("bizType", bizType);
		request.addParam("beginTime", beginTime);
		request.addParam("endTime", endTime);
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		request.addParam("searchType", searchType);
		request.addParam("state", state);
		return request;
	}

	/**
	 * 搜索接口 tabType [0:待办][1:公文管理][2:会议管理] operateType 如果为公文管理[0:已办][1:待办]
	 * 如果为会议管理[0:已办][1:主办会议][2:会议通知]
	 */
	public static ApiRequest searchInterface(String tabType, String docTitle,
			String swfNo, String operateType) {
		ApiRequest request = new ApiRequest("searchInterface");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("tabType", tabType);
		request.addParam("docTitle", docTitle);
		request.addParam("swfNo", swfNo);
		request.addParam("operateType", operateType);
		return request;
	}

	/** 环节选人接口 */
	public static ApiRequest getNextFpuAndStaffList(String swfNo, String fpuNo) {
		ApiRequest request = new ApiRequest("getNextFpuAndStaffList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("swfNo", swfNo);
		request.addParam("fpuNo", fpuNo);
		return request;
	}

	/** 会议管理：主办会议列表 */
	public static ApiRequest getSendMeetList(int pageIndex) {
		ApiRequest request = new ApiRequest("getSendMeetList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 会议管理：会议通知列表 */
	public static ApiRequest getReceiveMeetList(int pageIndex) {
		ApiRequest request = new ApiRequest("getReceiveMeetList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 会议管理：已办会议列表 */
	public static ApiRequest getMeetFlowList(int pageIndex) {
		ApiRequest request = new ApiRequest("getMeetFlowList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 获取版本号 */
	public static ApiRequest getAppVersion(String platform) {
		ApiRequest request = new ApiRequest("getAppVersion");
		request.addParam("platform", platform);
		return request;
	}

	/** 常务会议：列表 */
	public static ApiRequest getExecMeetList(int pageIndex) {
		ApiRequest request = new ApiRequest("meetingListFlow");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("meetTitle", "");
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}

	/** 常务会议：详情 */
	public static ApiRequest getExecMeetDetail(String id) {
		ApiRequest request = new ApiRequest("meetingDetailInfo");
		request.addParam("meetingId", id);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 常务会议详情 */
	public static ApiRequest cardDataFeedback(String content) {
		ApiRequest request = new ApiRequest("CardDataFeedback");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("bugDesc", content);
		return request;
	}

	/** 公文送出接口(办理环节那儿) */
	public static ApiRequest sendNextWorkFlow(String traceNo,
			String documentId, String wfNo, String swfNo, String nextFpuNo,
			String toStaffNos, String notes, String isSendMessage) {
		ApiRequest request = new ApiRequest("sendNextWorkFlow");
		request.addParam("traceNo", traceNo);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("documentId", documentId);
		request.addParam("wfNo", wfNo);
		request.addParam("swfNo", swfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("nextFpuNo", nextFpuNo);
		request.addParam("toStaffNos", toStaffNos);
		request.addParam("notes", notes);
		request.addParam("isSendMessage", isSendMessage);

		return request;
	}

	/** 公文退件接口 */
	public static ApiRequest rejectWorkFlow(String traceNo, String wfNo,
			String swfNo, String documentId, String reason) {
		ApiRequest request = new ApiRequest("rejectWorkFlow");
		request.addParam("traceNo", traceNo);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("wfNo", wfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("swfNo", swfNo);
		request.addParam("documentId", documentId);
		request.addParam("reason", reason);
		return request;
	}

	/** 公文撤回接口 */
	public static ApiRequest callBackWorkFlow(String traceNo,
			String documentId, String callBackReason) {
		ApiRequest request = new ApiRequest("callBackWorkFlow");
		request.addParam("traceNo", traceNo);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("documentId", documentId);
		request.addParam("callBackReason", callBackReason);
		return request;
	}

	/** 传阅送出接口 */
	public static ApiRequest sendPassRead(String documentId,
			String receiveStaffNo, String limitTime, String wfNo,
			String msgContent) {
		ApiRequest request = new ApiRequest("sendPassRead");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("documentId", documentId);
		request.addParam("receiveStaffNo", receiveStaffNo);
		request.addParam("limitTime", limitTime);
		request.addParam("wfNo", wfNo);
		request.addParam("msgContent", msgContent);
		return request;
	}

	/** 会议详情接口 */
	public static ApiRequest getMeetDetail(String meetingId, String wfNo) {
		ApiRequest request = new ApiRequest("getMeetDetail");
		request.addParam("meetingId", meetingId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("wfNo", wfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		return request;
	}

	/** 会议报名列表接口 */
	public static ApiRequest getMeetSingUp(String meetingId, int pageIndex) {
		ApiRequest request = new ApiRequest("getMeetSingUp");
		request.addParam("meetingId", meetingId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);

		return request;
	}

	/** 会议报名删除接口 */
	public static ApiRequest delMeetSingUp(String signUpId) {
		ApiRequest request = new ApiRequest("deleteMeetSignUp");
		request.addParam("signUpId", signUpId);
		request.addParam("authToken", SystemContext.getSessionId());

		return request;
	}

	/** 会议报名人员保存接口 */
	public static ApiRequest saveMeetSingUp(SignUpInfo signUpInfo) {
		ApiRequest request = new ApiRequest("editMeetSignUp");
		request.addParam("bizId", signUpInfo.getBizId());// 会议ID
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("signUpId", signUpInfo.getSignUpId());// 报名信息ID
																// 英文&符号拼接的字符串,为空的用空代替
		request.addParam("conventioner", signUpInfo.getConventioner());// 参会人英文&符号拼接的字符串
		request.addParam("conventionerRole", signUpInfo.getConventionerRole());// 参会人职务
																				// ,用英文&符号拼接的字符串
		request.addParam("contactTel", signUpInfo.getContactTel());// 联系人电话,用&拼接的字符串
		request.addParam("summary", signUpInfo.getSummary());// 备注用&符号拼接
		request.addParam("staffNo", SystemContext.getAccount());// 人员编号
		request.addParam("wfNo", signUpInfo.getWfNo());// 流程编号
		request.addParam("traceNo", signUpInfo.getTraceNo());// 跟踪编号
		return request;
	}

	/** 会议签到 */
	public static ApiRequest meetSingIn(String context) {
		ApiRequest request = new ApiRequest("MeetSignIn");
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("CodeStr", context);// 二维码扫描到的内容
		return request;
	}

	/** 是否已经报名接口 */
	public static ApiRequest GetStateOfSignUpInMeet(String meetingId) {
		ApiRequest request = new ApiRequest("GetStateOfSignUpInMeet");
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("meetingId", meetingId);// 会议id
		request.addParam("staffNo", SystemContext.getAccount());// 人员编码
		return request;
	}

	/** 附件上传接口 */
	public static ApiRequest uploadFile(String documentId, String swfNo,
			String postedFileName, List<File> files) {
		ApiRequest request = new ApiRequest("uploadFile");
		request.addParam("documentId", documentId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("swfNo", swfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		for (File file : files) {
			request.addParam("file", file);
		}
		return request;
	}

	/** 正文上传接口 */
	public static ApiRequest uploadDocFile(String documentId, String swfNo,
			String traceNo, File file) {
		ApiRequest request = new ApiRequest("uploadDocFile");
		request.addParam("documentId", documentId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("swfNo", swfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("traceNo", traceNo);
		request.addParam("file", file);
		// request.addParam("buffer", buffer); //Byte[]
		return request;
	}

	/** 附件下载 【没有采用】 */
	public static ApiRequest downloadAnnex(String fileCode) {
		ApiRequest request = new ApiRequest("downloadAnnex");
		request.addParam("fileCode", fileCode);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 附件删除 */
	public static ApiRequest deleteFile(String fileCode) {
		ApiRequest request = new ApiRequest("deleteFile");
		request.addParam("fileCode", fileCode);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}

	/** 来文的签收、拒收接口 */
	public static ApiRequest signReceiveDoc(String documentId, String wfNo,
			String traceNo, int isReject, String rejectReason,
			int isFinishWorkFlow) {
		ApiRequest request = new ApiRequest("signReceiveDoc");
		request.addParam("documentId", documentId);
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("wfNo", wfNo);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("traceNo", traceNo);
		request.addParam("isReject", isReject);
		request.addParam("rejectReason", rejectReason);
		request.addParam("isFinishWorkFlow", isFinishWorkFlow);

		return request;
	}

	/** 传阅回复 */
	public static ApiRequest replyPassread(String passreadId,
			String passreadContent) {
		ApiRequest request = new ApiRequest("replyPassread");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("passreadId", passreadId);
		request.addParam("passreadContent", passreadContent);
		return request;
	}

	/** 获取传阅办理信息 */
	public static ApiRequest getActionInfo(String wfNo) {
		ApiRequest request = new ApiRequest("getActionInfo");
		request.addParam("wfNo", wfNo);
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}
	
	/** 申领待办 **/
	public static ApiRequest getReceiveGoodsWaitList(int pageIndex) {
		ApiRequest request = new ApiRequest("getReceiveGoodsWaitList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}
	
	/** 申领查询 **/
	public static ApiRequest getReceiveGoodsGeneralList(String receiveCode, String receiveTitle, String beginTime, String endTime, String state, String isPass, int pageIndex) {
		ApiRequest request = new ApiRequest("getReceiveGoodsGeneralList");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("receiveCode", receiveCode);
		request.addParam("receiveTitle", receiveTitle);
		request.addParam("beginTime", beginTime);
		request.addParam("endTime", endTime);
		request.addParam("completeState", state);
		request.addParam("isPass", isPass);
		request.addParam("pageIndex", pageIndex);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		return request;
	}
	
	/** 申领详情 **/
	public static ApiRequest getReceiveGoodsDetails(String receiveId) {
		ApiRequest request = new ApiRequest("getReceiveGoodsDetails");
		request.addParam("receiveId", receiveId);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		return request;
	}
	
	/** 物品申领送出 **/
	public static ApiRequest sendNextReceiveGoods(String receiveId, String nextFpuNo, String nextStaffNo, String notes, String isSendMessage) {
		ApiRequest request = new ApiRequest("sendNextReceiveGoods");
		request.addParam("receiveId", receiveId);
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("nextFpuNo", nextFpuNo);
		request.addParam("nextStaffNo", nextStaffNo);
		request.addParam("notes", notes);
		request.addParam("isSendMessage", isSendMessage);
		return request;
	}
	
	/** 物品申领审批 **/
    public static ApiRequest auditReceiveGoods(String receiveId, String notes, String passState, String nextStaffNo) {
        ApiRequest request = new ApiRequest("auditReceiveGoods");
        request.addParam("receiveId", receiveId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("notes", notes);
        request.addParam("passState", passState);
        request.addParam("nextStaffNo", nextStaffNo);
        return request;
    }
    
    /** 物品申领办结 **/
    public static ApiRequest finishReceiveGoodsWorkFlow(String receiveId) {
        ApiRequest request = new ApiRequest("finishReceiveGoodsWorkFlow");
        request.addParam("receiveId", receiveId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        return request;
    }
	
	/** 保存申领 **/
	public static ApiRequest saveReceiveGoods(GoodsApplyDetails applyDetails) {
		ApiRequest request = new ApiRequest("saveReceiveGoods");
		request.addParam("staffNo", SystemContext.getAccount());
		request.addParam("authToken", SystemContext.getSessionId());
		request.addParam("receiveId", applyDetails.getReceiveId());
		request.addParam("receiveTitle", applyDetails.getReceiveTitle());
		request.addParam("receiveType", applyDetails.getReceiveType());
		request.addParam("receiveTypeName", applyDetails.getReceiveTypeName());
		request.addParam("goodsDetail", applyDetails.getGoodsDetail());
		request.addParam("<receiveDetailCollection>", "");
		List<GoodsApplyDetails.ApplyDetails> details = applyDetails.getApplyDetails();
		if (!BeanUtils.isEmpty(details)) {
			for (GoodsApplyDetails.ApplyDetails detail : details) {
				request.addParam("<ROW>", "");
				request.addParam("GOODS", detail.getGoods());
				request.addParam("COUNTS", detail.getCounts());
				request.addParam("REMARK", detail.getRemark());
				request.addParam("</ROW>", "");
			}
		} else {
			request.addParam("<ROW>", "");
			request.addParam("GOODS", "");
			request.addParam("COUNTS", "");
			request.addParam("REMARK", "");
			request.addParam("</ROW>", "");
		}
		request.addParam("</receiveDetailCollection>", "");
		return request ;
	}
	

    /** 物品申购--获取物品申购待办列表*/
    public static ApiRequest getPurchaseWaitList(int pageIndex) {
        ApiRequest request = new ApiRequest("getPurchaseWaitList");
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("pageIndex", pageIndex);
        request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
        return request;
    }

    /** 物品申购--查询 */
    public static ApiRequest getPurchaseGeneralList(String state, String code, String title, String passState, String type, String beginTime, String endTime, int pageIndex) {
        ApiRequest request = new ApiRequest("getPurchaseGeneralList");
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("completeState", state);
        request.addParam("purchaseCode", code);
        request.addParam("purchaseTitle", title);
        request.addParam("passState", passState);
        request.addParam("purchaseType", type);
        request.addParam("beginTime", beginTime);
        request.addParam("endTime", endTime);
        request.addParam("pageIndex", pageIndex);
        request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
        return request;
    }

    /** 物品申购--详情 */
    public static ApiRequest getPurchaseDetail(String purchaseId) {
        ApiRequest request = new ApiRequest("getPurchaseDetails");
        request.addParam("purchaseId", purchaseId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        return request;
    }

    /** 物品申购--新增 */
    public static ApiRequest savePurchase(PurchaseApply purchase) {
        ApiRequest request = new ApiRequest("savePurchase");
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("purchaseId", purchase.getPurchaseId());
        request.addParam("purchaseTitle", purchase.getPurchaseTitle());
        request.addParam("purchaseReason", purchase.getPurchaseReason());
        request.addParam("purchaseDate", purchase.getPurchaseDate());
        request.addParam("purchaseType", purchase.getPurchaseType());
        request.addParam("purchaseTypeName", purchase.getPurchaseTypeName());
        request.addParam("payMode", purchase.getPayMode());
        request.addParam("payModeName", purchase.getPayModeName());
        request.addParam("REMARK", purchase.getRemark());
        request.addParam("totalAccount", purchase.getTotleAccount());
        request.addParam("<purchaseDetailCollection>", "");
        List<PurchaseApply.PurchaseDetail> details = purchase.getDetails();
        if (!BeanUtils.isEmpty(details)) {
            for (PurchaseApply.PurchaseDetail detail : details) {
                request.addParam("<ROW>", "");
                request.addParam("PURCHASE_NAME", detail.getPurchaseName());
                request.addParam("SPEC", detail.getSpec());
                request.addParam("QUANTITY", detail.getQuantity());
                request.addParam("UNIT", detail.getUnit());
                request.addParam("UNIT_PRICE", detail.getUnitPrice());
                request.addParam("TOTAL_PRICE", detail.getTotalPrice());
                request.addParam("</ROW>", "");
            }
        }
        request.addParam("</purchaseDetailCollection>", "");
        return request;
    }

    /** 物品申购--送出接口 */
    public static ApiRequest sendNextPurchase(String purchaseId, String nextFpuNo, String nextStaffNo, String notes, String isSendMessage) {
        ApiRequest request = new ApiRequest("sendNextPurchase");
        request.addParam("purchaseId", purchaseId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("nextFpuNo", nextFpuNo);
        request.addParam("nextStaffNo", nextStaffNo);
        request.addParam("notes", notes);
        request.addParam("isSendMessage", isSendMessage);
        return request;
    }

    /** 物品申购--申购审批 */
    public static ApiRequest auditPurchase(String purchaseId, String notes, String passState, String nextStaffNo) {
        ApiRequest request = new ApiRequest("auditPurchase");
        request.addParam("purchaseId", purchaseId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        request.addParam("notes", notes);
        request.addParam("passState", passState);
        request.addParam("nextStaffNo", nextStaffNo);
        return request;
    }
    
    /** 物品申购办结 **/
    public static ApiRequest finishPurchaseWorkFlow(String purchaseId) {
        ApiRequest request = new ApiRequest("finishPurchaseWorkFlow");
        request.addParam("purchaseId", purchaseId);
        request.addParam("authToken", SystemContext.getSessionId());
        request.addParam("staffNo", SystemContext.getAccount());
        return request;
    }
    
    /** 公文催办--信息列表 */
    public static ApiRequest getUrgencySMSList(String documentId, String wfNo) {
    	ApiRequest request = new ApiRequest("getUrgencySMSList");
    	request.addParam("staffNo", SystemContext.getAccount());
    	request.addParam("authToken", SystemContext.getSessionId());
    	request.addParam("documentId", documentId);
    	request.addParam("wfNo", wfNo);
    	return request;
    }
    
    /** 发送催办信息 */
    public static ApiRequest sendUrgencyMessage(String wfNo, String traceNo) {
    	ApiRequest request = new ApiRequest("sendUrgencyMessage");
    	request.addParam("staffNo", SystemContext.getAccount());
    	request.addParam("authToken", SystemContext.getSessionId());
    	request.addParam("wfNo", wfNo);
    	request.addParam("traceNo", traceNo);
    	return request;
    }
    
}
