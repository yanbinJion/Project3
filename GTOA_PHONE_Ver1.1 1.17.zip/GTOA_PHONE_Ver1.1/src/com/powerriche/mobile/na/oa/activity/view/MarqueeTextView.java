package com.powerriche.mobile.na.oa.activity.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 具有跑马灯效果的TextView
 */
public class MarqueeTextView extends TextView {

	public MarqueeTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	public boolean isFocused() {
		// 让TextView永远都是获得焦点的状态
		return true;
	}

}