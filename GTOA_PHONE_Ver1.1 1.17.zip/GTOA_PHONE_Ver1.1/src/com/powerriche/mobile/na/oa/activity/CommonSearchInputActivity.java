package com.powerriche.mobile.na.oa.activity;

import java.util.Calendar;
import java.util.Date;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.SearchBarWidget.onSearchListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 综合查询：填写
 * 
 * @author 李运期
 * @date 2015年5月8日
 * @version v1.0
 */
@SuppressLint("ResourceAsColor")
public class CommonSearchInputActivity extends BaseActivity
		implements
			OnClickListener,
			OnCheckedChangeListener,
			onSearchListener {

	private static final String TAG = "CommonSearchInputActivity";

	private static final int REQUEST_WHAT_TO_SEARCH_RESULT = 1001;

	private Context mContext;
	private CommonSearchInputActivity acitvity;
	private View contextView;

	private SearchBarWidget mSearchBarWidget;

	// 基本信息界面相关
	private RadioGroup radioGroup_ywlx;
	private RadioButton radio_ywlx_1, radio_ywlx_2, radio_ywlx_3, radio_ywlx_4,
			radio_ywlx_5;
	private LinearLayout ll_cxlx;
	private RadioGroup radioGroup_cxlx;
	private RadioButton radio_cxlx_1, radio_cxlx_2;
	private LinearLayout ll_blzt;
	private TextView txt_blzt;
	private RadioGroup radioGroup_blzt;
	private RadioButton radio_blzt_1, radio_blzt_2, radio_blzt_3;
	private EditText et_begin_time;
	private EditText et_end_time;

	private Button btn_submit;

	private String searchTitle = ""; // 搜索标题
	private String bizType = "0"; // 业务类型：0,公文 1,内部事务 2,会议 3,议题 6,请假
	private String searchType = "0"; // 查询类型：0,办件 1,阅件
	private String searchState = "1"; // 查询状态：当searchType=0，[1,待办][2,已办][3,办结]。当searchType=1，[1,待阅][2,已阅][3,已传]
	private String beginTime = ""; // 开始时间，格式：yyyy-MM-dd
	private String endTime = ""; // 结束时间，格式：yyyy-MM-dd

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.common_search_input);

		acitvity = (CommonSearchInputActivity) this;

		mSearchBarWidget = (SearchBarWidget) findViewById(R.id.searchbar_title);
		//mSearchBarWidget.setSearchHint(getString(R.string.common_search_hint));
		((EditText) findViewById(R.id.search_text)).setHint(getString(R.string.common_search_hint));
		mSearchBarWidget.setOnSearchListener(null);

		bindView();
	}

	void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.common_search_title));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.INVISIBLE);// 隐藏右边按钮

		// 业务类型
		radioGroup_ywlx = (RadioGroup) findViewById(R.id.radioGroup_ywlx);
		radioGroup_ywlx.setOnCheckedChangeListener(this);
		radio_ywlx_1 = (RadioButton) findViewById(R.id.radio_ywlx_1);
		radio_ywlx_2 = (RadioButton) findViewById(R.id.radio_ywlx_2);
		radio_ywlx_3 = (RadioButton) findViewById(R.id.radio_ywlx_3);
		// radio_ywlx_4 = (RadioButton) findViewById(R.id.radio_ywlx_4);
		// radio_ywlx_5 = (RadioButton) findViewById(R.id.radio_ywlx_5);
		// 查询类型
		ll_cxlx = (LinearLayout) findViewById(R.id.ll_cxlx);
		radioGroup_cxlx = (RadioGroup) findViewById(R.id.radioGroup_cxlx);
		radioGroup_cxlx.setOnCheckedChangeListener(this);
		radio_cxlx_1 = (RadioButton) findViewById(R.id.radio_cxlx_1);
		radio_cxlx_2 = (RadioButton) findViewById(R.id.radio_cxlx_2);
		// 查询状态：办理状态、传阅状态：二合一共用
		ll_blzt = (LinearLayout) findViewById(R.id.ll_blzt);
		txt_blzt = (TextView) findViewById(R.id.txt_blzt);
		radioGroup_blzt = (RadioGroup) findViewById(R.id.radioGroup_blzt);
		radio_blzt_1 = (RadioButton) findViewById(R.id.radio_blzt_1);
		radio_blzt_2 = (RadioButton) findViewById(R.id.radio_blzt_2);
		radio_blzt_3 = (RadioButton) findViewById(R.id.radio_blzt_3);
		// 时间区间
		et_begin_time = (EditText) findViewById(R.id.et_begin_time);
		et_begin_time.setOnClickListener(this);
		et_end_time = (EditText) findViewById(R.id.et_end_time);
		et_end_time.setOnClickListener(this);

		// 按钮：查找
		btn_submit = (Button) findViewById(R.id.btn_submit);
		btn_submit.setOnClickListener(this);

		// 设置默认的时间区间：最近一个月
		et_end_time.setText(DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT));
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MONTH, -1);// 月份减1
		et_begin_time
				.setText(DateUtils.getDateStr(cal.getTime(), DateUtils.DATE_FORMAT));
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				finish();
				break;
			case R.id.btn_submit :// 按钮：查找
				if (doCheckData()) {// 验证
					doSubmitData();
				}
				break;
			case R.id.et_begin_time :// 搜索区间：开始时间
				UIHelper.showTimeSelect(mContext, et_begin_time, DateUtils.DATE_FORMAT);
				break;
			case R.id.et_end_time :// 搜索区间：结束时间
				UIHelper.showTimeSelect(mContext, et_end_time, DateUtils.DATE_FORMAT);
				break;
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup rg, int checkedId) {
		switch (checkedId) {
			case R.id.radio_ywlx_1 :// 业务类型：公文
				bizType = "0";// 1-公文
				ll_cxlx.setVisibility(View.VISIBLE);
				ll_blzt.setVisibility(View.VISIBLE);
				break;
			case R.id.radio_ywlx_2 :// 业务类型：会议
				bizType = "2";// 2-会议
				ll_cxlx.setVisibility(View.VISIBLE);
				ll_blzt.setVisibility(View.VISIBLE);
				break;
			case R.id.radio_ywlx_3 :// 业务类型：请假
				bizType = "6";// 6-请假
				ll_cxlx.setVisibility(View.GONE);
				ll_blzt.setVisibility(View.GONE);
				break;
			case R.id.radio_ywlx_4 :// 业务类型：内部事务
				bizType = "1";// 1-内部事务
				ll_cxlx.setVisibility(View.VISIBLE);
				ll_blzt.setVisibility(View.VISIBLE);
				break;
			case R.id.radio_ywlx_5 :// 业务类型：议题
				bizType = "3";// 3-议题
				ll_cxlx.setVisibility(View.VISIBLE);
				ll_blzt.setVisibility(View.VISIBLE);
				break;
			case R.id.radio_cxlx_1 :// 查询类型：办件
				txt_blzt.setText(getString(R.string.common_search_blzt));
				radio_blzt_1.setText(getString(R.string.common_search_blzt_1));
				radio_blzt_2.setText(getString(R.string.common_search_blzt_2));
				radio_blzt_3.setText(getString(R.string.common_search_blzt_3));
				radio_blzt_1.setChecked(true);
				break;
			case R.id.radio_cxlx_2 :// 查询类型：阅件
				txt_blzt.setText(getString(R.string.common_search_cyzt));
				radio_blzt_1.setText(getString(R.string.common_search_cyzt_1));
				radio_blzt_2.setText(getString(R.string.common_search_cyzt_2));
				radio_blzt_3.setText(getString(R.string.common_search_cyzt_3));
				radio_blzt_1.setChecked(true);
				break;
		}
	}

	/** 提交数据 */
	public void doSubmitData() {
		// 搜索关键字：文件标题
		searchTitle = mSearchBarWidget.getEditTextSearch().getText().toString();
		// 查询类型：0,办理状态 1,传阅状态
		if (radio_cxlx_1.isChecked()) {
			searchType = "0";// 0-办理状态
		} else if (radio_cxlx_2.isChecked()) {
			searchType = "1";// 1-传阅状态
		}
		// 查询状态：当searchType=0，[1,待办][2,已办][3,办结]。当searchType=1，[1,待阅][2,已阅][3,已传]
		if (radio_blzt_1.isChecked()) {
			searchState = "1";
		} else if (radio_blzt_2.isChecked()) {
			searchState = "2";
		} else if (radio_blzt_3.isChecked()) {
			searchState = "3";
		}
		// 时间区间
		beginTime = et_begin_time.getText().toString();
		endTime = et_end_time.getText().toString();

		/**
		 * 跳转到界面：综合查询-结果
		 */
		// 封装交互数据
		Bundle data = new Bundle();
		data.putString("searchTitle",
				(searchTitle == null ? "" : searchTitle.trim()));
		data.putString("bizType", (bizType == null ? "0" : bizType.trim()));
		data.putString("searchType",
				(searchType == null ? "0" : searchType.trim()));
		data.putString("searchState",
				(searchState == null ? "1" : searchState.trim()));
		data.putString("beginTime", beginTime);
		data.putString("endTime", endTime);

		// 跳转到详情页面
		UIHelper.forwardTargetActivity(this, CommonSearchResultActivity.class,
				data, false);

	}

	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		// if
		// (BeanUtils.isEmpty(mSearchBarWidget.getEditTextSearch().getText().toString()))
		// {//标题
		// Toast.makeText(CommonSearchInputActivity.this,
		// getString(R.string.required_tip_search_title),
		// Toast.LENGTH_SHORT).show();
		// return false;
		// }
		if (BeanUtils.isEmpty(et_begin_time.getText().toString())) {// 开始时间
			Toast.makeText(CommonSearchInputActivity.this,
					getString(R.string.required_tip_search_begin_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if (BeanUtils.isEmpty(et_end_time.getText().toString())) {// 结束时间
			Toast.makeText(CommonSearchInputActivity.this,
					getString(R.string.required_tip_search_end_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}

		// 检验时间范围
		Date begindate = DateUtils.parseDate(et_begin_time.getText().toString()
				+ " 00:00:00", "yyyy-MM-dd HH:mm:ss");
		if (begindate == null) {
			Toast.makeText(CommonSearchInputActivity.this,
					getString(R.string.error_tip_search_begin_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		Date enddate = DateUtils.parseDate(et_end_time.getText().toString()
				+ " 23:59:59", "yyyy-MM-dd HH:mm:ss");
		if (enddate == null) {
			Toast.makeText(CommonSearchInputActivity.this,
					getString(R.string.error_tip_search_end_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		if (enddate.before(begindate)) {
			Toast.makeText(CommonSearchInputActivity.this,
					getString(R.string.error_tip_between_search_time),
					Toast.LENGTH_SHORT).show();
			return false;
		}

		return true;
	}


	@Override
	public void onSearchChange(String search) {
		Logger.e(TAG, "搜索关键字：" + search);
	}

}
