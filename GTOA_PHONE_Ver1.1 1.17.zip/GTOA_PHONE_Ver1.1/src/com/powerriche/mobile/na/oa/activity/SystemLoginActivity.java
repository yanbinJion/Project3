package com.powerriche.mobile.na.oa.activity;

import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.jpush.android.api.JPushInterface;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.DataCleanManager;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.NotifyBean;
import com.powerriche.mobile.na.oa.bean.VersionInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UserHelper;
import com.powerriche.mobile.oa.vpn.OaVpnService;

/**
 * Filename : SystemLoginActivity.java
 * 
 * @Description :登录
 * @Author : gmf
 * @Version : 1.0
 * @Date :2015-04-20 09:38:24
 */
public class SystemLoginActivity extends BaseActivity {

	private final static int WHAT_SHOW = 7423;
	private final static int DIALOG_VERSION = 5235;
	private int localVersionCode = Integer.MAX_VALUE;//本地APK的版本编号
	private String localVersionName = "1.0.0";//本地APK的版本名称
	private String alertMessage;

	private String userId; // 用户名称，如： dengying
	private String password;

	// 权限列表
	private Set<String> rights = new HashSet<String>();

	private ResultItem userItem = null;
	private UserHelper userHelper = null;

	private String loginmessage = "";
	private boolean isAuto = false;

	private EditText userNameEdit, passwordEdit;
	private CheckBox isAutoBtn;
	private Button loginButton;

	private static Context mContext;

	// 定义一个变量，来标识是否退出
	private static boolean isExit = false;

	private LinearLayout logoLinearLayout;

	private static LinearLayout loginLinearLayout;
	private static LinearLayout buttonLinearLayout;

	private static TextView tvCopyright;

	/** vpn是否开通 */
	private boolean isVpn = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = this;
		// 判断是否需要手势密码
		if (UIHelper.JudgeGgesturesPassword(mContext)) {
			return;
		}
		// 判断是pad版本
		if (BeanUtils.isTabletDevice(mContext)) {
			// 横屏
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
			// 设置界面
			setContentView(R.layout.login_layout_pad);
		} else {
			// 设置界面
			setContentView(R.layout.login_layout);
		}
		// 初始化话vpn
		JudgeVpn();

		
		// 获取界面的控件
		userNameEdit = (EditText) findViewById(R.id.system_input_user);
		passwordEdit = (EditText) findViewById(R.id.system_input_password);
		isAutoBtn = (CheckBox) findViewById(R.id.system_input_autologin);
		loginButton = (Button) findViewById(R.id.system_btn_login);

		userHelper = new UserHelper();
		userItem = userHelper.getLastUserInfo();
		// 或者登录信息看是否是自动登录
		int isAutoLogin = userItem.getInt("AUTOLOGIN");
		String userName = userItem.getString("USERID");
		String password = userItem.getString("PASSWORD");
		rights.clear();

		// 如果自动标识为1表示是自动登录，再判断用户名和密码是否为空
		if (isAutoLogin == 1 && !BeanUtils.isEmpty(userName)
				&& !BeanUtils.isEmpty(password)) {
			loginmessage = getString(R.string.system_auto_message);
			isAutoBtn.setChecked(true);
			if (isVpn) {
				// 调用自动登录接口方法
				login(userName, password, true);
			}
		}

		if (!BeanUtils.isEmpty(userName)) {
			userNameEdit.setText(userName);
			passwordEdit.requestFocus();
		}

		userNameEdit.addTextChangedListener(watcher);
		passwordEdit.addTextChangedListener(watcher);

		// 动态显示出页面的元素
		logoLinearLayout = (LinearLayout) findViewById(R.id.logo_linearLayout);
		loginLinearLayout = (LinearLayout) findViewById(R.id.login_linearLayout);
		buttonLinearLayout = (LinearLayout) findViewById(R.id.button_linearLayout);
		tvCopyright = (TextView) findViewById(R.id.tv_copyright);
		Animation anim = AnimationUtils.loadAnimation(this,
				R.anim.in_from_translate);
		logoLinearLayout.startAnimation(anim);
		if (BeanUtils.isTabletDevice(mContext)) {
			timer.schedule(task, 3500);
		} else {
			timer.schedule(task, 2500);
		}

		// 绑定密码完成功能点，直接提交
		passwordEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						/* 判断是否是“完成”键 */
						if (actionId == EditorInfo.IME_ACTION_DONE) {
							if (checkInput()) {
								/* 隐藏软键盘 */
								InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
								if (inputMethodManager.isActive()) {
									inputMethodManager.hideSoftInputFromWindow(SystemLoginActivity.this.getCurrentFocus().getWindowToken(), 0);
								}
								// 登录
								String userId = userNameEdit.getText().toString();
								String passwd = passwordEdit.getText().toString();
								if (isVpn) {
									login(userId, passwd, isAuto);
								}
								return true;
							} else {
								// showDialog(DIALOG_CHECK);
								showErrorMessage(alertMessage);
							}
						}
						return false;
					}
				});
		initData();
	}
	
	
	// 初始化数据
	public void initData() {
		try {
			// 得到当前版本号
			PackageManager manager = this.getPackageManager();
			PackageInfo info = manager.getPackageInfo(this.getPackageName(), 0);
			localVersionCode = info.versionCode;
			localVersionName = info.versionName;
			getVersion();
		} catch (Exception e) {
			getVersion();
		}

	}
	
	/** 获取版本号 */
	public void getVersion() {
		ApiRequest request = OAServicesHandler.getAppVersion("android");
		helper.invokeWidthDialog(request, callBack, DIALOG_VERSION);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.powerriche.mobile.na.oa.activity.base.IRequestCallBack#process
		 * (com.powerriche.mobile.oa.network.http.HttpResponse, int)
		 */
		@Override
		public void process(HttpResponse response, int what) {
			if (DIALOG_VERSION == what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				String code = item.getString("code");
				String versionName = item.getString("vername");
				String localVersionInfo = "当前版本是" + localVersionName + "，"
						+ versionName;
				// 操作成功
				if (Constants.SUCCESS_CODE.equals(code)) {
					int remoteVersionCode = item.getInt("vercode", -1);// 远程APK的版本编号
					// 判断版本
					if (localVersionName.compareTo(versionName) < 0) {
						String downUrl = item.getString("url");
						String content = item.getString("content");
						String apkSize = item.getString("apksize");
						// int isforce = item.getInt("isforce", 0); //是否强制升级
						if (!BeanUtils.isEmpty(apkSize)) {
							content = content + "<br/>文件大小：" + apkSize;
						}
						VersionInfo bean = new VersionInfo();
						bean.setVersionCode(remoteVersionCode);
						bean.setVersionName(versionName);
						bean.setDownUrl(downUrl);
						bean.setContent(content);
						bean.setApkSize(apkSize);
						UIHelper.showTipsDialog(mContext, bean);
					}
				}
			} else if (what == Constants.WHAT_LOGIN_PORTAL) {// 门户登录返回
				ResultItem item = response.getResultItem(ResultItem.class);
				if (!BeanUtils.isEmpty(item)) {
					try {
						String code = item.getString("code");
						String message = item.getString("message");

						if (Constants.SUCCESS_CODE.equals(code)) {
							if (!BeanUtils.isEmpty(item.getItems("data"))) {
								item = item.getItems("data").get(0);

								String protalStaffNo = item
										.getString("STAFF_NO");// 门户的StaffNO
								String protalToken = item
										.getString("AUTH_TOKEN");// 门户的AuthToken
								String oaStaffNo = "";// 移动OA的StaffNO
								String oaToken = "";// 移动OA的AuthToken
								String realName = item.getString("REAL_NAME");
								String siteName = item.getString("SITE_NAME");
								String siteNo = item.getString("SITE_NO");
								String mobile = item.getString("MOBILE");
                                String position = item.getString("POSITION");
                                String sex = item.getString("SEX");
                                String phone = item.getString("PHONE");
								// 设置用户信息
								SystemContext.initUserInfo(userId,
										protalStaffNo, protalToken, oaStaffNo,
										oaToken, realName, siteNo, siteName,
										mobile, position, sex, phone);
								// 保存登录信息到本地
								userHelper.recodeLogin(userId, password,
										isAuto, realName);
								// showErrorMessage("登录成功！STAFF_NO:" + staffNo +
								// "token=" + token);
								// 如果是通知入口，登录成功后先进来通知界面
								SystemContext.setAccount(protalStaffNo);
								SystemContext.setSessionid(protalToken);
								convertStaffNoForOA();// 因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
								// 清空密码的字段
								passwordEdit.setText("");
								
							}
						} else {
							// errorMessage = message;
							// showDialog(DIALOG_LOGIN);
							showErrorMessage(message);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			} else if (what == Constants.WHAT_LOGIN_OA) { // OA登陆返回
				ResultItem item = response.getResultItem(ResultItem.class);
				if (!BeanUtils.isEmpty(item)) {

					String code = item.getString("code");
					String message = item.getString("message");
					if (Constants.SUCCESS_CODE.equals(code)) {
						item = item.getItems("data").get(0);

						String protalStaffNo = "";// 门户的StaffNO
						String protalToken = "";// 门户的AuthToken
						String oaStaffNo = item.getString("STAFF_NO");// 移动OA的StaffNO
						String oaToken = item.getString("AUTH_TOKEN");// 移动OA的AuthToken
						String realName = item.getString("REAL_NAME");
						String siteName = item.getString("SITE_NAME");
						String siteNo = item.getString("SITE_NO");
						String mobile = item.getString("MOBILE");
                        String position = item.getString("POSITION");
                        String sex = item.getString("SEX");
                        String phone = item.getString("PHONE");
						// 设置用户信息
						SystemContext.initUserInfo(userId, protalStaffNo,
								protalToken, oaStaffNo, oaToken, realName,
								siteNo, siteName, mobile, position, sex, phone);
						// 保存登录信息到本地
						userHelper.recodeLogin(userId, password, isAuto,
								realName);
						// 打开并跳转到系统主界面
						gotoMainActivity();

					} else {
						UIHelper.showMessage(context, message);
					}
				}

			} else if (what == Constants.WHAT_LOGIN_CONVERT) { // 门户登录转换：门户登录成功之后需要转换StaffNo值
				ResultItem item = response.getResultItem(ResultItem.class);
				if (!BeanUtils.isEmpty(item)) {

					String code = item.getString("code");
					String message = item.getString("message");
					if (Constants.SUCCESS_CODE.equals(code)) {
						item = item.getItems("data").get(0);

						String oaStaffNo = item.getString("STAFF_NO");// 移动OA的StaffNO
						String oaToken = item.getString("AUTH_TOKEN");// 移动OA的AuthToken
						SystemContext.setAccount(oaStaffNo);
						SystemContext.setSessionid(oaToken);
						// 打开并跳转到系统主界面
						if (Constants.NOTIFY_LOGIN && Constants.NOTIFY_BEAN != null) {
							forwardNotifyDetail();
						} else {
							gotoMainActivity();
						}

					} else {
						UIHelper.showMessage(context, message);
					}
				}

			} else if (what == 888) {
//				AskLeaveItemHelper leaveItemHelper = new AskLeaveItemHelper();
//				leaveItemHelper.process(mContext, response, true);

			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			if (what == Constants.WHAT_LOGIN_OA
					|| what == Constants.WHAT_LOGIN_PORTAL) {// 登录
				showErrorMessage(getString(R.string.system_login_error_message));
			}
		}

		@Override
		public void onNetError(int what) {
			if (what == Constants.WHAT_LOGIN_OA
					|| what == Constants.WHAT_LOGIN_PORTAL) {// 登录
				showErrorMessage(getString(R.string.system_login_net_error_message));
			}
		}

	};

	public void onClick(View view) {
		// 判断是否选择记住账号
		if (view.getId() == R.id.system_input_autologin) {
			// view.setClickable(isAuto ? false : true);
			isAutoBtn.setChecked(isAuto ? false : true);
			isAuto = !isAuto;
		}
	}

	private void gotoMainActivity() {
		Intent intent = new Intent(SystemLoginActivity.this, MainActivity.class);
		startActivityForResult(intent, 123456);
		overridePendingTransition(android.R.anim.slide_in_left,
				android.R.anim.slide_out_right);
		finish();
	}

	private TextWatcher watcher = new TextWatcher() {

		@Override
		public void afterTextChanged(Editable arg0) {

		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {

		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before,
				int count) {
			if (!BeanUtils.isEmpty(userNameEdit.getText().toString())
					&& !BeanUtils.isEmpty(passwordEdit.getText().toString())) {
				loginButton
						.setBackgroundResource(R.drawable.btn_round_blue_selector);
				loginButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						// 判断是否点击登录按钮
						String userId = userNameEdit.getText().toString();
						String passwd = passwordEdit.getText().toString();
						if (checkInput()) {
							// 登录
							login(userId, passwd, isAuto);
						} else {
							// showDialog(DIALOG_CHECK);
							showErrorMessage(alertMessage);
						}
					}
				});
			} else {
				loginButton.setBackgroundResource(R.drawable.btn_round_gray_bg);
				loginButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View arg0) {
					}
				});
			}
		}

	};
	
	/** 登陆认证 */
	public void login(String userId, String passWd, boolean isauto) {
		rights.clear();
		if (BeanUtils.isEmpty(loginmessage)) {
			loginmessage = getString(R.string.system_check_user_message);
		}
		this.userId = userId;
		this.password = passWd;
		this.isAuto = isauto;

		if (Constants.IS_USER_PORTAL) {// 采用门户接口
			ApiRequest requestPT = OAServicesHandler
					.portalLogin(userId, passWd);// 新版：门户转换登录，需要转换StaffNO
			requestPT.setMessage(loginmessage);
			helper.invokeWidthDialog(requestPT, callBack,
					Constants.WHAT_LOGIN_PORTAL);
		} else {// 采用OA接口
			ApiRequest requestOA = OAServicesHandler.mobileLogin(userId, passWd);// 老版：OA直接登录，不需要转换StaffNO
			requestOA.setMessage(loginmessage);
			helper.invokeWidthDialog(requestOA, callBack, Constants.WHAT_LOGIN_OA);
		}

	}

	/**
	 * 根据门户的StaffNo获取OA上对应的StaffNo和Token值<br>
	 * 因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
	 */
	public void convertStaffNoForOA() {
		ApiRequest request = OAServicesHandler
				.getStaffNoAndTokenForOA(SystemContext.getAccountProtal());
		helper.invoke(request, callBack, Constants.WHAT_LOGIN_CONVERT);
	}

	/** 验证提交的数据 */
	public boolean checkInput() {
		alertMessage = "";
		if (userNameEdit != null
				&& BeanUtils.isEmpty(userNameEdit.getText().toString())) {
			alertMessage = getString(R.string.system_login_user_hint);
			return false;
		}
		if (passwordEdit != null
				&& BeanUtils.isEmpty(passwordEdit.getText().toString())) {
			alertMessage = getString(R.string.system_login_passwd_hint);
			return false;
		}
		return true;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	public void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(),
					getString(R.string.system_logout_again), Toast.LENGTH_SHORT)
					.show();
			// 利用handler延迟发送更改状态信息
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			this.finish();
		}
	}

	private static Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == WHAT_SHOW) {
				showAll();
			} else {
				isExit = false;
			}
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (123456 == requestCode && data != null) {
			if (data.getBooleanExtra(SESSION_LOST_KEY, false)) {
				try {
					userItem = userHelper.getLastUserInfo();
					if (userItem != null) {
						int isAutoLogin = userItem.getInt("AUTOLOGIN");
						String userName = userItem.getString("USERID");
						String password = userItem.getString("PASSWORD");
						userNameEdit.setText(userName);
						passwordEdit.setText(isAutoLogin == 1 ? password : "");
						isAuto = isAutoLogin == 1;
						isAutoBtn.setChecked(!isAuto ? false : true);
					}
				} catch (Exception e) {
					Log.e("======返回接口异常======", e.getMessage());
				}
			} else if (data.getBooleanExtra(EXIT, false)) {
				finish();
			}
		} else if (resultCode == Constants.WHAT_VPN) {
			String prefix = getPackageName();
			Intent intent = new Intent(this, OaVpnService.class)
					.putExtra(prefix + ".ADDRESS",
							getString(R.string.vpn_address))
					.putExtra(prefix + ".PORT", getString(R.string.vpn_port))
					.putExtra(prefix + ".ACCOUNT",
							getString(R.string.vpn_account))
					.putExtra(prefix + ".SECRET",
							getString(R.string.vpn_secret));
			startService(intent);
			isVpn = true;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	Timer timer = new Timer();
	TimerTask task = new TimerTask() {
		@Override
		public void run() {
			// 需要做的事:发送消息
			Message message = new Message();
			message.what = WHAT_SHOW;
			mHandler.sendMessage(message);
		}
	};

	public static void showAll() {
		loginLinearLayout.setVisibility(View.VISIBLE);
		buttonLinearLayout.setVisibility(View.VISIBLE);
		tvCopyright.setVisibility(View.VISIBLE);
		Animation anim = AnimationUtils.loadAnimation(mContext,
				R.anim.in_from_alpha);
		loginLinearLayout.startAnimation(anim);
		buttonLinearLayout.startAnimation(anim);
		tvCopyright.startAnimation(anim);
	}

	/** 判断是否需要vpn 需要进行连接 */
	public void JudgeVpn() {
		// 等于1的时候使用vpn
		if (Constants.VPN_OPEN.equals(mContext
				.getString(R.string.vpn_isconnection))) {
			isVpn = false;
			// 调用vpn
			Intent intentVPN = VpnService.prepare(mContext);
			if (intentVPN != null) {
				startActivityForResult(intentVPN, Constants.WHAT_VPN);
			} else {
				onActivityResult(0, Constants.WHAT_VPN, null);
			}
		} else {
			isVpn = true;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		JPushInterface.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		JPushInterface.onPause(this);
	}

	/**
	 * 根据通知类型，跳转到相应通知详情界面查看
	 */
	private void forwardNotifyDetail() {
		Constants.NOTIFY_LOGIN = false;

		NotifyBean bean = Constants.NOTIFY_BEAN;
		Constants.NOTIFY_BEAN = null;
		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
//		// 请假：2014072509353877 请假详情界面跳转
		if ("2014072509353877".equals(bean.getSwfNo()) && bean.getType() == 1) {
			Constants.NOTIFY_DETAIL_BACK = true;
//			Constants.DOCUMENT_ID = BeanUtils.floatToInt4Str(bean
//					.getDocumentId());
//			Constants.TRACE_NO = BeanUtils.floatToInt4Str(bean.getTraceNo());
//			InvokeHelper helper = new InvokeHelper(this);
//			helper.invoke(OAServicesHandler.getLeaveDetails(BeanUtils
//					.floatToInt4Str(bean.getDocumentId())), callBack, 888);
			Bundle data = new Bundle();
			data.putString("documentId", BeanUtils.floatToInt4Str(bean.getDocumentId()));
			data.putString("wfNo", BeanUtils.floatToInt4Str(bean.getWfNo()));
			data.putString("swfNo", BeanUtils.isEmpty4Get(bean.getSwfNo()));
			data.putString("traceNo", BeanUtils.floatToInt4Str(bean.getTraceNo()));
			UIHelper.forwardTargetActivity(mContext, LeaveDetailActivity.class, data, false);

		} else {

			Bundle data = new Bundle();
			data.putString("documentId", BeanUtils.floatToInt4Str(bean.getDocumentId()));
			data.putString("wfNo", BeanUtils.floatToInt4Str(bean.getWfNo()));
			data.putString("swfNo", BeanUtils.isEmpty4Get(bean.getSwfNo()));
			data.putString("traceNo", BeanUtils.floatToInt4Str(bean.getTraceNo()));
			UIHelper.forwardTargetActivity(mContext, data, bean.getType());
			Constants.NOTIFY_BEAN = null;
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		}
	}

}
