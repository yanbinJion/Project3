package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.activity.document.CommonSearchListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br>
 * 综合查询：结果列表
 * 
 * @author 李运期
 * @date 2015年5月8日
 * @version v1.0
 */
public class CommonSearchResultActivity extends BaseActivity implements OnClickListener {

	private static final String TAG = "CommonSearchResultActivity";

	private Context mContext;
	private CommonSearchResultActivity acitvity;
	private View contextView;

	private PullToRefreshListView mPullView;
	private ListView mListView;
	private TextView tvNoDataMsg;

	public int pageIndex = 1;

	private static int OPT_TYPE = Constants.WHAT_REQUEST_ZHCX;

	public Handler indexHandler;
	/** 综合查询 */
	public CommonSearchListHelper commonSearchListHelper;

	private String searchTitle = ""; // 搜索标题
	private String bizType = "0"; // 业务类型：0,公文 1,内部事务 2,会议 3,议题 6,请假
	public  String searchType = "0"; // 查询类型：0,办理状态 1,传阅状态
	public  String searchState = "1"; // 查询状态：当searchType=0，[1,待办][2,已办][3,办结]。当searchType=1，[1,待阅][2,已阅][3,已传]
	private String beginTime = ""; // 开始时间，格式：yyyy-MM-dd
	private String endTime = ""; // 结束时间，格式：yyyy-MM-dd

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.common_search_result);

		acitvity = (CommonSearchResultActivity) this;
		contextView = findViewById(R.id.layout_zhcxzg);

		bindView();

		// 获取交互参数
		searchTitle = getIntent().getStringExtra("searchTitle");// 搜索标题
		bizType = getIntent().getStringExtra("bizType");// 业务类型
		searchType = getIntent().getStringExtra("searchType");// 办理类型
		searchState = getIntent().getStringExtra("searchState");// 传阅类型
		beginTime = getIntent().getStringExtra("beginTime");// 开始时间
		endTime = getIntent().getStringExtra("endTime");// 结束时间

		// 验证并纠正错误参数，去掉多余空格
		searchTitle = (searchTitle == null ? "" : searchTitle.trim());
		bizType = (bizType == null ? "0" : bizType.trim());
		searchType = (searchType == null ? "0" : searchType.trim());
		searchState = (searchState == null ? "1" : searchState.trim());
		beginTime = (beginTime == null ? "" : beginTime.trim());// 开始时间
		endTime = (endTime == null ? "" : endTime.trim());// 结束时间

		loadDataBySearch();// 加载列表数据
	}

	void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.common_search_title));// 顶部栏的中间标题

		// 设置中部的列表区
		mPullView = (PullToRefreshListView) findViewById(R.id.pulllistview_zhcxzg);
		mPullView.setPullRefreshEnabled(false);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);

		mListView = mPullView.getRefreshableView();
		// mListView.setVerticalScrollBarEnabled(false);//设置滚动条隐藏
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(android.R.color.transparent);

		mPullView.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 下拉加载数据
			}

			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				commonSearchListHelper.loadDataBySearch(OPT_TYPE, pageIndex,
						searchTitle, bizType, beginTime, endTime,
						BeanUtils.floatToInt(searchType),
						BeanUtils.floatToInt(searchState));
			}
		});
		
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);
	}

	/**
	 * 加载数据：通知公告列表
	 */
	public void loadDataBySearch() {
		// 设置选中项
		OPT_TYPE = Constants.WHAT_REQUEST_ZHCX;

		commonSearchListHelper = new CommonSearchListHelper(acitvity, contextView, tvNoDataMsg);
		// 请求加载数据
		pageIndex = 1;
		commonSearchListHelper.loadDataBySearch(OPT_TYPE, pageIndex,
				searchTitle, bizType, beginTime, endTime,
				BeanUtils.floatToInt(searchType), BeanUtils.floatToInt(searchState));
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				finish();
				break;
		}
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			if (what == Constants.WHAT_REQUEST_ZHCX) {// 通知公告
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					commonSearchListHelper.process(response, what);
				}
			}else if(what == Constants.OPT_TYPE_LEAVE_DETAIL){
				AskLeaveItemHelper leaveItemHelper= new AskLeaveItemHelper();
				leaveItemHelper.process(mContext, response, false);
			}
		}
	};

}
