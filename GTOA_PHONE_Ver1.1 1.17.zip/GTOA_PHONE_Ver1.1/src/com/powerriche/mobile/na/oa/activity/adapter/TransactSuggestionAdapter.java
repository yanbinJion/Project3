package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.TransactSuggestion;
import com.powerriche.mobile.oa.tools.BeanUtils;

import java.util.ArrayList;
import java.util.List;
/**
 * @title  办理意见列表
 * @author dir_wang
 * @date   2016-7-5下午3:09:49
 */
public class TransactSuggestionAdapter extends BaseAdapter {

    private Context mContext = null;
    private LayoutInflater inflater;

    private List<TransactSuggestion> dataList = new ArrayList<TransactSuggestion>();

    public TransactSuggestionAdapter(Context context) {
        this.mContext = context;
        this.inflater = LayoutInflater.from(this.mContext);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        ViewHolder holder = null;

        if (view == null) {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.transact_suggestion_item, null);
            holder.tvName = (TextView) view.findViewById(R.id.tv_user_name);
            holder.tvDepartment = (TextView) view.findViewById(R.id.tv_department);
            holder.tvContent = (TextView) view.findViewById(R.id.tv_content);
            holder.tvDatetime = (TextView) view.findViewById(R.id.tv_datetime);
            holder.tvAction = (TextView) view.findViewById(R.id.tv_operateAction);
            view.setTag(holder);

        } else {
            holder = (ViewHolder) view.getTag();
        }

        TransactSuggestion  transactSuggestion = dataList.get(position);
        holder.tvDatetime.setText(transactSuggestion.getSaveDate());
        holder.tvContent.setText(BeanUtils.isEmptyStr(transactSuggestion.getData()));
        holder.tvDepartment.setText(transactSuggestion.getProcessorDeptName());
        holder.tvName.setText(BeanUtils.isEmptyStr(transactSuggestion.getProcessor()));
        holder.tvAction.setText(transactSuggestion.getActionName());
        return view;
    }


    /**
     * 添加数据
     */
    public void addData(List<TransactSuggestion> dataList){
        this.dataList.addAll(dataList);
    }


    public void clearListData(){
        if (dataList != null){
            dataList.clear();
        }
    }

    public void removeData(int position){
        dataList.remove(position);
    }

    private class ViewHolder{
        private TextView tvName;
        private TextView tvDepartment;
        private TextView tvDatetime;
        private TextView tvContent;
        private TextView tvAction;
    }
}

