package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.SuggestListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshSwipeMenuListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenu;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuCreator;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuItem;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView.OnMenuItemClickListener;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 常用意见：列表
 * 
 * @author 李运期
 * @date 2015年5月3日
 * @version v1.0
 */
public class SuggestListActivity extends BaseActivity implements OnClickListener {

	private Context							mContext;
	private SuggestListActivity				acitvity;
	private View							contextView;

	private PullToRefreshSwipeMenuListView	mPullView;
	private SwipeMenuListView				mListView;
	private TextView 						tvNoDataMsg;

	public int								pageIndex	= 1;

	private static int						OPT_TYPE	= Constants.WHAT_REQUEST_CYYJ;

	public Handler							indexHandler;
	/** 常用意见 */
	public SuggestListHelper				suggestListHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.suggest_list);

		acitvity = (SuggestListActivity) this;
		contextView = findViewById(R.id.layout_cyyj);

		bindView();

		suggestListHelper = new SuggestListHelper(acitvity, contextView, tvNoDataMsg);

		loadData();//加载列表数据
	}

	void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.menu_suggest));//顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.VISIBLE);//显示右边按钮
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标

		//mListView = (ListView) findViewById(R.id.listview_cyyj);

		// 设置中部的列表区
		mPullView = (PullToRefreshSwipeMenuListView) findViewById(R.id.pulllistview_cyyj);
		mPullView.setPullRefreshEnabled(false);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);

		mListView = mPullView.getRefreshableView();
		//mListView.setVerticalScrollBarEnabled(false);//设置滚动条隐藏
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(R.color.transparent);

		mPullView.setOnRefreshListener(new OnRefreshListener<SwipeMenuListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<SwipeMenuListView> refreshView) {
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<SwipeMenuListView> refreshView) {
			}
		});

		//向左侧滑菜单
		SwipeMenuCreator creator = new SwipeMenuCreator() {
			@Override
			public void create(SwipeMenu menu) {
				SwipeMenuItem deleteItem = new SwipeMenuItem(getApplicationContext());// create "delete" item
				deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));// set item background
				int width = UIHelper.dp2px(mContext, 70);// set item width
				deleteItem.setWidth(width);
				deleteItem.setIcon(R.drawable.ic_delete);// set a icon
				menu.addMenuItem(deleteItem);// add to menu
			}
		};
		mListView.setMenuCreator(creator);
		mListView.setOnMenuItemClickListener(new OnMenuItemClickListener() {
			@Override
			public void onMenuItemClick(int position, SwipeMenu menu, int index) {
				switch (index) {
					case 0://执行删除
						suggestListHelper.deleteData(OPT_TYPE, Constants.OPT_TYPE_CYYJ_DEL, position);
						break;
				}
			}
		});
		
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);
	}

	/**
	 * 加载数据：意见列表
	 */
	public void loadData() {
		//设置选中项
		OPT_TYPE = Constants.WHAT_REQUEST_CYYJ;

		// 请求加载数据
		pageIndex = 1;
		suggestListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_CYYJ, pageIndex);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back:// 返回
				finish();
				break;
			case R.id.btn_top_right:// 新建常用意见
				UIHelper.forwardTargetActivity(mContext, SuggestAddActivity.class, null, true);
				break;
		}
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	private IRequestCallBack	callBack	= new BaseRequestCallBack() {
												@Override
												public void process(HttpResponse response, int what) {
													if (what == Constants.WHAT_REQUEST_CYYJ) {// 常用意见：加载数据
														ResultItem item = response.getResultItem(ResultItem.class);
														if (checkResult(item)) {
															suggestListHelper.process(response, what);
														}
													}
												}
											};

}
