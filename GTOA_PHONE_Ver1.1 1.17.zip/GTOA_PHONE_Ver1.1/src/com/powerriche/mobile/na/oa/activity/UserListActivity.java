package com.powerriche.mobile.na.oa.activity;
		
import java.util.ArrayList;
import java.util.List;
		
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
		
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.SimpleTreeListViewAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.TreeListViewAdapter.OnTreeNodeClickListener;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.UserInfoHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.OrgBean;
import com.powerriche.mobile.na.oa.treeview.util.Node;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
		
/** 	
 * 类描述：<br> 
 * 组织成员个人信息
 * @author  Fitz
 * @date    2015年4月22日
 * @version v1.0
 */ 	
public class UserListActivity extends BaseActivity implements OnClickListener {
		
	private static final int GET_STAFF_TREE_REQ = 0;
	private Context mContext;
	private ListView listView;
	private SimpleTreeListViewAdapter<OrgBean> treeAdapter;
	private AutoCompleteTextView searchText;
	private List<OrgBean> beans;
	private ArrayAdapter<String> adapter;
	private List<String> datas = new ArrayList<String>();
	private List<String> staffNos = new ArrayList<String>();
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		UIHelper.hideTitle(this);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.user_list);
		
		initView();
		loading();
	}	
		
	private void initView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.user_title));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.VISIBLE);// 
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(R.drawable.ic_home);
		listView = (ListView) findViewById(R.id.listView);
		searchText = (AutoCompleteTextView) findViewById(R.id.actv_search);
		searchText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
		
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if (BeanUtils.isEmpty(datas) || BeanUtils.isEmpty(staffNos)) {
					return;
				}
				int index = datas.indexOf(searchText.getText().toString().trim());
				Intent intent = new Intent(UserListActivity.this,UserInfoActivity.class);
				intent.putExtra(UserInfoHelper.KEY_USER_STAFFNO, staffNos.get(index));
				startActivity(intent);
			}
		});
	}	
		
	private void loading(){
		getStaffTree();
	}	
		
		
	public InvokeHelper getInvokeHelper() {
		return helper;
	}	
		
	private void getStaffTree(){
        ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
        if (request != null){
            helper.invokeWidthDialog(request, callBack, GET_STAFF_TREE_REQ);
        }
    }	
		
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch(id){
		case R.id.system_back:
			finish();
			break;
		
		case R.id.btn_top_right:
			finish();
			break;
		}
	}	
		
	private void showStaffTree(List<ResultItem> item) {
		if(item == null) {
			return;
		}
		beans = new ArrayList<OrgBean>();
		for (ResultItem resultItem : item) {
			String dispOrder = resultItem.getString("DISP_ORDER");
//			String orderNo = resultItem.getString("ORDERNO");
			String realName = resultItem.getString("REAL_NAME");
//			String siteName = resultItem.getString("SITE_NAME");
			String siteNo = resultItem.getString("SITE_NO");
			String staffNo = resultItem.getString("STAFF_NO");
//			org.setOrderNo(orderNo);
//			org.setSiteName(siteName);
			OrgBean org = new OrgBean(staffNo, siteNo, realName);
			org.setDispOrder(dispOrder);
			beans.add(org);
		}
		
		if (!BeanUtils.isEmpty(beans)) {
			if (treeAdapter == null) {
				treeAdapter = new SimpleTreeListViewAdapter<OrgBean>(this, listView, beans, 0);
				listView.setAdapter(treeAdapter);
			} else {
				treeAdapter.notifyDataSetChanged();
			}
		}
		
		treeAdapter.setOnTreeNodeClickLitener(new OnTreeNodeClickListener() {
		
			@Override
			public void onClick(Node node, int position) {
				if (node.isLeaf()) {
					Intent intent = new Intent(UserListActivity.this,UserInfoActivity.class);
					intent.putExtra(UserInfoHelper.KEY_USER_STAFFNO, node.getId());
					startActivity(intent);
				}
			}
		});
		
		if (!BeanUtils.isEmpty(beans)) {
			for (int i = 0; i < beans.size(); i++) {
				if (beans.get(i).getDispOrder().equals("2.0")) {
					datas.add(beans.get(i).getLable());
					staffNos.add(beans.get(i).getId());
				}
			}
		}
		
		if (adapter == null) {
			adapter = new ArrayAdapter<String>(mContext, android.R.layout.simple_dropdown_item_1line, datas);
			searchText.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}
	}	
		
		
	private IRequestCallBack callBack = new BaseRequestCallBack() {	
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String code = item.getString("code");
				String message = item.getString("message");
				if (!Constants.SUCCESS_CODE.equals(code)) {
					UIHelper.showMessage(mContext, message);
					return;
				}
				if (what == GET_STAFF_TREE_REQ) {
					List<ResultItem> items = item.getItems("data");
					showStaffTree(items);
				}
			}
		}
	};	
		
}		
		