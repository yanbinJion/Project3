package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 公文附件
 * @author  Fitz
 * @date    2015年4月29日
 * @version v1.0
 */
public class DocManagerInfo {

	public DocManagerInfo(){}
	
	public DocManagerInfo(String name, String dep, String date, String suggest){
		this.name = name;
		this.department = dep;
		this.datatime = date;
		this.suggest = suggest;
	}
	
	String name;
	String department;
	String datatime;
	String suggest;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDatatime() {
		return datatime;
	}

	public void setDatatime(String datatime) {
		this.datatime = datatime;
	}

	public String getSuggest() {
		return suggest;
	}

	public void setSuggest(String suggest) {
		this.suggest = suggest;
	}
	
}
