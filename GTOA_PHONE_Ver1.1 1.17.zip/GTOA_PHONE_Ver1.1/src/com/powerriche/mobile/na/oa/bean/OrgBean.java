package com.powerriche.mobile.na.oa.bean;

import com.powerriche.mobile.na.oa.treeview.annotation.TreeNodeId;
import com.powerriche.mobile.na.oa.treeview.annotation.TreeNodeLabel;
import com.powerriche.mobile.na.oa.treeview.annotation.TreeNodePid;



/**
 * @ClassName: OrgBean
 * @Description: 
 * @author sloop
 * @date 2015年2月21日 上午2:45:13
 *
 */
public class OrgBean {

	/**
	 * 当前id
	 */
	@TreeNodeId
	private String id;
	/**
	 * 父节点id
	 */
	@TreeNodePid
	private String pId;
	/**
	 * 标记名称
	 */
	@TreeNodeLabel
	private String lable;
	
	
	private String siteNo;	//到达的环节可选人员的部门编号
	private String siteName;	//到达的环节可选人员的部门名称
	private String staffNo;	//到达的环节可选人员的人员编号
	private String realName;	//到达的环节可选人员的人员姓名
	private String siteOrderNo;
	private String orderNo;
	private String dispOrder;
	public OrgBean(String id, String pId, String lable) {
		this.id = id;
		this.pId = pId;
		this.lable = lable;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getpId() {
		return pId;
	}
	public void setpId(String pId) {
		this.pId = pId;
	}
	public String getLable() {
		return lable;
	}
	public void setLable(String lable) {
		this.lable = lable;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getStaffNo() {
		return staffNo;
	}
	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getSiteOrderNo() {
		return siteOrderNo;
	}
	public void setSiteOrderNo(String siteOrderNo) {
		this.siteOrderNo = siteOrderNo;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getDispOrder() {
		return dispOrder;
	}
	public void setDispOrder(String dispOrder) {
		this.dispOrder = dispOrder;
	}
	
	
	
}
