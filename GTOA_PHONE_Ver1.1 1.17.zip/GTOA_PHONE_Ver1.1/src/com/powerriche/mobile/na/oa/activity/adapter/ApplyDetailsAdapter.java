package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.GoodsApplyDetails;

import java.util.ArrayList;
import java.util.List;

/**
 * @title  申领明细列表
 * @author dir_wang
 * @date   2016-7-4下午8:36:29
 */
public class ApplyDetailsAdapter extends BaseAdapter{

    private Context mContext;
    private ArrayList<GoodsApplyDetails.ApplyDetails> data = new ArrayList<GoodsApplyDetails.ApplyDetails>();

    public ApplyDetailsAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
    	
        ViewHolder holder = null;
        if (null == view) {
            holder = new ViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.apply_details_item, null);
            holder.tv_goods = (TextView) view.findViewById(R.id.tv_goods);
            holder.tv_goods_name = (TextView) view.findViewById(R.id.tv_goods_name);
            holder.tv_goods_counts = (TextView) view.findViewById(R.id.tv_goods_counts);
            holder.tv_goods_remark = (TextView) view.findViewById(R.id.tv_goods_remark);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        GoodsApplyDetails.ApplyDetails applyDetails = data.get(position);
        holder.tv_goods.setText("物品" + (position + 1));
        holder.tv_goods_name.setText(applyDetails.getGoods());
        holder.tv_goods_counts.setText(applyDetails.getCounts());
        holder.tv_goods_remark.setText(applyDetails.getRemark());
        return view;
    }
    
    private class ViewHolder {
    	private TextView tv_goods;
    	private TextView tv_goods_name;
    	private TextView tv_goods_counts;
    	private TextView tv_goods_remark;
    }

    /**
     * 添加数据
     */
    public void addData(List<GoodsApplyDetails.ApplyDetails> dataList){
        if (null != dataList) {
            this.data.addAll(dataList);
        }
    }

    public void clearListData(){
        if (data != null){
            data.clear();
        }
    }
}
