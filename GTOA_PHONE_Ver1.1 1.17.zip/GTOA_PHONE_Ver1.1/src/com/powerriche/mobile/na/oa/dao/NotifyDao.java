package com.powerriche.mobile.na.oa.dao;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;

import com.powerriche.mobile.na.oa.bean.NotifyBean;

/**
 * 类描述：<br> 
 * 消息通知Dao
 * @author  Fitz
 * @date    2015年5月14日
 * @version v1.0
 */
public class NotifyDao extends BaseDAO{
	
	public static String createTableSQL(){
        return "CREATE TABLE T_NOTIFY ( ID VARCHAR(50) PRIMARY KEY, MSG_ID VARCHAR(50), MSG_STAFF VARCHAR(50), MSG_TYPE INTEGER, "
        		+ "MSG_TITLE VARCHAR(200), MSG_CONTENT VARCHAR(200), MSG_STATUS INTEGER, MSG_PARAM TEXT, MSG_READ INTEGER);";
	}
	
	public static String getDropSQL() {
		return "DROP TABLE IF EXISTS T_NOTIFY;";
	}
	
	public NotifyDao(Context context){
		super(context);
	}
	
	public void insert(String msgID, String staffNo, int msgType, String title, String content, int status, String param, int isRead){
		String sql = "INSERT INTO T_NOTIFY(MSG_ID, MSG_STAFF, MSG_TYPE, MSG_TITLE, MSG_CONTENT, MSG_STATUS, MSG_PARAM, MSG_READ) VALUES(?,?,?,?,?,?,?,?);";
		this.execSQL(sql, new Object[]{msgID, staffNo, msgType, title, content, status, param, isRead});
	}
	
	/**
	 * 更改消息状态
	 * @param status 0未通知，1已通知
	 * @param msgId
	 */
	public void updateStatus(int status, String msgId){
		String sql = "UPDATE T_NOTIFY SET MSG_STATUS = ? WHERE MSG_ID = ?;";
		this.execSQL(sql, new Object[]{status, msgId});
	}
	
	
	/**
	 * 更改消息状态
	 * @param isRead 0未读，1已读
	 * @param msgId
	 */
	public void updateRead(int isRead, String msgId){
		String sql = "UPDATE T_NOTIFY SET MSG_READ = ? WHERE MSG_ID = ?;";
		this.execSQL(sql, new Object[]{isRead, msgId});
	}
	
	
	/**
	 * 获得所有未通知的消息
	 * @param status
	 * @param staffNo
	 * @return
	 */
	public List<NotifyBean> getAllNotify(int status, String staffNo){
		List<NotifyBean> dataList = null;
		Cursor cursor = null;
		try {
			String sql = "SELECT * FROM T_NOTIFY WHERE MSG_STATUS = ? and MSG_STAFF = ?";
			cursor = this.rawQuery(sql.toString(), new String[]{String.valueOf(status), staffNo});
			if (cursor != null) {
				dataList = new ArrayList<NotifyBean>();
				while (cursor.moveToNext()) {
					dataList.add(cursorToBean(cursor));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
				}
				cursor = null;
			}
			this.close();
		}
		return dataList;
	}
	
	
	private NotifyBean cursorToBean(Cursor cursor){
		NotifyBean bean = new NotifyBean();
		bean.setMsgId(cursor.getString(cursor.getColumnIndex("MSG_ID")));
		bean.setStatus(cursor.getInt(cursor.getColumnIndex("MSG_STATUS")));
		bean.setType(cursor.getInt(cursor.getColumnIndex("MSG_TYPE")));
		bean.setRead(cursor.getInt(cursor.getColumnIndex("MSG_READ")));
		bean.setContent(cursor.getString(cursor.getColumnIndex("MSG_CONTENT")));
		bean.setTitle(cursor.getString(cursor.getColumnIndex("MSG_TITLE")));
		bean.setParam(cursor.getString(cursor.getColumnIndex("MSG_PARAM")));
		return bean;
	}
	
}
