package com.powerriche.mobile.na.oa.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.RecordListAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.RecordListHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

public class RecordActivity extends BaseActivity implements View.OnClickListener {
	private static final int ATTENDANCE_RECORD_LIST = 1234;
	private TopActivity topActivity;
	private PullToRefreshListView mPullView;
	private ListView listView;
	private View view;
	public int pageIndex = 1;
	private RecordListHelper listHelper;
	private String staffNo;
	private String beginTime, endTime;
	private RecordListAdapter adapter;
	int attendanceList = 0;
	int attendanceConfig = 1;
	/**  正常开始上班时间*/
	private String startWorkTime;
	/**  正常下班时间*/
	private String endWorkTime;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attendance_record_list);
		Intent intent = getIntent();
		if(intent != null) {
			staffNo = intent.getExtras().getString("staffNo");
			beginTime = intent.getExtras().getString("beginTime");
			endTime = intent.getExtras().getString("endTime");
		}
		initView();
		initData();
//		getAttendanceList(beginTime, endTime, staffNo, pageIndex);
	}
	
	
	private void getAttendanceList(String beginTime, String endTime, String staffNo, int index) {
		ApiRequest request = OAServicesHandler.getAttendanceList(beginTime, endTime, staffNo , index);
		helper.invokeWidthDialog(request, callBack, attendanceList);
	}
	
	private void setDataState(int index) {/*
		String signInTime = mListData.get(index).getMorningSignInTime();
		String signOutTime = mListData.get(index).getMorningSignOutTime();
		if (!BeanUtils.isNullOrEmpty(signInTime) && signInTime.contains(" ")) {
			signInTime = signInTime.split(" ")[1];
			boolean flag = signInTime.compareTo(startWorkTime) >= 0;
			mListData.get(index).setMorningSignInState(!flag ? "正常上班" : "迟到");
		} else {
			mListData.get(index).setMorningSignInState("未签到");
		}
		if(!BeanUtils.isNullOrEmpty(signOutTime) && signOutTime.contains(" ")) {
			signOutTime = signOutTime.split(" ")[1];
			boolean flag = signOutTime.compareTo(endWorkTime) >= 0;
			mListData.get(index).setMorningSignOutState(flag ? "正常下班" : "早退");
		} else {
			mListData.get(index).setMorningSignOutState("未签退");
		}
		
	*/}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			String code = resultItem.getString("code");
			String message = resultItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(RecordActivity.this, message);
				return;
			}
            if (ATTENDANCE_RECORD_LIST == what) {
            	listHelper.process(response, what);
            } 
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(RecordActivity.this, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};
	
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.attendance_my_record));// 顶部栏的中间标题
		view = findViewById(R.id.layout_attendance_record);
		listHelper = new RecordListHelper(RecordActivity.this, view);
		mPullView = (PullToRefreshListView) findViewById(R.id.lv_attendance_record);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);
		listView = mPullView.getRefreshableView();
		listView.setDivider(null);
		listView.setCacheColorHint(Color.TRANSPARENT);
		listView.setFadingEdgeLength(0);
		listView.setSelector(R.color.transparent);
	}
	
	private void initData() {
		
		mPullView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
				pageIndex = 1;
				listHelper.loadData(ATTENDANCE_RECORD_LIST, beginTime, endTime, staffNo, pageIndex, false);
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
				pageIndex = pageIndex + 1;
				listHelper.loadData(ATTENDANCE_RECORD_LIST, beginTime, endTime, staffNo, pageIndex, false);
			}
		});
		listHelper.loadData(ATTENDANCE_RECORD_LIST, beginTime, endTime, staffNo, pageIndex, false);
	}
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			RecordActivity.this.finish();
			break;
		default:
			break;
		}
	}
	
	public InvokeHelper getInvokeHelper() {
		return helper;
	}
	
	public IRequestCallBack getCallBack() {
		return callBack;
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		// 恢复界面时，加载最新的第一页数据
		pageIndex = 1;
		listHelper.loadData(ATTENDANCE_RECORD_LIST, beginTime, endTime, staffNo, pageIndex, false);
	}
	
}
