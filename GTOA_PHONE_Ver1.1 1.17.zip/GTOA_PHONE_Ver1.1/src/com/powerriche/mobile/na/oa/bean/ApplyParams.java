package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

public class ApplyParams implements Serializable {
	private static final long serialVersionUID = 7466010492433669475L;
	private String receiveId;
	private String purchaseId;
	private String leaveId;
	private String swfNo;
	private String wfNo;
	private String traceNo;
	private String staffNo;
	private String nextFpuNo;
	private String nextStaffNo;
	private String notes;
	private String isSendMessage;
	private String passState;

	public ApplyParams(String swfNo, String wfNo, String nextFpuNo) {
		this.swfNo = swfNo;
		this.wfNo = wfNo;
		this.nextFpuNo = nextFpuNo;
	}

	public String getReceiveId() {
		return receiveId;
	}

	public void setReceiveId(String receiveId) {
		this.receiveId = receiveId;
	}

	public String getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(String purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(String leaveId) {
		this.leaveId = leaveId;
	}

	public String getSwfNo() {
		return swfNo;
	}

	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}

	public String getWfNo() {
		return wfNo;
	}

	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}

	public String getTraceNo() {
		return traceNo;
	}

	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}

	public String getStaffNo() {
		return staffNo;
	}

	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}

	public String getNextFpuNo() {
		return nextFpuNo;
	}

	public void setNextFpuNo(String nextFpuNo) {
		this.nextFpuNo = nextFpuNo;
	}

	public String getNextStaffNo() {
		return nextStaffNo;
	}

	public void setNextStaffNo(String nextStaffNo) {
		this.nextStaffNo = nextStaffNo;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getIsSendMessage() {
		return isSendMessage;
	}

	public void setIsSendMessage(String isSendMessage) {
		this.isSendMessage = isSendMessage;
	}

	public String getPassState() {
		return passState;
	}

	public void setPassState(String passState) {
		this.passState = passState;
	}

}
