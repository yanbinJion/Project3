package com.powerriche.mobile.na.oa.activity;

import java.util.Date;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.LeaveDetail;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * @title  新建请假申请
 * @author dir_wang
 * @date   2016-7-12下午5:33:06
 */
public class LeaveAddActivity extends BaseActivity implements OnClickListener, OnCheckedChangeListener {
	
	private static final int REQUEST_LEAVE_ADD = 0;

	// 新增请假相关控件
	private EditText leaveReason, leaveStartTime, leaveEndTime;

	private RadioGroup leaveCatalogRg;

	private RadioButton leaveRb, paidRb;

	private TextView etUserName, applyDate, leaveType;

	private Context mContext;

	public String leaveId;
	private LeaveDetail detail;
	private float totalDays;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.askleave_item_add);
		detail = (LeaveDetail) getIntent().getSerializableExtra("detail");
		bindViews();
	}
	
	private void bindViews() {

		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.askleave_apply_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(getString(R.string.btn_submit_save));
		String datestr = DateUtils.getDateStr(new Date(), DateUtils.DATE_HOUR_FORMAT);
		etUserName = (TextView) findViewById(R.id.tv_text_applicant);
		etUserName.setText(SystemContext.getUserName()); // 登录人系统登录用户
		applyDate = (TextView) findViewById(R.id.tv_apply_date);
		applyDate.setText(datestr); // 当前系统时间
		leaveRb = (RadioButton) this.findViewById(R.id.radio_leave);
		paidRb = (RadioButton) this.findViewById(R.id.radio_paid);
		leaveRb.setChecked(true);
		leaveCatalogRg = (RadioGroup) findViewById(R.id.radioGroup);
		leaveCatalogRg.setTag(leaveRb.getTag().toString());
		leaveCatalogRg.setOnCheckedChangeListener(this);
		leaveType = (TextView) findViewById(R.id.tv_leave_type);
		leaveType.setTag("");
		leaveType.setOnClickListener(this);

		leaveReason = (EditText) findViewById(R.id.tv_leave_reason);

		leaveStartTime = (EditText) findViewById(R.id.tv_leave_starttime);
		leaveStartTime.setOnClickListener(this);
		leaveEndTime = (EditText) findViewById(R.id.tv_leave_endTime);
		leaveEndTime.setOnClickListener(this);
		String beginTime = DateUtils.getDateStr(DateUtils.getNextDay(DateUtils.getTime(8, 30), 1), DateUtils.DATE_HOUR_FORMAT);
        String endTime = DateUtils.getDateStr(DateUtils.getNextDay(DateUtils.getTime(17, 30), 1), DateUtils.DATE_HOUR_FORMAT);
        leaveStartTime.setText(beginTime);
        leaveEndTime.setText(endTime);
        Date beginDate = DateUtils.parseDate(leaveStartTime.getText().toString() + ":00", DateUtils.DATETIME_FORMAT);
     	Date endDate = DateUtils.parseDate(leaveEndTime.getText().toString() + ":00", DateUtils.DATETIME_FORMAT);
     	totalDays = DateUtils.getTotalDays(beginDate, endDate);
		leaveEndTime.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				Date beginDate = DateUtils.parseDate(leaveStartTime.getText().toString() + ":00", DateUtils.DATETIME_FORMAT);
		     	Date endDate = DateUtils.parseDate(leaveEndTime.getText().toString() + ":00", DateUtils.DATETIME_FORMAT);
		     	totalDays = DateUtils.getTotalDays(beginDate, endDate);
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
		if (detail != null) {
			bindModifyValue();
		}
	}
	
	/**
	 * 绑定修改数据
	 */
	public void bindModifyValue() {
		if (detail != null) {
			String leaveCatalog = detail.getLeaveCatalog();
			if (BeanUtils.floatToInt(leaveCatalog) == 0) {
				leaveRb.setChecked(true);
			} else {
				paidRb.setChecked(true);
			}
			leaveCatalogRg.setTag(leaveCatalog);
			String type = detail.getLeaveType();
			leaveType.setText(Constants.LEAVE_TYPE_MAP.get(BeanUtils.floatToInt(type)));
			leaveType.setTag(BeanUtils.floatToInt(type));
			
			// 请假原因
			String reason = detail.getLeaveReason();
			leaveReason.setText(reason);
			// 请假申请开始时间
			String beginTime = detail.getBeginTime();
			leaveStartTime.setText(beginTime);
			// 请假申请结束时间
			String endTime = detail.getEndTime();
			leaveEndTime.setText(endTime);
		}

	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {
			toAskLeaveList();
		} else if (id == R.id.btn_top_right) { // 提交
			submit();
			if(!checkInput()) {
				return;
			}
			saveLeave(leaveDetail);
		} else if (id == R.id.tv_leave_type) { // 选择请假选项
			// 0请假弹出类别
			if (BeanUtils.floatToInt(leaveCatalogRg.getTag() + "") == 0 ){
				UIHelper.showLeaveType(mContext, leaveType);
			} else {
				// 1调休弹出类别
				UIHelper.showLeavePaidType(mContext, leaveType);
			}
		} else if (id == R.id.tv_leave_starttime) {
			UIHelper.showTime(mContext, leaveStartTime, DateUtils.DATE_HOUR_FORMAT, 8, 30);
		} else if (id == R.id.tv_leave_endTime) {
			UIHelper.showTime(mContext, leaveEndTime, DateUtils.DATE_HOUR_FORMAT, 17, 30);
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup rg, int checkedId) {
		if (checkedId == leaveRb.getId()) {
			leaveCatalogRg.setTag(leaveRb.getTag().toString());
		} else if (checkedId == paidRb.getId()) {
			leaveCatalogRg.setTag(paidRb.getTag().toString());
		}
		//去除已经选择的请假类型
		leaveType.setText("");
		leaveType.setTag("");
	}

	/**
	 * 提交：验证通过才提交数据
	 */
	private LeaveDetail leaveDetail;
	public void submit() {
		if (leaveDetail == null) {
			leaveDetail = new LeaveDetail();
		}
		leaveDetail.setLeaveId(detail == null ? "0" : detail.getLeaveId());
		leaveDetail.setOperateType(detail == null ? Constants.LEAVE_OPERATETYPE_ADD : Constants.LEAVE_OPERATETYPE_MOD);
		leaveDetail.setLeaveCatalog(leaveCatalogRg.getTag().toString());
		if(leaveType.getTag() != null) {
			leaveDetail.setLeaveType(leaveType.getTag().toString());
		}
		leaveDetail.setLeaveReason(leaveReason.getText().toString());
		leaveDetail.setBeginTime(leaveStartTime.getText().toString());
		leaveDetail.setEndTime(leaveEndTime.getText().toString());
		leaveDetail.setLeaveTotalDays(String.valueOf(totalDays));
	}
	
	private void saveLeave(LeaveDetail leave) {
		ApiRequest request = OAServicesHandler.saveLeave(leave);
		helper.invokeWidthDialog(request, callBack, REQUEST_LEAVE_ADD);
	}

	/**
	 * 验证输入
	 * @return
	 */
	private boolean checkInput() {
		if(null == leaveDetail) {
    		return false;
    	} 
		
		if (BeanUtils.isNullOrEmpty(leaveDetail.getLeaveCatalog())) {
			return setReturnMsg(getString(R.string.askleave_catalog_isempty));
		}

		if (BeanUtils.isNullOrEmpty(leaveDetail.getLeaveType())) {
			return setReturnMsg(getString(R.string.askleave_type_isempty));
		}

		if (BeanUtils.isNullOrEmpty(leaveDetail.getLeaveReason())) {
			return setReturnMsg(getString(R.string.askleave_reason_isempty));
		}

		if (BeanUtils.isNullOrEmpty(leaveDetail.getBeginTime())) {
			return setReturnMsg(getString(R.string.askleave_starttime_isempty));
		}
		if (BeanUtils.isNullOrEmpty(leaveDetail.getEndTime())) {
			return setReturnMsg(getString(R.string.askleave_endtime_isempty));
		}
		// 检验时间范围
		Date beginDate = DateUtils.parseDate(leaveDetail.getBeginTime() + ":00", "yyyy-MM-dd HH:mm:ss");
		if (beginDate == null) {
			return setReturnMsg(getString(R.string.error_tip_askleave_begin_time));
		}
		Date endDate = DateUtils.parseDate(leaveDetail.getEndTime() + ":00", "yyyy-MM-dd HH:mm:ss");
		if (endDate == null) {
			return setReturnMsg(getString(R.string.error_tip_askleave_end_time));
		}
		if (endDate.before(beginDate)) {
			return setReturnMsg(getString(R.string.error_tip_between_askleave_time));
		}
		
		return true;
	}
	private boolean setReturnMsg(String msg){
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
        return false;
    }

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
            ResultItem item = response.getResultItem(ResultItem.class);
            if (checkResult(item)) {
                String code = item.getString("code");
                String message = item.getString("message");
                if (Constants.SUCCESS_CODE.equals(code)) {
                	if(what == REQUEST_LEAVE_ADD) { 
	                    UIHelper.showMessage(mContext, message);
	                    LeaveAddActivity.this.finish();
                	}
                } else {
                    UIHelper.showMessage(mContext, message);
                }
            }
        }

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			toAskLeaveList();
		}
		return super.onKeyDown(keyCode, event);
	}

	// 调转列表页面
	public void toAskLeaveList() {
		finish();
	}

}
