package com.powerriche.mobile.na.oa.down;


/**
 * 类描述：<br> 
 * 日志处理类
 * @author  Alex
 * @date    2013-12-2
 */
public class Log {
	
	public final static String LOGTAG = "GTOA";

	/**
	 * 调试模式
	 */
	public static final boolean DEBUG = true;
	
	/**
	 * 打印堆栈信息
	 */
	public static final boolean PRINT_STACK_TRACE = true;

	/**
	 * 方法说明：<br>
	 * info级别
	 * @param msg
	 */
	public static void v(String msg) {
		if (msg != null)
			android.util.Log.v(LOGTAG, msg);
	}
	
	public static void w(String msg) {
		if (DEBUG) {
			try {

				android.util.Log.w(LOGTAG, msg);
			} catch (Exception e) {
			}
		}
	}

	public static void w(String tag, String msg, Throwable tr) {
		if (DEBUG) {
			try {
				android.util.Log.w(LOGTAG, msg, tr);
			} catch (Exception e) {
			}
		}
	}

	/**
	 * 方法说明：<br>
	 * error级别
	 * @param msg
	 */
	public static void e(String msg) { 
		if (DEBUG&&msg != null)
			android.util.Log.e(LOGTAG, msg);
	}
	
	/**
	 * 方法说明：<br>
	 * error级别
	 * @param msg
	 */
	public static void e(String msg,Exception e) { 
		if (DEBUG&&msg != null)
			android.util.Log.e(LOGTAG, msg);
		
		if (e == null) {
			android.util.Log.e(LOGTAG,"Exception Object is null!");
		} else {
			if (PRINT_STACK_TRACE)
				e.printStackTrace();
		}
	}

	/**
	 * 方法说明：<br>
	 * error级别
	 * @param c 类
	 * @param e 异常
	 */
	@SuppressWarnings("unused")
	public static void e(@SuppressWarnings("rawtypes") Class c, Exception e) {
		if (!DEBUG && c == null && e == null)
			return;

		if (e == null) {
			android.util.Log.e(LOGTAG + c.getName(),"Exception Object is null!");
		} else {
			if (PRINT_STACK_TRACE)
				e.printStackTrace();
		}
	}

	/**
	 * 方法说明：<br>
	 * error级别
	 * @param c 异常类
	 * @param msg 异常信息
	 */
	@SuppressWarnings("rawtypes")
	public static void e(Class c, String msg) {
		if (c == null && msg == null)
			return;

		if (DEBUG && msg == null)
			android.util.Log.e(LOGTAG + c.getName(), "msg Object is null!");
		else
			android.util.Log.e(LOGTAG + c.getName(), msg);
	}

	/**
	 * 方法说明：<br>
	 * debug级别
	 * @param msg 输出信息
	 */
	public static void d(String msg) {
		if (DEBUG && msg != null)
			android.util.Log.d(LOGTAG, msg);
	}
}
