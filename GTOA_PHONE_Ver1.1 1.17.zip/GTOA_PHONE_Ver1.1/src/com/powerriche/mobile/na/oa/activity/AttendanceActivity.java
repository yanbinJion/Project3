package com.powerriche.mobile.na.oa.activity;
		
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.PreferenceUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
		
public class AttendanceActivity extends BaseActivity implements
		View.OnClickListener {
	private TopActivity topActivity;
	private TextView tv_sign_in_time, tv_sign_in_working, tv_sign_in_location,
			tv_sign_out_time, tv_sign_out_working, tv_sign_out_location;
	private TextView tv_afternoon_sign_in_time;
	private TextView tv_afternoon_sign_in_location;
	private TextView tv_afternoon_sign_in_working;
	private TextView tv_afternoon_sign_out_time;
	private TextView tv_afternoon_sign_out_location;
	private TextView tv_afternoon_sign_out_working;
	private ImageView iv_sign_in, iv_sign_out;
	private Button btn_attendance_count;
	private TextView tv_morning_sign, tv_afternoon_sign;
		
	private LinearLayout ll_morning;
	private LinearLayout ll_afternoon;
	private String current_time;
	private String morning_sign_in_time;
	private String morning_sign_out_time;
	private String afternoon_sign_in_time;
	private String afternoon_sign_out_time;
		
	int currentAttendance = 0;
	int attendanceConfig = 1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attendance_record);
		initView();
		initData();
	}	
		
	@Override
	protected void onResume() {
		super.onResume();
		getCurrentAttendance();
		getAttendanceConfig();
	}	
		
	// 初始化控件
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnStyle(getString(R.string.remind));
		topActivity.setRightBtnOnClickListener(this);
		tv_sign_in_time = (TextView) findViewById(R.id.tv_sign_in_time);
		tv_sign_in_working = (TextView) findViewById(R.id.tv_sign_in_working);
		tv_sign_in_location = (TextView) findViewById(R.id.tv_sign_in_location);
		tv_sign_out_time = (TextView) findViewById(R.id.tv_sign_out_time);
		tv_sign_out_working = (TextView) findViewById(R.id.tv_sign_out_working);
		tv_sign_out_location = (TextView) findViewById(R.id.tv_sign_out_location);
		tv_afternoon_sign_in_time = (TextView) findViewById(R.id.tv_afternoon_sign_in_time);
		tv_afternoon_sign_in_working = (TextView) findViewById(R.id.tv_afternoon_sign_in_working);
		tv_afternoon_sign_in_location = (TextView) findViewById(R.id.tv_afternoon_sign_in_location);
		tv_afternoon_sign_out_time = (TextView) findViewById(R.id.tv_afternoon_sign_out_time);
		tv_afternoon_sign_out_working = (TextView) findViewById(R.id.tv_afternoon_sign_out_working);
		tv_afternoon_sign_out_location = (TextView) findViewById(R.id.tv_afternoon_sign_out_location);
		ll_morning = (LinearLayout) findViewById(R.id.ll_morning);
		ll_afternoon = (LinearLayout) findViewById(R.id.ll_afternoon);
		iv_sign_in = (ImageView) findViewById(R.id.iv_sign_in);
		iv_sign_out = (ImageView) findViewById(R.id.iv_sign_out);
		btn_attendance_count = (Button) findViewById(R.id.btn_attendance_count);
		tv_morning_sign = (TextView) findViewById(R.id.tv_morning_sign);
		tv_afternoon_sign = (TextView) findViewById(R.id.tv_afternoon_sign);
		tv_morning_sign.setTextColor(getResources().getColor(R.color.common_top_titlebar_bgcolor));
		tv_afternoon_sign.setTextColor(getResources().getColor(R.color.text_color_2e2e2e));
		tv_morning_sign.setSelected(true);
		tv_morning_sign.setOnClickListener(new MyOnClickListener());
		tv_afternoon_sign.setOnClickListener(new MyOnClickListener());
	}	
		
	private class MyOnClickListener implements View.OnClickListener {
		
		@Override
		public void onClick(View v) {
			int id = v.getId();
			switch (id) {
			case R.id.tv_morning_sign:
				ll_morning.setVisibility(View.VISIBLE);
				ll_afternoon.setVisibility(View.GONE);
				tv_morning_sign.setSelected(true);
				tv_afternoon_sign.setSelected(false);
				tv_morning_sign.setTextColor(getResources().getColor(R.color.common_top_titlebar_bgcolor));
				tv_afternoon_sign.setTextColor(getResources().getColor(R.color.text_color_2e2e2e));
				break;
			case R.id.tv_afternoon_sign:
				ll_morning.setVisibility(View.GONE);
				ll_afternoon.setVisibility(View.VISIBLE);
				tv_morning_sign.setSelected(false);
				tv_afternoon_sign.setSelected(true);
				tv_morning_sign.setTextColor(getResources().getColor(R.color.text_color_2e2e2e));
				tv_afternoon_sign.setTextColor(getResources().getColor(R.color.common_top_titlebar_bgcolor));
			default:
				break;
			}
		}
		
	}
	
	// 设置数据
	private void initData() {
		iv_sign_in.setOnClickListener(this);
		iv_sign_out.setOnClickListener(this);
		btn_attendance_count.setOnClickListener(this);
	}
	
	// 显示当前考勤配置信息
	private void showAttendanceConfig(ResultItem result) {
		if (result == null) {
			return;
		}
		// 	上午签到时间
		String amStartWorkTime = result.getString("AM_IN_WORKING_TIME");
		// 上午签退时间
		String amEndWorkTime = result.getString("AM_OFF_WORKING_TIME");
		// 下午签到时间
		String pmStartWorkTime = result.getString("PM_IN_WORKING_TIME");
		// 下午签退时间
		String pmEndWorkTime = result.getString("PM_OFF_WORKING_TIME");
		PreferenceUtils.putStringValue(PreferenceUtils.AM_START_WORK_TIME,amStartWorkTime);
		PreferenceUtils.putStringValue(PreferenceUtils.AM_END_WORK_TIME,amEndWorkTime);
		PreferenceUtils.putStringValue(PreferenceUtils.PM_START_WORK_TIME,pmStartWorkTime);
		PreferenceUtils.putStringValue(PreferenceUtils.PM_END_WORK_TIME,pmEndWorkTime);
	}
	
	private void getCurrentAttendance() {
		ApiRequest request = OAServicesHandler.getCurrentAttendance();
		helper.invoke(request, callBack, currentAttendance);
	}

	private void getAttendanceConfig() {
		ApiRequest request = OAServicesHandler.getAttendanceConfig();
		helper.invoke(request, callBack, attendanceConfig);
	}

	// 显示当前考勤信息
	private void showCurrentAttendance(ResultItem result) {
		
		if (result == null) {
			return;
		}
		current_time = result.getString("CURRENT_TIME");
		System.out.println(" current_time "+current_time);
		String type = getSignType();
		if (type.equals("0")) {
			topActivity.setTopTitle(getString(R.string.attendance_morning));// 顶部栏的中间标题
		} else {
			topActivity.setTopTitle(getString(R.string.attendance_afternoon));// 顶部栏的中间标题
		}
		setMorningData(result);
		setAfternoonData(result);
	}
	
	// 上午签到签退
	private void setMorningData(ResultItem result) {
		String morning_sign_in = result.getString("MORNING_SIGN_IN");
		morning_sign_in_time = result.getString("MORNING_SIGN_IN_TIME");
		String morning_sign_in_address = result.getString("MORNING_SIGN_IN_ADDRESS");
		String morning_sign_out = result.getString("MORNING_SIGN_OUT");
		morning_sign_out_time = result.getString("MORNING_SIGN_OUT_TIME");
		String morning_sign_out_address = result.getString("MORNING_SIGN_OUT_ADDRESS");
		if (morning_sign_in.equals("0")) {
			if (getSignType().equals("0")) {
				iv_sign_in.setImageResource(R.drawable.sign_in_normal);
				iv_sign_in.setEnabled(true);
			}
			
		} else {
			iv_sign_in.setImageResource(R.drawable.already_sign_in);
			iv_sign_in.setEnabled(false);
			tv_sign_in_time.setText(DateUtils.getDateStr(morning_sign_in_time, DateUtils.HOUR_MINUTE_FORMAT));
			tv_sign_in_location.setText(morning_sign_in_address);
		}
		
		if (morning_sign_out.equals("0")) {
			if (getSignType().equals("0")) {
				iv_sign_out.setImageResource(R.drawable.sign_out_normal);
				iv_sign_out.setEnabled(true);
			}
		} else {
			iv_sign_out.setImageResource(R.drawable.already_sign_out);
			iv_sign_out.setEnabled(false);
			tv_sign_out_time.setText(DateUtils.getDateStr(morning_sign_out_time, DateUtils.HOUR_MINUTE_FORMAT));
			tv_sign_out_location.setText(morning_sign_out_address);
		}
		showMorningWorkTime();
	}
	
	// 下午签到签退
	private void setAfternoonData(ResultItem result) {
		String afternoon_sign_in = result.getString("AFTERNOON_SIGN_IN");
		afternoon_sign_in_time = result.getString("AFTERNOON_SIGN_IN_TIME");
		String afternoon_sign_in_address = result.getString("AFTERNOON_SIGN_IN_ADDRESS");
		String afternoon_sign_out = result.getString("AFTERNOON_SIGN_OUT");
		afternoon_sign_out_time = result.getString("AFTERNOON_SIGN_OUT_TIME");
		String afternoon_sign_out_address = result.getString("AFTERNOON_SIGN_OUT_ADDRESS");
		if (afternoon_sign_in.equals("0")) {
			if (getSignType().equals("1")) {
				iv_sign_in.setImageResource(R.drawable.sign_in_normal);
				iv_sign_in.setEnabled(true);
			}
		} else {
			iv_sign_in.setImageResource(R.drawable.already_sign_in);
			iv_sign_in.setEnabled(false);
			tv_afternoon_sign_in_time.setText(DateUtils.getDateStr(afternoon_sign_in_time, DateUtils.HOUR_MINUTE_FORMAT));
			tv_afternoon_sign_in_location.setText(afternoon_sign_in_address);
//			tv_sign_in_time.setText(DateUtils.getDateStr(afternoon_sign_in_time, DateUtils.HOUR_MINUTE_FORMAT));
//			tv_sign_in_location.setText(afternoon_sign_in_address);
		}
		if (afternoon_sign_out.equals("0")) {
			if (getSignType().equals("1")) {
				iv_sign_out.setImageResource(R.drawable.sign_out_normal);
				iv_sign_out.setEnabled(true);
			}
		} else {
			iv_sign_out.setImageResource(R.drawable.already_sign_out);
			iv_sign_out.setEnabled(false);
			tv_afternoon_sign_out_time.setText(DateUtils.getDateStr(afternoon_sign_out_time, DateUtils.HOUR_MINUTE_FORMAT));
			tv_afternoon_sign_out_location.setText(afternoon_sign_out_address);
//			tv_sign_out_time.setText(DateUtils.getDateStr(afternoon_sign_out_time, DateUtils.HOUR_MINUTE_FORMAT));
//			tv_sign_out_location.setText(afternoon_sign_out_address);
		}
		showAfternoonWorkTime();
	}
	
	// 上午考勤状态
	private void showMorningWorkTime() {
		int color1 = getResources().getColor(R.color.text_color_bdb76b);
		int color2 = getResources().getColor(R.color.text_color_ff2525);
		if (!BeanUtils.isNullOrEmpty(morning_sign_in_time)
				&& morning_sign_in_time.contains(" ")) {
			morning_sign_in_time = morning_sign_in_time.split(" ")[1];
			boolean flag = morning_sign_in_time.compareTo(PreferenceUtils.getStringValue(PreferenceUtils.AM_START_WORK_TIME)) >= 0;
			tv_sign_in_working.setText(!flag ? "正常上班" : "迟到");
			tv_sign_in_working.setTextColor(!flag ? color1 : color2);
		} else {
			tv_sign_in_working.setText("未签到");
		}
		if (!BeanUtils.isNullOrEmpty(morning_sign_out_time)
				&& morning_sign_out_time.contains(" ")) {
			morning_sign_out_time = morning_sign_out_time.split(" ")[1];
			boolean flag = morning_sign_out_time.compareTo(PreferenceUtils.getStringValue(PreferenceUtils.AM_END_WORK_TIME)) >= 0;
			tv_sign_out_working.setText(flag ? "正常下班" : "早退");
			tv_sign_out_working.setTextColor(flag ? color1 : color2);
		} else {
			tv_sign_out_working.setText("未签退");
		}
	}
	// 下午考勤状态
	private void showAfternoonWorkTime() {
		int color1 = getResources().getColor(R.color.text_color_bdb76b);
		int color2 = getResources().getColor(R.color.text_color_ff2525);
		if (!BeanUtils.isNullOrEmpty(afternoon_sign_in_time)
				&& afternoon_sign_in_time.contains(" ")) {
			afternoon_sign_in_time = afternoon_sign_in_time.split(" ")[1];
			boolean flag = afternoon_sign_in_time.compareTo(PreferenceUtils.getStringValue(PreferenceUtils.PM_START_WORK_TIME)) >= 0;
			tv_afternoon_sign_in_working.setText(!flag ? "正常上班" : "迟到");
			tv_afternoon_sign_in_working.setTextColor(!flag ? color1 : color2);
//			tv_sign_in_working.setText(!flag ? "正常上班" : "迟到");
//			tv_sign_in_working.setTextColor(!flag ? color1 : color2);
		} else {
			tv_afternoon_sign_in_working.setText("未签到");
		}	
		if (!BeanUtils.isNullOrEmpty(afternoon_sign_out_time)
				&& afternoon_sign_out_time.contains(" ")) {
			afternoon_sign_out_time = afternoon_sign_out_time.split(" ")[1];
			boolean flag = afternoon_sign_out_time.compareTo(PreferenceUtils.getStringValue(PreferenceUtils.PM_END_WORK_TIME)) >= 0;
			tv_afternoon_sign_out_working.setText(flag ? "正常下班" : "早退");
			tv_afternoon_sign_out_working.setTextColor(flag ? color1 : color2);
//			tv_sign_out_working.setText(flag ? "正常下班" : "早退");
//			tv_sign_out_working.setTextColor(flag ? color1 : color2);
		} else {
			tv_afternoon_sign_out_working.setText("未签退");
		}	
	}		
	private IRequestCallBack callBack = new BaseRequestCallBack() {
			
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			String code = resultItem.getString("code");
			String message = resultItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(AttendanceActivity.this, message);
				return;
			}
			ResultItem result = (ResultItem) resultItem.get("data");
			if (what == currentAttendance) {
				showCurrentAttendance(result);
				return;
			} else if (what == attendanceConfig) {
				showAttendanceConfig(result);
				
			} 
		}	
			
		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(AttendanceActivity.this, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};
	
	/**
	 * 获取是上午还是下午
	 */
	private String getSignType() {
		String signType = "";
		if (!BeanUtils.isNullOrEmpty(current_time) && current_time.contains(" ")) {
			String time = "12:00";
//			String amEndTime = PreferenceUtils.getStringValue(PreferenceUtils.AM_END_WORK_TIME);
			String currentTime = DateUtils.getDateStr(current_time, DateUtils.HOUR_MINUTE_FORMAT);
			boolean flag = currentTime.compareTo(time) >= 0;
			signType = !flag ? "0" : "1";
		}
		return signType;
	}
	
	@Override
	public void onClick(View v) {
		String type = getSignType();
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			AttendanceActivity.this.finish();
			break;
		case R.id.btn_top_right:
			Intent remind_intent = new Intent(AttendanceActivity.this,
					RemindActivity.class);
			startActivity(remind_intent);
			break;
		case R.id.iv_sign_in:
			signInOrOutDialog("是否确定签到", "1", type);
			break;
		case R.id.iv_sign_out:
			signInOrOutDialog("是否确定签退", "-1", type);
			break;
		case R.id.btn_attendance_count:
			Intent intent = new Intent(AttendanceActivity.this,
					AttendanceCountActivity.class);
			startActivity(intent);
			
			break;
		default:
			break;
		}
	}	
		
	private void signInOrOutDialog(String signInOrOut, final String signState, final String signType) {
		final SystemDialog chooseDialog = new SystemDialog(
				AttendanceActivity.this);
		chooseDialog.setMessage(signInOrOut);
		chooseDialog.setOnConfirmClickListener(new View.OnClickListener() { // 确定按钮事件
					@Override
					public void onClick(View view) {
						Intent intent = new Intent(
								AttendanceActivity.this, MapActivity.class);
						intent.putExtra("sign_state", signState);
						intent.putExtra("sign_type", signType);
						startActivity(intent);
					}
				});
		chooseDialog.setOnCancelClickListener(new View.OnClickListener() { // 取消
					@Override
					public void onClick(View v) {
						if (chooseDialog != null) {
							chooseDialog.dismiss();
						}
					}
				});
		chooseDialog.show();
	}	
		
}		
