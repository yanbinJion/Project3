package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.TransactorActivity;
import com.powerriche.mobile.na.oa.activity.adapter.TranscatorAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.ApplyParams;
import com.powerriche.mobile.na.oa.bean.DepartmentInfo;
import com.powerriche.mobile.na.oa.bean.FpuInfo;
import com.powerriche.mobile.na.oa.bean.StaffsInfo;
import com.powerriche.mobile.na.oa.view.widget.ArrayWheelAdapter;
import com.powerriche.mobile.na.oa.view.widget.OnWheelChangedListener;
import com.powerriche.mobile.na.oa.view.widget.WheelView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

import android.content.Context;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TransactorHelper {
	private Context context;
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;
	private ExpandableListView exListView;
	private TranscatorAdapter adapter;
	private LinearLayout llTypeWrap;
	private WheelView wheelView;
	private TextView tvPeople;

	private List<DepartmentInfo> groupList; // 分组信息
	private List<List<StaffsInfo>> userList;// 员工信息
	private Map<String, DepartmentInfo> mapGroup;
	private List<FpuInfo> fpuList; // 办理环节列表
	private String nextFpuNo;
	public TransactorHelper(Context context, IRequestCallBack callBack,
			ExpandableListView exListView, LinearLayout llTypeWrap,
			TextView tvPeople, WheelView wheelView) {
		this.context = context;
		this.callBack = callBack;
		this.exListView = exListView;
		this.llTypeWrap = llTypeWrap;
		this.tvPeople = tvPeople;
		this.wheelView = wheelView;
		this.wheelView.setDrawableBg(R.drawable.wheel_child_bg);
		this.wheelView.setDrawableVal(R.drawable.wheel_child_val);
		this.wheelView.setADDITIONAL_ITEM_HEIGHT(0);
		this.wheelView.setTEXT_SIZE(16);//自动根据屏幕密度调整字体的大小
		this.wheelView.setDrawShadows(false);
		this.wheelView.setSHADOWS_COLORS(new int[] { android.R.color.transparent, 
				android.R.color.transparent, android.R.color.transparent});
		this.wheelView.setITEMS_TEXT_COLOR(0xFFCCCCCC);
		
		this.wheelView.addChangingListener(new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				FpuInfo bean = fpuList.get(newValue);
				chooseType(bean.getToFpuNo(), bean.getPosition());
				select(bean.getPosition());
				nextFpuNo = bean.getToFpuNo();
			}
		});
		
		this.fpuList = new ArrayList<FpuInfo>();
		this.groupList = new ArrayList<DepartmentInfo>();
		this.userList = new ArrayList<List<StaffsInfo>>();
		this.mapGroup = new HashMap<String, DepartmentInfo>();
		this.helper = ((TransactorActivity) context).getInvokeHelper();
	}
	
	private void setWheelViewType() {
		String types[] = new String[fpuList.size()];
		for(int i=0; i<fpuList.size(); i++){
			FpuInfo fpt = fpuList.get(i);
			types[i] = fpt.getToActionName();
		}
		this.wheelView.setAdapter(new ArrayWheelAdapter<String>(types));
		this.wheelView.setVisibleItems(3);
		this.wheelView.setCurrentItem(0);
		
		select(0);
		String toFpuNo = fpuList.get(0).getToFpuNo();
		chooseType(toFpuNo, 0);	//默认第一个选中
		nextFpuNo = toFpuNo;
	}

	private void setTypeView() {
		for (int i = 0; i < fpuList.size(); i++) {
			FpuInfo fpt = fpuList.get(i);
			fpt.setPosition(i);

			TextView tv = new TextView(context);
			tv.setLayoutParams(new LinearLayout.LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1.0f));
			tv.setTextColor(context.getResources().getColor(R.color.black));
			tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
			tv.setGravity(Gravity.CENTER);
			tv.setPadding(15, 15, 15, 15);
			tv.setTag(fpt);
			tv.setText(fpt.getToActionName());
			tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					FpuInfo tag = (FpuInfo) v.getTag();
					chooseType(tag.getToFpuNo(), tag.getPosition());
					select(tag.getPosition());
					nextFpuNo = tag.getToFpuNo();
				}
			});

			llTypeWrap.addView(tv);
		}
		select(0);
		String toFpuNo = fpuList.get(0).getToFpuNo();
		chooseType(toFpuNo, 0); // 默认第一个选中
		nextFpuNo = toFpuNo;
	}

	public void chooseType(String toFpuNo, int indexPosition) {
		List<List<StaffsInfo>> userShowList = new ArrayList<List<StaffsInfo>>();
		// userShowList.addAll(userList); //此方法不起作用
		for (int i = 0; i < userList.size(); i++) {
			List<StaffsInfo> tempList = userList.get(i);
			List<StaffsInfo> showList = new ArrayList<StaffsInfo>();
			for (int j = 0; j < tempList.size(); j++) {
				StaffsInfo bean = tempList.get(j);
				showList.add(bean);
			}
			userShowList.add(showList);
		}

		int groupSize = userList.size();
		for (int i = 0; i < groupSize; i++) {

			List<StaffsInfo> list = userList.get(i);
			int size = list.size();
			for (int j = size - 1; j >= 0; j--) {
				
				StaffsInfo bean = list.get(j);
				if (!bean.getFpuNo().equals(toFpuNo)) {
					userShowList.get(i).remove(j);
				}

			}
		}
		
		Log.i("TEST", " userShowList "+userShowList.toString());
		
		adapter.clear();
		adapter.addData(groupList, userShowList);
		adapter.setIndexPosition(indexPosition);
		adapter.notifyDataSetChanged();
	}

	public List<FpuInfo> getFpList() {
		return fpuList;
	}

	public void selectAll(boolean isSelectAll) {
		List<List<StaffsInfo>> typeList = adapter.getTypeList();
		StringBuffer sb = new StringBuffer();
		if (isSelectAll) { // 全选
			for (int i = 0; i < typeList.size(); i++) {
				List<StaffsInfo> valueList = typeList.get(i); // 获取到需要设置选中的list
				int length = valueList.size();
				for (int j = 0; j < length; j++) {
					typeList.get(i).get(j).setStatus(1);
					sb.append(typeList.get(i).get(j).getRealName()).append("、");
				}
				adapter.setValueList(valueList); // 把选中的list添加到全选值中
			}

		} else { // 取消全选
			sb = new StringBuffer("");
			for (int i = 0; i < typeList.size(); i++) {
				int length = typeList.get(i).size();
				for (int j = 0; j < length; j++) {
					typeList.get(i).get(j).setStatus(0);
				}
			}
			adapter.clearValueList(); // 清空之前全选的值
		}
		adapter.notifyDataSetChanged();
		adapter.setTextStyle(this.tvPeople, sb.toString());
	}

	/**
	 * 设置标签选中背景颜色
	 * 
	 * @param index
	 */
	private void select(int index) {
		int childViewCount = llTypeWrap.getChildCount();
		for (int i = 0; i < childViewCount; i++) {
			TextView tv = (TextView) llTypeWrap.getChildAt(i);
			if (index == i) {
				tv.setTextColor(context.getResources().getColor(R.color.white));
				tv.setBackgroundColor(context.getResources().getColor(
						R.color.common_top_titlebar_bgcolor));
			} else {
				tv.setTextColor(context.getResources().getColor(R.color.black));
				tv.setBackgroundColor(context.getResources().getColor(
						R.color.white));
			}
		}
	}

	/**
	 * 加载数据
	 * 
	 * @param swfNo
	 * @param fpuNo
	 */
	public void loadData(String swfNo, String fpuNo) {
		ApiRequest request = OAServicesHandler.getNextFpuAndStaffList(swfNo,
				fpuNo);
		if (request != null) {
			helper.invokeWidthDialog(request, callBack);
		}
	}

	/**
	 * 接口返回操作数据
	 * 
	 * @param response
	 * @param what
	 */
	public void process(ResultItem resultItem) {
		if (opData(resultItem)) {
			adapter = new TranscatorAdapter(context, tvPeople);
			exListView.setAdapter(adapter);
			setTypeView();
			setWheelViewType();
		} else {
			// 数据解析出错了
			UIHelper.showMessage(context, "数据解析错误");
		}	
	}		
			
	private boolean opData(ResultItem resultItem) {
		List<ResultItem> items = resultItem.getItems("data");
			
		if (!BeanUtils.isEmpty(items)) {
			
			List<StaffsInfo> staffsList = new ArrayList<StaffsInfo>();
			this.fpuList = getFpuList(items, staffsList);
			
			// 处理分组数据
			Set<String> set = mapGroup.keySet();
			for (String siteNo : set) {
				DepartmentInfo beanGroup = mapGroup.get(siteNo);
				groupList.add(beanGroup);
			}
			
			// 把子项添加到组中，按索引
			for (DepartmentInfo group : groupList) {
				List<StaffsInfo> tempList = new ArrayList<StaffsInfo>();
				for (StaffsInfo user : staffsList) {
					if (group.getSiteNo().equals(user.getSiteNo())) {
						if (!tempList.contains(user)) {
							tempList.add(user);
						}
					}
				}
				
				userList.add(tempList);
			}
			Log.i("TEST", " userList "+userList.toString());
		}	
		return true;
	}		
			
	/** 解析数据，得到办理环节的列表信息 */
	private List<FpuInfo> getFpuList(List<ResultItem> items,
			List<StaffsInfo> staffsList) {
		List<FpuInfo> fpuList = new ArrayList<FpuInfo>();
		Log.i("TEST", " fpuList "+fpuList.toString()+" items "+items.size());
		int len = items.size();
		for (int i = 0; i < len; i++) {
			FpuInfo bean = new FpuInfo();
			
			ResultItem item = items.get(i);
			String swfNo = item.getString("SWF_NO");
			String toFpuNo = item.getString("TO_FPU_NO");
			String toActionNo = item.getString("TO_ACTION_NO");
			String toActionName = item.getString("TO_ACTION_NAME");
			
			bean.setSwfNo(swfNo);
			bean.setToActionName(toActionName);
			bean.setToFpuNo(toFpuNo);
			bean.setToActionNo(toActionNo);
			
			fpuList.add(bean);
			
			List<ResultItem> toStaffsItems = item.getItems("ToStaffs");
			if (!BeanUtils.isEmpty(toStaffsItems)) {
				staffsList.addAll(getStaffs(toStaffsItems)); // 把所有人加入到这个集合中
			}
			
		}	
		return fpuList;
	}		
			
	private List<StaffsInfo> getStaffs(List<ResultItem> items) {
		if (items == null) {
			return null;
		}	
		List<StaffsInfo> staffs = new ArrayList<StaffsInfo>();

		int len = items.size();
		for (int i = 0; i < len; i++) {
			StaffsInfo bean = new StaffsInfo();

			ResultItem item = items.get(i);
			String fpuNo = item.getString("FPU_NO"); // 办理环节编号
			String staffNo = item.getString("STAFF_NO");
			String siteName = item.getString("SITE_NAME");
			String siteNo = item.getString("SITE_NO");
			String realName = item.getString("REAL_NAME");
			String siteOrderNo = item.getString("SITE_ORDER_NO");
			String orderNo = item.getString("ORDER_NO");

			DepartmentInfo group = new DepartmentInfo(siteNo, siteName);
			if (!mapGroup.containsKey(siteNo)) {
				mapGroup.put(siteNo, group);
			}

			bean.setFpuNo(fpuNo);
			bean.setSiteNo(siteNo);
			bean.setSiteName(siteName);
			bean.setStaffNo(staffNo);
			bean.setRealName(realName);
			bean.setOrderNo(orderNo);
			bean.setSiteOrderNo(siteOrderNo);
			staffs.add(bean);
		}
		return staffs;
	}

	/**
	 * 物品申领送出
	 */
	public void sendReceiveGoods(ApplyParams apply) {
        if (null == apply) {
            return ;
        }
        ApiRequest request = OAServicesHandler.sendNextReceiveGoods(apply.getReceiveId(), apply.getNextFpuNo(), apply.getNextStaffNo(), apply.getNotes(), apply.getIsSendMessage());
		if (request != null) {
			request.setMessage(context
					.getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, 1111);
		}
	}
	
	/**
	 * 物品申领审批
	 */
	public void auditReceiveGoods(ApplyParams apply) {
		if (null == apply) {
            return;
        }
		ApiRequest request = OAServicesHandler.auditReceiveGoods(apply.getReceiveId(), apply.getNotes(), apply.getPassState(), apply.getNextStaffNo());
		if (request != null) {
			request.setMessage(context
					.getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, 2222);
		}
	}
	
	/**
	 * 物品申购送出
	 */
	public void sendNextPurchase(ApplyParams apply) {
        if (null == apply) {
            return ;
        }
        ApiRequest request = OAServicesHandler.sendNextPurchase(apply.getPurchaseId(), apply.getNextFpuNo(), apply.getNextStaffNo(), apply.getNotes(), apply.getIsSendMessage());
		if (request != null) {
			request.setMessage(context.getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, 3333);
		}
	}
	
	/**
	 * 物品申购审批
	 */
	public void auditPurchase(ApplyParams apply) {
		if (null == apply) {
            return;
        }
		ApiRequest request = OAServicesHandler.auditPurchase(apply.getPurchaseId(), apply.getNotes(), apply.getPassState(), apply.getNextStaffNo());
		if (request != null) {
			request.setMessage(context.getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, 4444);
		}
	}
	
	/**
	 * 请假送出
	 */
	public void sendNextLeave(ApplyParams apply) {
        if (null == apply) {
            return ;
        }
        ApiRequest request = OAServicesHandler.sendNextLeave(apply.getLeaveId(), apply.getNextFpuNo(), apply.getNextStaffNo(), apply.getNotes(), apply.getIsSendMessage());
		if (request != null) {
			request.setMessage(context.getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, 5555);
		}
	}
	
	/**
	 * 获得部门人员的ID集合
	 * 
	 * @return
	 */
	public String getToStaffNos() {
		StringBuffer sbIds = new StringBuffer();
		List<StaffsInfo> valueList = adapter.getValueList();
		for (int i = 0; i < valueList.size(); i++) {
			sbIds.append(valueList.get(i).getStaffNo()).append(",");
		}
		return sbIds.substring(0, sbIds.length() - 1);
	}

	public String getNextFpuNo() {
		return nextFpuNo;
	}

}
