package com.powerriche.mobile.na.oa.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentTransactorHelper;
import com.powerriche.mobile.na.oa.bean.DocumentParams;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.na.oa.view.widget.WheelView;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 公文办理选择操作
 * @author  Fitz
 * @date    2015年4月30日
 * @version v1.0
 */
public class DocumentTransactorActivity extends BaseActivity implements OnClickListener{

	/**
	 * 0:返回按钮，	1：去列表
	 */
	public static final String KEY_BACK = "KEY_BACK";
	public static final int CODE_REQUEST_TRANS = 2000;
	
	private Context mContext;
	private ExpandableListView exListView;
	private DocumentTransactorHelper transactorHelper;
	
	//header
	private LinearLayout llTypeWrap;
	private WheelView wheelView;
	private TextView tvPeople;
	private Button btnSelectAll;
	
	//footer
	private EditText etSuggest;
	
	private int passreadTag = -1;	//如果passread不等于1000，则初始话办理信息view，否则初始化传阅信息view
	
//	private int isBackFlag = 0;//返回标识，1标识公文详情 2标识会议详情，0是其他
	
	private DocumentParams params;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		
		if(BeanUtils.isTabletDevice(mContext)){
			setContentView(R.layout.document_transactor_pad);
		}else{
			setContentView(R.layout.document_transactor);
		}
		
		
		params = (DocumentParams) getIntent().getSerializableExtra("DOCUMENT_PARAMS");
		if(params==null){
			UIHelper.showMessage(mContext, "参数丢失");
			finishActiviy(0);
			
		}else{
			initView();
			transactorHelper = new DocumentTransactorHelper(mContext, callBack, exListView, llTypeWrap, tvPeople, wheelView);
//			transactorHelper.loadData(swfNo, fpuNo);
			transactorHelper.process(params.getResultItem());
		}
	}
	
	private void initView(){
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.INVISIBLE);
		topActivity.setTopTitle(getString(R.string.select_people_title));	//选择人员
		
		exListView = (ExpandableListView) findViewById(R.id.ex_listview);
		exListView.setGroupIndicator(null);//去掉圆形三角箭头
		exListView.setDivider(null);
		exListView.setCacheColorHint(Color.TRANSPARENT);
		exListView.setFadingEdgeLength(0);
		
		wheelView = (WheelView) findViewById(R.id.wheel_type);
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.document_transactor_header, null);
		llTypeWrap = (LinearLayout) header.findViewById(R.id.ll_type_wrap);
		tvPeople = (TextView) header.findViewById(R.id.tv_people);
		tvPeople.setVisibility(View.GONE);
		btnSelectAll = (Button) header.findViewById(R.id.btn_all_select);
		btnSelectAll.setOnClickListener(this);
		
		exListView.addHeaderView(header);
		
		if(BeanUtils.isTabletDevice(mContext)){	//pad
			findViewById(R.id.tv_add_suggest).setOnClickListener(this);
			findViewById(R.id.ll_suggest_wrap).setOnClickListener(this);
			findViewById(R.id.iv_add_suggest).setOnClickListener(this);
			findViewById(R.id.btn_send).setOnClickListener(this);
			etSuggest = (EditText) findViewById(R.id.et_suggest);
			
		}else{	//手机
			View footer = LayoutInflater.from(mContext).inflate(R.layout.document_transactor_footer, null);
			footer.findViewById(R.id.tv_add_suggest).setOnClickListener(this);
			footer.findViewById(R.id.ll_suggest_wrap).setOnClickListener(this);
			footer.findViewById(R.id.iv_add_suggest).setOnClickListener(this);
			footer.findViewById(R.id.btn_send).setOnClickListener(this);
			etSuggest = (EditText) footer.findViewById(R.id.et_suggest);
			exListView.addFooterView(footer);
		}
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (10086 == requestCode && data != null) {
			try {
				String content = data.getStringExtra("SUGGEST_CONTENT");
				if(!BeanUtils.isEmpty(content)){
					etSuggest.setText(content);
				}
			} catch (Exception e) {
				
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	public InvokeHelper getInvokeHelper() {
		return helper;
	}
	
	private void finishActiviy(int opType){
		Intent intent = new Intent();
		intent.putExtra(KEY_BACK, opType);
		setResult(Activity.RESULT_OK, intent);
		finish();
	}
	
	
	/**
	 * 返回详情界面
	 * @param flag 办理结果标志：1-办理成功（返回待办列表需要移除当前待办项），0-未办理或办理不成功（返回待办列表不需要移除当前待办项）
	 */
	private void goback(int flag){
		Bundle data = new Bundle();
		data.putString("documentId", params.getDocumentId());
		data.putString("wfNo", params.getWfNo());
		data.putString("traceNo", params.getTraceNo());
		data.putString("fpuNo", params.getFpuNo());	//当前环节编号
		data.putString("swfNo", params.getSwfNo());	//系统流程编号
		data.putInt("IS_PASS_READ", passreadTag);	//传阅入口标示
		/** 办理结果标志：1-办理成功（返回待办列表需要移除当前待办项），0-未办理或办理不成功（返回待办列表不需要移除当前待办项）*/
		data.putInt("DEAL_WITH_FLAG", flag);//办理结果标志
		DocumentDetailActivity.dealwithFlag = flag;//办理结果标志
		MeetDetailActivity.dealwithFlag = flag;//办理结果标志
		
		//以下是之前注释的
		/*if(isBackFlag == 1){
			UIHelper.forwardTargetActivity(mContext, DocumentDetailActivity.class, data, true);
		}else if(isBackFlag == 2){
			UIHelper.forwardTargetActivity(mContext, MeetDetailActivity.class, data, true);
		}else{
			finish();
		}*/

		finishActiviy(1);
	}
	
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_back){//返回
			finishActiviy(0);
			
		}else if(id == R.id.btn_all_select){//全选操作
			if(btnSelectAll.isSelected()){
				btnSelectAll.setSelected(false);//取消全选
				transactorHelper.selectAll(false);
			}else{
				btnSelectAll.setSelected(true);//全选
				transactorHelper.selectAll(true);
			}
		}else if(id==R.id.tv_add_suggest || id==R.id.ll_suggest_wrap || id==R.id.iv_add_suggest){	//选择常用建议
			// 请求加载获取常用意见，如果获取成功，才弹出选择对话框
			//doLoadUserNotesList();
			UIHelper.forwardTargetActivityForResult(this,
					DocumentTransactorSuggestActivity.class, null, false, 10086);
		}else if(id == R.id.btn_send){//办理
			String names = tvPeople.getText().toString();
			String notes = etSuggest.getText().toString();
			if(BeanUtils.isEmpty(names)){
				UIHelper.showMessage(mContext, "办理人员不能为空");
				return;
			}
			if(BeanUtils.isEmpty(notes)){
				UIHelper.showMessage(mContext, "办理意见不能为空");
				etSuggest.requestFocus();
				return;
			}
			String toStaffNos = transactorHelper.getToStaffNos();
			transactorHelper.sendNextWorkFlow(params.getTraceNo(), params.getDocumentId(), params.getWfNo(), params.getSwfNo(), 
					transactorHelper.getNextFpuNo(), toStaffNos, notes, "0");
		}
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == 0) {
					//老版本解析数据
//					transactorHelper.process(response);

				} else if (what == 1111) {
					String message = response.getResultItem(ResultItem.class).getString("message");
					UIHelper.showMessage(mContext, message);
					goback(1);
				}
			}else{
				//goback(0);// 失败都给关了
			}
		}
	};
	
}
