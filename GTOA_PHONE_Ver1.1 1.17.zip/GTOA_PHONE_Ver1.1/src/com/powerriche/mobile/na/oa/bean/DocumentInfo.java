package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 公文基本信息
 * @author  Fitz
 * @date    2015年4月27日
 * @version v1.0
 */
public class DocumentInfo {

	String documentType;
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	int documentId;
	String title;
	String characters;
	String department;	//拟稿人部门
	String drafter;	//拟稿人姓名
	String urgency;	//缓急
	String level;	//密级等级
	String summary;	//摘要
	String remark;	//备注信息
	
	String wfNo;	//流程编号
	String swfNo;	//系统流程编号
	String fpuNo;   //当前环节
	String docCode;	//公文编号
	String createDate;	//创建时间
	
	int operateType;	//操作类型--0:添加,1:修改
	
	int exchangeFlag;	//0,交换来文; 1,手工登记(字段仅对来文swfNo=2006083005302033有效)
	int isReceiptReplied;	//0：未签收 1：已签收 2：已拒收
	int isFirstFpu;		//是否是流程的第一个环节：1是第一个环节，0不是第一个环节
	int result;		//0待办，1已办，-1只读页
	
	int isCallback;//0 不能撤回（不显示撤回按钮）1 可以撤回（显示撤回按钮）
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCharacters() {
		return characters;
	}
	public void setCharacters(String characters) {
		this.characters = characters;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	/**
	 * 拟稿人
	 * @return
	 */
	public String getDrafter() {
		return drafter;
	}
	/**
	 * 拟稿人
	 * @return
	 */
	public void setDrafter(String drafter) {
		this.drafter = drafter;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUrgency() {
		return urgency;
	}
	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}
	public String getWfNo() {
		return wfNo;
	}
	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}
	public String getSwfNo() {
		return swfNo;
	}
	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}
	public String getDocCode() {
		return docCode;
	}
	public void setDocCode(String docCode) {
		this.docCode = docCode;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public int getDocumentId() {
		return documentId;
	}
	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}
	public int getOperateType() {
		return operateType;
	}
	public void setOperateType(int operateType) {
		this.operateType = operateType;
	}
	public int getExchangeFlag() {
		return exchangeFlag;
	}
	public void setExchangeFlag(int exchangeFlag) {
		this.exchangeFlag = exchangeFlag;
	}
	public int getIsReceiptReplied() {
		return isReceiptReplied;
	}
	public void setIsReceiptReplied(int isReceiptReplied) {
		this.isReceiptReplied = isReceiptReplied;
	}
	public int getIsFirstFpu() {
		return isFirstFpu;
	}
	public void setIsFirstFpu(int isFirstFpu) {
		this.isFirstFpu = isFirstFpu;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public int getIsCallback() {
		return isCallback;
	}
	public void setIsCallback(int isCallback) {
		this.isCallback = isCallback;
	}
	public String getFpuNo() {
		return fpuNo;
	}
	public void setFpuNo(String fpuNo) {
		this.fpuNo = fpuNo;
	}
	
	
	
}
