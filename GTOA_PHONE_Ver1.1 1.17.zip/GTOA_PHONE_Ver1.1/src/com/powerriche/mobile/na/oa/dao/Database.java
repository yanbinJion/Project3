package com.powerriche.mobile.na.oa.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.powerriche.mobile.na.oa.down.DownloadInfoField;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.tools.ContactDbhelper;
import com.powerriche.mobile.oa.tools.FileDownHelper;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UserHelper;

/**
 * 类描述：<br>
 * 初始化程序
 * 
 * @author Fitz
 * @date 2014-12-4
 */
public class Database {

	public static final String TAG = "Database";

	private static Database sInstance = null;

	public static SQLiteDatabase writableSQLiteDatabase = null;
	public static SQLiteDatabase readableSQLiteDatabase = null;

	/**
	 * SQLiteDatabase Open Helper
	 */
	private DatabaseHelper mOpenHelper = null;

	/**
	 * SQLiteOpenHelper
	 */
	private static class DatabaseHelper extends SQLiteOpenHelper {

		public DatabaseHelper(Context context) {
			super(context, Constants.DB_NAME, null, Constants.DB_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			Logger.e(TAG, "-------->DatabaseHelper.onCreate()：创建本地数据库");
			createAllTables(db);//创建所有表
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Logger.e(TAG, "-------->DatabaseHelper.onUpgrade()：升级本地数据库，数据库版本号："
					+ oldVersion + "--->" + newVersion);
			dropAllTables(db);//1、先删除旧表
			createAllTables(db);//2、再创建新表
		}

		@Override
		public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Logger.e(TAG, "-------->DatabaseHelper.onDowngrade()：降级本地数据库，数据库版本号："
					+ oldVersion + "--->" + newVersion);
			dropAllTables(db);//1、先删除旧表
			createAllTables(db);//2、再创建新表
		}
		
	}

	/**
	 * Construct
	 * 
	 * @param context
	 */
	private Database(Context context) {
		mOpenHelper = new DatabaseHelper(context);
	}

	/**
	 * Get Database
	 * 
	 * @param context
	 * @return
	 */
	public static synchronized Database getInstance(Context context) {
		if (null == sInstance) {
			sInstance = new Database(context);
		}

		if (writableSQLiteDatabase == null) {
			writableSQLiteDatabase = sInstance.getDb(true);
		}
		if (readableSQLiteDatabase == null) {
			readableSQLiteDatabase = sInstance.getDb(false);
		}

		return sInstance;
	}

	/**
	 * Get SQLiteDatabase Open Helper
	 * 
	 * @return
	 */
	public SQLiteOpenHelper getSQLiteOpenHelper() {
		return mOpenHelper;
	}

	/**
	 * Get Database Connection
	 * 
	 * @param writeable
	 * @return
	 */
	public SQLiteDatabase getDb(boolean writeable) {
		if (writeable) {
			return mOpenHelper.getWritableDatabase();
		} else {
			return mOpenHelper.getReadableDatabase();
		}
	}

	/**
	 * 方法说明：<br>
	 * Close Database
	 */
	public void close() {
		if (null != sInstance) {
			mOpenHelper.close();
			sInstance = null;
		}
	}

	/**
	 * 方法说明：<br>
	 * Create All tables
	 * 
	 * @param db
	 */
	private static void createAllTables(SQLiteDatabase db) {
		try {
			db.execSQL(FileDownHelper.createTableSql());
			db.execSQL(UserHelper.createTableUserRecord());
			db.execSQL(UserHelper.createTableUserGesturescode());
			db.execSQL(DownloadInfoField.getCreateSQL());
			db.execSQL(NotifyDao.createTableSQL());
            db.execSQL(ContactDbhelper.createContact());
		} catch (Exception e) {
			Logger.e(TAG, e.toString());
		}
	}

	/**
	 * 方法说明：<br>
	 * Drop All tables
	 * 
	 * @param db
	 */
	private static void dropAllTables(SQLiteDatabase db) {
		try {
			db.execSQL(FileDownHelper.getDropSQL());
			db.execSQL(UserHelper.getDropSQLUserRecord());
			db.execSQL(UserHelper.getDropSQLUserGesturescode());
			db.execSQL(DownloadInfoField.getDropSQL());
			db.execSQL(NotifyDao.getDropSQL());
            db.execSQL(ContactDbhelper.dropContact());
		} catch (Exception e) {
			Logger.e(TAG, e.toString());
		}
	}

}
