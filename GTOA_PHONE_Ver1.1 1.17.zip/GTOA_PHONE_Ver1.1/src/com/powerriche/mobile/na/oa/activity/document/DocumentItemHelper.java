package com.powerriche.mobile.na.oa.activity.document;

import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.FileDownListener;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * Filename : DocumentItemHelper.java
 * 
 * @Description : 公文的详细页
 * @Author : 刘剑
 * @Version : 1.0
 * @Date :2012-06-04 下午09:38:24
 */
public class DocumentItemHelper {

	private String workflowId;

	private String documentId;

	// 通知id
	private String noticeId;

	// 公文类型 发文:4,来文:3
	private String bizCode;

	// 任务编号
	private String taskNo;

	/***/
	private String documentTitle;

	/** 发文和收文的标题 */
	private TextView titleView;

	/** 发文和收文的其他显示 */
	private TextView titleOtherView;

	/** 发文和收文 摘要显示 */
	private TextView zyView;

	/** 通知的标题 */
	private TextView noticeTitle;

	/** 通知的内容 */
	private WebView noticeContent;

	/** 发文和收文的附件显示 */
	private LinearLayout fjView;

	/***/
	private Button contentBtn;

	/***/
	private String zwfile;

	/***/
	private String zwurl;

	private int doucmentType = 0;

	private FileDownListener downListener;

	private Map<Integer, String[]> filesCache = new HashMap<Integer, String[]>();

	private InvokeHelper helper = null;

	private Context context = null;

	private IRequestCallBack callBack = null;

	private Handler handler;

	public DocumentItemHelper(Context context, View contextView) {
	}

	public void loadItem(String noticeId, String bizCode, String taskNo,
			int doucmentType, int what) {
	}

	public void process(HttpResponse response, int what) {
	}

	public void downFileByIndex(int index) {
		String[] values = filesCache.get(index);
		if (values != null) {
			downFile(values[0], values[1]);
		}
	}

	public void downFile(String url, String name) {
		try {
			int codeindex = url.lastIndexOf("=");
			int pointindex = name.lastIndexOf(".");
			String code = url.substring(codeindex + 1);
			String format = name.substring(pointindex);
			code = BeanUtils.md532(code);
			boolean isOk = downListener.setRequest(code + format, url);
			if (isOk) {
				downListener.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 设置通知内容的webview显示
	 * 
	 * @param content
	 *            通知的内容显示
	 * @return void [返回类型说明]
	 * @exception throws [违例类型] [违例说明]
	 * @see [类、类#方法、类#成员]
	 */
	public void buildNoticeContent(String content) {
		View convertView = LayoutInflater.from(context).inflate(
				R.layout.list_item_files, null);
		TextView textView = (TextView) convertView
				.findViewById(R.id.list_item_text_field);
		textView.setText(content);
		convertView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// downFileByIndex(index);
			}
		});
		noticeContent.addView(convertView);
	}

	/**
	 * 设置附件的显示
	 * 
	 * @param tilte
	 *            附件的名称
	 * @param index
	 *            第几个附件
	 * @return void [返回类型说明]
	 * @exception throws [违例类型] [违例说明]
	 * @see [类、类#方法、类#成员]
	 */
	public void buildFileViews(String tilte, final int index) {
		View convertView = LayoutInflater.from(context).inflate(
				R.layout.list_item_files, null);
		TextView textView = (TextView) convertView
				.findViewById(R.id.list_item_text_field);
		textView.setText((index + 1) + "、" + tilte);
		convertView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				downFileByIndex(index);
			}
		});
		fjView.addView(convertView);
	}

	public String getWorkflowId() {
		return workflowId;
	}

	public String getDocumentId() {
		return documentId;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public String getBizCode() {
		return bizCode;
	}

	public String getTaskNo() {
		return taskNo;
	}

	public String getNoticeId() {
		return noticeId;
	}
}
