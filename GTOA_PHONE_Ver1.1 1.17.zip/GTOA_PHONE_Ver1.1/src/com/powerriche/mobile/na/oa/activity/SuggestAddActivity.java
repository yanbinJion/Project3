package com.powerriche.mobile.na.oa.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 常用意见：新建
 * 
 * @author 李运期
 * @date 2015年5月3日
 * @version v1.0
 */
public class SuggestAddActivity extends BaseActivity implements OnClickListener {

	private static final String	TAG				= "SuggestAddActivity";

	private final static int	DIALOG_MESSAGE	= 1001;
	private final static int	DIALOG_CHECK	= 1002;

	private Context				mContext;

	private TopActivity			topActivity;
	private Button				mBtnRight;

	private EditText			mTxtContent;
	private Button				mBtnSubmit;

	private String				noteId			= null;
	private String				noteContent		= null;

	private String				alertMessage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.suggest_add);

		mTxtContent = (EditText) findViewById(R.id.txt_content);
		mBtnSubmit = (Button) findViewById(R.id.btn_submit);
		mBtnSubmit.setOnClickListener(this);

		bindViews();
	}

	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.suggest_add_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.GONE);

		mTxtContent.setEnabled(true);
		mBtnSubmit.setClickable(true);
		mBtnSubmit.setVisibility(View.VISIBLE);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back:// 返回
				gotoListPage();
				break;
			case R.id.btn_submit:// 提交
				if (doCheckData()) {//验证
					doSubmitData();
				}
				break;
		}

	}

	/** 提交数据 */
	public void doSubmitData() {
		noteId = null;
		noteContent = mTxtContent.getText().toString();

		//提交请求
		ApiRequest request = OAServicesHandler.editUserNotes(noteId, noteContent, Constants.OPT_TYPE_CYYJ_ADD);
		request.setMessage(getString(R.string.system_commit_message));
		helper.invokeWidthDialog(request, callBack);
	}

	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		if (BeanUtils.isEmpty(mTxtContent.getText().toString())) {
			alertMessage = getString(R.string.suggest_content_check_tip);
			showDialog(DIALOG_CHECK);
			return false;
		}
		return true;
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
			case DIALOG_MESSAGE:
				return new AlertDialog.Builder(SuggestAddActivity.this).setIcon(R.drawable.icon).setTitle(R.string.app_name).setMessage(alertMessage)
						.setNegativeButton(R.string.system_dialog_confirm, new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {

							}
						}).create();
			case DIALOG_CHECK:
				return new AlertDialog.Builder(SuggestAddActivity.this).setIcon(R.drawable.icon).setTitle(R.string.app_name).setMessage(alertMessage)
						.setNegativeButton(R.string.system_dialog_confirm, new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {

							}
						}).create();
			default:
				break;
		}
		return super.onCreateDialog(id);
	}

	private IRequestCallBack	callBack	= new BaseRequestCallBack() {
												@Override
												public void process(HttpResponse response, int what) {
													ResultItem item = response.getResultItem(ResultItem.class);
													if (checkResult(item)) {
														String message = item.getString("message");
														// 操作成功
														if (message != null) {
															Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
														} else {
															Toast.makeText(
																	context,
																	getString(R.string.system_operation_success_message),
																	Toast.LENGTH_SHORT).show();
														}
														gotoListPage();
													}
												}
											};

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	/** 返回到列表页面 */
	public void gotoListPage() {

		UIHelper.forwardTargetActivity(mContext, SuggestListActivity.class, null, true);

		finish();
	}

}
