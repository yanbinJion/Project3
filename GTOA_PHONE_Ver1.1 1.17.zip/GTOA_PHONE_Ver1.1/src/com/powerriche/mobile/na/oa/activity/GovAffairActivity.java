package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.GovAffairListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshSwipeMenuListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenu;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuCreator;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuItem;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView.OnMenuItemClickListener;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 领导政务管理
 * 
 * @author Fitz
 * @date 2015年4月28日
 * @version v1.0
 */
public class GovAffairActivity extends BaseActivity implements OnClickListener {

	public static int OP_REFRESH = 0;

	public static final int WATH_LOADING = 0;
	public static final int WATH_DELETE = 1;

	public static final int WATH_DETAIL = 1234;

	private Context mContext;
	private TextView tvTitle;

	
	private PullToRefreshSwipeMenuListView pullView;	//政务listView
	private SwipeMenuListView mListView;
	
	private PullToRefreshListView pullViewLeader;		//领导listView
	private ListView listViewLeader;
	
	private TextView tvNoDataMsg;
	
	private GovAffairListHelper govHelper;

	private PopupWindow mPop;
	private int searchState = Constants.GOVAFFAIR_STATE_DEFAULT;// 默认按政务查询

	private int pageIndex = 1;

	private TopActivity topActivity;
	
	private SearchBarWidget mSearchBarWidget;
	private SearchBarWidget mSearchBarWidgetLeader;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		// 设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.govaffair_list);

		bindView();

		govHelper = new GovAffairListHelper(mContext, callback, helper, mListView, tvNoDataMsg, pullView, pullViewLeader, listViewLeader,
				mSearchBarWidget, mSearchBarWidgetLeader);
		//加载第一页的列表数据
		loadingData(searchState, pageIndex,true);
	}

	void bindView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.gov_affair_title));// 顶部栏的中间标题.默认政务
		topActivity.setRightBtnVisibility(View.VISIBLE);// 显示右边按钮
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(R.drawable.add_button);// “新建”图标
		Drawable moreIcon = getResources().getDrawable(R.drawable.ic_arrows_down);
		moreIcon.setBounds(0, 0, moreIcon.getMinimumWidth(),moreIcon.getMinimumHeight()); // 设置边界
		topActivity.getTvTitle().setCompoundDrawables(null, null, moreIcon, null);

		tvTitle = (TextView) findViewById(R.id.tv_top_title);
		tvTitle.setOnClickListener(this);

		initPopup();

		pullView = (PullToRefreshSwipeMenuListView) findViewById(R.id.pull_view);
		pullView.setPullRefreshEnabled(true);
		pullView.setPullLoadEnabled(false);
		pullView.setScrollLoadEnabled(true);
		pullView.setOnRefreshListener(new OnRefreshListener<SwipeMenuListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<SwipeMenuListView> refreshView) {
				pageIndex =  1;
				loadingData(searchState, pageIndex, false);
			}
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<SwipeMenuListView> refreshView) {
				// 上拉刷新
				pageIndex = pageIndex + 1;
				loadingData(searchState, pageIndex, false);
			}
		});

		mListView = pullView.getRefreshableView();
		mListView.setVerticalScrollBarEnabled(false);// 设置滚动条隐藏(包含活动跟不活动)
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(android.R.color.transparent);
		
		//添加“公共搜索框”：可以跟随列表数据一起滚动
		View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
		mSearchBarWidget = (SearchBarWidget) header.findViewById(R.id.search_bar_widget);
		mListView.addHeaderView(header);

		// 向左侧滑菜单
		SwipeMenuCreator creator = new SwipeMenuCreator() {
			@Override
			public void create(SwipeMenu menu) {
				SwipeMenuItem deleteItem = new SwipeMenuItem(getApplicationContext());// create "delete" item
				deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));// set item background//
										// (R.color.yellow_delete 无效)
				int width = UIHelper.dp2px(mContext, 70);// set item width
				deleteItem.setWidth(width);
				deleteItem.setIcon(R.drawable.ic_delete);// set a icon
				menu.addMenuItem(deleteItem);// add to menu
			}
		};
		mListView.setMenuCreator(creator);
		mListView.setOnMenuItemClickListener(new OnMenuItemClickListener() {
			@Override
			public void onMenuItemClick(int position, SwipeMenu menu, int index) {
				switch (index) {
					case 0 :
						// 执行删除
						govHelper.deleteData(position, WATH_DELETE);
						break;
				}
			}
		});
		
		
		//*****************领导listView*************
		pullViewLeader = (PullToRefreshListView) findViewById(R.id.pull_leader);
		pullViewLeader.setPullRefreshEnabled(false);
		pullViewLeader.setPullLoadEnabled(false);
		pullViewLeader.setScrollLoadEnabled(true);
		
		listViewLeader = pullViewLeader.getRefreshableView();
		UIHelper.setListViewAttribute(listViewLeader);
		
		pullViewLeader.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
				pageIndex =  1;
				loadingData(searchState, pageIndex, false);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				loadingData(searchState, pageIndex, false);
			}
		});
		
		//添加“公共搜索框”：可以跟随列表数据一起滚动
		View headerLeader = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
		mSearchBarWidgetLeader = (SearchBarWidget) headerLeader.findViewById(R.id.search_bar_widget);
		listViewLeader.addHeaderView(headerLeader);
		
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);
	}

	private void initPopup() {
		if (mPop == null) {
			View view = LayoutInflater.from(mContext).inflate(R.layout.govaffair_top_menu, null);
			mPop = new PopupWindow(view, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);

			view.findViewById(R.id.tv_search_leader).setOnClickListener(this);
			view.findViewById(R.id.tv_search_gov).setOnClickListener(this);
		}
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				finish();
				break;

			case R.id.btn_top_right : // 新增领导政务
				UIHelper.forwardTargetActivity(mContext, GovAffairAddActivity.class, null, false);
				break;

			case R.id.tv_top_title : // 中间标题
				showPopup();
				break;

			case R.id.tv_search_leader : // 查询类型：领导
				searchState = Constants.GOVAFFAIR_STATE_LEADER;
				topActivity.setTopTitle(getString(R.string.gov_leader_title));// 顶部栏的中间标题.领导
				showPopup();
				pageIndex = 1;
				loadingData(searchState, pageIndex, true);
				break;

			case R.id.tv_search_gov : // 查询类型：政务
				searchState = Constants.GOVAFFAIR_STATE_DEFAULT;
				topActivity.setTopTitle(getString(R.string.gov_affair_title));// 顶部栏的中间标题.默认政务
				showPopup();
				pageIndex = 1;
				loadingData(searchState, pageIndex, true);
				break;
		}
	}

	/** 显示弹出菜单 */
	void showPopup() {
		if (mPop.isShowing()) {
			mPop.dismiss();
		} else {
			mPop.showAsDropDown(tvTitle);
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (OP_REFRESH == 1) {
			OP_REFRESH = 0;
			loadingData(searchState, 1,true); // 默认查询第一页
		}
	}

	void loadingData(int state, int pageIndex, boolean isDialog) {
		govHelper.loadData(state, pageIndex, isDialog);
	}

	private IRequestCallBack callback = new BaseRequestCallBack() {

		int position = 0;

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == 0) { // 加载数据
					govHelper.process(response, 0);
				} else if (what == WATH_DELETE) { // 删除返回
					govHelper.deleteBack(response, position);
				}
			}
		}

		@Override
		public void handleMessage(Message message, int what) {
			super.handleMessage(message, what);
			position = message.what;
		}

	};

}
