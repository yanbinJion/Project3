package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;
import java.util.List;

/**
 * 物品申购实体类 Created by root on 16-7-4.
 */
public class PurchaseApply implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -438079978301988837L;
	/* 申购Id，新增时为0* */
	private String purchaseId;
	private String purchaseTitle;
	private String purchaseProposer;
	private String purchaseTime;
	private String purchaseReason;
	private String purchasePerson;
	private String purchaseDate;
	/* 申购类型 0 办公用品，1 工程用品，2 其它* */
	private String purchaseType;
	/* 申购类型选择其它时，手动输入的申购类型名称* */
	private String purchaseTypeName;
	/* 支付方式 0 现金 1 汇款 2 支付宝 3 其它* */
	private String payMode;
	private String payModeName;
	private String remark;
	private String totleAccount;
	private String applyDate;
	private String documentId;
	private String fpuNo;
	/* -1 只读 0 待办 1 已办* */
	private String result;
	/* 0 申请中 1 申请通过 -1 申请被拒绝* */
	private String passState;
	private boolean isShowSave;
	private boolean isShowSend;
	private boolean isShowAgree;
	private boolean isShowRefuse;
	private boolean isShowFinish;
	private List<PurchaseDetail> details;
	private List<TransactSuggestion> transactSuggestion;
	private List<TransactInfo> transactInfo;
	private List<DocFileInfo> files;

	public boolean isOtherType() {
		return "2".equals(purchaseType);
	}

	public boolean isOtherPay() {
		return "3".equals(payMode);
	}

	public String getPurchaseTitle() {
		return purchaseTitle;
	}

	public void setPurchaseTitle(String purchaseTitle) {
		this.purchaseTitle = purchaseTitle;
	}

	public String getPurchaseProposer() {
		return purchaseProposer;
	}

	public void setPurchaseProposer(String purchaseProposer) {
		this.purchaseProposer = purchaseProposer;
	}

	public String getPurchaseTime() {
		return purchaseTime;
	}

	public void setPurchaseTime(String purchaseTime) {
		this.purchaseTime = purchaseTime;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getPassState() {
		return passState;
	}

	public void setPassState(String passState) {
		this.passState = passState;
	}

	public String getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getFpuNo() {
		return fpuNo;
	}

	public void setFpuNo(String fpuNo) {
		this.fpuNo = fpuNo;
	}

	public String getPurchasePerson() {
		return purchasePerson;
	}

	public void setPurchasePerson(String purchasePerson) {
		this.purchasePerson = purchasePerson;
	}

	public boolean isShowSave() {
		return isShowSave;
	}

	public void setShowSave(boolean showSave) {
		isShowSave = showSave;
	}

	public boolean isShowSend() {
		return isShowSend;
	}

	public void setShowSend(boolean showSend) {
		isShowSend = showSend;
	}

	public boolean isShowAgree() {
		return isShowAgree;
	}

	public void setShowAgree(boolean showAgree) {
		isShowAgree = showAgree;
	}

	public boolean isShowRefuse() {
		return isShowRefuse;
	}

	public void setShowRefuse(boolean showRefuse) {
		isShowRefuse = showRefuse;
	}

	public boolean isShowFinish() {
		return isShowFinish;
	}

	public void setShowFinish(boolean isShowFinish) {
		this.isShowFinish = isShowFinish;
	}

	public String getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(String purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getPurchaseReason() {
		return purchaseReason;
	}

	public void setPurchaseReason(String purchaseReason) {
		this.purchaseReason = purchaseReason;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getPurchaseType() {
		return purchaseType;
	}

	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}

	public String getPurchaseTypeName() {
		return purchaseTypeName;
	}

	public void setPurchaseTypeName(String purchaseTypeName) {
		this.purchaseTypeName = purchaseTypeName;
	}

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}

	public String getPayModeName() {
		return payModeName;
	}

	public void setPayModeName(String payModeName) {
		this.payModeName = payModeName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTotleAccount() {
		return totleAccount;
	}

	public void setTotleAccount(String totleAccount) {
		this.totleAccount = totleAccount;
	}

	public List<PurchaseDetail> getDetails() {
		return details;
	}

	public void setDetails(List<PurchaseDetail> details) {
		this.details = details;
	}

	public List<TransactSuggestion> getTransactSuggestion() {
		return transactSuggestion;
	}

	public void setTransactSuggestion(List<TransactSuggestion> transactSuggestion) {
		this.transactSuggestion = transactSuggestion;
	}

	public List<TransactInfo> getTransactInfo() {
		return transactInfo;
	}

	public void setTransactInfo(List<TransactInfo> transactInfo) {
		this.transactInfo = transactInfo;
	}

	public List<DocFileInfo> getFiles() {
		return files;
	}

	public void setFiles(List<DocFileInfo> files) {
		this.files = files;
	}

	public class PurchaseDetail implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5189995855646348194L;
		private String detailId;
		private String purchaseName;
		private String spec;
		private String quantity;
		private String unit;
		private String unitPrice;
		private String totalPrice;
		
		public String getDetailId() {
			return detailId;
		}

		public void setDetailId(String detailId) {
			this.detailId = detailId;
		}

		public String getPurchaseName() {
			return purchaseName;
		}

		public void setPurchaseName(String purchaseName) {
			this.purchaseName = purchaseName;
		}

		public String getSpec() {
			return spec;
		}

		public void setSpec(String spec) {
			this.spec = spec;
		}

		public String getQuantity() {
			return quantity;
		}

		public void setQuantity(String quantity) {
			this.quantity = quantity;
		}

		public String getUnit() {
			return unit;
		}

		public void setUnit(String unit) {
			this.unit = unit;
		}

		public String getUnitPrice() {
			return unitPrice;
		}

		public void setUnitPrice(String unitPrice) {
			this.unitPrice = unitPrice;
		}

		public String getTotalPrice() {
			return totalPrice;
		}

		public void setTotalPrice(String totalPrice) {
			this.totalPrice = totalPrice;
		}
	}

}
