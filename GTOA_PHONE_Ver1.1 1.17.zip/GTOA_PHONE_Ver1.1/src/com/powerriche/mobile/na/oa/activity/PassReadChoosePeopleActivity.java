package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.MyTreeListViewAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.TreeListAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.NodeBean;
import com.powerriche.mobile.na.oa.treeview.util.Node;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 传阅功能选人界面
 * @author  Fitz
 * @date    2015年5月13日
 * @version v1.0
 */
public class PassReadChoosePeopleActivity extends BaseActivity implements View.OnClickListener {

	private static final int GET_STAFF_TREE_REQ = 0;
	protected static final int GET_PASS_READ_REQ = 1;
	private Context mContext;
	private ListView listView;
	private List<NodeBean> nodes;
	private TextView tv_selected_people;
	private MyTreeListViewAdapter<NodeBean> treeAdapter;
	private String userId;
	private String documentId, wfNo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		UIHelper.hideTitle(this);
		setContentView(R.layout.common_choose_people);
		documentId = getIntent().getStringExtra("documentId");
		wfNo = getIntent().getStringExtra("wfNo");
		bindView();
		getStaffTree();
	}

	private void bindView() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle("传阅选人");
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("确认");
		tv_selected_people = (TextView) findViewById(R.id.tv_selected_people);
		listView = (ListView) findViewById(R.id.listView);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {
			finish();
			
		} else if (id == R.id.btn_top_right) {
			returnResult();
		}
	}
	
	private void getStaffTree() {
        ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
        if (request != null){
            helper.invokeWidthDialog(request, callBack, GET_STAFF_TREE_REQ);
        }
    }

	private void showStaffTree(List<ResultItem> item) {
		if (item == null) {
			return;
		}
		nodes = new ArrayList<NodeBean>();
		for (ResultItem resultItem : item) {
//			String dispOrder = resultItem.getString("DISP_ORDER");
//			String orderNo = resultItem.getString("ORDERNO");
			String realName = resultItem.getString("REAL_NAME");
//			String siteName = resultItem.getString("SITE_NAME");
			String siteNo = resultItem.getString("SITE_NO");
			String staffNo = resultItem.getString("STAFF_NO");
			NodeBean node = new NodeBean(staffNo, siteNo, realName);
			nodes.add(node);
		}
		treeAdapter = new MyTreeListViewAdapter<NodeBean>(listView, this, nodes, 0/*, isHide*/);
		treeAdapter.setOnTreeNodeClickListener(new TreeListAdapter.OnTreeNodeClickListener() {

			@Override
			public void onClick(Node node, int position) {
				
			}

			@Override
			public void onCheckChange(Node node, int position,
					List<Node> checkedNodes) {
				String name = "";
				userId = "";
				for (Node n : checkedNodes) {
					if (n.isLeaf()) {
						if (!name.equals("")) {
							name += ",";
						}
						name += n.getName();
						if (!userId.equals("")) {
							userId += ",";
						}
						userId += n.getId();
					}
				}
				tv_selected_people.setText(name);
			}
		});
		listView.setAdapter(treeAdapter);
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {	
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String code = item.getString("code");
				String message = item.getString("message");
				if (!Constants.SUCCESS_CODE.equals(code)) {
					UIHelper.showMessage(mContext, message);
					return;
				}
				if (what == GET_STAFF_TREE_REQ) {
					List<ResultItem> items = item.getItems("data");
					showStaffTree(items);
				} else if (what == GET_PASS_READ_REQ) {
					UIHelper.showMessage(mContext, message);
					PassReadChoosePeopleActivity.this.finish();
				}
			}
		}
	};

	private void returnResult() {
		String selected_people = tv_selected_people.getText().toString().trim();
		if (BeanUtils.isEmptyStrs(selected_people)) {
			UIHelper.showMessage(mContext, "请至少选择一个人员");
			return;
		}
		//提交选人数据
		ApiRequest request = OAServicesHandler.sendPassRead(documentId, userId, "", wfNo, "");
		if (request != null) {
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, GET_PASS_READ_REQ);
		}
	}

}
