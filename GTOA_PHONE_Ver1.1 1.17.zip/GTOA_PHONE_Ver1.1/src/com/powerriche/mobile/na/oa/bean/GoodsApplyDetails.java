package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;
import java.util.List;

/**
 * @title 物品申领详情实体类
 * @author dir_wang
 * @date 2016-6-29下午6:51:51
 */
public class GoodsApplyDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	private String receiveId;
	private String receiveTitle;
	private String receiveName;
	private String receiveTime;
	private String receiveDepartment;
	private String receiveType;
	private String receiveTypeName;
	private String goodsDetail;
	private String fpuNo;
	private String swfNo;
	private String wfNo;
	private String isPass;
	private String displaySaveButton;
	private String displaySendButton;
	private String displayAgreeButton;
	private String displayRefuseButton;
	private String displayFinishButton;
	private String documentId;
	// 申领明细
	private List<ApplyDetails> applyDetails;
	// 办理意见
	private List<TransactSuggestion> transactSuggestion;
	// 办理信息
	private List<TransactInfo> transactInfo;
	// 附件信息
	private List<DocFileInfo> fileList;

	public String getReceiveId() {
		return receiveId;
	}

	public void setReceiveId(String receiveId) {
		this.receiveId = receiveId;
	}

	public String getReceiveTitle() {
		return receiveTitle;
	}

	public void setReceiveTitle(String receiveTitle) {
		this.receiveTitle = receiveTitle;
	}

	public String getReceiveName() {
		return receiveName;
	}

	public void setReceiveName(String receiveName) {
		this.receiveName = receiveName;
	}

	public String getReceiveTime() {
		return receiveTime;
	}

	public void setReceiveTime(String receiveTime) {
		this.receiveTime = receiveTime;
	}

	public String getReceiveDepartment() {
		return receiveDepartment;
	}

	public void setReceiveDepartment(String receiveDepartment) {
		this.receiveDepartment = receiveDepartment;
	}

	public String getReceiveType() {
		return receiveType;
	}

	public void setReceiveType(String receiveType) {
		this.receiveType = receiveType;
	}

	public String getReceiveTypeName() {
		return receiveTypeName;
	}

	public void setReceiveTypeName(String receiveTypeName) {
		this.receiveTypeName = receiveTypeName;
	}

	public String getGoodsDetail() {
		return goodsDetail;
	}

	public void setGoodsDetail(String goodsDetail) {
		this.goodsDetail = goodsDetail;
	}

	public String getFpuNo() {
		return fpuNo;
	}

	public void setFpuNo(String fpuNo) {
		this.fpuNo = fpuNo;
	}
	
	public String getSwfNo() {
		return swfNo;
	}

	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}

	public String getWfNo() {
		return wfNo;
	}

	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}

	public String getIsPass() {
		return isPass;
	}

	public void setIsPass(String isPass) {
		this.isPass = isPass;
	}

	public String getDisplaySaveButton() {
		return displaySaveButton;
	}

	public void setDisplaySaveButton(String displaySaveButton) {
		this.displaySaveButton = displaySaveButton;
	}

	public String getDisplaySendButton() {
		return displaySendButton;
	}

	public void setDisplaySendButton(String displaySendButton) {
		this.displaySendButton = displaySendButton;
	}

	public String getDisplayAgreeButton() {
		return displayAgreeButton;
	}

	public void setDisplayAgreeButton(String displayAgreeButton) {
		this.displayAgreeButton = displayAgreeButton;
	}

	public String getDisplayRefuseButton() {
		return displayRefuseButton;
	}

	public void setDisplayRefuseButton(String displayRefuseButton) {
		this.displayRefuseButton = displayRefuseButton;
	}
	
	public String getDisplayFinishButton() {
		return displayFinishButton;
	}

	public void setDisplayFinishButton(String displayFinishButton) {
		this.displayFinishButton = displayFinishButton;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public List<ApplyDetails> getApplyDetails() {
		return applyDetails;
	}

	public void setApplyDetails(List<ApplyDetails> applyDetails) {
		this.applyDetails = applyDetails;
	}

	public List<TransactSuggestion> getTransactSuggestion() {
		return transactSuggestion;
	}

	public void setTransactSuggestion(
			List<TransactSuggestion> transactSuggestion) {
		this.transactSuggestion = transactSuggestion;
	}

	public List<TransactInfo> getTransactInfo() {
		return transactInfo;
	}

	public void setTransactInfo(List<TransactInfo> transactInfo) {
		this.transactInfo = transactInfo;
	}

	public List<DocFileInfo> getFileList() {
		return fileList;
	}

	public void setFileList(List<DocFileInfo> files) {
		this.fileList = files;
	}

	public class ApplyDetails implements Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = -5411760063782449171L;
		private String detailId;
		private String goods;
		private String counts;
		private String remark;
		
		public String getDetailId() {
			return detailId;
		}

		public void setDetailId(String detailId) {
			this.detailId = detailId;
		}

		public String getGoods() {
			return goods;
		}

		public void setGoods(String goods) {
			this.goods = goods;
		}

		public String getCounts() {
			return counts;
		}

		public void setCounts(String counts) {
			this.counts = counts;
		}

		public String getRemark() {
			return remark;
		}

		public void setRemark(String remark) {
			this.remark = remark;
		}

	}

}
