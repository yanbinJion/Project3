package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.SimpleAdapter.ViewBinder;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 任务信息：结果上报
 * 
 * @author 李运期
 * @date 2015年5月4日
 * @version v1.0
 */
public class TaskReplyActivity extends BaseActivity implements OnClickListener {

	private static final String TAG = "TaskReplyActivity";

	private int WHAT_IMAGE_OPEN = 1001;

	private Context mContext;

	private EditText etTaskContent;

	private GridView GridView_task_adjunct; // 网格显示缩略图
	private ArrayList<HashMap<String, ImageInfo>> imageItem;
	private SimpleAdapter simpleAdapter; // 适配器
	private Bitmap bmp; // 导入临时图片
	private String imagePath; // 图片路径

	private DialogInterface prepareDeleteDialog = null;//
	private int prepareDeleteImageIndex = -1;// 要删除的图片索引号

	private String taskId;// 任务ID
	private String documentId;// 任务上报关联的ID
	private String taskReportId;// 上报编号：为空添加，不为空修改
	private String reportContent;// 上报内容

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.task_reply);

		etTaskContent = (EditText) findViewById(R.id.et_task_report_content);

		taskId = getIntent().getStringExtra("taskId");// 任务的ID
		documentId = getIntent().getStringExtra("documentId");
		taskReportId = getIntent().getStringExtra("taskReportId");

		bindViews();

		// 获取控件对象
		GridView_task_adjunct = (GridView) findViewById(R.id.GridView_task_adjunct);
		GridView_task_adjunct.setVerticalScrollBarEnabled(false);
		GridView_task_adjunct.setCacheColorHint(Color.TRANSPARENT);
		GridView_task_adjunct.setFadingEdgeLength(0);
		GridView_task_adjunct.setSelector(android.R.color.transparent);

		initGridView();
	}

	private void initGridView() {
		/**
		 * 载入默认图片添加图片加号 通过适配器实现 SimpleAdapter参数imageItem为数据源
		 * R.layout.griditem_addpic为布局
		 */
		bmp = BitmapFactory.decodeResource(getResources(),
				R.drawable.gridview_addpic); // 加号
		imageItem = new ArrayList<HashMap<String, ImageInfo>>();
		HashMap<String, ImageInfo> map = new HashMap<String, ImageInfo>();
		map.put("itemImage", new ImageInfo(null, null, bmp));
		imageItem.add(map);

		simpleAdapter = new SimpleAdapter(this, imageItem,
				R.layout.task_reply_addpic, new String[]{"itemImage"},
				new int[]{R.id.imageView_task_adjunct});
		/**
		 * HashMap载入bmp图片在GridView中不显示,但是如果载入资源ID能显示 如 map.put("itemImage",
		 * R.drawable.img); 解决方法: 1.自定义继承BaseAdapter实现 2.ViewBinder()接口实现 参考
		 * http://blog.csdn.net/admin_/article/details/7257901
		 */
		simpleAdapter.setViewBinder(new ViewBinder() {
			@Override
			public boolean setViewValue(View view, Object data,
					String textRepresentation) {
				if (view instanceof ImageView && data instanceof ImageInfo) {
					ImageView iv = (ImageView) view;
					ImageInfo imageInfo = (ImageInfo) data;
					iv.setImageBitmap((Bitmap) imageInfo.fileBmp);
					return true;
				}
				return false;
			}
		});

		GridView_task_adjunct.setAdapter(simpleAdapter);

		/**
		 * GridView的Item点击事件
		 */
		GridView_task_adjunct.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View v,
					int position, long id) {
				if (position == 0) { // 点击图片位置为+ 0对应0张图片
					// 选择图片
					Intent intent = new Intent(
							Intent.ACTION_PICK,
							android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
					startActivityForResult(intent, WHAT_IMAGE_OPEN);
				} else {
					doShowBigImage(position);
				}
			}
		});
		/**
		 * GridView的Item长按事件
		 */
		GridView_task_adjunct
				.setOnItemLongClickListener(new OnItemLongClickListener() {
					@Override
					public boolean onItemLongClick(AdapterView<?> parent,
							View v, int position, long id) {
						if (position == 0) { // 点击图片位置为+ 0对应0张图片
						} else {
							doDeleteImage(position);
						}
						return true;
					}
				});
	}

	private void bindViews() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.task_report));
		topActivity.setBtnBackOnClickListener(this);

		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("提交");// 右边按钮文字：提交
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back :// 返回
				gotoDetailPage();
				finish();
				break;
			case R.id.btn_top_right :// 任务管理：上传结果
				if (doCheckData()) {// 验证
					doSubmitData();
				}
				break;
		}

	}

	/** 提交数据 */
	public void doSubmitData() {
		if (taskId == null || documentId == null) {
			return;
		}

		reportContent = etTaskContent.getText().toString();// 上报的内容

		taskReportId = (BeanUtils.isEmpty(taskReportId) ? "" : taskReportId);

		// 提交请求
		ApiRequest request = OAServicesHandler.reportTask(taskId, taskReportId,
				documentId, reportContent);
		if (request != null) {
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, savecallBack, 1001);
		}

	}

	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		if (BeanUtils.isEmpty(etTaskContent.getText().toString())) {// 上报内容
			Toast.makeText(TaskReplyActivity.this,
					getString(R.string.task_report_content_hint),
					Toast.LENGTH_SHORT).show();
			return false;
		}
		return true;// 验证通过
	}

	// 结果上报的回调
	private IRequestCallBack savecallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				Toast.makeText(context,
						getString(R.string.system_operation_success_message),
						Toast.LENGTH_SHORT).show();
				// 跳转到界面：详情界面
				gotoDetailPage();
			}
		}
	};

	/**
	 * 跳转到界面：详情界面
	 */
	public void gotoDetailPage() {
		// 封装交互数据
		Bundle data = new Bundle();
		data.putString("taskId", taskId);

		// 跳转到详情页面
		UIHelper.forwardTargetActivity(mContext, TaskDetailActivity.class,
				data, true);

		finish();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		// 打开图片
		if (resultCode == RESULT_OK && requestCode == WHAT_IMAGE_OPEN) {
			Uri uri = data.getData();
			if (!TextUtils.isEmpty(uri.getAuthority())) {
				// 查询选择图片
				Cursor cursor = getContentResolver().query(uri,
						new String[]{MediaStore.Images.Media.DATA}, null, null,
						null);
				// 返回 没找到选择图片
				if (null == cursor) {
					return;
				}
				// 光标移动至开头 获取图片路径
				cursor.moveToFirst();
				imagePath = cursor.getString(cursor
						.getColumnIndex(MediaStore.Images.Media.DATA));

				Log.e(TAG, "选中的文件  --->" + imagePath);
				Log.e(TAG, "执行上传  --->开始");
				doUploadImage(imagePath);
				Log.e(TAG, "执行上传  --->完毕");
			}
		}

	}

	// 执行图片上传
	private void doUploadImage(String filePath) {
		File file = new File(filePath);
		if (file != null && file.exists() && file.isFile()) {
			List<File> files = new ArrayList<File>();
			files.add(file);
			ApiRequest request = OAServicesHandler.uploadFile(documentId, "",
					"", files);
			if (request != null) {
				request.setMessage(getString(R.string.system_upload_file));
				new InvokeHelper(TaskReplyActivity.this).invokeWidthDialog(
						request, uploadcallBack, 12345);
			}
		}
	}

	// 上传图片的回调
	private IRequestCallBack uploadcallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (!BeanUtils.isEmpty(item)) {
				int code = item.getInt("code");
				String message = item.getString("message");
				String tempFileCode = item.getString("FILE_CODE");
				if (code == 0) {// 操作成功
					refurbishGridViewForAdd(imagePath, tempFileCode);
					if (message != null) {
						Toast.makeText(TaskReplyActivity.this, message,
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(
								TaskReplyActivity.this,
								getString(R.string.system_upload_file_success_message),
								Toast.LENGTH_SHORT).show();
					}
				} else {// 操作失败
					if (message != null) {
						Toast.makeText(TaskReplyActivity.this, message,
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(
								TaskReplyActivity.this,
								getString(R.string.system_upload_file_error_message),
								Toast.LENGTH_SHORT).show();
					}
				}
			} else {
				Toast.makeText(TaskReplyActivity.this,
						getString(R.string.system_upload_file_error_message),
						Toast.LENGTH_SHORT).show();
			}
		}
	};

	// 为新添加的图片刷新GridView
	private void refurbishGridViewForAdd(String imagePath, String imageCode) {
		if (!TextUtils.isEmpty(imagePath)) {

			// Log.e(TAG, "本地图片路径  --->" + imagePath);

			Bitmap addbmp = BitmapFactory.decodeFile(imagePath);
			HashMap<String, ImageInfo> map = new HashMap<String, ImageInfo>();
			map.put("itemImage", new ImageInfo(imageCode, imagePath, addbmp));
			imageItem.add(map);

			simpleAdapter = new SimpleAdapter(this, imageItem,
					R.layout.task_reply_addpic, new String[]{"itemImage"},
					new int[]{R.id.imageView_task_adjunct});
			simpleAdapter.setViewBinder(new ViewBinder() {
				@Override
				public boolean setViewValue(View view, Object data,
						String textRepresentation) {
					if (view instanceof ImageView && data instanceof ImageInfo) {
						ImageView iv = (ImageView) view;
						ImageInfo imageInfo = (ImageInfo) data;
						iv.setImageBitmap((Bitmap) imageInfo.fileBmp);
						return true;
					}
					return false;
				}
			});

			GridView_task_adjunct.setAdapter(simpleAdapter);
			simpleAdapter.notifyDataSetChanged();

			// 刷新后释放防止手机休眠后自动添加
			imagePath = null;
			imageCode = null;
		}
	}

	// 刷新图片
	@Override
	protected void onResume() {
		super.onResume();
	}

	/**
	 * 放大显示图片
	 */
	protected void doShowBigImage(final int position) {
		HashMap<String, ImageInfo> map = imageItem.get(position);
		ImageInfo imageInfo = map.get("itemImage");
		String localImagePath = imageInfo.localFilePath;// 本地图片路径

		if (!BeanUtils.isEmpty(localImagePath)) {
			File file = new File(localImagePath);
			if (file != null && file.exists() && file.isFile()) {
				// 封装交互数据
				Bundle data = new Bundle();
				data.putString("localImagePath", localImagePath);

				// 跳转到界面：查看大图
				UIHelper.forwardTargetActivity(mContext,
						TaskReplyShowBigImageActivity.class, data, false);
			}
		}

	}

	/**
	 * Dialog对话框提示用户删除操作 position为删除图片位置
	 */
	protected void doDeleteImage(final int position) {
		/** 移除图片 */
		AlertDialog.Builder builder = new Builder(TaskReplyActivity.this);
		builder.setMessage("您确定要移除已添加的图片吗？");
		builder.setTitle("提示");
		builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// dialog.dismiss();
				// imageItem.remove(position);
				// simpleAdapter.notifyDataSetChanged();

				prepareDeleteDialog = dialog;
				prepareDeleteImageIndex = position;

				HashMap<String, ImageInfo> map = imageItem.get(position);
				ImageInfo imageInfo = map.get("itemImage");
				String fileCode = imageInfo.fileCode;// 必须参数

				if (!BeanUtils.isEmpty(fileCode)) {
					ApiRequest request = OAServicesHandler.deleteFile(fileCode);
					if (request != null) {
						request.setMessage(getString(R.string.system_delete_file));
						new InvokeHelper(TaskReplyActivity.this)
								.invokeWidthDialog(request, deletecallBack,
										12345);
					}
				}

			}
		});
		builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.create().show();
	}

	// 删除图片的回调
	private IRequestCallBack deletecallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (!BeanUtils.isEmpty(item)) {
				int code = item.getInt("code");
				String message = item.getString("message");
				if (code == 0) {// 操作成功

					if (prepareDeleteDialog != null) {
						prepareDeleteDialog.dismiss();
					}
					if (prepareDeleteImageIndex != -1) {
						imageItem.remove(prepareDeleteImageIndex);
						simpleAdapter.notifyDataSetChanged();
					}

					if (message != null) {
						Toast.makeText(TaskReplyActivity.this, message,
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(
								TaskReplyActivity.this,
								getString(R.string.system_operation_success_message),
								Toast.LENGTH_SHORT).show();
					}
				} else {// 操作失败
					if (message != null) {
						Toast.makeText(TaskReplyActivity.this, message,
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(
								TaskReplyActivity.this,
								getString(R.string.system_operation_error_message),
								Toast.LENGTH_SHORT).show();
					}
				}
			} else {
				Toast.makeText(TaskReplyActivity.this,
						getString(R.string.system_operation_error_message),
						Toast.LENGTH_SHORT).show();
			}
		}
	};

	private class ImageInfo {
		public ImageInfo(String fileCode, String localFilePath, Bitmap fileBmp) {
			this.fileCode = fileCode;
			this.localFilePath = localFilePath;
			this.fileBmp = fileBmp;
		}

		public String fileCode;
		public String localFilePath;
		public Bitmap fileBmp;
	}

}
