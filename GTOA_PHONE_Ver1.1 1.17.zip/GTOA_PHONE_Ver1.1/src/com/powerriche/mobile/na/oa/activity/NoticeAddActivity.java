package com.powerriche.mobile.na.oa.activity;
		
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
		
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
		
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
		
/**		
 * 类描述：<br> 通知公告：发布（即新建）
 * 		
 * @author 李运期
 * @date 2015年5月3日
 * @version v1.0
 */		
public class NoticeAddActivity extends BaseActivity implements OnClickListener, OnCheckedChangeListener {
		
	private static final String	TAG	= "NoticeAddActivity";
		
	private static final int REQUEST_WHAT_TO_CHOOSE_PERSON = 1001;
		
	private Context				mContext;
		
	private TopActivity			topActivity;
	private Button				mBtnRight;
		
	//基本信息界面相关
	private EditText			etNoticeTitle;
	private RadioGroup			rgNoticeType;
	private RadioButton			rbtnTZ, rbtnGG;
	private EditText			etNoticeToStaffNo;
	private EditText			etNoticeToStaffNoName;
	private EditText			etNoticeBeginTime;
	private EditText			etNoticeEndTime;
	private EditText			etNoticeContent;
	private LinearLayout		llNoticeToStaffNo;
		
	private String				noticeId, noticeType;
	private String				noticeTitle;
	private String				noticeContent;
	private String				noticeToStaffNo;
	private String				noticeBeginTime, noticeEndTime;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.notice_add);
		
		noticeId = null;//通知公告的ID
		
		String datestr = DateUtils.getDateStr(new Date(), DateUtils.DATE_FORMAT);
		
		etNoticeTitle = (EditText) findViewById(R.id.et_notice_title);
		etNoticeToStaffNo = (EditText) findViewById(R.id.et_notice_to_staffno);
		etNoticeToStaffNoName = (EditText) findViewById(R.id.et_notice_to_staffno_name);
		etNoticeToStaffNoName.setOnClickListener(this);
		
		etNoticeBeginTime = (EditText) findViewById(R.id.et_notice_begin_time);
		etNoticeBeginTime.setOnClickListener(this);
		etNoticeBeginTime.setText(datestr); // 当前系统时间
		
		etNoticeEndTime = (EditText) findViewById(R.id.et_notice_end_time);
		etNoticeEndTime.setOnClickListener(this);
		etNoticeEndTime.setText(datestr); // 当前系统时间
		
		etNoticeContent = (EditText) findViewById(R.id.et_notice_content);
		llNoticeToStaffNo = (LinearLayout) findViewById(R.id.ll_notice_to_staffno);
		
		rbtnTZ = (RadioButton) this.findViewById(R.id.radio_tongzhi);
		rbtnTZ.setChecked(true);
		rbtnGG = (RadioButton) this.findViewById(R.id.radio_gonggao);
		
		noticeType = "1";//通知公告的类型。默认值：通知
		rgNoticeType = (RadioGroup) findViewById(R.id.radioGroup_notice_type);
		rgNoticeType.setOnCheckedChangeListener(this);
		
		bindViews();
	}	
		
	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.menu_notice));
		topActivity.setBtnBackText(getString(R.string.notice_right_cancel));
		topActivity.setBtnBackOnClickListener(this);
		
		mBtnRight = topActivity.getBtnRight();
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("发布");//右边按钮文字：发布
	}	
		
	/** 提交数据 */
	public void doSubmitData() {
		if (noticeType == null) {
			return;
		}
		
		noticeTitle = etNoticeTitle.getText().toString();//标题
		noticeToStaffNo = etNoticeToStaffNo.getText().toString();//被通知人的ID
		noticeBeginTime = etNoticeBeginTime.getText().toString();//开始时间
		noticeEndTime = etNoticeEndTime.getText().toString();//结束时间
		noticeContent = etNoticeContent.getText().toString();//通知公告的内容
		
		ApiRequest request;
		int what;
		if ("0".equals(noticeType)) {//类型：公告，被通知人的ID传空值
			request = OAServicesHandler.editNoticeDetials(noticeId, 0, noticeTitle, "", noticeBeginTime, noticeEndTime, noticeContent, Constants.OPT_TYPE_TZGG_ADD);
			what = 1002;
			
		} else {//类型：通知
			request = OAServicesHandler.editNoticeDetials(noticeId, 1, noticeTitle, noticeToStaffNo, noticeBeginTime, noticeEndTime, noticeContent, Constants.OPT_TYPE_TZGG_ADD);
			what = 1003;
		}	
			
		request.setMessage(getString(R.string.system_commit_message));
		helper.invokeWidthDialog(request, savecallBack, what);
	}		
			
	/** 验证数据：提交之前进行验证 */
	public boolean doCheckData() {
		if (BeanUtils.isEmpty(etNoticeTitle.getText().toString())) {//标题
			UIHelper.showMessage(mContext, getString(R.string.required_tip_notice_title));
			return false;
		}	
		if ("1".equals(noticeType)) {//类型：通知
			if (BeanUtils.isEmpty(etNoticeToStaffNo.getText().toString())) {//被通知人的ID
				UIHelper.showMessage(mContext, getString(R.string.required_tip_notice_to_staffno));
				return false;
			}
		}	
		if (BeanUtils.isEmpty(etNoticeBeginTime.getText().toString())) {//开始时间
			UIHelper.showMessage(mContext, getString(R.string.required_tip_notice_begin_time));
			return false;
		}	
			
		if (BeanUtils.isEmpty(etNoticeEndTime.getText().toString())) {//结束时间
			UIHelper.showMessage(mContext, getString(R.string.required_tip_notice_end_time));
			return false;
		}	
			
		if (BeanUtils.isEmpty(etNoticeContent.getText().toString())) {//通知内容
			UIHelper.showMessage(mContext, getString(R.string.required_tip_notice_content));
			return false;
		}	
			
		//检验时间范围
		Date begindate = DateUtils.parseDate(etNoticeBeginTime.getText().toString() + " 00:00:00", "yyyy-MM-dd HH:mm:ss");
		if (begindate == null) {
			UIHelper.showMessage(mContext, getString(R.string.error_tip_notice_begin_time));
			return false;
		}	
			
		Date enddate = DateUtils.parseDate(etNoticeEndTime.getText().toString() + " 23:59:59", "yyyy-MM-dd HH:mm:ss");
		if (enddate == null) {
			UIHelper.showMessage(mContext, getString(R.string.error_tip_notice_end_time));
			return false;
		}	
			
		if (enddate.before(begindate)) {
			UIHelper.showMessage(mContext, getString(R.string.error_tip_between_notice_time));
			return false;
		}	
			
		return true;
	}		
			
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back:// 返回
				// 跳转到界面：通知公告的列表
				gotoListPage();
				break;
				
			case R.id.btn_top_right:// 标题栏的右边按钮
				if ("发布".equals(mBtnRight.getText())) {
					if (doCheckData()) {//验证
						doSubmitData();
					}
				}
				break;
				
			case R.id.et_notice_to_staffno_name:// 通知公告：被通知人
				Bundle data = new Bundle();
				data.putString(ChoosePeoplesActivity.KEY_CUSTOM_TITLE, "请选择被通知人");
				data.putBoolean(ChoosePeoplesActivity.KEY_IS_MULTIPLE_SELECT, true); //可以多选
				ArrayList<String> staffnoList = new ArrayList<String>(Arrays.asList(etNoticeToStaffNo.getText().toString().split(",")));
				data.putStringArrayList(ChoosePeoplesActivity.KEY_USER_IDS_INIT, staffnoList); //初始化界面时，已经选中的人员ID
				UIHelper.forwardTargetActivityForResult(this, ChoosePeoplesActivity.class, data, false, REQUEST_WHAT_TO_CHOOSE_PERSON);
				break;
				
			case R.id.et_notice_begin_time:// 通知公告：开始时间
				UIHelper.showTimeSelect(mContext, etNoticeBeginTime,DateUtils.DATE_FORMAT);
				break;
				
			case R.id.et_notice_end_time:// 通知公告：结束时间
				UIHelper.showTimeSelect(mContext, etNoticeEndTime,DateUtils.DATE_FORMAT);
				break;
		}		
				
	}			
				
	@Override	
	public void onCheckedChanged(RadioGroup rg, int checkedId) {
		if (checkedId == rbtnTZ.getId()) {//选中：通知
			noticeType = "1";//通知公告的类型
			llNoticeToStaffNo.setVisibility(View.VISIBLE);//显示
			rgNoticeType.setTag(rbtnTZ.getText().toString());
		} else if (checkedId == rbtnGG.getId()) {//选中：公告
			noticeType = "0";//通知公告的类型
			llNoticeToStaffNo.setVisibility(View.GONE);//隐藏
			rgNoticeType.setTag(rbtnGG.getText().toString());
		} else {
			noticeType = "1";//通知公告的类型
			llNoticeToStaffNo.setVisibility(View.VISIBLE);//显示
			rgNoticeType.setTag(rbtnTZ.getText().toString());
		}		
	}			
				
	@Override	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// 选择被通知人返回
		if (REQUEST_WHAT_TO_CHOOSE_PERSON == requestCode && data != null) {
			try {
//				String ids = data.getStringExtra(ChoosePeoplesActivity.KEY_USER_IDS_STRING);
//				String names = data.getStringExtra(ChoosePeoplesActivity.KEY_USER_NAMES_STRING);
				String ids = data.getStringExtra("staffNo");
				String names = data.getStringExtra("name");
				Log.i("TEST", " names "+names+" ids "+ids);
				//验证返回的数据是否正确
				if (names == null || ids == null || names.isEmpty() || ids.isEmpty()) {//不正确
					etNoticeToStaffNo.setText("");//被通知人的ID
					etNoticeToStaffNoName.setText("");//被通知人的姓名
				} else {//正确
					etNoticeToStaffNo.setText(ids);//被通知人的ID
					etNoticeToStaffNoName.setText(names);//被通知人的姓名
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
	private IRequestCallBack savecallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String message = item.getString("message");
				if (message != null) {
					UIHelper.showMessage(mContext, message);
					
				} else {
					UIHelper.showMessage(mContext, getString(R.string.system_operation_success_message));
				}
				// 跳转到界面：通知公告的列表
				gotoListPage();
			}
		}
	};
	
	
	/**
	 * 跳转到界面：通知公告的列表
	 */
	public void gotoListPage() {
		UIHelper.forwardTargetActivity(mContext, NoticeListActivity.class, null, true);
		finish();
	}

}
