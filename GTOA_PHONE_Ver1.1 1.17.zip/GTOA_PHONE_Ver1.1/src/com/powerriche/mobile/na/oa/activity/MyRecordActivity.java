package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.RecordListAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.bean.Attendance;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

public class MyRecordActivity extends BaseActivity implements View.OnClickListener {
	private static final int ATTENDANCE_RECORD_LIST = 0;
	private static final int ATTENDANCE_CONFIG = 1;
	private TopActivity topActivity;
	private PullToRefreshListView lv_attendance_record;
	private TextView tv_no_data_attendance_record;
	private String staffNo;
	private String beginTime, endTime;
	private RecordListAdapter adapter;
	private ListView listView;
	private List<Attendance> mListData = new ArrayList<Attendance>();
	private int pageIndex = 1;
	private String morningStartWorkTime;
	private String morningEndWorkTime;
	private String afternoonStartWorkTime;
	private String afternoonEndWorkTime;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attendance_record_list);
		Intent intent = getIntent();
		if(intent != null) {
			staffNo = intent.getExtras().getString("staffNo");
			beginTime = intent.getExtras().getString("beginTime");
			endTime = intent.getExtras().getString("endTime");
		}
		initView();
		initData();
	}
	
	
	private void getAttendanceConfig() {
		ApiRequest request = OAServicesHandler.getAttendanceConfig();
		helper.invoke(request, callBack, ATTENDANCE_CONFIG);
	}
	
	// 显示当前考勤配置信息
	private void showAttendanceConfig(ResultItem result) {
		if (result == null) {
			return;
		}
		// 上午签到时间
		morningStartWorkTime = result.getString("AM_IN_WORKING_TIME") + ":00";
		// 上午签退时间
		morningEndWorkTime = result.getString("AM_OFF_WORKING_TIME") + ":00";
		// 下午签到时间
		afternoonStartWorkTime = result.getString("PM_IN_WORKING_TIME") + ":00";
		// 下午签退时间
		afternoonEndWorkTime = result.getString("PM_OFF_WORKING_TIME") + ":00";
		setDataState();
	}
	
	// 显示当前人的考勤列表
	private void showAttendanceList(List<ResultItem> resultSet) {
		if (!BeanUtils.isEmpty(resultSet)) {
			for (ResultItem resultItem : resultSet) {
				Attendance attendance = new Attendance();
				attendance.setAttendDate(resultItem.getString("ATTEND_DATE"));
				attendance.setMorningSignIn(resultItem.getString("MORNING_SIGN_IN"));
				attendance.setMorningSignInTime(resultItem.getString("MORNING_SIGN_IN_TIME"));
				attendance.setMorningSignInAddress(resultItem.getString("MORNING_SIGN_IN_ADDRESS"));
				attendance.setMorningSignOut(resultItem.getString("MORNING_SIGN_OUT"));
				attendance.setMorningSignOutTime(resultItem.getString("MORNING_SIGN_OUT_TIME"));
				attendance.setMorningSignOutAddress(resultItem.getString("MORNING_SIGN_OUT_ADDRESS"));
				attendance.setAfternoonSignIn(resultItem.getString("AFTERNOON_SIGN_IN"));
				attendance.setAfternoonSignInTime(resultItem.getString("AFTERNOON_SIGN_IN_TIME"));
				attendance.setAfternoonSignInAddress(resultItem.getString("AFTERNOON_SIGN_IN_ADDRESS"));
				attendance.setAfternoonSignOut(resultItem.getString("AFTERNOON_SIGN_OUT"));
				attendance.setAfternoonSignOutTime(resultItem.getString("AFTERNOON_SIGN_OUT_TIME"));
				attendance.setAfternoonSignOutAddress(resultItem.getString("AFTERNOON_SIGN_OUT_ADDRESS"));
				mListData.add(attendance);
			}
		}
		setDataState();
		if(!BeanUtils.isEmpty(mListData)) {
			if (adapter == null) {
				adapter = new RecordListAdapter(MyRecordActivity.this, mListData);
				listView.setAdapter(adapter);
			} else {
				adapter.notifyDataSetChanged();
				tv_no_data_attendance_record.setVisibility(View.GONE);
			}
		} else {
			tv_no_data_attendance_record.setVisibility(View.VISIBLE);
		}
		if (BeanUtils.isEmpty(resultSet) || resultSet.size() < Constants.RECORD_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			if (BeanUtils.isEmpty(resultSet)) {
				tv_no_data_attendance_record.setVisibility(View.VISIBLE);
			}
			lv_attendance_record.onPullDownRefreshComplete();
			lv_attendance_record.onPullUpRefreshComplete();
			lv_attendance_record.setHasMoreData(false);
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			lv_attendance_record.onPullDownRefreshComplete();
			lv_attendance_record.onPullUpRefreshComplete();
			lv_attendance_record.setHasMoreData(true);
		}
	}
	// 设置上午下午签到签退状态
	private void setDataState() {
		if (!BeanUtils.isEmpty(mListData)) {
			for (int i = 0; i < mListData.size(); i++) {
				String morningSignInTime = mListData.get(i).getMorningSignInTime();
				String morningSignOutTime = mListData.get(i).getMorningSignOutTime();
				String afternoonSignInTime = mListData.get(i).getAfternoonSignInTime();
				String afternoonSignOutTime = mListData.get(i).getAfternoonSignOutTime();
				setMorningState(i, morningSignInTime, morningSignOutTime);
				setAfternoonState(i, afternoonSignInTime, afternoonSignOutTime);
			}
		}
	}

	// 上午签到签退状态
	private void setMorningState(int position, String morningSignInTime,
			String morningSignOutTime) {
		if (!BeanUtils.isNullOrEmpty(morningSignInTime) && morningSignInTime.contains(" ")) {
			morningSignInTime = morningSignInTime.split(" ")[1];
			boolean flag = morningSignInTime.compareTo(morningStartWorkTime) >= 0;
			mListData.get(position).setMorningSignInState(!flag ? "正常上班" : "迟到");
			mListData.get(position).setMorningSignInFlag(flag);
		}
		if(!BeanUtils.isNullOrEmpty(morningSignOutTime) && morningSignOutTime.contains(" ")) {
			morningSignOutTime = morningSignOutTime.split(" ")[1];
			boolean flag = morningSignOutTime.compareTo(morningEndWorkTime) >= 0;
			mListData.get(position).setMorningSignOutState(flag ? "正常下班" : "早退");
			mListData.get(position).setMorningSignOutFlag(flag);
		}
	}
	
	// 下午签到签退状态
	private void setAfternoonState(int position, String afternoonSignInTime,
			String afternoonSignOutTime) {
		if (!BeanUtils.isNullOrEmpty(afternoonSignInTime) && afternoonSignInTime.contains(" ")) {
			afternoonSignInTime = afternoonSignInTime.split(" ")[1];
			boolean flag = afternoonSignInTime.compareTo(afternoonStartWorkTime) >= 0;
			mListData.get(position).setAfternoonSignInState(!flag ? "正常上班" : "迟到");
			mListData.get(position).setAfternoonSignInFlag(flag);
		}
		if (!BeanUtils.isNullOrEmpty(afternoonSignOutTime) && afternoonSignOutTime.contains(" ")) {
			afternoonSignOutTime = afternoonSignOutTime.split(" ")[1];
			boolean flag = afternoonSignOutTime.compareTo(afternoonEndWorkTime) >= 0;
			mListData.get(position).setAfternoonSignOutState(flag ? "正常下班" : "早退");
			mListData.get(position).setAfternoonSignOutFlag(flag);
		}
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			String code = resultItem.getString("code");
			String message = resultItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(MyRecordActivity.this, message);
				return;
			}
            if (ATTENDANCE_RECORD_LIST == what) {
                List<ResultItem> resultSet = resultItem.getItems("data");
                showAttendanceList(resultSet);
            } else if (ATTENDANCE_CONFIG == what) {
            	showAttendanceConfig(resultItem);
            }
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(MyRecordActivity.this, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};
	
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(SystemContext.getUserName() + getString(R.string.attendance_my_record));// 顶部栏的中间标题
		lv_attendance_record = (PullToRefreshListView) findViewById(R.id.lv_attendance_record);
		lv_attendance_record.setPullRefreshEnabled(true);
		lv_attendance_record.setPullLoadEnabled(false);
		lv_attendance_record.setScrollLoadEnabled(true);
		listView = lv_attendance_record.getRefreshableView();
		UIHelper.setListViewAttribute(listView);
		tv_no_data_attendance_record = (TextView) findViewById(R.id.tv_no_data_attendance_record);
	}
	
	private void initData() {
		lv_attendance_record.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
				if (!BeanUtils.isEmpty(mListData)) {
					mListData.clear();
				}
				pageIndex = 1;
				loadData(ATTENDANCE_RECORD_LIST, pageIndex, false);
				getAttendanceConfig();
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
				pageIndex = pageIndex + 1;
				loadData(ATTENDANCE_RECORD_LIST, pageIndex, false);
				getAttendanceConfig();
			}
		});
		loadData(ATTENDANCE_RECORD_LIST, pageIndex, true);
		getAttendanceConfig();
	}
	
	// 查看当前人的考勤记录
	private void loadData(int what, int index, boolean isDialog) {
		ApiRequest request = OAServicesHandler.getAttendanceList(beginTime, endTime, staffNo, index);
		if (request != null) {
			if (isDialog) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}

	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			MyRecordActivity.this.finish();
			break;
		default:
			break;
		}
	}
	
}
