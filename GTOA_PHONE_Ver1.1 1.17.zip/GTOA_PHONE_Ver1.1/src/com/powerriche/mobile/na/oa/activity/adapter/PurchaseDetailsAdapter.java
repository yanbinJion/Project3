package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.PurchaseApply;

import java.util.ArrayList;
import java.util.List;

/**
 * @title  申购明细列表
 * @author dir_wang
 * @date   2016-7-4下午8:36:29
 */
public class PurchaseDetailsAdapter extends BaseAdapter{

    private Context mContext;
    private ArrayList<PurchaseApply.PurchaseDetail> data = new ArrayList<PurchaseApply.PurchaseDetail>();

    public PurchaseDetailsAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
    	
        ViewHolder holder = null;
        if (null == view) {
            holder = new ViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.purchase_details_item, null);
            holder.tv_purchase_goods = (TextView) view.findViewById(R.id.tv_purchase_goods);
            holder.tv_purchase_goods_name = (TextView) view.findViewById(R.id.tv_purchase_goods_name);
            holder.tv_purchase_remark = (TextView) view.findViewById(R.id.tv_purchase_remark);
            holder.tv_purchase_counts = (TextView) view.findViewById(R.id.tv_purchase_counts);
            holder.tv_purchase_unit = (TextView) view.findViewById(R.id.tv_purchase_unit);
            holder.tv_purchase_price = (TextView) view.findViewById(R.id.tv_purchase_price);
            holder.tv_purchase_total = (TextView) view.findViewById(R.id.tv_purchase_total);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        PurchaseApply.PurchaseDetail details = data.get(position);
        holder.tv_purchase_goods.setText("物品" + (position + 1));
        holder.tv_purchase_goods_name.setText(details.getPurchaseName());
        holder.tv_purchase_remark.setText(details.getSpec());
        holder.tv_purchase_counts.setText(details.getQuantity());
        holder.tv_purchase_unit.setText(details.getUnit());
        holder.tv_purchase_price.setText(details.getUnitPrice());
        holder.tv_purchase_total.setText(details.getTotalPrice());
        return view;
    }

    private class ViewHolder {
    	private TextView tv_purchase_goods;
    	private TextView tv_purchase_goods_name;
    	private TextView tv_purchase_remark;
    	private TextView tv_purchase_counts;
    	private TextView tv_purchase_unit;
    	private TextView tv_purchase_price;
    	private TextView tv_purchase_total;
    }

    /**
     * 添加数据
     */
    public void addData(List<PurchaseApply.PurchaseDetail> dataList){
        if (null != dataList) {
            this.data.addAll(dataList);
        }
    }

    public void clearListData(){
        if (data != null){
            data.clear();
        }
    }
}
