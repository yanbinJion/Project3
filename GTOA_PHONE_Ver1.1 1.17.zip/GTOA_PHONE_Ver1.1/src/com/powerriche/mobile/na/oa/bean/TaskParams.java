package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

import com.powerriche.mobile.oa.common.ResultItem;

/**
 * 类描述：<br>
 * 办理送出传递参数
 * 
 * @author WangZheng
 * @date 2016年5月13日
 * @version v1.0
 */
public class TaskParams implements Serializable {
	private static final long serialVersionUID = 6215326588171350393L;
    private String taskId;
	private String traceNo;
	private String documentId;
	private String wfNo;
	private String swfNo;
	private String staffNo;
	private String nextFpuNo;
	private String notes;
	private String isSendMessage;
    private String toStaffNo;
	private ResultItem resultItem;

	public TaskParams() {

	}

	public TaskParams(String traceNo, String documentId, String wfNo,
			String swfNo, String nextFpuNo) {
		this.traceNo = traceNo;
		this.documentId = documentId;
		this.wfNo = wfNo;
		this.swfNo = swfNo;
		this.nextFpuNo = nextFpuNo;
	}

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTraceNo() {
		return traceNo;
	}

	public void setTraceNo(String traceNo) {
		this.traceNo = traceNo;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getWfNo() {
		return wfNo;
	}

	public void setWfNo(String wfNo) {
		this.wfNo = wfNo;
	}

	public String getSwfNo() {
		return swfNo;
	}

	public void setSwfNo(String swfNo) {
		this.swfNo = swfNo;
	}

	public String getStaffNo() {
		return staffNo;
	}

	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}

	public String getNextFpuNo() {
		return nextFpuNo;
	}

	public void setNextFpuNo(String nextFpuNo) {
		this.nextFpuNo = nextFpuNo;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getIsSendMessage() {
		return isSendMessage;
	}

	public void setIsSendMessage(String isSendMessage) {
		this.isSendMessage = isSendMessage;
	}

    public String getSendMessage() {
        return isSendMessage;
    }

    public void setSendMessage(String sendMessage) {
        isSendMessage = sendMessage;
    }

    public String getToStaffNo() {
        return toStaffNo;
    }

    public void setToStaffNo(String toStaffNo) {
        this.toStaffNo = toStaffNo;
    }

    public ResultItem getResultItem() {
		return resultItem;
	}

	public void setResultItem(ResultItem resultItem) {
		this.resultItem = resultItem;
	}

    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer("TaskParams:");
        buffer.append("traceNo:\t").append(traceNo);
        buffer.append("documentId:\t").append(documentId);
        buffer.append("wfNo:\t").append(wfNo);
        buffer.append("swfNo:\t").append(swfNo);
        buffer.append("nextFpuNo:\t").append(nextFpuNo);
        buffer.append("notes:\t").append(notes);
        buffer.append("toStaffNo:\t").append(toStaffNo);
        return buffer.toString();
    }

}
