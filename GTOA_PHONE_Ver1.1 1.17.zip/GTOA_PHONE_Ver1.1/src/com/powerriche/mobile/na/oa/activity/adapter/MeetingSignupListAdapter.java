package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.MeetDetailActivity;
import com.powerriche.mobile.na.oa.activity.document.MeetDetailHelper;
import com.powerriche.mobile.na.oa.bean.SignUpInfo;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.Logger;

/**
 * 类描述：<br> 
 * 办理信息list
 * @author  Fitz
 * @date    2015年4月29日
 * @version v1.0
 */
public class MeetingSignupListAdapter extends BaseAdapter implements OnClickListener{

	private Context mContext = null;
	private LayoutInflater inflater;
	private List<SignUpInfo> dataList;
	private MeetDetailHelper helper;
	
	
	private boolean isDel = false;

	public MeetingSignupListAdapter(Context context,boolean isDel, MeetDetailHelper helper) {
		this.mContext = context;
		this.helper = helper;
		
		this.inflater = LayoutInflater.from(this.mContext);
		this.dataList = new ArrayList<SignUpInfo>();
		this.isDel = isDel;
	}

	
	@Override
	public void onClick(View v) {
		//删除一条数据
		if(v.getId() == R.id.im_del_line){
			SignUpInfo bean = (SignUpInfo) v.getTag();
			removeData(bean.getPosition());
			this.notifyDataSetChanged();
			if(!BeanUtils.isEmpty(bean.getSignUpId())){
				this.helper.delSignUp(bean.getSignUpId(), MeetDetailActivity.CODE_DELETE_SIGNUP);
			}
		}
	}
	

	@Override
	public int getCount() {
		return dataList.size();
	}

	@Override
	public Object getItem(int position) {
		return dataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		ViewHolder holder = null;
        if (view == null) {
        	holder = new ViewHolder();
        	view = inflater.inflate(R.layout.meet_sign_up_item, null);
        	holder.tvAttender = (TextView) view.findViewById(R.id.tv_conventioner);
        	holder.tvDepartment = (TextView) view.findViewById(R.id.tv_conventionerRole);
        	holder.tvContent = (EditText) view.findViewById(R.id.et_summary);
            holder.tvContactTel = (EditText) view.findViewById(R.id.et_contactTel);
            holder.delBtn = (ImageView) view.findViewById(R.id.im_del_line);
            view.setTag(holder);
            
        } else {
        	holder = (ViewHolder) view.getTag();
        }
        
        //如果不能删除，这隐藏删除按钮
        holder.delBtn.setVisibility(isDel?View.VISIBLE:View.GONE);
        holder.delBtn.setOnClickListener(this);
        
        SignUpInfo bean = dataList.get(position);
        bean.setPosition(position);
        
        holder.tvAttender.setText(bean.getConventioner());
        holder.tvDepartment.setText(bean.getConventionerRole());
        String temp = bean.getContactTel();
        if(BeanUtils.isEmpty(temp)){
        	temp = "暂无";
        }
        holder.tvContactTel.setText(temp);
        holder.tvContactTel.setTag(bean);	//手机号编辑
        holder.tvContactTel.setOnFocusChangeListener(new MyFocusChangeListener(true));
        
        holder.tvContent.setText(bean.getSummary());	//备注信息编辑
        holder.tvContent.setTag(bean);
        holder.tvContent.setOnFocusChangeListener(new MyFocusChangeListener(false));
        
        holder.delBtn.setTag(bean);
		return view;
	}

	class MyFocusChangeListener implements View.OnFocusChangeListener{	//失去焦点，设置编辑后的值
		private boolean flag;	//flag=true?"电话号码编辑":"备注信息编辑"
		public MyFocusChangeListener(boolean flag){
			this.flag = flag;
		}
		
		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			try{
				SignUpInfo tag = (SignUpInfo) v.getTag();
				String txt = ((EditText) v).getText().toString();
				if(hasFocus) {// 此处为得到焦点时的处理内容
					
				} else {// 此处为失去焦点时的处理内容
					if(flag){
						dataList.get(tag.getPosition()).setContactTel(txt);	//设置编辑后的值
					}else{
						dataList.get(tag.getPosition()).setSummary(txt);	//设置编辑后的值
					}
				}
			}catch(Exception e){
				Logger.e("MeetingSignupListAdapter", e.getMessage());
			}
		}
	};
	
	
	/**
	 * 添加数据
	 * @param groupList
	 * @param userList
	 */
	public void addData(List<SignUpInfo> dataList){
		this.dataList.addAll(dataList);
	}
	
	/**
	 * 返回列表数据
	 * @return
	 */
	public List<SignUpInfo> getSignUpList(){
		return dataList;
	}
	
	public void clearListData(){
		if(dataList!=null){
			dataList.clear();
		}
	}
	
	public void removeData(int position){
		dataList.remove(position);
	}
	
	private class ViewHolder{
		TextView tvAttender, tvDepartment;
		EditText  tvContactTel, tvContent;
		ImageView delBtn;
	}
	
}
