package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 部门编号
 * 
 * @author Fitz
 * @date 2015年4月25日
 * @version v1.0
 */
public class DepartmentInfo {

	public DepartmentInfo() {
	}

	public DepartmentInfo(String siteNo, String siteName) {
		this.siteNo = siteNo;
		this.siteName = siteName;
	}

	public DepartmentInfo(String siteNo, String siteName, int siteStatus) {
		this.siteNo = siteNo;
		this.siteName = siteName;
		this.siteStatus = siteStatus;
	}

	private String	siteNo;				//部门编号
	private String	siteName;			//部门名称
	private int	siteStatus	= 0;	//部门下的员工选中状态：0全部未选中，1全部选中，2部分选中

	public String getSiteNo() {
		return siteNo;
	}

	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public int getSiteStatus() {
		return siteStatus;
	}

	public void setSiteStatus(int siteStatus) {
		this.siteStatus = siteStatus;
	}

}
