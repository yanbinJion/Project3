package com.powerriche.mobile.na.oa.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.ContentView;
import com.powerriche.mobile.na.oa.view.GestureDrawl.GestureCallBack;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UserHelper;

/**
 * Filename : SetGesturesPasswordActivity
 * 
 * @Description : 设置手势密码
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-22 17:50:00
 */
public class SetGesturesPasswordActivity extends BaseActivity {

	private FrameLayout gesturespwdLayout;

	private ContentView content;

	private UserHelper userHelper = null;

	private TextView msgView;
	
	/** 操作次数 */
	private int successNumber = 1;

	//忘记手势密码进入
	private boolean isForgetGestures  = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gestures_password);
		((RelativeLayout) findViewById(R.id.user_name_layout)).setVisibility(View.GONE);
		findViewById(R.id.tv_forget_pass).setVisibility(View.GONE);
		findViewById(R.id.tv_change_user).setVisibility(View.GONE);
		
		gesturespwdLayout = (FrameLayout) findViewById(R.id.gesturespwd_layout);
		msgView = (TextView) findViewById(R.id.pwdMsgView);
		msgView.setText(R.string.gesturespassword_seting_title);
		// 初始化一个显示各个点的viewGroup
		content = new ContentView(Constants.GESTURES_OPTTYPE_SETPWD, this,
				null, new GestureCallBack() {
					@Override
					public void checkedSuccess() {
						content.clearAll();//清除页面所有的画线
						msgView.setText(R.string.gesturespassword_set_again);
						msgView.setTextColor(Color.parseColor(getString(R.color.white)));
						successNumber++;
					}

					@Override
					public void checkedFail() {
						// 如果等于1，表示密码第一次设置就没有成功过，就失败，提示：必须大于几个点
						if (successNumber == 1) {
							msgView.setText(R.string.gesturespassword_min_points);
						} else {
							msgView.setText(R.string.gesturespassword_set_notsame);
							successNumber = 1;
						}
						msgView.setTextColor(Color.parseColor(getString(R.color.red)));
					}

					@Override
					public void checkedSuccessBack(String param) {
						msgView.setText(R.string.gesturespassword_set_success);
						msgView.setTextColor(Color.parseColor(getString(R.color.white)));
						userHelper = new UserHelper();
						ResultItem userItem = userHelper.getLastUserInfo();
						//删除旧的手势密码
						userHelper.delGesturesCodeByUserId(userItem.getString("USERID"));
						//保存新的手势密码
						userHelper.setGesturesCode(userItem.getString("USERID"), param, true);
						//忘记密码进来的时候，跳转到首页
						if(isForgetGestures){
							
							toMain();
						}else{
							toUserAccountSecurity();// 跳转到“账户安全”界面
						}
					}
				});
		// 设置手势解锁显示到哪个布局里面
		content.setParentView(gesturespwdLayout);
		isForgetGestures = getIntent().getBooleanExtra("isForgetGestures", false);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if(isForgetGestures){
				finish();
			}else{
				toUserAccountSecurity();// 跳转到“账户安全”界面
			}
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
	// 调转到帐号安全页面
	public void toLogin() {
		UIHelper.forwardTargetActivity(SetGesturesPasswordActivity.this,
				LoginGesturesPasswordActivity.class, null, true);
	}
	//跳转到首页
	public void toMain() {
		Intent intent = new Intent(SetGesturesPasswordActivity.this, MainActivity.class);
		startActivityForResult(intent, 123456);
		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	}

	// 调转到帐号安全页面
	public void toUserAccountSecurity() {
		UIHelper.forwardTargetActivity(SetGesturesPasswordActivity.this,
				UserAccountSecurityActivity.class, null, true);
	}

}
