package com.powerriche.mobile.na.oa.down;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.os.Handler;
import android.os.Message;

/**
 * 类描述：<br> 
 * 下载管理类<br>
 * 功能: 创建下载任务, 保存下载任务, 通知界面下载状态, 更新下载任务
 * @author  Miter
 * @date    2013-12-17
 */
public class DownloadManager implements UIEvent {

	public static final int MSG_DOWNLOAD_STATE_CHANGE = 2;
	public static final int MSG_DOWNLOAD_UPDATE_PROGRESS = 3;
	public static final int MSG_DOWNLOAD_STATE_ERROR = 4;

	private static DownloadManager mInstance;
	

	/**
	 * 界面通知Handler
	 */
	public ArrayList<Handler> mHandlerList = new ArrayList<Handler>();
	
	/**
	 * 根据下载地址，保存下载任务的map集合
	 */
	private Map<String,DownloadTask> downloadTaskMap = new HashMap<String,DownloadTask>();
	
	
	
	DownloadTask getDownloadTaskByUrl(String url){
		if(downloadTaskMap!=null)
			return downloadTaskMap.get(url);
		
		return null;
	}
	
	public void removeDownloadTaskByUrl(String url){
		if(downloadTaskMap!=null)
			downloadTaskMap.remove(url);
	}
	
	void addDownloadTaskByUrl(String url,DownloadTask downloadTask){
		if(downloadTaskMap!=null ){
			if(downloadTaskMap.containsKey(url)){
				DownloadTask tmp = this.downloadTaskMap.remove(url);
				tmp.exit();
				tmp = null;
			}
			downloadTaskMap.put(url, downloadTask);
		}
	}
	

	public static DownloadManager getInstance() {
		if (mInstance == null) {
			mInstance = new DownloadManager();
		}
		return mInstance;
	}

	public DownloadManager() {
		// 启动线程池
	}

	/**
	 * 初始化 读任务列表, 判断任务和下载大小
	 */
	void init() {
		
	}

	static void destroy() {

		if (mInstance.mHandlerList != null) {
			mInstance.mHandlerList.clear();
			mInstance.mHandlerList = null;
		}
		
		/*if(mInstance.downloadTaskMap!=null){
			mInstance.downloadTaskMap.clear();
			mInstance.downloadTaskMap = null;
		}*/

		if (mInstance == null) {
			return;
		}
	}

	/**
	 * 方法说明：<br>
	 * 增加 下载DownloadHandler 
	 * @param handler
	 */
	void addHandler(Handler handler) {
		if (!mHandlerList.contains(handler)) {
			mHandlerList.add(handler);
		}
	}

	/**
	 * 方法说明：<br>
	 * 移除 下载DownloadHandler
	 * @param handler
	 */
	void removeHandler(Handler handler) {
		mHandlerList.remove(handler);
	}

	static void NotifyUI(int what, long totalSize, long downloadSize, Object obj) {
	
		ArrayList<Handler> downloadHandlerList = DownloadManager.getInstance().mHandlerList;
		for (Handler h : downloadHandlerList) {
			
			Message msg = Message.obtain();
			msg.what = what;
			Object[] tObj = new Object[3];
			tObj[0] = obj;
			tObj[1] = totalSize;
			tObj[2] = downloadSize;
			msg.obj = tObj;
			h.sendMessage(msg);
		}
	}

	/**
	 * 开始状态变化
	 */
	@Override
	public void onDownloadStateChange(String url, int state) {

		switch (state) {
		case DownloadInfo.STATE_COMPLE:
			NotifyUI(DownloadInfo.STATE_COMPLE, 0, 0, url);
			break;
		default:
			break;
		}
		

		/*
		 * //final DownloadInfo dInfo = getDownloadInfo(url); if (dInfo != null)
		 * { dInfo.mState = state; NotifyUI(MSG_DOWNLOAD_STATE_CHANGE, state, 0,
		 * url);
		 * 
		 * switch (state) { case DownloadInfo.STATE_COMPLE: dInfo.mPath =
		 * dInfo.mFullPath;
		 * 
		 * break; // 如果已经下载完成或删除, 从数据表中删除 case
		 * DownloadInfo.STATE_INSTALL_SUCCESS:
		 * 
		 * 
		 * break; case DownloadInfo.STATE_PAUSE: case
		 * DownloadInfo.STATE_DELETED: case DownloadInfo.STATE_ERROR_IO: case
		 * DownloadInfo.STATE_ERROR_NET: case
		 * DownloadInfo.STATE_DOWNLOAD_FAILED:
		 * 
		 * break; case DownloadInfo.STATE_UNINSTALL_SUCCESS:
		 * 
		 * break; default: break; } }
		 */
	}

	@Override
	public void onProgressUpdate(String url, long downloadSize, long totalSize) {
		NotifyUI(MSG_DOWNLOAD_UPDATE_PROGRESS, totalSize, downloadSize, url);
	}

	@Override
	public void onDownloadError(String url, int error) {
		NotifyUI(MSG_DOWNLOAD_STATE_ERROR, error, 0, url);
	}

	/**
	 * 方法说明：<br>
	 * 安装成功通知 PS：没有用到
	 * @param packageName
	 */
	public void NotifyInstallSucceed(String packageName) {

	}

	/**
	 * 方法说明：<br>
	 * 安装失败通知 PS:没有用到
	 * @param packageName
	 */
	public void NotifyUninstallSucceed(String packageName) {

	}
	
}
