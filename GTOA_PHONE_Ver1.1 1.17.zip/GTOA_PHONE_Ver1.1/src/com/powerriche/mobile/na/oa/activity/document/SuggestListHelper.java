package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.SuggestEditActivity;
import com.powerriche.mobile.na.oa.activity.SuggestListActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshSwipeMenuListView;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : SuggestListHelper.java
 * 
 * @Description : 数据处理：常用意见
 * @Author : 李运期
 * @Version : 1.0
 * @Date : 2015年5月3日
 */
public class SuggestListHelper {

	// 接口返回的字段名称
	private static final String NOTE_ID = "NOTE_ID"; // 意见ID
	private static final String NOTE_CONTENT = "CONTENT"; // 意见内容

	private PullToRefreshSwipeMenuListView mPullView;
	private SwipeMenuListView listView;
	private TextView tvNoDataMsg;

	private List<ResultItem> resultItems = new ArrayList<ResultItem>();

	private int doucmentType = 0;

	private InvokeHelper helper = null;

	private Context mContext = null;

	private IRequestCallBack callBack = null;

	private ResultSimpleAdapter adapter;
	
	private int pageIndex;

	public SuggestListHelper(Context context, View contextView, TextView tvNoDataMsg) {
		this.mContext = context;
		SuggestListActivity acitvity = (SuggestListActivity) context;
		this.helper = acitvity.getInvokeHelper();
		this.callBack = acitvity.getCallBack();
		this.tvNoDataMsg = tvNoDataMsg;

		mPullView = (PullToRefreshSwipeMenuListView) contextView
				.findViewById(R.id.pulllistview_cyyj);
		listView = (SwipeMenuListView) mPullView.getRefreshableView();

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long arg3) {
				try {
					ResultItem item = resultItems.get(index);
					if(item == null){
						return;//空
					}

					String noteId = item.getString(NOTE_ID);// 意见ID
					String noteContent = item.getString(NOTE_CONTENT); // 意见内容

					if (noteId == null || noteContent == null) {
						return;
					}
					
					// 封装交互数据
					Bundle data = new Bundle();
					data.putString("noteId", BeanUtils.floatToInt4Str(noteId));
					data.putString("noteContent", noteContent);

					// 跳转到详情页面
					UIHelper.forwardTargetActivity(mContext,
							SuggestEditActivity.class, data, true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void process(HttpResponse response, int what) {
		// resultItems.clear();//清除
		List<ResultItem> items = response.getResultItem(ResultItem.class)
				.getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			// for (ResultItem it : items) {
			// Log.e(TAG, "意见ID->" + it.getString(NOTE_ID) + ",意见内容->" +
			// it.getString(NOTE_CONTENT));
			// }
			resultItems.addAll(items);
		}
		if (adapter == null) {
			int[] txtids = null;
			String[] keys = null;

			// AndroidUI的组件ID
			txtids = new int[]{R.id.list_item_text_field};
			// 意见内容
			keys = new String[]{NOTE_CONTENT};
			adapter = new ResultSimpleAdapter(mContext, resultItems,
					R.layout.suggest_list_item, keys, txtids);

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						// ResultItem item = resultItems.get(position);
					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int position) {
					// ResultItem item = resultItems.get(position);
				}
			});
			listView.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items) || items.size() < Integer.MAX_VALUE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
			
			if(pageIndex==1 && (BeanUtils.isEmpty(items) || items.size()==0)){
				mPullView.setVisibility(View.GONE);
				tvNoDataMsg.setVisibility(View.VISIBLE);
			}else{
				mPullView.setVisibility(View.VISIBLE);
				tvNoDataMsg.setVisibility(View.GONE);
			}
			
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}

	}

	public void loadData(int documentTye, int what, int pageIndex) {
		this.doucmentType = documentTye;
		this.pageIndex = pageIndex;
		if (pageIndex == 1) {
			resultItems.clear();// 清除
		}

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
		ApiRequest request = null;

		if (doucmentType == Constants.WHAT_REQUEST_CYYJ) {// 常用意见：列表
			request = OAServicesHandler.getUserNotesList();
		}

		if (request != null) {
			if (pageIndex == 1) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}
	}

	public void deleteData(int documentTye, int what, int position) {
		ResultItem item = resultItems.get(position);
		String noteId = item.getString(NOTE_ID); // 意见ID
		if (!BeanUtils.isEmpty(noteId)) {
			// 提交请求
			ApiRequest request = OAServicesHandler.deleteUserNotes(BeanUtils.floatToInt4Str(noteId));
			if (request != null) {
				helper.invoke(request, new BaseRequestCallBack() {
					@Override
					public void process(HttpResponse response, int what) {
						// 从ListView移除被删除的列表项
						resultItems.remove(what);
						adapter.notifyDataSetChanged();
					}
				}, position);
			}
		}
	}

	public int getDoucmentType() {
		return doucmentType;
	}

}
