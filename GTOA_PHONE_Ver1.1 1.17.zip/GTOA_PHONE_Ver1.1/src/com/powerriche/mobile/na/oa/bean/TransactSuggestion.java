package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * @title 办理意见类
 * @author dir_wang
 * @date 2016-8-1下午5:47:53
 */
public class TransactSuggestion implements Serializable {
	private static final long serialVersionUID = -272817981472667571L;
	private String data;
	private String actionName;
	private String processorDeptName;
	private String processor;
	private String saveDate;

	public String getData() {
		return data;
	}

	public String getActionName() {
		return actionName;
	}

	public String getProcessorDeptName() {
		return processorDeptName;
	}

	public String getProcessor() {
		return processor;
	}

	public String getSaveDate() {
		return saveDate;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public void setProcessorDeptName(String processorDeptName) {
		this.processorDeptName = processorDeptName;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public void setSaveDate(String saveDate) {
		this.saveDate = saveDate;
	}

}
