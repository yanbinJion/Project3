package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.NoticeListHelper;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshSwipeMenuListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenu;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuCreator;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuItem;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView;
import com.powerriche.mobile.na.oa.view.swipemenu.SwipeMenuListView.OnMenuItemClickListener;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 通知公告：列表
 * 
 * @author 李运期
 * @date 2015年5月3日
 * @version v1.0
 */
public class NoticeListActivity extends BaseActivity implements OnClickListener {

	private Context							mContext;
	private NoticeListActivity				acitvity;
	private View							contextView;

	private PullToRefreshSwipeMenuListView	mPullView;
	private SwipeMenuListView				mListView;
	
	private TextView 						tvNoDataMsg;
	
	public int								pageIndex	= 1;

	private static int						OPT_TYPE	= Constants.WHAT_REQUEST_TZGG;

	public Handler							indexHandler;
	/** 通知公告 */
	public NoticeListHelper					noticeListHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.notice_list);

		acitvity = (NoticeListActivity) this;
		contextView = findViewById(R.id.layout_tzgg);

		bindView();

		noticeListHelper = new NoticeListHelper(acitvity, contextView, tvNoDataMsg);
		//加载第一页的列表数据
		loadData();
	}

	void bindView() {
		// 设置顶部的标题栏
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.menu_notice));//顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.VISIBLE);//显示右边按钮
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标

		// 设置中部的列表区
		mPullView = (PullToRefreshSwipeMenuListView) findViewById(R.id.pulllistview_tzgg);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);

		mListView = mPullView.getRefreshableView();
		//mListView.setVerticalScrollBarEnabled(false);//设置滚动条隐藏
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(android.R.color.transparent);
		
		//添加“公共搜索框”：可以跟随列表数据一起滚动
		View header = LayoutInflater.from(this).inflate(R.layout.main_search_bar_top, null);
		mListView.addHeaderView(header);

		mPullView.setOnRefreshListener(new OnRefreshListener<SwipeMenuListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<SwipeMenuListView> refreshView) {
				pageIndex = 1;
				noticeListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_TZGG, pageIndex,false);
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase<SwipeMenuListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				noticeListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_TZGG, pageIndex,false);
			}
		});

		//向左侧滑菜单
		SwipeMenuCreator creator = new SwipeMenuCreator() {
			@Override
			public void create(SwipeMenu menu) {
				SwipeMenuItem deleteItem = new SwipeMenuItem(getApplicationContext());// create "delete" item
				deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));// set item background
				int width = UIHelper.dp2px(mContext, 70);// set item width
				deleteItem.setWidth(width);
				deleteItem.setIcon(R.drawable.ic_delete);// set a icon
				menu.addMenuItem(deleteItem);// add to menu
			}
		};
		mListView.setMenuCreator(creator);
		mListView.setOnMenuItemClickListener(new OnMenuItemClickListener() {
			@Override
			public void onMenuItemClick(int position, SwipeMenu menu, int index) {
				switch (index) {
					case 0://执行删除
						noticeListHelper.deleteData(OPT_TYPE, Constants.OPT_TYPE_TZGG_DEL, position);
						break;
				}
			}
		});
		
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);
	}

	/** 加载数据：通知公告列表 */
	public void loadData() {
		OPT_TYPE = Constants.WHAT_REQUEST_TZGG;//设置选中项
		
		pageIndex = 1;
		noticeListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_TZGG, pageIndex, true);// 请求加载数据
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_back){
			finish();
			
		}else if(id == R.id.btn_top_right){
			UIHelper.forwardTargetActivity(mContext, NoticeAddActivity.class, null, true);
		}
	}


	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	private IRequestCallBack	callBack	= new BaseRequestCallBack() {
												@Override
												public void process(HttpResponse response, int what) {
													if (what == Constants.WHAT_REQUEST_TZGG) {// 通知公告
														ResultItem item = response.getResultItem(ResultItem.class);
														if (checkResult(item)) {
															noticeListHelper.process(response, what);
														}
													}
												}
											};

}
