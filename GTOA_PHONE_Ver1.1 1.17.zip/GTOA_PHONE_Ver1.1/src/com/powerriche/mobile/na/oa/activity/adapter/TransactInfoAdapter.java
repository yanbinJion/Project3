package com.powerriche.mobile.na.oa.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.TransactInfo;

import java.util.ArrayList;
import java.util.List;
/**
 * @title  办理信息列表
 * @author dir_wang
 * @date   2016-7-5下午2:32:59
 */
public class TransactInfoAdapter extends BaseAdapter{

    private Context mContext;
    private List<TransactInfo> data = new ArrayList<TransactInfo>();
    public TransactInfoAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (null == view) {
            holder = new ViewHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.transact_info_item, null);
            holder.tv_processor = (TextView) view.findViewById(R.id.tv_processor);
            holder.tv_action = (TextView) view.findViewById(R.id.tv_action);
            holder.tv_begin_time = (TextView) view.findViewById(R.id.tv_begin_time);
            holder.tv_end_time = (TextView) view.findViewById(R.id.tv_end_time);
            holder.tv_remark = (TextView) view.findViewById(R.id.tv_remark);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        TransactInfo transactInfo = data.get(position);
        holder.tv_processor.setText(transactInfo.getProcessor());
        holder.tv_action.setText(transactInfo.getAction());
        holder.tv_begin_time.setText(transactInfo.getBeginTime());
        holder.tv_end_time.setText(transactInfo.getEndTime());
        holder.tv_remark.setText(transactInfo.getRemark());
        return view;
    }

    private class ViewHolder {
        private TextView tv_processor;
        private TextView tv_action;
        private TextView tv_begin_time;
        private TextView tv_end_time;
        private TextView tv_remark;
    }

    /**
     * 添加数据
     */
    public void addData(List<TransactInfo> dataList){
        if (null != dataList) {
            this.data.addAll(dataList);
        }
    }

    public void clearListData(){
        if (data != null){
            data.clear();
        }
    }
}
