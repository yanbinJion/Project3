package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 会议基本信息
 * @author  Fitz
 * @date    2015年5月9日
 * @version v1.0
 */
public class MeetInfo {

	private String documentId;
	private String title;
	private String beginTime;
	private String endTime;
	private String content;
	private String address;
	private String persider;
	
	private int isFirstFpu;
	private int result;

	int exchangeFlag;	//0,交换来文; 1,手工登记(字段仅对来文swfNo=2006083005302033有效)
	int isReceiptReplied;	//0：未签收 1：已签收 2：已拒收
	
	int isCallback;//0 不能撤回（不显示撤回按钮）1 可以撤回（显示撤回按钮）
	
	
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public int getIsFirstFpu() {
		return isFirstFpu;
	}
	public void setIsFirstFpu(int isFirstFpu) {
		this.isFirstFpu = isFirstFpu;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPersider() {
		return persider;
	}
	public void setPersider(String persider) {
		this.persider = persider;
	}
	public int getExchangeFlag() {
		return exchangeFlag;
	}
	public void setExchangeFlag(int exchangeFlag) {
		this.exchangeFlag = exchangeFlag;
	}
	public int getIsReceiptReplied() {
		return isReceiptReplied;
	}
	public void setIsReceiptReplied(int isReceiptReplied) {
		this.isReceiptReplied = isReceiptReplied;
	}
	public int getIsCallback() {
		return isCallback;
	}
	public void setIsCallback(int isCallback) {
		this.isCallback = isCallback;
	}
	
	
}
