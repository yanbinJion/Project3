package com.powerriche.mobile.na.oa.bean;

import com.powerriche.mobile.oa.tools.BeanUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 用于保存个人任务详情
 * Created by root on 16-5-13.
 */
public class TaskDetails implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5469940000708482464L;
	private int taskId;
    private String taskCode;
    private String taskTitle;
    private String createName;
    private String createTime;
    private String limitTime;
    /** 计划上报类型：0 季度 1 月 2 周 3 时间段*/
    private String submitType;
    private String taskYear;
    private String contact;
    private String contactPhone;
    private String mainSubmit;
    private String copySubmit;
    private String mainName;
    private String copyName;
    private String documentId;
    /** 任务状态，为0表示登记，此时需要显示任务分派 2 表示已分派*/
    private String taskState;
    /** 任务审批或审核: RWSH,RWSP*/
    private String actionNo;
    /** 是否已经签收*/
    private String isSign;
    /** 个人任务审批是否通过: 0 申请中 1 通过 -1 被拒绝*/
    private String passState;
    /** 个人任务办理结果是否通过: 0 待办 1 已办理 -1 只读*/
    private String processResult;

    private EventInfo event;
    //附件信息
    private ArrayList<FileInfo> fileList;
    private ArrayList<ProcessInfo> processInfos;
    private ArrayList<ProgressInfo> progressInfos;
    private ArrayList<HistoryProgress> historyInfos;
    private HashMap<String, ArrayList<HistoryProgress>> progressMaps;
    private ArrayList<Suggest> suggests;
    private ArrayList<DocFileInfo> fileInfoList; 

    public ArrayList<Suggest> getSuggests() {
        return suggests;
    }

    public void setSuggests(ArrayList<Suggest> suggests) {
        this.suggests = suggests;
    }

    public HashMap<String, ArrayList<HistoryProgress>> getProgressMaps() {
        return progressMaps;
    }

    public void putProgressMaps(String no, ArrayList<HistoryProgress> list) {
        if (null == progressMaps) {
            progressMaps = new HashMap<String, ArrayList<HistoryProgress>>();
        }
        progressMaps.put(no, list);
    }

    public ArrayList<HistoryProgress> getMapListByNo(String no) {
        if (BeanUtils.isNullOrEmpty(no) || BeanUtils.isEmpty(progressMaps)) {
            return null;
        }
        return progressMaps.get(no);
    }

    public void setProgressMaps(HashMap<String, ArrayList<HistoryProgress>> progressMaps) {
        this.progressMaps = progressMaps;
    }

    public ArrayList<HistoryProgress> getHistoryInfos() {
        return historyInfos;
    }

    public void setHistoryInfos(ArrayList<HistoryProgress> historyInfos) {
        this.historyInfos = historyInfos;
    }

    /** 返回是否是代办*/
    public boolean isEditable() {
        return "0".equals(processResult);
    }

    /** 返回是否已签收*/
    public boolean isSign() {
        return "1".equals(isSign);
    }

    /** 任务是否处于审核或审批状态*/
    public boolean isProcessAction() {
        return "RWSH".equals(actionNo) || "RWSP".equals(actionNo);
    }

    public String getTaskState() {
        return taskState;
    }

    public void setTaskState(String taskState) {
        this.taskState = taskState;
    }

    public String getActionNo() {
        return actionNo;
    }

    public void setActionNo(String actionNo) {
        this.actionNo = actionNo;
    }

    public String getSign() {
        return isSign;
    }

    public void setSign(String sign) {
        isSign = sign;
    }

    public String getPassState() {
        return passState;
    }

    public void setPassState(String passState) {
        this.passState = passState;
    }

    public String getProcessResult() {
        return processResult;
    }

    public void setProcessResult(String processResult) {
        this.processResult = processResult;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

	public EventInfo getEvent() {
		return event;
	}

	public void setEvent(EventInfo event) {
		this.event = event;
	}

	public String getTaskCode() {
		return taskCode;
	}

	public void setTaskCode(String taskId) {
		this.taskCode = taskId;
	}

	public String getTaskTitle() {
		return taskTitle;
	}

	public void setTaskTitle(String taskTitle) {
		this.taskTitle = taskTitle;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getLimitTime() {
		return limitTime;
	}

	public void setLimitTime(String limitTime) {
		this.limitTime = limitTime;
	}

	public String getSubmitType() {
		return submitType;
	}

	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}

	public String getTaskYear() {
		return taskYear;
	}

	public void setTaskYear(String taskYear) {
		this.taskYear = taskYear;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getMainSubmit() {
		return mainSubmit;
	}

	public void setMainSubmit(String mainSubmit) {
		this.mainSubmit = mainSubmit;
	}

	public String getCopySubmit() {
		return copySubmit;
	}

	public void setCopySubmit(String copySubmit) {
		this.copySubmit = copySubmit;
	}

	public ArrayList<FileInfo> getFileList() {
		return fileList;
	}

	public void setFileList(ArrayList<FileInfo> fileList) {
		this.fileList = fileList;
	}

	public ArrayList<ProcessInfo> getProcessInfos() {
		return processInfos;
	}
	
	public ArrayList<DocFileInfo> getFileInfoList() {
		return fileInfoList;
	}

	public void setFileInfoList(ArrayList<DocFileInfo> fileInfoList) {
		this.fileInfoList = fileInfoList;
	}

	public void setProcessInfos(ArrayList<ProcessInfo> processInfos) {
		this.processInfos = processInfos;
	}

	public ArrayList<ProgressInfo> getProgressInfos() {
		return progressInfos;
	}

	public void setProgressInfos(ArrayList<ProgressInfo> progressInfos) {
		this.progressInfos = progressInfos;
	}

	public String getDocumentId() {
		return documentId;
	}

    public String getMainName() {
        return mainName;
    }

    public void setMainName(String mainName) {
        this.mainName = mainName;
    }

    public String getCopyName() {
        return copyName;
    }

    public void setCopyName(String copyName) {
        this.copyName = copyName;
    }

    public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public void clearDetails() {
		if (!BeanUtils.isEmpty(fileList)) {
			fileList.clear();
			fileList = null;
		}
		if (!BeanUtils.isEmpty(processInfos)) {
			processInfos.clear();
			processInfos = null;
		}
        if (!BeanUtils.isEmpty(progressInfos)) {
            progressInfos.clear();
            progressInfos = null;
        }
        if (!BeanUtils.isEmpty(historyInfos)) {
            historyInfos.clear();
            historyInfos = null;
        }
        if (!BeanUtils.isEmpty(progressMaps)) {
            progressMaps.clear();
            progressMaps = null;
        }
        if (!BeanUtils.isEmpty(suggests)) {
            suggests.clear();
            suggests = null;
        }
	}

	public String getType() {
		String type = "季度";
		if ("1".equals(submitType) || "1.0".equals(submitType)) {
			type = "月";
		} else if ("2".equals(submitType) || "2.0".equals(submitType)) {
			type = "周";
		} else if ("3".equals(submitType) || "3.0".equals(submitType)) {
			type = "时间段";
		}
		return type;
	}

	public void parseFile() {

	}

	public void parseProcess() {

	}

	public class FileInfo implements Serializable {
		private String fileId;
		private String fileTitle;
		private String fileName;
		private String filePath;

		public String getFileId() {
			return fileId;
		}

		public void setFileId(String fileId) {
			this.fileId = fileId;
		}

		public String getFileTitle() {
			return fileTitle;
		}

		public void setFileTitle(String fileTitle) {
			this.fileTitle = fileTitle;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public String getFilePath() {
			return filePath;
		}

		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}
	}

	public class ProcessInfo implements Serializable {
		private String data;
		private String actionName;
		private String deptName;
		private String processor;
		private String processTime;

		public String getData() {
			return data;
		}

		public void setData(String data) {
			this.data = data;
		}

		public String getActionName() {
			return actionName;
		}

		public void setActionName(String actionName) {
			this.actionName = actionName;
		}

		public String getDeptName() {
			return deptName;
		}

		public void setDeptName(String deptName) {
			this.deptName = deptName;
		}

		public String getProcessor() {
			return processor;
		}

		public void setProcessor(String processor) {
			this.processor = processor;
		}

		public String getProcessTime() {
			return processTime;
		}

		public void setProcessTime(String processTime) {
			this.processTime = processTime;
		}
	}

	public class ProgressInfo implements Serializable {
		private String progressDetailsId;
		private String processNo;
		private String reportName;
		private String reportTime;
		private String fromDate;
		private String toDate;
		private String progressContent;
		private String progerssCompleteDegree;
		private String completeTime;
		private String cost;
		private String quantity;
		private String sumTime;
		private String sumMoney;
		private String remark;
		private String documentId;

        private boolean isExpand;
        private boolean isShowHistory;

        public boolean isShowHistory() {
            return isShowHistory;
        }

        public void setShowHistory(boolean showHistory) {
            isShowHistory = showHistory;
        }

        public boolean isExpand() {
            return isExpand;
        }

        public void setExpand(boolean expand) {
            isExpand = expand;
        }

        public String getProgressDetailsId() {
			return progressDetailsId;
		}

		public void setProgressDetailsId(String progressDetailsId) {
			this.progressDetailsId = progressDetailsId;
		}

		public String getProcessNo() {
			return processNo;
		}

		public void setProcessNo(String processNo) {
			this.processNo = processNo;
		}

		public String getReportName() {
			return reportName;
		}

		public void setReportName(String reportName) {
			this.reportName = reportName;
		}

		public String getReportTime() {
			return reportTime;
		}

		public void setReportTime(String reportTime) {
			this.reportTime = reportTime;
		}

		public String getFromDate() {
			return fromDate;
		}

		public void setFromDate(String fromDate) {
			this.fromDate = fromDate;
		}

		public String getToDate() {
			return toDate;
		}

		public void setToDate(String toDate) {
			this.toDate = toDate;
		}

		public String getProgressContent() {
			return progressContent;
		}

		public void setProgressContent(String progressContent) {
			this.progressContent = progressContent;
		}

		public String getProgerssCompleteDegree() {
			return progerssCompleteDegree;
		}

		public void setProgerssCompleteDegree(String progerssCompleteDegree) {
			this.progerssCompleteDegree = progerssCompleteDegree;
		}

		public String getCompleteTime() {
			return completeTime;
		}

		public void setCompleteTime(String completeTime) {
			this.completeTime = completeTime;
		}

		public String getCost() {
			return cost;
		}

		public void setCost(String cost) {
			this.cost = cost;
		}

		public String getQuantity() {
			return quantity;
		}

		public void setQuantity(String quantity) {
			this.quantity = quantity;
		}

		public String getSumTime() {
			return sumTime;
		}

		public void setSumTime(String sumTime) {
			this.sumTime = sumTime;
		}

		public String getSumMoney() {
			return sumMoney;
		}

		public void setSumMoney(String sumMoney) {
			this.sumMoney = sumMoney;
		}
		
		public String getRemark() {
			return remark;
		}

		public void setRemark(String remark) {
			this.remark = remark;
		}

		public String getDocumentId() {
			return documentId;
		}

		public void setDocumentId(String documentId) {
			this.documentId = documentId;
		}

		@Override
		public String toString() {
			return "ProgressInfo [progressDetailsId=" + progressDetailsId
					+ ", processNo=" + processNo + ", reportName=" + reportName
					+ ", reportTime=" + reportTime + ", fromDate=" + fromDate
					+ ", toDate=" + toDate + ", progressContent="
					+ progressContent + ", progerssCompleteDegree="
					+ progerssCompleteDegree + ", completeTime=" + completeTime
					+ ", cost=" + cost + ", quantity=" + quantity
					+ ", sumTime=" + sumTime + ", sumMoney=" + sumMoney
					+ ", remark=" + remark + ", documentId=" + documentId + "]";
		}
		
	}

	public class EventInfo implements Serializable {
		private String reason;
		private String type;
		private String address;
		private String device;
		private String remark;
		private ArrayList<String> workList;

		public String getReason() {
			return reason;
		}

		public void setReason(String reason) {
			this.reason = reason;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getDevice() {
			return device;
		}

		public void setDevice(String device) {
			this.device = device;
		}

		public String getRemark() {
			return remark;
		}

		public void setRemark(String remark) {
			this.remark = remark;
		}

		public ArrayList<String> getWorkList() {
			return workList;
		}

		public void setWorkList(ArrayList<String> workList) {
			this.workList = workList;
		}
	}

    public class HistoryProgress implements Serializable {
        private String detailId;
        private String progressId;
        private String reportName;
        private String reportTime;
        private String fromDate;
        private String toDate;
        private String content;
        private String degree;
        private String completeTime;
        private String sumHumanCost;
        private String sumQuantity;
        private String sumTime;
        private String sumMoney;
        private String version;
        private String remark;
        private String documentId;

        public String getDetailId() {
            return detailId;
        }

        public void setDetailId(String detailId) {
            this.detailId = detailId;
        }

        public String getProgressId() {
            return progressId;
        }

        public void setProgressId(String progressId) {
            this.progressId = progressId;
        }

        public String getReportName() {
            return reportName;
        }

        public void setReportName(String reportName) {
            this.reportName = reportName;
        }

        public String getReportTime() {
            return reportTime;
        }

        public void setReportTime(String reportTime) {
            this.reportTime = reportTime;
        }

        public String getFromDate() {
            return fromDate;
        }

        public void setFromDate(String fromDate) {
            this.fromDate = fromDate;
        }

        public String getToDate() {
            return toDate;
        }

        public void setToDate(String toDate) {
            this.toDate = toDate;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getDegree() {
            return degree;
        }

        public void setDegree(String degree) {
            this.degree = degree;
        }

        public String getCompleteTime() {
            return completeTime;
        }

        public void setCompleteTime(String completeTime) {
            this.completeTime = completeTime;
        }

        public String getSumHumanCost() {
            return sumHumanCost;
        }

        public void setSumHumanCost(String sumHumanCost) {
            this.sumHumanCost = sumHumanCost;
        }

        public String getSumQuantity() {
            return sumQuantity;
        }

        public void setSumQuantity(String sumQuantity) {
            this.sumQuantity = sumQuantity;
        }

        public String getSumTime() {
            return sumTime;
        }

        public void setSumTime(String sumTime) {
            this.sumTime = sumTime;
        }

        public String getSumMoney() {
            return sumMoney;
        }

        public void setSumMoney(String sumMoney) {
            this.sumMoney = sumMoney;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getDocumentId() {
            return documentId;
        }

        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }
    }
    
    public class Materials implements Serializable {
    	private String brand;
    	private String unit;
    	private String quantity;
		public String getBrand() {
			return brand;
		}
		public void setBrand(String brand) {
			this.brand = brand;
		}
		public String getUnit() {
			return unit;
		}
		public void setUnit(String unit) {
			this.unit = unit;
		}
		public String getQuantity() {
			return quantity;
		}
		public void setQuantity(String quantity) {
			this.quantity = quantity;
		}
    	
    }

    public class Suggest implements Serializable {

        private String actionId;
        private String processor;
        private String action;
        private String beginTime;
        private String endTime;
        private String readTime;
        private String remark;

        public String getActionId() {
            return actionId;
        }

        public void setActionId(String actionId) {
            this.actionId = actionId;
        }

        public String getProcessor() {
            return processor;
        }

        public void setProcessor(String processor) {
            this.processor = processor;
        }

        public String getAction() {
            return action;
        }

        public void setAction(String action) {
            this.action = action;
        }

        public String getBeginTime() {
            return beginTime;
        }

        public void setBeginTime(String beginTime) {
            this.beginTime = beginTime;
        }

        public String getEndTime() {
            return endTime;
        }

        public void setEndTime(String endTime) {
            this.endTime = endTime;
        }

        public String getReadTime() {
            return readTime;
        }

        public void setReadTime(String readTime) {
            this.readTime = readTime;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }
    }

}
