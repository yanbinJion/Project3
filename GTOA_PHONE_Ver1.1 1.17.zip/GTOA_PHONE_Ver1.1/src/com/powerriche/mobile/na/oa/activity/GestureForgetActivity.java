package com.powerriche.mobile.na.oa.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UserHelper;

/**
 * 类描述：<br> 
 * 忘记手续密码
 * @author  Fitz
 * @date    2015年6月5日
 * @version v1.0
 */
public class GestureForgetActivity extends BaseActivity implements OnClickListener {

	private ResultItem lastUserItem = null;
	
	private EditText passwordEdit;
	private TextView tvUserAccount;
	
	private String userId;
	private String password;
	private boolean isAuto;
	private Context mContext;
	private UserHelper userHelper = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.mContext =  this;
		setContentView(R.layout.gesture_forget);
		userHelper = new UserHelper(this);
		bindView();
	}

	void bindView() {
		tvUserAccount = (TextView) findViewById(R.id.tv_user_account);

		//获取最后一个登录的用户
		lastUserItem = userHelper.getLastUserInfo();
		
		// 如果查询为空，则跳转到输入用户名和密码页面
		if(lastUserItem==null||BeanUtils.isEmpty(lastUserItem.getString("USERID"))||BeanUtils.isEmpty(lastUserItem.getString("USERNAME"))){
			UIHelper.forwardTargetActivity(GestureForgetActivity.this,
					SystemLoginActivity.class, null, true);
			return;
		}
		
		String userName = lastUserItem.getString("USERID");//用户名称
		
		tvUserAccount.setText(userName);
		passwordEdit = (EditText) findViewById(R.id.system_input_password);
		
		//绑定密码完成功能点，直接提交
		passwordEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {  
			@Override  
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {  
				/*判断是否是“完成”键*/  
				if(actionId == EditorInfo.IME_ACTION_DONE){  
					String userId = tvUserAccount.getText().toString();
					String passwd = passwordEdit.getText().toString();
					if(BeanUtils.isEmpty(passwd)){
						UIHelper.showMessage(mContext, "请输入登陆密码");
						passwordEdit.requestFocus();
						return false;
					}
					/*隐藏软键盘*/  
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);  
					if(inputMethodManager.isActive()){  
						inputMethodManager.hideSoftInputFromWindow(GestureForgetActivity.this.getCurrentFocus().getWindowToken(), 0);  
					}  
					// 登录
					login(userId, passwd, false);
					return true;  
				}  
				return false;  
			}  
		}); 
		findViewById(R.id.system_btn_login).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.system_btn_login){	//登陆
			String password = passwordEdit.getText().toString().trim();
			if(BeanUtils.isEmpty(password)){
				UIHelper.showMessage(this, "请输入登陆密码");
				passwordEdit.requestFocus();
				return;
			}
			String userId = tvUserAccount.getText().toString();
			String passwd = passwordEdit.getText().toString();
			login(userId, passwd, false);	//不自动登陆
			
		}
	}
	
	/** 登陆认证 */
	public void login(String userId, String passWd, boolean isauto) {
		String loginmessage = getString(R.string.system_check_user_message);
		
		this.userId = userId;
		this.password = passWd;
		this.isAuto = isauto;
		
		if(Constants.IS_USER_PORTAL){//采用门户接口
			ApiRequest requestPT = OAServicesHandler.portalLogin(userId, passWd);//新版：门户转换登录，需要转换StaffNO
			requestPT.setMessage(loginmessage);
			helper.invokeWidthDialog(requestPT, callBack, Constants.WHAT_LOGIN_PORTAL);
		}else{//采用OA接口
			ApiRequest requestOA = OAServicesHandler.mobileLogin(userId, passWd);//老版：OA直接登录，不需要转换StaffNO
			requestOA.setMessage(loginmessage);
			helper.invokeWidthDialog(requestOA, callBack, Constants.WHAT_LOGIN_OA);
		}
		
	}
	
	/**
	 * 根据门户的StaffNo获取OA上对应的StaffNo和Token值<br>
	 * 因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
	 */
	public void convertStaffNoForOA(){
		ApiRequest request = OAServicesHandler.getStaffNoAndTokenForOA(SystemContext.getAccountProtal());
		helper.invoke(request, callBack, Constants.WHAT_LOGIN_CONVERT);
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			
			if(what == Constants.WHAT_LOGIN_PORTAL){//门户登录返回
				String code = item.getString("code");
				String message = item.getString("message");
				if (Constants.SUCCESS_CODE.equals(code)) {
					if (!BeanUtils.isEmpty(item.getItems("data"))) {
						item = item.getItems("data").get(0);
						
						String protalStaffNo = item.getString("STAFF_NO");// 门户的StaffNO
						String protalToken = item.getString("AUTH_TOKEN");// 门户的AuthToken
						String oaStaffNo = "";// 移动OA的StaffNO
						String oaToken = "";// 移动OA的AuthToken
						String realName = item.getString("REAL_NAME");
						String siteName = item.getString("SITE_NAME");
						String siteNo = item.getString("SITE_NO");
						String mobile = item.getString("MOBILE");
                        String position = item.getString("POSITION");
                        String sex = item.getString("SEX");
                        String phone = item.getString("PHONE");
						
						//设置用户信息
                        SystemContext.initUserInfo(userId,
                                protalStaffNo, protalToken, oaStaffNo,
                                oaToken, realName, siteNo, siteName,
                                mobile, position, sex, phone);
						// 保存登录信息到本地
						userHelper.recodeLogin(userId, password, isAuto, realName);

						// showErrorMessage("登录成功！STAFF_NO:" + staffNo + "token=" + token);
						
						convertStaffNoForOA();//因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
					}
				} else {
					showErrorMessage(message);
				}
					
			}else if(what == Constants.WHAT_LOGIN_OA){//OA登陆返回
					
				String code = item.getString("code");
				String message = item.getString("message");
				if(Constants.SUCCESS_CODE.equals(code)){
					item = item.getItems("data").get(0);
					
					String protalStaffNo = "";// 门户的StaffNO
					String protalToken = "";// 门户的AuthToken
					String oaStaffNo = item.getString("STAFF_NO");// 移动OA的StaffNO
					String oaToken = item.getString("AUTH_TOKEN");// 移动OA的AuthToken
					String realName = item.getString("REAL_NAME");
					String siteName = item.getString("SITE_NAME");
					String siteNo = item.getString("SITE_NO");
					String mobile = item.getString("MOBILE");
                    String position = item.getString("POSITION");
                    String sex = item.getString("SEX");
                    String phone = item.getString("PHONE");
					
					//设置用户信息
                    SystemContext.initUserInfo(userId,
                            protalStaffNo, protalToken, oaStaffNo,
                            oaToken, realName, siteNo, siteName,
                            mobile, position, sex, phone);
					// 保存登录信息到本地
					userHelper.recodeLogin(userId, password, isAuto, realName);
					
					toSetGestures();
					
				}else{
					UIHelper.showMessage(context, message);
				}
				
			}else if(what == Constants.WHAT_LOGIN_CONVERT){	//门户登录转换：门户登录成功之后需要转换StaffNo值
				if (!BeanUtils.isEmpty(item)) {
					
					String code = item.getString("code");
					String message = item.getString("message");
					if(Constants.SUCCESS_CODE.equals(code)){
						item = item.getItems("data").get(0);
						
						String oaStaffNo = item.getString("STAFF_NO");// 移动OA的StaffNO
						String oaToken = item.getString("AUTH_TOKEN");// 移动OA的AuthToken
						
						SystemContext.setAccount(oaStaffNo);
						SystemContext.setSessionid(oaToken);
						
						//打开并跳转到系统主界面
						toSetGestures();
						
					}else{
						UIHelper.showMessage(context, message);
					}
				}
				
			}
		}
	};
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			UIHelper.forwardTargetActivity(this, SystemLoginActivity.class, null, true);
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	/**
	 * 跳转到手势密码设置界面
	 */
	public void toSetGestures(){
		Intent intent = new Intent(GestureForgetActivity.this, SetGesturesPasswordActivity.class);
		intent.putExtra("isForgetGestures", true);
		startActivity(intent);
		finish();
	}
	
}
