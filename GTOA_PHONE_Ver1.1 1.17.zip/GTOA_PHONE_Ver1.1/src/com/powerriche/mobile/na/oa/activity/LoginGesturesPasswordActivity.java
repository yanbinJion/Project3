package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.ContentView;
import com.powerriche.mobile.na.oa.view.GestureDrawl.GestureCallBack;
import com.powerriche.mobile.na.oa.view.TipsDialog;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UserHelper;
import com.powerriche.mobile.oa.vpn.OaVpnService;

/**
 * Filename : GesturesPasswordActivity
 * 
 * @Description : 手势密码
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-22 17:50:00
 */
public class LoginGesturesPasswordActivity extends BaseActivity implements OnClickListener{

	private FrameLayout gesturespwdLayout;

	private ContentView content;

	private ResultItem lastUserItem = null;
	private ResultItem gesturesPwdItem = null;

	private UserHelper userHelper = null;

	private int errorNumber = 5;

	private TextView msgView;

	// 定义一个变量，来标识是否退出
	private static boolean isExit = false;

	private String userId;

	private Context mContext;
	
	/**解锁屏幕*/
	private  static String isLock;
	
	/**vpn是否开通*/
	private boolean isVpn = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gestures_password);
		isLock = getIntent().getStringExtra(Constants.LOCK_SCREEN);
		this.mContext = this;
		gesturespwdLayout = (FrameLayout) findViewById(R.id.gesturespwd_layout);
		msgView = (TextView) findViewById(R.id.pwdMsgView);
		msgView.setText(R.string.gesturespassword_login_title);
		
		findViewById(R.id.tv_change_user).setOnClickListener(this);
		findViewById(R.id.tv_forget_pass).setOnClickListener(this);
		((RelativeLayout) findViewById(R.id.user_name_layout)).setVisibility(View.VISIBLE);
		findViewById(R.id.tv_forget_pass).setVisibility(View.VISIBLE);
		findViewById(R.id.tv_change_user).setVisibility(View.VISIBLE);
		
		userHelper = new UserHelper();
		
		//获取最后一个登录的用户
		lastUserItem = userHelper.getLastUserInfo();
		
		// 如果查询为空，则跳转到输入用户名和密码页面
		if(lastUserItem==null||BeanUtils.isEmpty(lastUserItem.getString("USERID"))||BeanUtils.isEmpty(lastUserItem.getString("USERNAME"))){
			toLogin(false);
			return;
		}
		
		userId = lastUserItem.getString("USERID");//用户ID
		String userName = lastUserItem.getString("USERNAME");//用户名称
		
		//根据用户ID获取最后登录用户的手势密码
		gesturesPwdItem = userHelper.getGesturesCodeByUserId(userId);
		
		// 如果查询为空或者被锁定，则跳转到输入用户名和密码页面
		if(gesturesPwdItem!=null&& gesturesPwdItem.getInt("ISLOCK") == 1 && !BeanUtils.isEmpty(gesturesPwdItem.getString("GESTURESCODE"))){
			String gesturescode = gesturesPwdItem.getString("GESTURESCODE");//手势密码
			((TextView) findViewById(R.id.login_user_name)).setText(userName);
			// 初始化一个显示各个点的viewGroup
			content = new ContentView(Constants.GESTURES_OPTTYPE_LOGIN, this,
					gesturescode, new GestureCallBack() {
						@Override
						public void checkedSuccess() {
							msgView.setTextColor(Color
									.parseColor(getString(R.color.white)));
							msgView.setText(R.string.gesturespassword_login_success);
							//如果是解锁的，则直接进入页面，关闭当前的activity
							if(!BeanUtils.isEmpty(isLock) && "true".equals(isLock)){
								finish();
							}else{
								if(isVpn){
									// 静默登录
									String userId = lastUserItem.getString("USERID");//用户ID
									String password = lastUserItem.getString("PASSWORD");//登录密码
									
									if(Constants.IS_USER_PORTAL){//采用门户接口
										ApiRequest requestPT = OAServicesHandler.portalLogin(userId, password);//新版：门户转换登录，需要转换StaffNO
										helper.invokeWidthDialog(requestPT, callBack, Constants.WHAT_LOGIN_PORTAL);
									}else{//采用OA接口
										ApiRequest requestOA = OAServicesHandler.mobileLogin(userId, password);//老版：OA直接登录，不需要转换StaffNO
										helper.invokeWidthDialog(requestOA, callBack, Constants.WHAT_LOGIN_OA);
									}
									
								}
							}
						}

						@Override
						public void checkedFail() {
							msgView.setTextColor(Color
									.parseColor(getString(R.color.red)));
							errorNumber--;
							if (errorNumber == 0) {
								String userId = lastUserItem.getString("USERID");//用户ID
								userHelper.delGesturesCodeByUserId(userId);
								toLogin(true);
								return;
							} else {
								msgView.setText("密码错了，还可以输入" + errorNumber + "次");
							}
						}

						@Override
						public void checkedSuccessBack(String param) {
						}
					});
			// 设置手势解锁显示到哪个布局里面
			content.setParentView(gesturespwdLayout);
		} else {
			toLogin(false);
			return;
		}
		
		//初始化话vpn
		JudgeVpn();
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			if (what == Constants.WHAT_LOGIN_PORTAL) {//门户登录返回
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					try {
						String code = item.getString("code");
						// 操作成功
						if (Constants.SUCCESS_CODE.equals(code)) {
							if (!BeanUtils.isEmpty(item.getItems("data"))) {
								item = item.getItems("data").get(0);
								
								String protalStaffNo = item.getString("STAFF_NO");// 门户的StaffNO
								String protalToken = item.getString("AUTH_TOKEN");// 门户的AuthToken
								String oaStaffNo = "";// 移动OA的StaffNO
								String oaToken = "";// 移动OA的AuthToken
								String realName = item.getString("REAL_NAME");
								String siteName = item.getString("SITE_NAME");
								String siteNo = item.getString("SITE_NO");
								String mobile = item.getString("MOBILE");
                                String position = item.getString("POSITION");
                                String sex = item.getString("SEX");
                                String phone = item.getString("PHONE");
								
								//设置用户信息
                                SystemContext.initUserInfo(userId,
                                        protalStaffNo, protalToken, oaStaffNo,
                                        oaToken, realName, siteNo, siteName,
                                        mobile, position, sex, phone);
								
								convertStaffNoForOA();//因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
							}
						} else {
							toLogin(true);
							return;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}else{
					String code = item.getString("code");
					//用户的密码不对，需要重新登录
					if ("-109".equals(code)) {
						// 还要弹个dialog出来，确定先签收来文
						final TipsDialog dialog = new TipsDialog(mContext);
						dialog.setMessage(getString(R.string.gestures_loginpassword_error));
						dialog.setOnOkClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								userHelper.setIsLock(false);
								toLogin(true);
								dialog.dismiss();
							}
						});
						dialog.show();
						return;
					}else{
						UIHelper.showMessage(mContext, errorMessage);
						return;
					}
				}
				
			}else if(what == Constants.WHAT_LOGIN_OA){//OA登录返回
				ResultItem item = response.getResultItem(ResultItem.class);
				String code = item.getString("code");
				String message = item.getString("message");
				if(Constants.SUCCESS_CODE.equals(code)){
					item = item.getItems("data").get(0);
					
					String protalStaffNo = "";// 门户的StaffNO
					String protalToken = "";// 门户的AuthToken
					String oaStaffNo = item.getString("STAFF_NO");// 移动OA的StaffNO
					String oaToken = item.getString("AUTH_TOKEN");// 移动OA的AuthToken
					String realName = item.getString("REAL_NAME");
					String siteName = item.getString("SITE_NAME");
					String siteNo = item.getString("SITE_NO");
					String mobile = item.getString("MOBILE");
                    String position = item.getString("POSITION");
                    String sex = item.getString("SEX");
                    String phone = item.getString("PHONE");
					
					//设置用户信息
                    SystemContext.initUserInfo(userId,
                            protalStaffNo, protalToken, oaStaffNo,
                            oaToken, realName, siteNo, siteName,
                            mobile, position, sex, phone);
					
					//打开并跳转到系统主界面
					gotoMainActivity();
					
				}else{
					UIHelper.showMessage(context, message);
				}
			}else if(what == Constants.WHAT_LOGIN_CONVERT){	//门户登录转换：门户登录成功之后需要转换StaffNo值
				ResultItem item = response.getResultItem(ResultItem.class);
				if (!BeanUtils.isEmpty(item)) {
					
					String code = item.getString("code");
					String message = item.getString("message");
					if(Constants.SUCCESS_CODE.equals(code)){
						item = item.getItems("data").get(0);
						
						String oaStaffNo = item.getString("STAFF_NO");// 移动OA的StaffNO
						String oaToken = item.getString("AUTH_TOKEN");// 移动OA的AuthToken
						
						SystemContext.setAccount(oaStaffNo);
						SystemContext.setSessionid(oaToken);
						
						//打开并跳转到系统主界面
						gotoMainActivity();
						
					}else{
						UIHelper.showMessage(context, message);
					}
				}
				
			}

		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			if (what == Constants.WHAT_LOGIN_OA || what == Constants.WHAT_LOGIN_PORTAL) {//登录
				showErrorMessage(getString(R.string.system_login_error_message));
			}
		}

		@Override
		public void onNetError(int what) {
			if (what == Constants.WHAT_LOGIN_OA || what == Constants.WHAT_LOGIN_PORTAL) {//登录
				showErrorMessage(getString(R.string.system_login_net_error_message));
			}
		}

	};

	// 跳转到输入用户名和密码页面
	public void toLogin(boolean isLogin) {
		if (isLogin) {
			userHelper = new UserHelper();
			userHelper.setAutoLogin(false);
		}
		UIHelper.forwardTargetActivity(LoginGesturesPasswordActivity.this,
				SystemLoginActivity.class, null, true);
	}
	
	/**
	 * 根据门户的StaffNo获取OA上对应的StaffNo和Token值<br>
	 * 因为门户和OA的StaffNo值不一致，所以门户登录成功之后需要进行StaffNo转换
	 */
	public void convertStaffNoForOA(){
		ApiRequest request = OAServicesHandler.getStaffNoAndTokenForOA(SystemContext.getAccountProtal());
		helper.invoke(request, callBack, Constants.WHAT_LOGIN_CONVERT);
	}
	
	/**
	 * 跳转到主界面
	 */
	private void gotoMainActivity() {
		Intent intent = new Intent(LoginGesturesPasswordActivity.this, MainActivity.class);
		startActivity(intent);
		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		finish();
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		default:
			break;
		}
		return super.onCreateDialog(id);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	public void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(),
					getString(R.string.system_logout_again), Toast.LENGTH_SHORT)
					.show();
			// 利用handler延迟发送更改状态信息
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			this.finish();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == Constants.WHAT_VPN) {
			String prefix = getPackageName();
			Intent intent = new Intent(this, OaVpnService.class)
					.putExtra(prefix + ".ADDRESS",	getString(R.string.vpn_address))
					.putExtra(prefix + ".PORT", getString(R.string.vpn_port))
                    .putExtra(prefix + ".ACCOUNT", getString(R.string.vpn_account))
					.putExtra(prefix + ".SECRET",getString(R.string.vpn_secret));
			startService(intent);
			isVpn = true;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private static Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			isExit = false;
		}
	};
	
	/**判断是否需要vpn 需要进行连接*/
	public void JudgeVpn() {
		// 等于1的时候使用vpn
		if (Constants.VPN_OPEN.equals(mContext
				.getString(R.string.vpn_isconnection))) {
			isVpn = false;
			// 调用vpn
			Intent intentVPN = VpnService.prepare(mContext);
			if (intentVPN != null) {
				startActivityForResult(intentVPN, Constants.WHAT_VPN);
			} else {
				onActivityResult(0, Constants.WHAT_VPN, null);
			}
		}else{
			isVpn = true;
		}
	}

	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.tv_change_user){	//更改用户
			userHelper.setIsLock(false);
			userHelper.setAutoLogin(false);
			UIHelper.forwardTargetActivity(mContext, SystemLoginActivity.class, null, true);
			
		}else if(v.getId()==R.id.tv_forget_pass){
			UIHelper.forwardTargetActivity(mContext, GestureForgetActivity.class, null, true);
		}
	}

}
