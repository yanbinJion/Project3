package com.powerriche.mobile.na.oa.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Created by root on 16-6-8.
 */
public class LeaveProcessActivity extends BaseActivity implements View.OnClickListener {

    private final String TAG = "TaskProcessActivity";

    private String leaveId;

    private EditText notesEdt;
    private Button agreeBtn;
    private Button disagreeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_process_layout);
        leaveId = getIntent().getStringExtra("leaveId");
        Logger.d(TAG, "leaveId: " + leaveId);
        initView();
    }

    private void initView() {
        TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
        topActivity.setBtnBackOnClickListener(this);
        topActivity.setRightBtnVisibility(View.GONE);
        topActivity.setTopTitle(getString(R.string.task_process_title));
        notesEdt = (EditText) findViewById(R.id.et_suggest);
        agreeBtn = (Button) findViewById(R.id.task_process_agree_btn);
        disagreeBtn = (Button) findViewById(R.id.task_process_disagree_btn);
        agreeBtn.setOnClickListener(this);
        disagreeBtn.setOnClickListener(this);
        findViewById(R.id.ll_suggest_wrap).setOnClickListener(this);
        findViewById(R.id.btn_send).setVisibility(View.GONE);
        notesEdt = (EditText) findViewById(R.id.et_suggest);
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            ResultItem item = response.getResultItem(ResultItem.class);
            if (!BeanUtils.isEmpty(item)) {
                String code = item.getString("code");
                if (Constants.SUCCESS_CODE.equals(code)) {
                    Toast.makeText(LeaveProcessActivity.this, getString(R.string.system_succes_cl), Toast.LENGTH_SHORT).show();
                    LeaveDetailActivity.finishActivity();
                    LeaveProcessActivity.this.finish();
                    return;
                }
            }
            Toast.makeText(LeaveProcessActivity.this, getString(R.string.system_request_error_message), Toast.LENGTH_SHORT).show();
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (10086 == requestCode && data != null) {
            try {
                String content = data.getStringExtra("SUGGEST_CONTENT");
                if(!BeanUtils.isEmpty(content)){
                    notesEdt.setText(content);
                }
            } catch (Exception e) {
            	e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void processLeave(String state) {
		ApiRequest request = OAServicesHandler.auditLeave(leaveId, notesEdt.getText().toString().trim(), state, "0");
		request.setMessage(getString(R.string.system_commit_message));
		helper.invokeWidthDialog(request, callBack, 10000);
	}

    @Override
    public void onClick(View view) {
        int viewId = view.getId();
        if (R.id.task_process_agree_btn == viewId) {
        	processLeave("1");
        } else if (R.id.task_process_disagree_btn == viewId) {
        	processLeave("-1");
        } else if (viewId == R.id.system_back) {
            finish();
        } else if (viewId == R.id.ll_suggest_wrap) {
            UIHelper.forwardTargetActivityForResult(this,
                    DocumentTransactorSuggestActivity.class, null, false, 10086);
        }
    }
}
