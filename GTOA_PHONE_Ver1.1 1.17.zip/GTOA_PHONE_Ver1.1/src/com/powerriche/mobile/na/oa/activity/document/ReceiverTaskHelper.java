package com.powerriche.mobile.na.oa.activity.document;
	
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.MTaskDetailActivity;
import com.powerriche.mobile.na.oa.activity.MyTaskActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.TemperCache;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;

import java.util.ArrayList;
import java.util.List;
	
/** 
 * 接受任务帮助类
 * Created by root on 16-5-9.
 */ 
public class ReceiverTaskHelper implements SearchBarWidget.onSearchListener {
    
    private final String TAG = "ReceiverTaskHelper";

    private PullToRefreshListView mPullView;
    private ListView mListView;
    private TextView tvNoDataMsg;

    private List<ResultItem> resultItems = new ArrayList<ResultItem>();
    private List<ResultItem> allResultItems = new ArrayList<ResultItem>();

    private int doucmentType = 0;

    private InvokeHelper helper = null;

    private Context mContext = null;

    private IRequestCallBack callBack = null;

    private ResultSimpleAdapter adapter;

    private SearchBarWidget mSearchBarWidget;

    private String searchText;

    private int pageIndex;

    public ReceiverTaskHelper(Context context, View contextView, TextView tvNoDataMsg, PullToRefreshListView pullView,
                          ListView listView, IRequestCallBack callback, InvokeHelper helper) {
        this.mContext = context;
        MyTaskActivity activity = (MyTaskActivity) context;
        this.callBack = callback;
        this.tvNoDataMsg = tvNoDataMsg;
        this.helper = helper;

        mSearchBarWidget = (SearchBarWidget) contextView.findViewById(R.id.search_bar_widget);
        mSearchBarWidget.setOnSearchListener(this);

        mPullView = pullView;

        mListView = listView;
        mListView.setDivider(null);
        mListView.setCacheColorHint(Color.TRANSPARENT);
        mListView.setFadingEdgeLength(0);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
                int resultItemIndex = position;
                if(resultItemIndex == 0 && (R.id.layout_search_bar_top == mListView.getChildAt(0).getId())){
                    return;//跳过：被单击的是搜索栏
                }else{
                    resultItemIndex = resultItemIndex - 1;
                }

                ResultItem item = resultItems.get(resultItemIndex);
                if(item == null){
                    return;//空
                }
                String streamId = item.getString("WF_NO");
                String taskId = item.getString("TASK_ID");
                String swfNo = item.getString("SWF_NO");
                String traceNo = item.getString("TRACE_NO");
                String fpuNo = item.getString("FPU_NO");
                if (null == streamId || streamId.length() <= 0) {
                    return;
                }
                //这里进入详情界面
                Bundle data = new Bundle();
                data.putString("taskId", taskId);
                data.putString("swfNo", swfNo);
                data.putString("wfNo", streamId);
                data.putString("traceNo", traceNo);
                data.putString("fpuNo", fpuNo);
                data.putBoolean("editable", false);
                UIHelper.forwardTargetActivity(mContext, MTaskDetailActivity.class, data, false);
            }
        });
    }

    public void process(HttpResponse response, int what) {
        if (pageIndex == 1) {
            resultItems.clear();// 清除
            allResultItems.clear();
        }
        List<ResultItem> result = response.getResultItem(ResultItem.class).getItems("data");
//        List<ResultItem> result = new ArrayList<ResultItem>();
        if (!BeanUtils.isEmpty(result)) {
            resultItems.addAll(result);
            allResultItems.addAll(result);
            TemperCache.getInstance().saveTaskList(result);
        }
        if (null == adapter) {
            int[] txtids = null;
            String[] keys = new String[]{"TASK_TITLE", "CONTACTER", "SEND_TIME"};

            // AndroidUI的组件ID
            txtids = new int[]{R.id.list_item_text_field,
                    R.id.list_item_text_field1, R.id.list_item_text_field2};
//            if (doucmentType == Constants.OPT_TYPE_SEND_TASK) {// 公文管理：发文
//                // 标题、传入人、开始时间（传入时间）
//                keys = new String[]{"TASK_TITLE", "TASK_STATE", "SEND_TIME"};
//            }

            adapter = new ResultSimpleAdapter(mContext, resultItems,
                    R.layout.list_item_gwgl, keys, txtids);
            adapter.setHelper(new ResultSimpleAdapter.ISimpleAdapterHelper() {
                @Override
                public Object parseValue(Object currentobj, List<?> items,
                                         int position, String key, View view) {
                    try {
                        ResultItem item = resultItems.get(position);
//
                        /**
                         * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
                         */
                        if ("SEND_TIME".equals(key) && currentobj != null) {
                        	DateUtils dateUtils = new DateUtils(mContext);
                            return dateUtils.diffFromToNow(DateUtils.parseDate(currentobj.toString()));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return (currentobj == null || "null".equals(currentobj
                            .toString().toLowerCase())) ? "" : currentobj;
                }

                @Override
                public void apply(View convertView, Object obj, int position) {
                    // 如果有搜索关键字，高亮显示
                    if (!BeanUtils.isEmpty(searchText)) {
                        TextView textView = (TextView) convertView
                                .findViewById(R.id.list_item_text_field);
                        SearchUtils.spannableResultItems(textView,
                                (String) textView.getText(), searchText);
                    }
                }
            });
            mListView.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }

        /**
         * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
         */
        if (BeanUtils.isEmpty(result) || result.size() < Constants.COMMON_PAGE_SIZE) {
            // 已经全部加载完成，关闭UI组件的下拉加载更多功能
            mPullView.onPullDownRefreshComplete();
            mPullView.onPullUpRefreshComplete();
            mPullView.setHasMoreData(false);

            if(pageIndex==1 && (BeanUtils.isEmpty(result) || result.size()==0)){
                mPullView.setVisibility(View.GONE);
                tvNoDataMsg.setVisibility(View.VISIBLE);
            }else{
                mPullView.setVisibility(View.VISIBLE);
                tvNoDataMsg.setVisibility(View.GONE);
            }

        } else {
            // 还有更多数据，继续打开“下拉加载更多”功能
            mPullView.onPullDownRefreshComplete();
            mPullView.onPullUpRefreshComplete();
            mPullView.setHasMoreData(true);
            mPullView.setVisibility(View.VISIBLE);
            tvNoDataMsg.setVisibility(View.GONE);
        }
    }

    public void loadData(int documentTye, int what, int pageIndex,boolean isDialog) {
        this.pageIndex = pageIndex;
        this.doucmentType = documentTye;

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        ApiRequest request = null;
        request = OAServicesHandler.getPersonalTaskList(pageIndex, 1);
        Logger.e(TAG, "loadData " + request);
        if (request != null) {
            if (isDialog) {
                helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
            } else {
                helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
            }
        }
    }

    public int getDoucmentType() {
        return doucmentType;
    }

    @Override
    public void onSearchChange(String search) {
        searchText = search;
        resultItems.clear();// 清除
        if (allResultItems != null && allResultItems.size() > 0
                && !BeanUtils.isEmpty(search)) {
            resultItems.addAll(SearchUtils.filterResults(allResultItems,
                    search, "TITLE"));
        } else {
            resultItems.addAll(allResultItems);
        }

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }
}
