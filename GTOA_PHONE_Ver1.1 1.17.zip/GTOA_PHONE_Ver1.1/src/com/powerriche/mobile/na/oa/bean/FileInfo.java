package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

public class FileInfo implements Serializable {
	private static final long serialVersionUID = -7516778145073015050L;
	private String fileId;
	private String fileTitle;
	private String fileName;
	private String fileSize;
	private String filePath;

	public String getFileId() {
		return fileId;
	}

	public String getFileTitle() {
		return fileTitle;
	}

	public String getFileName() {
		return fileName;
	}

	public String getFileSize() {
		return fileSize;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public void setFileTitle(String fileTitle) {
		this.fileTitle = fileTitle;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

}
