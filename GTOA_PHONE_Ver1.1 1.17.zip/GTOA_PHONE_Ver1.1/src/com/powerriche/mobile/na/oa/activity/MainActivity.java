package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout.DrawerListener;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nineoldandroids.view.ViewHelper;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseFragmentActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.AskLeaveItemHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentWaitListHelper;
import com.powerriche.mobile.na.oa.activity.document.UserInfoHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.receiver.GTOAInitService;
import com.powerriche.mobile.na.oa.receiver.UpdateVersionReceiver;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.SystemContext;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.ContactDbhelper;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 框架主类
 * 
 * @author Fitz
 * @date 2015年4月23日
 * @version v1.0
 */
public class MainActivity extends BaseFragmentActivity implements OnClickListener {

	private Context					mContext;
	private FrameManager			frameManager;
	private int[]					lls, btns;

	private DrawerLayout			mDrawerLayout;

	private View					leftFragment, rightFragment;			// 左右侧滑菜单布局View

	private RelativeLayout			rlUserList;

	private RelativeLayout			rlAbSet;
	
	private RelativeLayout			rlAttendance;
	

	/** 待办事宜 */
	public DocumentWaitListHelper	documentWaitListHelper;
	/** 公文管理 */
//	public DocumentGwglListHelper	documentGwglListHelper;
	/** 会议管理 */
//	public DocumentHyglListHelper	documentHyglListHelper;

	// 会议管理列表
	public final static int			WHAT_REQUEST_MEET_WAIT_LIST	= 5452;

	// 定义一个变量，来标识是否退出
	private static boolean			isExit						= false;
	public static TextView			realName 					= null;

	private UpdateVersionReceiver receiver;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		UIHelper.hideTitle(this);
		this.mContext = this;
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.main);
		
		initView();
		initEvents();
		initIds();
//		initReceiver();
//		initService();
		
		//使用StaffNo作为极光推送的设置别名(Alias)注册
		UIHelper.initJPush(mContext, SystemContext.getAccount());
//		BeanUtils.setAlarm(this);
	}
	
	
	/**
	 * 打开右抽屉，锁定左抽屉
	 */
	public void openRightMenu() {
		mDrawerLayout.openDrawer(Gravity.RIGHT);
		mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.RIGHT);
		mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, Gravity.LEFT);
	}

	/**
	 * 打开左抽屉，锁定右抽屉
	 */
	public void openLeftMenu() {
		mDrawerLayout.openDrawer(Gravity.LEFT);
		mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.LEFT);
		mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, Gravity.RIGHT);
	}

	private void initEvents() {
		mDrawerLayout.setDrawerListener(new DrawerListener() {
			@Override
			public void onDrawerStateChanged(int newState) {
			}

			@Override
			public void onDrawerSlide(View drawerView, float slideOffset) {
				View mContent = mDrawerLayout.getChildAt(0);
				View mMenu = drawerView;
				float scale = 1 - slideOffset;
				float rightScale = 0.8f + scale * 0.2f;

				if (drawerView.getTag().equals("LEFT")) {

					float leftScale = 1 - 0.3f * scale;

					ViewHelper.setScaleX(mMenu, leftScale);
					ViewHelper.setScaleY(mMenu, leftScale);
					ViewHelper.setAlpha(mMenu, 0.6f + 0.4f * (1 - scale));
					ViewHelper.setTranslationX(mContent, mMenu.getMeasuredWidth() * (1 - scale));
					ViewHelper.setPivotX(mContent, 0);
					ViewHelper.setPivotY(mContent, mContent.getMeasuredHeight() / 2);
					mContent.invalidate();
					ViewHelper.setScaleX(mContent, rightScale);
					ViewHelper.setScaleY(mContent, rightScale);

				} else {

					ViewHelper.setTranslationX(mContent, -mMenu.getMeasuredWidth() * slideOffset);
					ViewHelper.setPivotX(mContent, mContent.getMeasuredWidth());
					ViewHelper.setPivotY(mContent, mContent.getMeasuredHeight() / 2);
					mContent.invalidate();
					ViewHelper.setScaleX(mContent, rightScale);
					ViewHelper.setScaleY(mContent, rightScale);
				}

			}

			@Override
			public void onDrawerOpened(View drawerView) {
				if(drawerView.getId() == R.id.fragment_right_menu){	//右边抽屉菜单打开
					mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, Gravity.LEFT);	//左边不能滑
//					Logger.e("MainActivity", "--左-->边不能滑");
				}else{
					mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, Gravity.RIGHT);	//右边不能滑
//					Logger.e("MainActivity", "--右-->边不能滑");
				}
			}

			@Override
			public void onDrawerClosed(View drawerView) {
				//抽屉关闭时，解锁两边抽屉锁定
				mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.LEFT);
				mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.RIGHT);
//				Logger.e("MainActivity", "------左右都能滑------");
				//意思是右边菜单锁定，然后可以根据点击某个按钮操作，弹出(拉出)右边菜单
				//mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, Gravity.RIGHT);
			}
		});
	}

	private void initView() {
		mDrawerLayout = (DrawerLayout) findViewById(R.id.id_drawerLayout);
		//意思是右边菜单锁定，然后可以根据点击某个按钮操作，弹出(拉出)右边菜单
		//mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, Gravity.RIGHT);

		leftFragment = mDrawerLayout.findViewById(R.id.fragment_left_menu);
		rightFragment = mDrawerLayout.findViewById(R.id.fragment_right_menu);

		/**
		 * 左边的功能菜单
		 */

		// 设置姓名和部门
		realName = (TextView) leftFragment.findViewById(R.id.real_name_textView);
		realName.setOnClickListener(this);
		realName.setText(SystemContext.getUserName());
		leftFragment.findViewById(R.id.iv_user_icon).setOnClickListener(this);
		TextView departmentName = (TextView) leftFragment.findViewById(R.id.department_textView);
		departmentName.setText(SystemContext.getSiteName());

		// 功能菜单：AB角设置
		rlAbSet = (RelativeLayout) leftFragment.findViewById(R.id.rl_ab_set);
		rlAbSet.setOnClickListener(this);

		// 功能菜单：常用意见
		RelativeLayout rlSuggest = (RelativeLayout) leftFragment.findViewById(R.id.rl_suggest);
		rlSuggest.setOnClickListener(this);
			 
		// 功能菜单：组织机构
		rlUserList = (RelativeLayout) leftFragment.findViewById(R.id.rl_user_list);
		rlUserList.setOnClickListener(this);
			  
		// 功能菜单：考勤记录
		rlAttendance = (RelativeLayout) leftFragment.findViewById(R.id.rl_attendance);
		rlAttendance.setOnClickListener(this);
			  
		/**   
		 * 右边的功能菜单
		 */   
			   
		// 功能菜单：综合查询
		LinearLayout rightMenuZHCX = (LinearLayout) rightFragment.findViewById(R.id.ll_common_search);
		rightMenuZHCX.setOnClickListener(this);
			
		// 功能菜单：领导政务
		LinearLayout rightMenuLDZW = (LinearLayout) rightFragment.findViewById(R.id.ll_govaffair);
		rightMenuLDZW.setOnClickListener(this);
			
		// 功能菜单：通知公告
		LinearLayout rightMenuTZGG = (LinearLayout) rightFragment.findViewById(R.id.ll_notice);
		rightMenuTZGG.setOnClickListener(this);
			
		// 功能菜单：任务管理
		LinearLayout rightMenuRWGL = (LinearLayout) rightFragment.findViewById(R.id.ll_unit_affair);
		rightMenuRWGL.setOnClickListener(this);
			
		// 功能菜单：传阅(即公文传阅)
		LinearLayout rightMenuGWCY = (LinearLayout) rightFragment.findViewById(R.id.ll_transfer);
		rightMenuGWCY.setOnClickListener(this);
			
		// 功能菜单：常务会议
		LinearLayout rightMenuCWHY = (LinearLayout) rightFragment.findViewById(R.id.ll_excutivemeet);
		rightMenuCWHY.setOnClickListener(this);
			
        helper.invoke(OAServicesHandler.getSiteStaffTreeList(), callBack, 0);
	}		
			
	void initIds() {
		lls = new int[3];
		lls[0] = R.id.ll_main_dbsy;
		lls[1] = R.id.ll_main_gwgl;
		lls[2] = R.id.ll_main_meet;
			
		btns = new int[3];
		btns[0] = R.id.btn_main_dbsy;
		btns[1] = R.id.btn_main_gwgl;
		btns[2] = R.id.btn_main_meet;
			
		this.frameManager = FrameManager.instance(this);
		this.frameManager.showDefaultPage(0);
			
		for (int i = 0, len = btns.length; i < len; i++) {
			findViewById(btns[i]).setOnClickListener(this);
		}	
	}		
			
	@Override
	public void onClick(View v) {
		int id = v.getId();
			
		if(id == R.id.btn_main_dbsy){	// 显示界面：待办事宜
			this.frameManager.showFrame(FrameManager.FRAME_0, null);
			
		}else if(id == R.id.btn_main_gwgl){	// 显示界面：公文管理
			this.frameManager.showFrame(FrameManager.FRAME_1, null);
			
		}else if(id == R.id.btn_main_meet){	// 显示界面：会议管理
			this.frameManager.showFrame(FrameManager.FRAME_2, null);
			
		}else if(id == R.id.rl_user_list){	// 跳转到界面：组织成员列表
			UIHelper.forwardTargetActivity(mContext, UserListActivity.class, null, false);
		}else if(id == R.id.rl_attendance){	// 跳转到界面：考勤记录
			UIHelper.forwardTargetActivity(mContext, AttendanceActivity.class, null, false);			
		}else if(id == R.id.rl_ab_set){	// 跳转到界面：AB角设置
			UIHelper.forwardTargetActivity(mContext, ABRoleActivity.class, null, false);
		}else if(id == R.id.rl_suggest){	// 跳转到界面：常用意见
			UIHelper.forwardTargetActivity(mContext, SuggestListActivity.class, null, false);
		}else if(id == R.id.ll_common_search){	//// 跳转到界面：综合查询
			UIHelper.forwardTargetActivity(mContext, CommonSearchInputActivity.class, null, false);
		}else if(id == R.id.ll_govaffair){	// 跳转到界面：领导政务
			UIHelper.forwardTargetActivity(mContext, GovAffairActivity.class, null, false);
		}else if(id == R.id.ll_notice){	// 跳转到界面：通知公告
			UIHelper.forwardTargetActivity(mContext, NoticeListActivity.class, null, false);
		}else if(id == R.id.ll_unit_affair){	// 跳转到界面：单位事务
			UIHelper.forwardTargetActivity(mContext, UnitAffairActivity.class, null, false);
		}else if(id == R.id.user_setting_btn){	// 跳转到界面：设置页面
			UIHelper.forwardTargetActivity(mContext, UserSettingActivity.class, null, false);
		}else if(id == R.id.ll_transfer){	// 跳转到界面：传阅(即公文传阅)
			UIHelper.forwardTargetActivity(mContext, PassreadListActivity.class, null, false);
			
		}else if(id==R.id.real_name_textView || id==R.id.iv_user_icon){
			Bundle bundle = new Bundle();
			
			if (Constants.IS_USER_PORTAL) {
				bundle.putString(UserInfoHelper.KEY_USER_STAFFNO, SystemContext.getAccountProtal());
			} else {
				bundle.putString(UserInfoHelper.KEY_USER_STAFFNO, SystemContext.getAccount());
			}
			UIHelper.forwardTargetActivity(mContext, UserInfoActivity.class, bundle, false);
			
		}else if(id == R.id.ll_excutivemeet) {	// 跳转到界面：常务会议
			UIHelper.forwardTargetActivity(mContext, ExecutiveMeetingActivity.class, null, false);
		}	
	}		
			
	/**		
	 * 方法说明：<br> tab底部菜单选中
	 * 		
	 * @param selected
	 */		
	public void selectBottomItem(int selected) {
		for (int i = 0, len = lls.length; i < len; i++) {
			RelativeLayout ll = (RelativeLayout) findViewById(lls[i]);
			if (i == selected) {
				ll.setSelected(true);
			} else {
				ll.setSelected(false);
			}
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(this.receiver != null)
			unregisterReceiver(this.receiver);
		
		frameManager.onDestroy();
		frameManager = null;
		mDrawerLayout = null;
	}


	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	public IRequestCallBack getCallBack() {
		return callBack;
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			
			ResultItem item = response.getResultItem(ResultItem.class);
            if (0 == what) {
                if (!BeanUtils.isEmpty(item)) {
                    ContactDbhelper dbHelper = new ContactDbhelper(mContext);
                    String code = item.getString("code");
                    if (!Constants.SUCCESS_CODE.equals(code)) {
                        dbHelper.insertContactResult(response.getResultItem(ResultItem.class)
                                .getItems("data"));
                    } else {
                        dbHelper.deleteAll();
                    }
                }
                return;
            }
			if (checkResult(item)) {
				//请假详情返回
				if(what == Constants.OPT_TYPE_LEAVE_DETAIL){
					AskLeaveItemHelper leaveItemHelper= new AskLeaveItemHelper();
					leaveItemHelper.process(mContext, response, true);
				}else if (what == Constants.WHAT_REQUEST_WAIT) {// 待办事宜
                    documentWaitListHelper.process(response, what);
                } else if (what == Constants.WHAT_REQUEST_GWGL) {// 公文管理
//							documentGwglListHelper.process(response, what);
                } else if (what == Constants.WHAT_REQUEST_HYGL) {// 会议管理
//						documentHyglListHelper.process(response, what);
                }
			}
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
			default:
				break;
		}
		return super.onCreateDialog(id);
	}

	private static Handler	mHandler	= new Handler() {
											@Override
											public void handleMessage(Message msg) {
												super.handleMessage(msg);
												isExit = false;
											}
										};

	public void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), getString(R.string.system_logout_again), Toast.LENGTH_SHORT).show();
			// 利用handler延迟发送更改状态信息
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
//			android.os.Process.killProcess(android.os.Process.myPid());
			finish();
		}
	}

	@Override
	protected void onResume() {
		try {
			if (documentWaitListHelper != null) {
				documentWaitListHelper.doRemoveItemById();
			}
			//公文管理调用移除方法
			/*if (documentGwglListHelper != null) {
				documentGwglListHelper.doRemoveItemById();
			}*/
			//主板会议调用移除方法
			/*if (documentHyglListHelper != null) {
				documentHyglListHelper.doRemoveItemById();
			}*/
			frameManager.onResume();
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.onResume();
	}

	/**
     * 初始化广播
     */
	private void initReceiver(){
		if (this.receiver == null)
			this.receiver = new UpdateVersionReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(UpdateVersionReceiver.ACTION_APP_UPDATE);
		this.registerReceiver(receiver, filter);
	}
	
	/**
     * 初始化启动服务
     */
    private void initService(){
		Intent intent = new Intent(this, GTOAInitService.class);
		Bundle bundle = new Bundle();
		bundle.putInt(GTOAInitService.DO_TYPE, GTOAInitService.DO_APPLICATION_START);
		intent.putExtras(bundle);
		this.startService(intent);
    }
	
} 
