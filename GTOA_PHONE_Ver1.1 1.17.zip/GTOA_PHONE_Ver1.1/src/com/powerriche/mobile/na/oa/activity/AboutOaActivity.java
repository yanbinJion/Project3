package com.powerriche.mobile.na.oa.activity;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 关于OA
 * 
 * @author 高明峰
 * @date 2015年5月11日
 * @version v1.0
 */
public class AboutOaActivity extends BaseActivity implements OnClickListener {

	private TopActivity topActivity;

	private TextView tvCurrentVersion;
	private int localVersionCode = Integer.MAX_VALUE;//本地APK的版本编号
	private String localVersionName = "1.0.0";//本地APK的版本名称

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.about_oa_layout);

		bindViews();
		tvCurrentVersion = (TextView) findViewById(R.id.tvCurrentVersion);
		
		try {
			// 得到当前版本号
			PackageManager manager = this.getPackageManager();
			PackageInfo info = manager.getPackageInfo(this.getPackageName(), 0);
			localVersionCode = info.versionCode;
			localVersionName = info.versionName;

			String localVersionInfo = "当前版本：" + localVersionName;
			tvCurrentVersion.setText(localVersionInfo);//显示当前版本
		} catch (Exception e) {
		}
	}

	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		//topActivity.setBtnBackText("  " + getString(R.string.setting_auxiliary_titile));
		topActivity.setTopTitle(getString(R.string.about_oa_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.INVISIBLE);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:// 返回
			finish();
			break;
		}

	}

	public void exit() {
		finish();
	}

}
