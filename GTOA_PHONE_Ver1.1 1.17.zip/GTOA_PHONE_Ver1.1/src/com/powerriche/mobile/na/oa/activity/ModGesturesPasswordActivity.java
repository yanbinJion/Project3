package com.powerriche.mobile.na.oa.activity;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.ContentView;
import com.powerriche.mobile.na.oa.view.GestureDrawl.GestureCallBack;
import com.powerriche.mobile.na.oa.view.ModGesPwdDialog;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
import com.powerriche.mobile.oa.tools.UserHelper;

/**
 * Filename : ModGesturesPasswordActivity
 * 
 * @Description : 修改手势密码
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-22 17:50:00
 */
public class ModGesturesPasswordActivity extends BaseActivity implements OnClickListener {

	private final static int DIALOG_LOGINPASSWORD = 1234;

	private final static int DIALOG_CHECK = 4234;

	private final static int DIALOG_CHECKPASSWORD = 1235;

	private FrameLayout gesturespwdLayout;

	private ContentView content;

	private UserHelper userHelper = null;

	private ResultItem pwdItem = null;

	/**
	 * 操作次数
	 */
	private int successNumber = 1;

	private TextView msgView;

	private String alertMessage;
	private Dialog dialog;

	//验证成功
	private boolean isAuthSuccess = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gestures_password);
		
		((RelativeLayout) findViewById(R.id.user_name_layout)).setVisibility(View.GONE);
		
		findViewById(R.id.tv_forget_pass).setVisibility(View.GONE);
		findViewById(R.id.tv_change_user).setVisibility(View.GONE);
		
		gesturespwdLayout = (FrameLayout) findViewById(R.id.gesturespwd_layout);
		userHelper = new UserHelper();
		pwdItem = userHelper.getLastGesturesCode();

		msgView = (TextView) findViewById(R.id.pwdMsgView);
		msgView.setText(R.string.gesturespassword_seting_title);
		// 如果查询为空，调转到设置手势密码
		if (pwdItem == null) {
			UIHelper.forwardTargetActivity(this,
					SetGesturesPasswordActivity.class, null, true);
		}
		
		// 初始化一个显示各个点的viewGroup
		content = new ContentView(Constants.GESTURES_OPTTYPE_MODPWD, this,null, new GestureCallBack() {
					@Override
					public void checkedSuccess() {
						content.clearAll();// 清除页面所有的画线
						msgView.setText(R.string.gesturespassword_set_again);
						msgView.setTextColor(Color
								.parseColor(getString(R.color.white)));
						successNumber++;
					}

					@Override
					public void checkedFail() {
						// 如果等于1，表示密码第一次设置就没有成功过，就失败，提示：必须大于几个点
						if (successNumber == 1) {
							msgView.setText(R.string.gesturespassword_min_points);
						} else {
							msgView.setText(R.string.gesturespassword_set_notsame);
						}
						msgView.setTextColor(Color.parseColor(getString(R.color.red)));
					}

					@Override
					public void checkedSuccessBack(String param) {
						if (isAuthSuccess) {
							msgView.setTextColor(Color.parseColor(getString(R.color.white)));
							msgView.setText(R.string.gesturespassword_mod_success);
							userHelper = new UserHelper();
							ResultItem userItem = userHelper.getLastUserInfo();
							// 删除旧的手势密码
							userHelper.delGesturesCodeByUserId(userItem.getString("USERID"));
							// 保存新的手势密码
							userHelper.setGesturesCode(userItem.getString("USERID"), param, true);
							successNumber = 1;
							// content.setParentView(gesturespwdLayout);
							toUserAccountSecurity();// 跳转到“账户安全”界面
						} else {
							showDialog(DIALOG_CHECKPASSWORD);
							showDialog(DIALOG_LOGINPASSWORD);
						}
					}
				});

		content.setParentView(gesturespwdLayout);
		// 设置手势解锁显示到哪个布局里面
		showDialog(DIALOG_LOGINPASSWORD);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			toUserAccountSecurity();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	// 调转到帐号安全页面
	public void toUserAccountSecurity() {
		UIHelper.forwardTargetActivity(ModGesturesPasswordActivity.this,
				UserAccountSecurityActivity.class, null, true);
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
			case DIALOG_LOGINPASSWORD :
				userHelper = new UserHelper();
				ResultItem userItem = userHelper.getLastUserInfo();
				
				final ModGesPwdDialog mDialog = new ModGesPwdDialog(this);
				mDialog.setTvTips(userItem.getString("USERID")+"\n"+getString(R.string.gesturespassword_mod_loginpassword));// 对话框标题
				mDialog.setCancelable(false);
				mDialog.setOnConfirmClickListener("确定",
						new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								EditText password = mDialog.getEtPassword();
								if (checkInput(password)) {
									toCheckPassword(password.getText().toString());// 验证密码是否正确
									
								} else {
									Toast.makeText(getApplicationContext(), alertMessage, Toast.LENGTH_SHORT).show();
								}
							}
						});
				mDialog.setOnCancelClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						toUserAccountSecurity();// 跳转到“账户安全”界面
					}
				});
				mDialog.show();
				dialog = mDialog;

				break;
			case DIALOG_CHECK :
				Toast.makeText(getApplicationContext(), alertMessage, Toast.LENGTH_SHORT).show();

			case DIALOG_CHECKPASSWORD :
				Toast.makeText(getApplicationContext(),
						getString(R.string.gesturespassword_mod_loginmsg),
						Toast.LENGTH_SHORT).show();
				break;
			default :
				break;
		}

		return super.onCreateDialog(id);
	}

	/** 验证提交的数据 */
	public boolean checkInput(EditText passwordEdit) {
		alertMessage = "";
		// 密码
		if (passwordEdit != null
				&& BeanUtils.isEmpty(passwordEdit.getText().toString())) {
			alertMessage = getString(R.string.gesturespassword_mod_loginpassword);
			return false;
		}

		return true;
	}

	/** 判断密码是否正确 */
	public void toCheckPassword(String password) {
		ApiRequest request = OAServicesHandler.checkPassword(password);
		helper.invokeWidthDialog(request, callBack);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				alertMessage = item.getString("message");
				String code = item.getString("code");
				// 操作成功
				if (Constants.SUCCESS_CODE.equals(code)) {
					isAuthSuccess = true;
					dialog.dismiss();// 密码正确，可以关闭对话框
					
				} else {
					isAuthSuccess = false;
					dialog.show();// 密码不对，仍然显示对话框
					showDialog(DIALOG_CHECK);
				}
			}
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error, int what) {
			showErrorMessage(getString(R.string.system_commit_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	@Override
	public void onClick(View view) {
		if (view.getId() == R.id.system_back) {
			setResult(RESULT_OK);
			finish();
		}
	}

}
