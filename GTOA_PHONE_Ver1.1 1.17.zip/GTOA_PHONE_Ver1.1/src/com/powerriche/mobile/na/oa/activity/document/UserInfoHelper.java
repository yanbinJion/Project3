package com.powerriche.mobile.na.oa.activity.document;

import android.content.Context;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.UserInfoActivity;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br>
 * 获取个人信息Helper
 * 
 * @author Fitz
 * @date 2015年4月27日
 * @version v1.0
 */
public class UserInfoHelper {

	public static final String KEY_USER_STAFFNO = "KEY_USER_STAFFNO";

	private Context mContext;

	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;

	public UserInfoHelper(Context context, IRequestCallBack callBack) {
		this.mContext = context;
		this.callBack = callBack;
		this.helper = ((UserInfoActivity) context).getInvokeHelper();
	}

	public void loadData(String staffNo, int what) {
		ApiRequest request = OAServicesHandler.getUserInfo(staffNo);// 获取用户信息
		if (request != null) {
			request.setMessage(mContext.getString(R.string.system_load_message));
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	public void editUser(String realName, String sex, String phone,
			String mobile, int what) {
		ApiRequest request = OAServicesHandler.editUserInfo(realName, sex,
				phone, mobile);
		if (request != null) {
			request.setMessage(mContext
					.getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, what);
		}
	}

	public UserInfo getUserInfo(HttpResponse response) {
		ResultItem item = response.getResultItem(ResultItem.class);
		if (!BeanUtils.isEmpty(item)) {
			try {
				// 解析权限
				String code = item.getString("code");
				// 操作成功
				if (Constants.SUCCESS_CODE.equals(code)) {
					item = item.getItems("data").get(0);
					String name = item.getString("REAL_NAME");
					String sex = item.getString("SEX");
					String siteName = item.getString("SITE_NAME"); // 科室
					String position = item.getString("POSITION"); // 职位
					String phone = item.getString("PHONE");
//					String phone = item.getString("RELA_PHONE");
					String mobile = item.getString("MOBILE");
				
					UserInfo user = new UserInfo();
					user.setMobile(BeanUtils.isEmpty4Get(mobile));
					user.setPhone(BeanUtils.isEmpty4Get(phone));
					user.setPosition(position);
					user.setRealName(name);
					user.setSex(sex);
					user.setSiteName(siteName);
				
					return user;
				} else {
					// 未成功操作
					String message = item.getString("message");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return null;
	}		
			
}			
			