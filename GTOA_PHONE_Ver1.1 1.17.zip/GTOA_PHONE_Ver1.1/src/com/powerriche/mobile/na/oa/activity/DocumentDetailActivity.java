package com.powerriche.mobile.na.oa.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils.TruncateAt;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.DocumentTransactListAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.PassreadListAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentAddHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentDetailHelper;
import com.powerriche.mobile.na.oa.activity.document.DocumentHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.DocManagerInfo;
import com.powerriche.mobile.na.oa.bean.DocumentInfo;
import com.powerriche.mobile.na.oa.bean.DocumentParams;
import com.powerriche.mobile.na.oa.bean.PassreadInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.na.oa.down.DownloadInfoBean;
import com.powerriche.mobile.na.oa.down.DownloadInfoDAO;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper;
import com.powerriche.mobile.na.oa.down.DownloadUIHelper.DownloadButtonListener;
import com.powerriche.mobile.na.oa.view.RoundProgressButton;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.na.oa.view.TextDialog;
import com.powerriche.mobile.na.oa.view.TipsDialog;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.FileDownUtil;
import com.powerriche.mobile.oa.tools.FileUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;
import com.powerriche.mobile.oa.tools.TextBodyUtile;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 公文详细信息
 * 
 * @author Fitz
 * @date 2015年4月27日
 * @version v1.0
 */
public class DocumentDetailActivity extends BaseActivity implements
		OnClickListener, OnLongClickListener, DownloadButtonListener {

	public static final String TAG  = "DocumentDetailActivity";
	public static final int CODE_BASIC = 0;
	public static final int CODE_RETURN = 1;// 操作码：退件
	public static final int CODE_CALLBACK = 2;// 操作码：撤回
	public static final int CODE_URGE = 3;// 操作码：催办
	public static final int CODE_DELETE_FILE = 5;// 操作码：删除文件
	public static final int CODE_PASS_READ = 6;// 操作码：传阅
	public static final int CODE_INPUT_SUGGEST = 7;
	public static final int CODE_UPLOAD_TEXT_FILE = 8;// 操作码：上传文件

	public static final int CODE_MODFLY = 9; // 修改正文保存
	public static final int CODE_TRANCE = 10; // 办理送出
	public static final int CODE_MODIFY_UPLOAD_FILE = 11; // 附件上传

	public static final int CODE_PASS_READ_TAG = 1000;

	private Context mContext;

	private ViewPager viewPager;// 页卡内容
	private ImageView imageView;// 动画图片

	private TextView tv1, tv2, tv3;
	private View view1, view2, view3;

	private List<View> views;// Tab页面列表
	private int offset = 0;// 动画图片偏移量
	private int currIndex = 0;// 当前页卡编号
	private int bmpW;// 动画图片宽度

	private TopActivity topActivity;

	public static String documentId;
	private String wfNo, fpuNo, swfNo, traceNo,documentType;

	/** 0打开菜单，1传阅，2撤回 */
	private int goWhere = 0;

	private String passreadId = null;// 传阅编号
	// 标志：用于记录是否需要在详情页面调用“标志已阅”接口，1-需要，0-不需要
	// private int postReadFlag = 0;

	private boolean isFirst1 = true, isFirst3 = true;// isFirst2 = true,

	// 基本信息界面相关
	private DocumentDetailHelper detailHelper;
	private EditText etTitle, etTextNo, etDepartment, etUserName, etZhaiyao;
	private TextView tvHuanji, tvLevel, tvFileGroup, tvExtend;
	private LinearLayout llFileWrap;

	// 办理、传阅共用界面相关
	private ListView listView; // 办理信息ListView，传阅信息ListView

	// 办理信息相关
	private DocumentTransactListAdapter adapterManager;

	// 传阅信息相关
	private PassreadListAdapter adapterPassread; // 传阅列表
	private int passreadTag = -1; // 如果passread不等于1000，则初始话办理信息view，否则初始化传阅信息view
	private int passreadType = -1;// PASS_READ_TYPE 取消”已传件“的回复功能
	private EditText etPassreadContent;

	// ****************正文界面相关*****************
	private TextView tvNoTextBody; // 无正文提示
	private Button btnOpenFile; // 打开正文按钮
	private DocFileInfo bodyBean;
	private boolean isFirstOpen = true;

	// 附件上传相关
	private Button btnUpload;
	private String mdfFilePath, mdfFileName; // 附件上传成功临时变量
	// private FileDownHelper downHelper;

	// 逻辑菜单相关
	private PopupWindow mPop;
	private Button rightBtn;
	// 传阅回复按钮
	private Button btnReply;
	
	// 附件上传铺助
	private String deleteFilePath;
	
	private boolean isNewDoc = false; // 是否需要new一个新的word
	
	/**
	 * 已办的公文或者会议都不能删除增加附件<br>
	 * true可以删除新增
	 */
	private boolean isDeleteAddToken = true;
	
	/**
	 * 这个参数是办理界面的返回值：办理结果标志：1-办理成功（返回待办列表需要移除当前待办项），0-未办理、办理失败（返回待办列表不需要移除当前待办项）
	 */
	public static int dealwithFlag = 0;
	/** 撤回结果标题：1-撤回成功（返回已办列表需要移除当前已办项），0-未撤回、撤回失败（返回已办列表不需要移除当前已办项） */
	public static int retracementFlag = 0;
	/** 退件结果标题：1-退件成功（返回待办列表需要移除当前待办项），0-未退件、退件失败（返回待办列表不需要移除当前待办项） */
	public static int retroversionFlag = 0;
	
	private DownloadUIHelper downloadUIHelper = null;
	private DownloadInfoDAO dao = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		// getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
		this.mContext = this;
		// 设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		setContentView(R.layout.document_detail);

		documentType = getIntent().getStringExtra("documentType");
		documentId = getIntent().getStringExtra("documentId"); // 公文ID
		Log.i(TAG, " documentId "+documentId);
		wfNo = getIntent().getStringExtra("wfNo"); // 流程编号
		fpuNo = getIntent().getStringExtra("fpuNo"); // 当前环节编号
		swfNo = getIntent().getStringExtra("swfNo"); // 系统流程编号
		traceNo = getIntent().getStringExtra("traceNo"); // 系统流程编号
		Log.i(TAG, " wfNo "+wfNo+" traceNo "+traceNo);
		passreadId = getIntent().getStringExtra("passreadId"); // 传阅编号
		// postReadFlag = getIntent().getIntExtra("postReadFlag", 0);
		passreadTag = getIntent().getIntExtra("IS_PASS_READ", -1); // 传阅入口标示
		passreadType = getIntent().getIntExtra("PASS_READ_TYPE", -1);
		dealwithFlag = getIntent().getIntExtra("DEAL_WITH_FLAG", 0); // 这个参数是办理界面的返回值：办理结果标志：1-办理成功，0-未办理或办理失败
		isDeleteAddToken = getIntent()
				.getBooleanExtra("isDeleteAddToken", true); // 已办公文参数标志，已办公文附件，不可以新增跟删除
		
		bindViews();
		
		detailHelper = new DocumentDetailHelper(mContext, callBack, helper);
		// downHelper = new FileDownHelper(mContext);
		
		registerBroadcast();
		
		this.downloadUIHelper = new DownloadUIHelper(mContext);
		this.downloadUIHelper.setEventListener(this);
		this.dao = new DownloadInfoDAO(mContext);
	}	
		
	private void bindViews() {
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setTopTitle(getString(R.string.document_detail_title));
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		rightBtn = topActivity.getBtnRight();
		
		initImageView();
		initTextView();
		initViewPager();
		
		initView1();// 第1部分：基本信息
		initView2();// 第2部分：正文
		initView3();// 第3部分：办理信息
	}	
		
	private void initView1() {
		etTitle = (EditText) view1.findViewById(R.id.tv_title);
		etTextNo = (EditText) view1.findViewById(R.id.tv_text_no);
		etDepartment = (EditText) view1.findViewById(R.id.tv_department);
		etUserName = (EditText) view1.findViewById(R.id.tv_user_name);
		etZhaiyao = (EditText) view1.findViewById(R.id.tv_zhaiyao);
		
		tvHuanji = (TextView) view1.findViewById(R.id.tv_huanji);
		tvHuanji.setOnClickListener(this);
		tvLevel = (TextView) view1.findViewById(R.id.tv_level);
		tvLevel.setOnClickListener(this);
		
		tvExtend = (TextView) view1.findViewById(R.id.tv_extend);
		tvExtend.setOnClickListener(this);
		tvExtend.setTag(false);// 默认收起
		tvExtend.setVisibility(View.GONE);
		
		tvFileGroup = (TextView) view1.findViewById(R.id.tv_file_group);
		tvFileGroup.setOnClickListener(this);
		tvFileGroup.setTag(true);
		tvFileGroup.setVisibility(View.VISIBLE);
		llFileWrap = (LinearLayout) view1.findViewById(R.id.ll_file_wrap);
		llFileWrap.setVisibility(View.GONE);
		
		btnUpload = (Button) view1.findViewById(R.id.btn_upload);
		btnUpload.setOnClickListener(this);
		btnUpload.setVisibility(View.GONE);
		
		// 初始化传阅相关按钮
		if (passreadTag == CODE_PASS_READ_TAG) {
			if (passreadType == Constants.OPT_TYPE_GWCY_YC) { // 已传列表跳转到详情，没有回复功能点
				view1.findViewById(R.id.ll_sign_wrap).setVisibility(View.GONE); // 传阅下角回复GONE
			} else {
				view1.findViewById(R.id.ll_sign_wrap).setVisibility(
						View.VISIBLE); // 传阅下角回复VISIBLE
			}
			btnReply = (Button) view1.findViewById(R.id.btn_reply);
			btnReply.setOnClickListener(this); // 传阅回复按钮
			view1.findViewById(R.id.btn_input).setOnClickListener(this); // 导入常用建议按钮
			etPassreadContent = (EditText) view1.findViewById(R.id.et_content);
		}
	}

	private void initView2() {
		tvNoTextBody = (TextView) view2.findViewById(R.id.tv_no_text_body);
		tvNoTextBody.setOnClickListener(this);
		btnOpenFile = (Button) view2.findViewById(R.id.btn_new_file);
		btnOpenFile.setOnClickListener(this);
	}

	void initView3() {
		listView = (ListView) view3.findViewById(R.id.lv_document_transact);
		listView.setDivider(null);
		listView.setCacheColorHint(Color.TRANSPARENT);
		listView.setFadingEdgeLength(0);
	}

	/**
	 * 要根据条件来判断初始化右上角操作按
	 * 
	 * @param opButtonType
	 * @param isFirstFpu
	 * @param exChangeFlag
	 * @param isReceiptReplied
	 */
	private void initPopup(int resultType, int isFirstFpu, int exChangeFlag,
			int isReceiptReplied, String swfNo, int isCallback) {
		// 根据条件来初始化菜单
		if (mPop == null) {
			View view = null;

			// 传阅过来，只有传阅和回复
			if (passreadTag == CODE_PASS_READ_TAG) {
				topActivity.setRightBtnStyle("传阅");
				topActivity.setRightBtnOnClickListener(this);
				goWhere = 1;
				isNewDoc = false;// 是否正文可以新建

			} else if (resultType == 0 && exChangeFlag == 0
					&& isReceiptReplied == 0 && "0_1".equals(documentType)) {
				// resultType=0,是待办，EXCHANGE_FLAG=0交换来文，IS_RECEIPT_REPLIED 0：未签收
				// swfNo是来文的 2006083005302033
				// 只能进行签收和拒收
				view = LayoutInflater.from(mContext).inflate(
						R.layout.document_detail_top_right_menu_sign, null);
				view.findViewById(R.id.tv_document_sign).setOnClickListener(
						this); // 签收
				view.findViewById(R.id.tv_document_rejection)
						.setOnClickListener(this); // 拒绝
				mPop = new PopupWindow(view, LayoutParams.MATCH_PARENT,
						LayoutParams.MATCH_PARENT);
				goWhere = 0;
				UIHelper.setBtnStyle(mContext, this.rightBtn,
						R.drawable.ic_more_menu);
				isNewDoc = false;// 是否正文可以新建
				// 还要弹个dialog出来，确定先签收来文
				final TipsDialog dialog = new TipsDialog(mContext);
				dialog.setMessage("请先签收或拒收公文");
				dialog.setOnOkClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View arg0) {
						dialog.dismiss();
					}
				});
				dialog.show();

			} else if (isReceiptReplied == 2 || resultType == -1) {// 拒收 //
																	// -1：只读页
				topActivity.setRightBtnVisibility(View.INVISIBLE);
				isNewDoc = false;// 是否正文可以新建

			} else if (resultType == 1) {
				// resultType=1已办列表，只有撤回功能点
				// IS_CALLBACK 0 不能撤回（不显示撤回按钮） 1 可以撤回（显示撤回按钮）
				view = LayoutInflater.from(mContext).inflate(
						R.layout.document_detail_top_right_menu, null);
				TextView tv_revoke = (TextView) view.findViewById(R.id.tv_document_return);
				TextView tv_urge_handle = (TextView) view.findViewById(R.id.tv_document_look);
				if (isCallback == 1) {
					tv_revoke.setText("撤回");
					tv_revoke.setOnClickListener(this); // 撤回
				} else {
					tv_revoke.setVisibility(View.GONE);
				}
//				没有催办了
//				tv_urge_handle.setText("催办");
				tv_urge_handle.setVisibility(View.GONE);
//				tv_urge_handle.setOnClickListener(this); // 催办
				
				DisplayMetrics dm = new DisplayMetrics();
				getWindowManager().getDefaultDisplay().getMetrics(dm);
				int screenW = dm.widthPixels;// 获取分辨率宽度
				mPop = new PopupWindow(view, screenW / 3, ViewGroup.LayoutParams.WRAP_CONTENT);
				mPop.setBackgroundDrawable(new BitmapDrawable());
				mPop.setFocusable(true);
				mPop.setOutsideTouchable(true);
//				if (isCallback == 1) {
//					topActivity.setRightBtnStyle("撤回");
//					topActivity.setRightBtnOnClickListener(this);
//				}
				goWhere = 2;
				isNewDoc = false;// 是否正文可以新建
				UIHelper.setBtnStyle(mContext, this.rightBtn,
						R.drawable.ic_more_menu);

			} else if (isFirstFpu == 1) {
				// 第一环节只有送出跟传阅
				topActivity.setRightBtnStyle("传阅");
				topActivity.setRightBtnOnClickListener(this);
				Button btnSend = (Button) view1.findViewById(R.id.btn_send); // 送出按钮
				btnSend.setOnClickListener(this);
				btnSend.setVisibility(View.VISIBLE);
				goWhere = 1;
				isNewDoc = true;// 是否正文可以新建-->可以新建正文
				tvNoTextBody
						.setText(getString(R.string.document_new_file_text));
				showBtnUpload();
						
			} else {
				// 其他的就是办理 ： 退件，传阅，送出操作
				view = LayoutInflater.from(mContext).inflate(
						R.layout.document_detail_top_right_menu, null);
				view.findViewById(R.id.tv_document_return).setOnClickListener(
						this); // 退件
				view.findViewById(R.id.tv_document_look).setOnClickListener(
						this); // 传阅
				DisplayMetrics dm = new DisplayMetrics();
				getWindowManager().getDefaultDisplay().getMetrics(dm);
				int screenW = dm.widthPixels;// 获取分辨率宽度
				mPop = new PopupWindow(view, screenW / 3, ViewGroup.LayoutParams.WRAP_CONTENT);
				mPop.setBackgroundDrawable(new BitmapDrawable());
				mPop.setFocusable(true);
				mPop.setOutsideTouchable(true);
				Button btnSend = (Button) view1.findViewById(R.id.btn_send); // 送出按钮
				btnSend.setOnClickListener(this);
				btnSend.setVisibility(View.VISIBLE);
				goWhere = 0;
				UIHelper.setBtnStyle(mContext, this.rightBtn,
						R.drawable.ic_more_menu);
				isNewDoc = true;// 是否正文可以新建
				tvNoTextBody
						.setText(getString(R.string.document_new_file_text));
				showBtnUpload();
			}
		}

		// 已办公文，不能新增和删除附件
		if (!isDeleteAddToken) {
			this.btnUpload.setVisibility(View.GONE);
		}

		// 只要是来文：都不可以正文编辑，如果没有正文时，页面提示：也就是说：在来文的情况下，正文只是显示用的，不需要编辑和上传
		// 来文，在没有正文时，页面提示内容：“没有录入正文，正文见原件”
		if (Constants.LW_CODE.equals(documentType)) {
			isNewDoc = false;
			tvNoTextBody.setText(getString(R.string.document_not_create_file));
		}
	}

	/** 显示弹出菜单 */
	private void showPopup() {
		if (mPop != null) {
			if (mPop.isShowing()) {
				mPop.dismiss();
			} else {
				mPop.showAsDropDown(rightBtn);
			}
		}
	}

	private void showBtnUpload() {
		this.btnUpload.setVisibility(View.VISIBLE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (data != null) {
			if (requestCode == CODE_INPUT_SUGGEST) {
				try {
					String content = data.getStringExtra("SUGGEST_CONTENT");
					if (!BeanUtils.isEmpty(content)) {
						etPassreadContent.setText(content);
					}
				} catch (Exception e) {

				}

			} else if (requestCode == DocumentTransactorActivity.CODE_REQUEST_TRANS) {
				int opType = data.getIntExtra(
						DocumentTransactorActivity.KEY_BACK, 0);
				if (opType == 1) { // 如果办理信息进行处理了，则关闭当前公文详情，否则，证明在办理信息中，没有进行任何流程上操作
					finish();
				}
				
			} else if (requestCode == SDCardFileExplorerActivity.REQUEST_CODE_FILE) {
				
				String fileName = data.getStringExtra("FILE_NAME");
				String filePath = data.getStringExtra("FILE_PATH");
				// 更改附件选择，然后是选择一个附件就上传
				List<File> files = new ArrayList<File>();
				File file = new File(filePath);
				if (file != null && file.exists()) {
					files.add(file);
					mdfFilePath = filePath;
					mdfFileName = fileName;
					
					UploadParams params = new UploadParams(
							getString(R.string.system_servics_url),
							"uploadFile", documentId, swfNo, "",
							CODE_MODIFY_UPLOAD_FILE);
					params.setListFile(files);
					HttpMultipartPost post = new HttpMultipartPost(mContext,
							handler);
					post.execute(params);
					
					// 老方式上传
					// UIHelper.modifyFileUpload(mContext, callBack, helper,
					// CODE_MODIFY_UPLOAD_FILE, documentId, "", files);
				} else {
					UIHelper.showMessage(mContext, "该文件不存在");
				}	
			}		
		}			
		super.onActivityResult(requestCode, resultCode, data);
	}				

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.system_back) {
			onClickBack();

		} else if (id == R.id.btn_top_right) {
			if (goWhere == 0) {
				showPopup();// 菜单show
			} else if (goWhere == 1) { // 传阅
				goPassread();

			} else if (goWhere == 2) {
				showPopup();
//				showDocumentRecall(); // 撤回操作
			}

		} else if (id == R.id.tv_file_group) {
			UIHelper.isOpenFile(mContext, tvFileGroup, llFileWrap);
		} else if (id == R.id.tv_document_return) { // 退件
			if (goWhere == 0) {
				showDocumentReturnDialog(); // 退件操作
			} else if (goWhere == 2) {
				showDocumentRecall(); // 撤回操作
			}
		} else if (id == R.id.btn_send) { // 送出(办理)
			goTransactorActivity(); // 去办理送出界面
		} else if (id == R.id.tv_document_sign) { // 签收
			goSignActivity(true);
		} else if (id == R.id.tv_document_rejection) { // 拒绝
			goSignActivity(false);
		} else if (id == R.id.tv_document_look) { // 传阅
			if (goWhere == 0) {
				goPassread();
			} else if (goWhere == 2) {
				sendUrgencyMessage(); // 催办
			}
		} else if (id == R.id.tv_huanji) { // 弹出缓急选择框
			UIHelper.showHuanji(mContext, tvHuanji);
		} else if (id == R.id.tv_level) { // 弹出级别选择框
			UIHelper.showLevel(mContext, tvLevel);

		} else if (id == R.id.btn_new_file || id == R.id.tv_no_text_body) { // 打开正文
																			// PS:如果有正文，则打开，否则新建word文档
			Object tag = v.getTag();
			if (tag != null) {
				if (tag instanceof DocFileInfo) {
					DocFileInfo tempBean = (DocFileInfo) tag;
					if (tempBean != null) {
						String url;
						// 0,标识使用system_servics_download下载，1标识使用system_servics_url下载
						if ("1".equals(getString(R.string.is_download_flag))) {
							url = UIHelper.downFileUrl(tempBean.getFileCode());
						} else {
							url = getString(R.string.system_servics_download)
									.concat(tempBean.getFilePath());
						}

						// 来文只能是阅读模式
						String readModel = Constants.WPS_NORMAL;
						if (Constants.LW_CODE.equals(documentType)) {
							readModel = Constants.WPS_READMODE;
						}
						FileDownUtil downUtil = new FileDownUtil(mContext, url,
								tempBean.getFileName(), tempBean.getFileCode(),
								tempBean.getFileType(), tempBean.getFileSize(),
								"正文正在下载", readModel);
						downUtil.start();
					}
				} else if (tag instanceof String) {
					String tagStr = tag.toString();
					String filePath = "";
					if (Constants.TAG_TEMP_FILE.equals(tagStr)) {
						filePath = Constants.SDCARD_DIR_NEW_FILE
								.concat(Constants.SDCARD_TEMP_FILE);
					} else {
						filePath = Constants.SDCARD_DIR_DOCUMENT_DOWNLOAD
								.concat(tagStr).concat(".doc");
					}
					UIHelper.openWps(mContext, filePath, Constants.WPS_NORMAL); // 新建一个正文
				}

			} else {
				// 不等于传阅才可以进行操作
				if (isNewDoc) {
					UIHelper.openWps(mContext, null, Constants.WPS_NORMAL); // 新建一个正文
				}
			}

		} else if (id == R.id.btn_reply) { // 传阅回复
			String passreadContent = etPassreadContent.getText().toString();// 回复内容
			if (BeanUtils.isEmpty(passreadContent)) {
				UIHelper.showMessage(mContext,
						getString(R.string.required_tip_passread_content));
				return;
			} else {
				ApiRequest request = OAServicesHandler.replyPassread(
						passreadId, passreadContent);
				if (request != null) {
					request.setMessage(getString(R.string.system_commit_message));
					new InvokeHelper(mContext).invokeWidthDialog(request,
							replycallBack, 12345);
				}
			}

		} else if (id == R.id.btn_input) { // 传阅导入常用建议按钮
			UIHelper.forwardTargetActivityForResult(this,
					DocumentTransactorSuggestActivity.class, null, false,
					CODE_INPUT_SUGGEST);

		} else if (id == R.id.btn_upload) { // 附件上传
			UIHelper.forwardTargetActivityForResult(this,
					SDCardFileExplorerActivity.class, null, false,
					SDCardFileExplorerActivity.REQUEST_CODE_FILE);

		} else if (id == R.id.tv_extend) { // 单机摘要展开按钮
			zhaiyaoExpand();

		} else if (id == R.id.btn_process || id == R.id.rl_item_wrap
				|| id == R.id.rl_add_item_wrap) { // 附件下载
			UIHelper.downViewClick(mContext, v, downloadUIHelper, dao);
		}
	}

	/** 去办理送出界面，先判断是否有到达的环节 */
	void goTransactorActivity() {
		detailHelper.loadTranceData(swfNo, fpuNo, CODE_TRANCE);
	}

	/** 送出时，得保存修改后的公文 */
	void modifyDocument() {
		etTitle.setTag(documentId);
		DocumentAddHelper addHelper = new DocumentAddHelper(mContext, callBack,
				helper, 1);
		addHelper.submit(etTitle, etTextNo, etDepartment, etUserName, tvHuanji,
				tvLevel, etZhaiyao, CODE_MODFLY, rightBtn);
	}

	/** 退件 */
	void showDocumentReturnDialog() {
		final TextDialog dialog = new TextDialog(mContext);
		dialog.setTvTips("退件理由");
		dialog.setOnConfirmClickListener("确定", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String reason = dialog.getMessage();
				ApiRequest request = OAServicesHandler.rejectWorkFlow(traceNo,
						wfNo, swfNo, documentId, reason);
				if (request != null) {
					request.setMessage(getString(R.string.system_commit_message));
					helper.invokeWidthDialog(request, callBack, CODE_RETURN);
				}
			}
		});
		dialog.setOnCancelClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	/** 撤回 */
	void showDocumentRecall() {
		final TextDialog dialog = new TextDialog(mContext);
		dialog.setTvTips(getString(R.string.recall_tips));
		dialog.setOnConfirmClickListener(
				getString(R.string.system_dialog_confirm),
				new View.OnClickListener() {
		
					@Override
					public void onClick(View v) {
						String reason = dialog.getMessage();
						ApiRequest request = OAServicesHandler
								.callBackWorkFlow(traceNo, documentId, reason);
						if (request != null) {
							request.setMessage(getString(R.string.system_commit_message));
							helper.invokeWidthDialog(request, callBack,
									CODE_CALLBACK);
						}
					}
				});
		
		dialog.setOnCancelClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	void goSignActivity(boolean flag) {
		Bundle data = new Bundle();
		data.putString("documentId", documentId);
		data.putString("wfNo", wfNo);
		data.putString("traceNo", traceNo);
		data.putString("fpuNo", fpuNo); // 当前环节编号
		data.putString("swfNo", swfNo); // 系统流程编号
		data.putString("passreadId", passreadId); // 传阅编号
		// data.putInt("postReadFlag", postReadFlag);
		data.putInt("IS_PASS_READ", passreadTag); // 传阅入口标示
		data.putBoolean("isSign", flag);
		data.putInt("isBackFlag", 1);
		UIHelper.forwardTargetActivity(mContext,
				DocumentSignRejectActivity.class, data, true);
	}

	void goPassread() {
		Bundle data = new Bundle();
		data.putString("documentId", documentId);
		data.putString("wfNo", wfNo);
		UIHelper.forwardTargetActivity(mContext,
				PassReadChoosePeopleActivity.class, data, false);
	}

	void zhaiyaoExpand() {
		boolean isExpand = (Boolean) tvExtend.getTag();
		Drawable drawable;
		if (!isExpand) {
			int lineCount = etZhaiyao.getLineCount();// 获取最大行数
			etZhaiyao.setMaxLines(lineCount);
			drawable = UIHelper.closeDrawable(mContext, R.drawable.btn_packup); // 更改为收起按钮
			isExpand = true;// 已经展开了
		} else {
			etZhaiyao.setLines(3);// 只显示3行
			drawable = UIHelper.openDrawable(mContext, R.drawable.btn_expand); // 更换为展开按钮
			isExpand = false;
		}
		tvExtend.setCompoundDrawables(null, null, drawable, null);
		tvExtend.setTag(isExpand);
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == CODE_MODIFY_UPLOAD_FILE) { // 附件上传返回
				ResultItem item = (ResultItem) msg.obj;
				String code = item.getString("code");
				// String message = item.getString("message");
				String fileCode = item.getString("file_code");

				if (Constants.SUCCESS_CODE.equals(code)) {
					UIHelper.showMessage(mContext, "附件上传成功");

					// 将附件复制到下载目录
					if (UIHelper.copeChildFile(fileCode, mdfFilePath)) {

						String newPath = UIHelper.getDownNewFilePath(fileCode,
								mdfFilePath);
						// 添加这个附件到附件列表中
						UIHelper.setFileWrap(mContext, llFileWrap,
								DocumentDetailActivity.this,
								DocumentDetailActivity.this, mdfFileName,
								mdfFilePath, fileCode, newPath);
					}
					mdfFileName = null;
					mdfFilePath = null;
				} else {// 上传失败
					UIHelper.showMessage(mContext, "附件上传失败！");
				}

			} else if (msg.what == CODE_UPLOAD_TEXT_FILE) { // 上传正文返回
				ResultItem item = (ResultItem) msg.obj;
				String code = item.getString("code");
				String message = item.getString("message");
				UIHelper.showMessage(mContext, message);
				String fileCode = item.getString("file_code");

				if (Constants.SUCCESS_CODE.equals(code)) { // 操作成功
					// 复制文件成功之后才进行删除
					if (UIHelper.copeTextBodyFile(fileCode)) {
						// 删除临时文件
						UIHelper.deleteTempDoc();
						// 改变打开正文
						tvNoTextBody
								.setText(getString(R.string.document_open_file)); // 显示打开正文
						btnOpenFile.setTag(fileCode);
						tvNoTextBody.setTag(fileCode);
					}
				}
			} else {
				if (!BeanUtils.isEmpty(msg.obj)) {
					UIHelper.showMessage(mContext, msg.obj.toString());
				} else {
					UIHelper.showMessage(mContext, "不明确的错误");
				}
			}
		}
	};

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == CODE_BASIC) { // 基本信息查询返回
					Map<String, Object> map = detailHelper.process(response,
							what);
					if (map != null && map.size() > 0) {
						DocumentInfo docInfo = (DocumentInfo) map
								.get("docBean");
						if (docInfo != null) {
							setView1Value(docInfo);
						}

						// 文件附件
						@SuppressWarnings("unchecked")
						List<DocFileInfo> fileList = (List<DocFileInfo>) map
								.get("fileList");
						if (fileList != null && fileList.size() > 0) {
							foreachFiles(fileList);
						}

						if (passreadTag != CODE_PASS_READ_TAG) { // 如果不是传阅标示，则去显示办理信息
							// 办理信息
							@SuppressWarnings("unchecked")
							List<DocManagerInfo> docManagerList = (List<DocManagerInfo>) map
									.get("managerList");
							if (docManagerList != null
									&& docManagerList.size() > 0) {
								adapterManager = new DocumentTransactListAdapter(
										mContext);
								listView.setAdapter(adapterManager);
								adapterManager.addData(docManagerList);
								adapterManager.notifyDataSetChanged();
							} else {
								listView.setVisibility(View.GONE);
							}
						}
					}
					
				} else if (what == CODE_RETURN) { // 退件提交系统返回
					retroversionFlag = 1;// 退回成功
					showBackMsg(response);
					
				} else if (what == CODE_CALLBACK) { // 撤回系统返回
					retracementFlag = 1;// 撤回成功
					showBackMsg(response);
					
				} else if (what == CODE_URGE) { // 催办系统返回
					retracementFlag = 1; // 催办成功
					showBackMsg(response);
				} else if (what == CODE_DELETE_FILE) { // 删除文件返回
					UIHelper.removeFileView(llFileWrap, deleteFilePath);
					deleteFilePath = null;
					
				} else if (what == CODE_PASS_READ) { // 传阅信息返回
					proceePassreadData(response);
					
				} else if (what == CODE_TRANCE) { // 是否有办理信息可到达的环节
					DocumentParams params = new DocumentParams(swfNo, fpuNo,
							wfNo, traceNo, documentId);
					params.setPassreadId(passreadId);
					params.setIsBackFlag(passreadTag);
					params.setIsBackFlag(1);
					params.setResultItem(item);
					
					Bundle data = new Bundle();
					data.putSerializable("DOCUMENT_PARAMS", params);
					UIHelper.forwardTargetActivityForResult(mContext,
							DocumentTransactorActivity.class, data, false,
							DocumentTransactorActivity.CODE_REQUEST_TRANS);
					
					modifyDocument();
				}	
					
			} else {
				String code = item.getString("code");
				if (!Constants.LOGIN_FAIL_CODE.equals(code)) {
					// 如果是详情页面的，则让其关闭
					if (what == CODE_BASIC) {
						exit();
					}
				}
			}	
		}	
			
		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			rightBtn.setClickable(true);
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			rightBtn.setClickable(true);
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	private void exit() {
		finish();
	}

	/** 显示系统返回操作的信息 */
	private void showBackMsg(HttpResponse response) {
		String code = response.getResultItem(ResultItem.class)
				.getString("code");
		// 操作成功
		String message = response.getResultItem(ResultItem.class).getString(
				"message");
		UIHelper.showMessage(mContext, message);
		// 当成功的时候，刷新下自己
		if (Constants.SUCCESS_CODE.equals(code)) {
			refreshSelf();
		}
	}

	/**
	 * 刷新自己
	 */
	private void refreshSelf() {
		Bundle data = new Bundle();
		data.putString("documentId", documentId);
		data.putString("wfNo", wfNo);
		data.putString("traceNo", traceNo);
		data.putString("fpuNo", fpuNo); // 当前环节编号
		data.putString("swfNo", swfNo); // 系统流程编号
		data.putInt("IS_PASS_READ", passreadTag); // 传阅入口标示
		UIHelper.forwardTargetActivity(mContext, DocumentDetailActivity.class,
				data, true);
	}

	/**
	 * 循环附件
	 * 
	 * @param fileList
	 */
	private void foreachFiles(List<DocFileInfo> fileList) {
			
		for (int i = 0, len = fileList.size(); i < len; i++) {
			final DocFileInfo bean = fileList.get(i);
			ViewHolderFile holder = new ViewHolderFile();
			
			View view = LayoutInflater.from(mContext).inflate(
					R.layout.govaffair_file_item, null);
			holder.rlItemWrap = (RelativeLayout) view
					.findViewById(R.id.rl_item_wrap);
			holder.ivType = (ImageView) view.findViewById(R.id.iv_file_type);
			holder.tvFileName = (TextView) view.findViewById(R.id.tv_file_name);
			
			holder.btnDownload = (RoundProgressButton) view
					.findViewById(R.id.btn_process);
			holder.rlRoundBtnWrap = (RelativeLayout) view
					.findViewById(R.id.rl_round_btn_wrap);
			
			String extend = FileUtils.getFileExtends(bean.getFileName());
			UIHelper.setFileTypeIcon(mContext, holder.ivType, extend); // 设置文件类型
			
			if (bean.getFileCataLog() == 0) { // 【0:正文】 【1：附件】
				bodyBean = bean;
				btnOpenFile.setTag(bean);
				tvNoTextBody.setTag(bean);
				tvNoTextBody.setText(getString(R.string.document_open_file)); // 显示打开正文
				continue;
			}
			
//			holder.tvFileName.setText(bean.getFileName());
			holder.tvFileName.setText(bean.getFileTitle());
			holder.tvFileName.setTag(bean.getFilePath());
			
			holder.btnDownload.setTag(bean);
			holder.btnDownload.setOnClickListener(this);
			
			// String url =
			// UIHelper.downFileUrl(bean.getFileCode());//getString(R.string.system_servics_download).concat(bean.getFilePath());
			String url;
			// 0,标识使用system_servics_download下载，1标识使用system_servics_url下载
			if ("1".equals(getString(R.string.is_download_flag))) {
				url = UIHelper.downFileUrl(bean.getFileCode());
			} else {
				url = getString(R.string.system_servics_download).concat(
						bean.getFilePath());
			}
			holder.rlRoundBtnWrap.setTag(url);// 下载标识
			
			holder.rlItemWrap.setTag(bean);// 长按删除
			holder.rlItemWrap.setOnClickListener(this);
			
			if (isDeleteAddToken) {
				holder.rlItemWrap.setOnLongClickListener(this);
			}
			
			try {
				DownloadInfoBean downBean = dao.getAppBeanByCd(bean
						.getFileCode());
				if (downBean != null) { // 下载完成
					int state = downBean.getState();
					if (state == DownloadInfoDAO.DOWNLOAD_STATE_2) {
						holder.btnDownload
								.setBackgroundResource(R.drawable.ic_down_finish); // 存在则打开

					} else if (state == DownloadInfoDAO.DOWNLOAD_STATE_3) {
						holder.btnDownload
								.setBackgroundResource(R.drawable.ic_down_pause); // 暂停状态
						
					} else {
						holder.btnDownload
								.setBackgroundResource(R.drawable.ic_down); // 否则下载
					}
				} else {
					holder.btnDownload
							.setBackgroundResource(R.drawable.ic_down); // 否则下载
				}
				holder.btnDownload.setCricleAndProgressColor(this
						.getResources().getColor(R.color.transparent), this
						.getResources().getColor(R.color.transparent));
			} catch (Exception e) {

			}
			llFileWrap.addView(view);
		}
		if (llFileWrap.getChildCount() > 0) {
			llFileWrap.setVisibility(View.VISIBLE);
			tvFileGroup.setVisibility(View.VISIBLE);
		}
	}

	@Override
	public boolean onLongClick(final View v) {
		if (v.getId() == R.id.rl_item_wrap) {
			// 传阅没有删除附件功能
			if (passreadTag != CODE_PASS_READ_TAG) {
				UIHelper.vibrate(mContext, 50); // 震动下
				if (llFileWrap != null) {
					final DocFileInfo bean = (DocFileInfo) v.getTag();
					String message = bean.getFileName();
					final SystemDialog chooseDialog = new SystemDialog(mContext);
					chooseDialog.setMessage("确定要删除这条“" + message + "”附件？");
					chooseDialog.setOnConfirmClickListener("删除",
							new View.OnClickListener() { // 确定按钮事件
								@Override
								public void onClick(View view) {
									deleteFilePath = bean.getFilePath();
									UIHelper.deleteFile(mContext, callBack,
											helper, bean.getFileCode(),
											CODE_DELETE_FILE);
								}
							});
					chooseDialog.setOnCancelClickListener("放弃",
							new View.OnClickListener() { // 取消
								@Override
								public void onClick(View v) {
									if (chooseDialog != null) {
										chooseDialog.dismiss();
									}
								}
							});
					chooseDialog.show();
				}
			}

		} else if (v.getId() == R.id.rl_add_item_wrap) {
			UIHelper.vibrate(mContext, 50); // 震动下
			final SystemDialog chooseDialog = new SystemDialog(mContext);
			chooseDialog.setMessage("确定要删除这条附件？");
			chooseDialog.setOnConfirmClickListener("删除",
					new View.OnClickListener() { // 确定按钮事件
						@Override
						public void onClick(View view) {
							if (llFileWrap != null) {
								int fileSize = llFileWrap.getChildCount();
								if (fileSize > 0) {
									DocFileInfo bean = (DocFileInfo) v.getTag();
									if (bean == null)
										return;

									for (int i = 0; i < fileSize; i++) {
										View fileView = llFileWrap
												.getChildAt(i);
										if (fileView == null) {
											continue;
										}
										TextView tvFileName = (TextView) fileView
												.findViewById(R.id.tv_file_name);
										String tempPath = (String) tvFileName
												.getTag();
										if (bean.getFilePath().equals(tempPath)) { // 如果按钮相等，则删除这条数据
											// llFileWrap.removeViewAt(i);
											deleteFilePath = bean.getFilePath();
											UIHelper.deleteFile(mContext,
													callBack, helper,
													bean.getFileCode(),
													CODE_DELETE_FILE);
										}
									}
								}
							}
						}
					});
			chooseDialog.setOnCancelClickListener("放弃",
					new View.OnClickListener() { // 取消
						@Override
						public void onClick(View v) {
							if (chooseDialog != null) {
								chooseDialog.dismiss();
							}
						}
					});
			chooseDialog.show();
		}
		return false;
	}	
		
	void setView1Value(DocumentInfo bean) {
		etTitle.setText(bean.getTitle());
		etTextNo.setText(bean.getDocCode());
		etDepartment.setText(bean.getDepartment());
		etUserName.setText(bean.getDrafter());
		String huanji = DocumentHelper.getHj(BeanUtils.floatToInt(bean
				.getUrgency()));// 缓急
		tvHuanji.setText(huanji);
		tvHuanji.setTag(bean.getUrgency());
		String miji = DocumentHelper
				.getMj(BeanUtils.floatToInt(bean.getLevel()));// 密级
		tvLevel.setText(miji);
		tvLevel.setTag(bean.getLevel());
		
		etZhaiyao.setText(bean.getSummary()); // 摘要
		int line = etZhaiyao.getLineCount();
		if (line > 3) {
			etZhaiyao.setLines(3);
			etZhaiyao.setEllipsize(TruncateAt.END);
			tvExtend.setVisibility(View.VISIBLE);
		}
		
		initPopup(bean.getResult(), bean.getIsFirstFpu(),
				bean.getExchangeFlag(), bean.getIsReceiptReplied(),
				bean.getDocumentType(), bean.getIsCallback());

		// 传阅不可以删除附件，不可以修改内容
		if (passreadTag == CODE_PASS_READ_TAG) {
			etTitle.setEnabled(false);
			etTextNo.setEnabled(false);
			etDepartment.setEnabled(false);
			etUserName.setEnabled(false);
			tvHuanji.setEnabled(false);
			tvLevel.setEnabled(false);
			etZhaiyao.setEnabled(false);
		}//
			// 如果当前环节为空，则取详情返回的
		if (fpuNo == null || "".equals(fpuNo.trim())) {
			fpuNo = bean.getFpuNo();
		}
	}

	private class ViewHolderFile {
		TextView tvFileName;
		ImageView ivType;
		RoundProgressButton btnDownload;
		RelativeLayout rlItemWrap, rlRoundBtnWrap;
	}	
		
	/** 注册广播 */
	private void registerBroadcast() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(TextBodyUtile.ACTION_SAVE_FILE);
		registerReceiver(saveFileBroadcast, filter);
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (this.downloadUIHelper != null)
			this.downloadUIHelper.unRegUiHandler();
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (this.downloadUIHelper != null)
			this.downloadUIHelper.regUiHandler();// 界面恢复调用
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		mContext = null;
		if (saveFileBroadcast != null) {
			unregisterReceiver(saveFileBroadcast);
		}
		if (this.downloadUIHelper != null)
			this.downloadUIHelper.unRegUiHandler();
	}

	private BroadcastReceiver saveFileBroadcast = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			// 接收到的参数
			final String filePath = intent.getExtras().getString("filePath"); // 文件路径
			// 只有可以新建的时候可以进行上传
			if (isNewDoc) {
				// 证明已经做了保存操作
				if (TextBodyUtile.IS_SAVE_FILE
						&& TextBodyUtile.FILE_PATH.equals(filePath)) {
					tvNoTextBody
							.setText(getString(R.string.document_open_file)); // 显示打开正文
					btnOpenFile.setTag(Constants.TAG_TEMP_FILE); // 再次打开，则打开临时文件
					tvNoTextBody.setTag(Constants.TAG_TEMP_FILE);// 再次打开，则打开临时文件
					final SystemDialog sysDialog = new SystemDialog(context);
					sysDialog.setTitle("上传提示");
					sysDialog.setMessage("是否上传正文？");
					sysDialog
							.setOnCancelClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									sysDialog.dismiss();
								}
							});
					sysDialog.setOnConfirmClickListener("上传",
							new View.OnClickListener() {
								@Override
								public void onClick(View v) {
									File file = new File(filePath);
									if (file != null && file.exists()) {
										detailHelper.uploadDocFile(documentId,
												swfNo, traceNo, file,
												CODE_UPLOAD_TEXT_FILE, handler);
									} else {
										UIHelper.showMessage(mContext, "文件丢失");
									}
									sysDialog.dismiss();
								}
							});
					sysDialog.show();
					TextBodyUtile.IS_SAVE_FILE = false;
					TextBodyUtile.FILE_PATH = "";
				}
			}
		}
	};

	/**
	 * 显示传阅列表
	 * 
	 * @param response
	 */
	void proceePassreadData(HttpResponse response) {
		String code = response.getResultItem(ResultItem.class)
				.getString("code");
		// 操作成功	 
		if (Constants.SUCCESS_CODE.equals(code)) {
			List<ResultItem> items = response.getResultItem(ResultItem.class)
					.getItems("data");
			if (!BeanUtils.isEmpty(items)) {
				List<PassreadInfo> dataList = new ArrayList<PassreadInfo>();
				for (ResultItem item : items) {
					String name = item.getString("REAL_NAME");
					String datetime = item.getString("SEND_TIME");
					String remark = item.getString("REPLY_CONTENT");
					String department = item.getString("SITE_NAME");
					String status = item.getString("READ_STATE");
					
					PassreadInfo bean = new PassreadInfo(name, department,
							datetime, remark, status);
					dataList.add(bean);
				}
				
				adapterPassread = new PassreadListAdapter(mContext);
				listView.setAdapter(adapterPassread);
				adapterPassread.addData(dataList);
				adapterPassread.notifyDataSetChanged();
				
			} else {
				// 显示无信息提示
				listView.setVisibility(View.GONE);
			}
		}
	}

	/** 初始化动画 */
	private void initImageView() {
		imageView = (ImageView) findViewById(R.id.cursor);
		bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor)
				.getWidth();// 获取图片宽度

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int screenW = dm.widthPixels;// 获取分辨率宽度
		offset = (screenW / 3 - bmpW) / 2;// 计算偏移量
		Matrix matrix = new Matrix();
		matrix.postTranslate(offset, 0);
		imageView.setImageMatrix(matrix);// 设置动画初始位置
	}

	/** 初始化头标 */
	private void initTextView() {
		tv1 = (TextView) findViewById(R.id.tv_1);
		tv2 = (TextView) findViewById(R.id.tv_2);
		tv3 = (TextView) findViewById(R.id.tv_3);

		if (passreadTag == CODE_PASS_READ_TAG) {
			tv3.setText(getString(R.string.pass_read_title)); // 传阅信息
		}

		tv1.setOnClickListener(new MyOnClickListener(0));
		tv2.setOnClickListener(new MyOnClickListener(1));
		tv3.setOnClickListener(new MyOnClickListener(2));
	}	
		
	/** 
	 * 方法说明：<br>
	 * 初始化 页卡
	 */ 
	private void initViewPager() {
		viewPager = (ViewPager) findViewById(R.id.vp_pager);
		views = new ArrayList<View>();
		LayoutInflater inflater = getLayoutInflater();
		
		view1 = inflater.inflate(R.layout.document_detail_basic, null);
		view2 = inflater.inflate(R.layout.document_detail_body, null);
		view3 = inflater.inflate(R.layout.document_detail_transact, null);
		views.add(view1);
		views.add(view2);
		views.add(view3);
		viewPager.setAdapter(new MyViewPagerAdapter(views));
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
	}	
		
	private class MyOnClickListener implements OnClickListener {
		private int index = 0;

		public MyOnClickListener(int i) {
			index = i;
		}

		public void onClick(View v) {
			viewPager.setCurrentItem(index);
		}
	}	
		
	public class MyViewPagerAdapter extends PagerAdapter {
		private List<View> mListViews;
		
		public MyViewPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;
		}
		
		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));
		}
		
		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(mListViews.get(position), 0);
			
			if (currIndex == 0) { //
				tv1.setTextColor(getResources().getColor(R.color.bluex));
				if (isFirst1) {
					detailHelper
							.getDocumentDetail(documentId, wfNo, CODE_BASIC); // 查询公文基本信息
					isFirst1 = false;
				}
			}
			
			return mListViews.get(position);
		}	
			
		@Override
		public int getCount() {
			return mListViews.size();
		}	
			
		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}	
		
	public class MyOnPageChangeListener implements OnPageChangeListener {
		int one = offset * 2 + bmpW;// 页卡1 -> 页卡2 偏移量
		
		public void onPageScrollStateChanged(int arg0) {
		
		}
		
		public void onPageScrolled(int arg0, float arg1, int arg2) {
		
		}
		
		public void onPageSelected(int arg0) {
			Animation animation = new TranslateAnimation(one * currIndex, one
					* arg0, 0, 0);
			currIndex = arg0;
			animation.setFillAfter(true);// True:图片停在动画结束位置
			animation.setDuration(300);
			imageView.startAnimation(animation);
			
			if (currIndex == 0) {
				UIHelper.setTabTextHighlight(mContext, tv1, tv2, tv3);
			
			} else if (currIndex == 1) { // 打开正文
				UIHelper.hideKeyboard(DocumentDetailActivity.this); // 隐藏软键盘
				UIHelper.setTabTextHighlight(mContext, tv2, tv1, tv3);
				
				if (bodyBean != null && isFirstOpen) {
					isFirstOpen = false;
					// String url =
					// UIHelper.downFileUrl(bodyBean.getFileCode());//getString(R.string.system_servics_download).concat(bodyBean.getFilePath());
					String url;
					// 0,标识使用system_servics_download下载，1标识使用system_servics_url下载
					if ("1".equals(getString(R.string.is_download_flag))) {
						url = UIHelper.downFileUrl(bodyBean.getFileCode());
					} else {
						url = getString(R.string.system_servics_download)
								.concat(bodyBean.getFilePath());
					}
					// 来文只能是阅读模式
					String readModel = Constants.WPS_NORMAL;
					if (Constants.LW_CODE.equals(documentType)) {
						readModel = Constants.WPS_READMODE;
					}
					FileDownUtil downUtil = new FileDownUtil(mContext, url,
							bodyBean.getFileName(), bodyBean.getFileCode(),
							bodyBean.getFileType(), bodyBean.getFileSize(),
							"正文正在下载", readModel);
					downUtil.start();
				}	
					
			} else if (currIndex == 2) {
				UIHelper.hideKeyboard(DocumentDetailActivity.this); // 隐藏软键盘
				UIHelper.setTabTextHighlight(mContext, tv3, tv1, tv2);
				if (isFirst3) {
					if (passreadTag == CODE_PASS_READ_TAG) {
						UIHelper.getPassreadInfo(mContext, callBack, helper,
								CODE_PASS_READ, wfNo);
					}
					isFirst3 = false;
				}	
			}		
		}			
	}				
	/** 公文催办 */		
	private void sendUrgencyMessage() {
		ApiRequest request = OAServicesHandler.sendUrgencyMessage(wfNo, traceNo);
		if (request != null) {
			request.setMessage(getString(R.string.system_commit_message));
			helper.invokeWidthDialog(request, callBack, CODE_URGE);
		} 
	}
	
	private IRequestCallBack replycallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				String message = item.getString("message");
				if (message != null) {
					UIHelper.showMessage(mContext, message);
				} else {
					UIHelper.showMessage(
							mContext,
							getString(R.string.system_operation_success_message));
				}
				etPassreadContent.setText("");
				etPassreadContent.setHint("你已经回复了");
				// btnReply.setClickable(false);//已回复了，无法再次回复
			}
		}
	};

	@Override
	public void onProgressUpdate(String url, long totalSize, long dealtSize) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
				true);
		if (btnDown == null)
			return;
		btnDown.cancelDown();
		btnDown.setBackgroundResource(R.drawable.ic_down_ing); // 正在下载
		btnDown.setCricleAndProgressColor(
				this.getResources().getColor(R.color.gray_split_line_bg), this
						.getResources().getColor(R.color.down_progress_color));

		float num = (float) dealtSize / (float) totalSize;
		int result = (int) (num * 100);

		btnDown.setProgress(result);
	}

	@Override
	public void onDownloadComplete(String url) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
				true); // 下载完成
		if (btnDown == null)
			return;
		btnDown.cancelDown();
		btnDown.setBackgroundResource(R.drawable.ic_down_finish);
		btnDown.setCricleAndProgressColor(
				this.getResources().getColor(R.color.transparent), this
						.getResources().getColor(R.color.transparent));

		UIHelper.openFile(mContext, url);
	}

	@Override
	public void onDownloadStateChange(String url, int state) {
		switch (state) {
		case DownloadInfoDAO.DOWNLOAD_STATE_3:
			RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
					true); // 暂停下载
			if (btnDown != null) {
				btnDown.cancelDown();
				btnDown.setBackgroundResource(R.drawable.ic_down_pause);
				btnDown.setCricleAndProgressColor(
						this.getResources().getColor(R.color.transparent), this
								.getResources().getColor(R.color.transparent));
			}
			break;
		}
	}

	@Override
	public void onDownloadError(String url, int state) {
		RoundProgressButton btnDown = UIHelper.showDownBtn(llFileWrap, url,
				true);
		if (btnDown != null) {
			btnDown.setBackgroundResource(R.drawable.ic_down);
			btnDown.setCricleAndProgressColor(
					this.getResources().getColor(R.color.gray_split_line_bg),
					this.getResources().getColor(R.color.down_progress_color));
		}
		UIHelper.showMessage(mContext, "下载错误");
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			onClickBack();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void onClickBack() {
		if (Constants.NOTIFY_DETAIL_BACK) {
			UIHelper.setNotifyRestore();
			UIHelper.forwardTargetActivity(mContext, MainActivity.class, null,
					true);

		} else {
			UIHelper.deleteTempDoc();
			finish();
		}
	}

}
