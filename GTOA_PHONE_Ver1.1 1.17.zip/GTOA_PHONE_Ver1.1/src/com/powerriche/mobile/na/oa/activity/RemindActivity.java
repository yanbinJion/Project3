package com.powerriche.mobile.na.oa.activity;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.PreferenceUtils;
import com.powerriche.mobile.oa.tools.SettingPreference;

public class RemindActivity extends BaseActivity implements
		View.OnClickListener {
	private static final int CHOICE_DIALOG_SIGN_IN = 0;
	private static final int CHOICE_DIALOG_SIGN_OUT = 1;
	private static final int CHOICE_DIALOG_WORKDAY = 2;
	private TopActivity topActivity;
	private TextView tv_sign_in_remind, tv_sign_out_remind, tv_day;
	private ImageView iv_in_remind, iv_out_remind, iv_working_day;
	private String[] signInReminds = { "提前5分钟", "提前10分钟", "提前15分钟" };
	private String[] signOutReminds = { "延后5分钟", "延后10分钟", "延后15分钟" };
	private int[] minutes = { 5, 10, 15 };
	private boolean[] selected = { false, false, false, false, false, false, false };
	private String[] strWorkdays = { "周一", "周二", "周三", "周四", "周五", "周六", "周日" };
	private SettingPreference preference;
	private Button btn_sign_in_remind, btn_sign_out_remind, btn_ring, btn_quake;
	private Vibrator vibrator;
	private LinearLayout ll_sign_in, ll_sign_out, ll_working_day;
	private String signIn, signOut;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attendance_remind);
		initView();
		initData();
		if (!BeanUtils.isEmptyStrs(signIn)) {
			signIn = PreferenceUtils.getStringValue(PreferenceUtils.SIGN_IN_REMIND);
			tv_sign_in_remind.setText(signIn);
		} else {
			tv_sign_in_remind.setText(R.string.sign_in_time_remind);
		}
		if (!BeanUtils.isEmptyStrs(signOut)) {
			signOut = PreferenceUtils.getStringValue(PreferenceUtils.SIGN_OUT_REMIND);
			tv_sign_out_remind.setText(signOut);
		} else {
			tv_sign_out_remind.setText(R.string.sign_out_time_remind);
		}
		tv_day.setText(PreferenceUtils.getStringValue(PreferenceUtils.WEEKDAY_TIP));
	}
	
	// 初始化控件
	private void initView() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.attendance_remind));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnStyle(getString(R.string.attendance_save));
		topActivity.setRightBtnOnClickListener(this);
		tv_sign_in_remind = (TextView) findViewById(R.id.tv_sign_in_remind);
		iv_in_remind = (ImageView) findViewById(R.id.iv_in_remind);
		tv_sign_out_remind = (TextView) findViewById(R.id.tv_sign_out_remind);
		iv_out_remind = (ImageView) findViewById(R.id.iv_out_remind);
		tv_day = (TextView) findViewById(R.id.tv_day);
		iv_working_day = (ImageView) findViewById(R.id.iv_working_day);
		btn_sign_in_remind = (Button) findViewById(R.id.btn_sign_in_remind);
		btn_sign_out_remind = (Button) findViewById(R.id.btn_sign_out_remind);
		btn_ring = (Button) findViewById(R.id.btn_ring);
		btn_quake = (Button) findViewById(R.id.btn_quake);
		ll_sign_in = (LinearLayout) findViewById(R.id.ll_sign_in);
		ll_sign_out = (LinearLayout) findViewById(R.id.ll_sign_out);
		ll_working_day = (LinearLayout) findViewById(R.id.ll_working_day);
	}
	// 设置数据
	private void initData() {
		iv_in_remind.setOnClickListener(this);
		iv_out_remind.setOnClickListener(this);
		iv_working_day.setOnClickListener(this);
		btn_sign_in_remind.setOnClickListener(this);
		btn_sign_out_remind.setOnClickListener(this);
		btn_ring.setOnClickListener(this);
		btn_quake.setOnClickListener(this);
		ll_sign_in.setOnClickListener(this);
		ll_sign_out.setOnClickListener(this);
		ll_working_day.setOnClickListener(this);
		preference = new SettingPreference(RemindActivity.this);
		int signInValue = preference.getSettingParam("KEY_SET_SIGN_IN", 0);
		int signOutValue = preference.getSettingParam("KEY_SET_SIGN_OUT", 0);
		int ringValue = preference.getSettingParam("KEY_SET_RING", 0);
		int quakeValue = preference.getSettingParam("KEY_SET_QUAKE", 0);
//		int signInValue = PreferenceUtils.getIntValue("KEY_SET_SIGN_IN");
//		int signOutValue = PreferenceUtils.getIntValue("KEY_SET_SIGN_OUT");
//		int ringValue = PreferenceUtils.getIntValue("KEY_SET_RING");
//		int quakeValue = PreferenceUtils.getIntValue("KEY_SET_QUAKE");
		if(signInValue == 0) {
			btn_sign_in_remind.setSelected(false);
		} else {
			btn_sign_in_remind.setSelected(true);
		}
		if(signOutValue == 0) {
			btn_sign_out_remind.setSelected(false);
		} else {
			btn_sign_out_remind.setSelected(true);
		}
		if(ringValue == 0) {
			btn_ring.setSelected(false);
		} else {
			btn_ring.setSelected(true);
		}
		if(quakeValue == 0) {
			btn_quake.setSelected(false);
		} else {
			btn_quake.setSelected(true);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.system_back) {
			RemindActivity.this.finish();
		} else if(v.getId() == R.id.btn_top_right) {
			RemindActivity.this.finish();
		} else if(v.getId() == R.id.iv_in_remind || v.getId() == R.id.ll_sign_in) {
			showDialog(CHOICE_DIALOG_SIGN_IN);
		} else if(v.getId() == R.id.iv_out_remind || v.getId() == R.id.ll_sign_out) {
			showDialog(CHOICE_DIALOG_SIGN_OUT);
		} else if(v.getId() == R.id.iv_working_day || v.getId() == R.id.ll_working_day) {
			showDialog(CHOICE_DIALOG_WORKDAY);
		} else if(v.getId() == R.id.btn_sign_in_remind) {
			setBtnSelect(btn_sign_in_remind, "KEY_SET_SIGN_IN");
		} else if(v.getId() == R.id.btn_sign_out_remind) {
			setBtnSelect(btn_sign_out_remind, "KEY_SET_SIGN_OUT");
		} else if(v.getId() == R.id.btn_ring) {
			setBtnSelect(btn_ring, "KEY_SET_RING");
		} else if(v.getId() == R.id.btn_quake) {
			setBtnSelect(btn_quake, "KEY_SET_QUAKE");
		}
	}
	/**
	 * 调用系统铃声
	 */
	private void ring() {
		MediaPlayer mp = new MediaPlayer();
		try {
			mp.setDataSource(this, RingtoneManager
					.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
			mp.prepare();
			mp.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 调用系统震动声
	 * 想设置震动大小可以通过改变pattern来设定，如果开启时间太短，震动效果可能感觉不到
	 */
	private void quake() {
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		long[] pattern = { 100, 400, 100, 400 }; // 停止 开启 停止 开启
		vibrator.vibrate(pattern, -1);         //重复两次上面的pattern 如果只想震动一次，index设为-1   
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		Dialog dialog = null;
		final ChoiceOnClickListener choiceListener = new ChoiceOnClickListener();
		switch (id) {
		case CHOICE_DIALOG_SIGN_IN:
			Builder sign_in = new AlertDialog.Builder(this);
			sign_in.setSingleChoiceItems(signInReminds, PreferenceUtils.getIntValue(PreferenceUtils.WORK_START_TIME_CHOICE), choiceListener);
			DialogInterface.OnClickListener sign_in_listener = new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int which) {
					int choiceWhich = choiceListener.getWhich();
					tv_sign_in_remind.setText(signInReminds[choiceWhich]);
					PreferenceUtils.putStringValue(PreferenceUtils.SIGN_IN_REMIND, signInReminds[choiceWhich]);
					PreferenceUtils.putIntValue(PreferenceUtils.WORK_START_TIP_TIME, minutes[choiceWhich]);
					PreferenceUtils.putIntValue(PreferenceUtils.WORK_START_TIME_CHOICE, choiceWhich);
					BeanUtils.setAlarm(RemindActivity.this);
				}
			};
			sign_in.setPositiveButton("确定", sign_in_listener);
			dialog = sign_in.create();
			break;
		case CHOICE_DIALOG_SIGN_OUT:
			Builder sign_out = new AlertDialog.Builder(this);
			sign_out.setSingleChoiceItems(signOutReminds,PreferenceUtils.getIntValue(PreferenceUtils.WORK_END_TIME_CHOICE), choiceListener);
			DialogInterface.OnClickListener sign_back_listener = new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int which) {
					int choiceWhich = choiceListener.getWhich();
					tv_sign_out_remind.setText(signOutReminds[choiceWhich]);
					PreferenceUtils.putStringValue(PreferenceUtils.SIGN_OUT_REMIND, signOutReminds[choiceWhich]);
					PreferenceUtils.putIntValue(PreferenceUtils.WORK_END_TIP_TIME, minutes[choiceWhich]);
					PreferenceUtils.putIntValue(PreferenceUtils.WORK_END_TIME_CHOICE, choiceWhich);
					BeanUtils.setAlarm(RemindActivity.this);
				}
			};
			sign_out.setPositiveButton("确定", sign_back_listener);
			dialog = sign_out.create();
			break;
		case CHOICE_DIALOG_WORKDAY:
			Builder workday  = new AlertDialog.Builder(this);
			DialogInterface.OnMultiChoiceClickListener workday_listener = new DialogInterface.OnMultiChoiceClickListener() {

				@Override
				public void onClick(DialogInterface dialogInterface, int which,
						boolean isChecked) {
					selected[which] = isChecked;
				}
			};
			workday.setMultiChoiceItems(strWorkdays, selected, workday_listener);
			DialogInterface.OnClickListener multiListener = new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialogInterface, int which) {
					String selectedStr = "";
					String workDay = "";
					for (int i = 0; i < selected.length; i++) {
						if (selected[i] == true) {
							selectedStr = selectedStr + "、" + strWorkdays[i];
							workDay += i + ",";
						}
					}
					if(selectedStr.length() > 0) {
						tv_day.setText(selectedStr.substring(1, selectedStr.length()));
						PreferenceUtils.putStringValue(PreferenceUtils.WEEKDAY_TIP, selectedStr.substring(1, selectedStr.length()));
						PreferenceUtils.putStringValue(PreferenceUtils.WORK_DAY_TIP, workDay.substring(0, workDay.length() - 1));
						//设置闹钟
						BeanUtils.setAlarm(RemindActivity.this);
					} else {
						tv_day.setText("");
						PreferenceUtils.putStringValue(PreferenceUtils.WEEKDAY_TIP, "");
						BeanUtils.setAlarm(RemindActivity.this);
					}
				}
			};
			workday.setPositiveButton("确定", multiListener);
			dialog = workday.create();
			break;
		}
		return dialog;
	}

	private class ChoiceOnClickListener implements
			DialogInterface.OnClickListener {

		private int which = 0;

		@Override
		public void onClick(DialogInterface dialogInterface, int which) {
			this.which = which;
		}

		public int getWhich() {
			return which;
		}
	}
	
	private void setBtnSelect(Button btn, String key) {
		int value = 0;
		if(btn.isSelected()) {
			btn.setSelected(false);
		} else {
			value = 1;
			btn.setSelected(true);
			if(key.equals("KEY_SET_RING")) {
				// 铃声开启
				ring();
			} else if(key.equals("KEY_SET_QUAKE")) {
				// 震动开启
				quake();
			}
		}
//		PreferenceUtils.putIntValue(key, value);
		preference.setSettingParam(key, value);
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		if(vibrator != null) {
			vibrator.cancel();
		}
	}

}
