package com.powerriche.mobile.na.oa.activity.document;
				  
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.ListView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.LeaveDetailActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.view.SearchBarWidget;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.common.TemperCache;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.Logger;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;
/**				  
 * @title  请假列表    
 * @author dir_wang
 * @date   2016-7-11上午11:55:16
 */				  
public class LeaveWaitListHelper implements SearchBarWidget.onSearchListener {
				  
    private final String TAG = "LeaveWaitListHelper";
    			  
    private PullToRefreshListView mPullView;
    private ListView mListView;
    private TextView tvNoDataMsg;
    			   
    private List<ResultItem> resultItems = new ArrayList<ResultItem>();
    private List<ResultItem> allResultItems = new ArrayList<ResultItem>();
    			  
    private InvokeHelper helper = null;
    			 
    private Context mContext = null;
    			 
    private IRequestCallBack callBack = null;
    			 
    private ResultSimpleAdapter adapter;
    			 
    private SearchBarWidget mSearchBarWidget;
    			 
    private String searchText;
    			
    private int pageIndex;
    			
    public LeaveWaitListHelper(Context context, View contextView, TextView tvNoDataMsg, PullToRefreshListView pullView,
                          ListView listView, IRequestCallBack callback, InvokeHelper helper) {
    			
        this.mContext = context;
        this.callBack = callback;
        this.tvNoDataMsg = tvNoDataMsg;
        this.helper = helper;
        		
        mSearchBarWidget = (SearchBarWidget) contextView.findViewById(R.id.search_bar_widget);
        mSearchBarWidget.setOnSearchListener(this);
        		
        mPullView = pullView;
        		
        mListView = listView;
        mListView.setDivider(null);
        mListView.setCacheColorHint(Color.TRANSPARENT);
        mListView.setFadingEdgeLength(0);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        		
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
            	Log.i(TAG, " 走了没有  ");
            	
                int resultItemIndex = position;
                if(resultItemIndex == 0 && (R.id.layout_search_bar_top == mListView.getChildAt(0).getId())){
                    return;//跳过：被单击的是搜索栏
                }else{
                    resultItemIndex = resultItemIndex - 1;
                }
                
                ResultItem item = resultItems.get(resultItemIndex);
                if(item == null){
                    return;//空
                }
                
                Log.i(TAG, " 走了没有 2 ");
                
                String leaveId = item.getString("LEAVE_BIZ_NO");
                String swfNo = item.getString("SWF_NO");
                String wfNo = item.getString("WF_NO");
                
                Log.i(TAG, " wfNo 1"+wfNo+" swfNo 1"+swfNo+" leaveId 1"+leaveId);
                if (null == wfNo || wfNo.length() <= 0) {
                    return;
                }
                
                Log.i(TAG, " wfNo"+wfNo+" swfNo "+swfNo+" leaveId "+leaveId);
                
                //这里进入详情界面
                Bundle data = new Bundle();
                data.putString("documentId", leaveId);
                data.putString("swfNo", swfNo);
                data.putString("wfNo", wfNo);
                UIHelper.forwardTargetActivity(mContext, LeaveDetailActivity.class, data, false);
                
            }	
        });		
    }			
    			
    public void process(HttpResponse response, int what) {
        if (pageIndex == 1) {
            resultItems.clear();// 清除
            allResultItems.clear();
        }	
        	
        List<ResultItem> result = response.getResultItem(ResultItem.class).getItems("data");
        if (!BeanUtils.isEmpty(result)) {
            resultItems.addAll(result);
            allResultItems.addAll(result);
            TemperCache.getInstance().saveTaskList(result);
        }	
        	
        if (null == adapter) {
        	// AndroidUI的组件ID
            int[] txtids = { R.id.tv_reason, R.id.tv_name, R.id.tv_type, R.id.tv_time, R.id.tv_days, R.id.tv_state };
            String[] keys = { "LEAVE_REASON", "START_STAFF_NAME", "LEAVE_TYPE", "APPLY_TIME", "LEAVE_TOTAL_DAYS", "IS_LEAVE_PASS" };
            adapter = new ResultSimpleAdapter(mContext, resultItems,
                    R.layout.list_item_leave, keys, txtids);
            adapter.setHelper(new ResultSimpleAdapter.ISimpleAdapterHelper() {
                @Override
                public Object parseValue(Object currentobj, List<?> items,
                                         int position, String key, View view) {
                    try {
                        /**
                         * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
                         */
                    	if ("APPLY_TIME".equals(key) && currentobj != null) {
                    		DateUtils dateUtils = new DateUtils(mContext);
                            return dateUtils.diffFromToNow(DateUtils.parseDate(currentobj.toString()));
                        } else if ("LEAVE_TYPE".equals(key) && currentobj != null) {
                    		String type = String.valueOf(currentobj);
                            String result = "";
                            if("0".equals(type) || "1".equals(type) || "2".equals(type) || "3".equals(type) 
                            		|| "4".equals(type) || "5".equals(type) || "6".equals(type)
                            		|| "7".equals(type) || "8".equals(type) || "9".equals(type)) {
                            	result = UIHelper.getLeaveType(mContext,type);
                            }
                            return result;
                    	} else if ("LEAVE_TOTAL_DAYS".equals(key) && currentobj != null) {
                    		String days = String.valueOf(currentobj);
                    		if (days.contains(".")) {
                    			days = days.substring(0, days.length() - 1);
                    		}
                    		return days + "天";
                    	} else if ("IS_LEAVE_PASS".equals(key) && currentobj != null) {
                    		String state = String.valueOf(currentobj);
                            String result = "";
                            TextView textView = (TextView) view.findViewById(R.id.tv_state);
                            if ("0".equals(state)) {
                            	result = mContext.getString(R.string.applying);
                            	textView.setTextColor(mContext.getResources().getColor(R.color.text_color_bdb76b));
                            } else if ("1".equals(state)) {
                            	result = mContext.getString(R.string.apply_pass);
                            	textView.setTextColor(mContext.getResources().getColor(R.color.text_color_7cfc00));
                            } else {
                            	result = mContext.getString(R.string.apply_refuse);
                            	textView.setTextColor(mContext.getResources().getColor(R.color.text_color_ff2525));
                            }
                            return result;
                    	}
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return (currentobj == null || "null".equals(currentobj
                            .toString().toLowerCase())) ? "" : currentobj;
                }
                
                @Override
                public void apply(View convertView, Object obj, int position) {
                    // 如果有搜索关键字，高亮显示
                    if (!BeanUtils.isEmpty(searchText)) {
                        TextView textView = (TextView) convertView
                                .findViewById(R.id.tv_reason);
                        SearchUtils.spannableResultItems(textView,
                                (String) textView.getText(), searchText);
                    }
                }	
            }); 	
            mListView.setAdapter(adapter);
        } else {	
            adapter.notifyDataSetChanged();
        }			
        			
        /** 		
         * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
         */ 		
        if (BeanUtils.isEmpty(result) || result.size() < Constants.COMMON_PAGE_SIZE) {
            // 已经全部加载完成，关闭UI组件的下拉加载更多功能
            mPullView.onPullDownRefreshComplete();
            mPullView.onPullUpRefreshComplete();
            mPullView.setHasMoreData(false);
            		
            if(pageIndex==1 && (BeanUtils.isEmpty(result) || result.size()==0)){
                mPullView.setVisibility(View.GONE);
                tvNoDataMsg.setVisibility(View.VISIBLE);
            }else{
                mPullView.setVisibility(View.VISIBLE);
                tvNoDataMsg.setVisibility(View.GONE);
            }	
            	
        } else {
            // 还有更多数据，继续打开“下拉加载更多”功能
            mPullView.onPullDownRefreshComplete();
            mPullView.onPullUpRefreshComplete();
            mPullView.setHasMoreData(true);
            mPullView.setVisibility(View.VISIBLE);
            tvNoDataMsg.setVisibility(View.GONE);
        }
    }	
    	
    public void loadData(int what, int pageIndex,boolean isDialog) {
        this.pageIndex = pageIndex;
        
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        
        ApiRequest request = null;
        request = OAServicesHandler.getAskLeaveList(pageIndex);
        Logger.e(TAG, "loadData " + request);
        if (request != null) {
            if (isDialog) {
                helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
            } else {
                helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
            }
        }
    }	
    	
    @Override
    public void onSearchChange(String search) {
        searchText = search;
        resultItems.clear();// 清除
        if (allResultItems != null && allResultItems.size() > 0
                && !BeanUtils.isEmpty(search)) {
            resultItems.addAll(SearchUtils.filterResults(allResultItems,
                    search, "LEAVE_REASON"));
        } else {
            resultItems.addAll(allResultItems);
        }

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }
}
