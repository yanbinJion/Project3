package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

public class AttendanceCount implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4486593932805882913L;
	private String staffNo;
	private String realName;
	private String siteNo;
	private String siteName;
	private String siteOrderNo;
	private String orderNo;

	public String getStaffNo() {
		return staffNo;
	}

	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getSiteNo() {
		return siteNo;
	}

	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getSiteOrderNo() {
		return siteOrderNo;
	}

	public void setSiteOrderNo(String siteOrderNo) {
		this.siteOrderNo = siteOrderNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

}
