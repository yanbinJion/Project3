package com.powerriche.mobile.na.oa.activity;
		
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
		
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.document.DocumentWaitListHelper;
import com.powerriche.mobile.na.oa.activity.view.BaseLinearLayout;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase.OnRefreshListener;
import com.powerriche.mobile.oa.common.Constants;
	    
/** 	
 * 类描述：<br> 待办事项
 *  	
 * @author 李运期
 * @date 2015年4月23日
 * @version v1.0
 */ 	
public class TabDbsyActivity extends BaseLinearLayout implements OnClickListener {
		
	private Context 				mContext;
	private MainActivity			acitvity;
	private View					contextView;
		
	private PullToRefreshListView	mPullView;
	private ListView				mListView;
	private TextView				tvNoDataMsg;
		
	/** 按钮：待办 */
	private Button					mBtnDb;
	/** 按钮：待阅 */
	private Button					mBtnDy;
		
	public int						pageIndex	= 1;
		
	private static int				OPT_TYPE	= Constants.OPT_TYPE_WAIT_DB;
		
	public TabDbsyActivity(Context context) {
		super(context);
		this.mContext = context;
		
		LayoutInflater.from(context).inflate(R.layout.main_dbsy, this, true);
		
		acitvity = (MainActivity) context;
		contextView = findViewById(R.id.layout_dbsy);
		
	}	
		
	@Override
	public void onCreate(Intent intent) {
		
		mBtnDb = (Button) findViewById(R.id.btn_db);
		mBtnDb.setOnClickListener(this);
		mBtnDy = (Button) findViewById(R.id.btn_dy);
		mBtnDy.setOnClickListener(this);
		
		Button btnUser = (Button) findViewById(R.id.btn_system_user);
		btnUser.setOnClickListener(this);
		Button btnBack = (Button) findViewById(R.id.btn_left_menu);
		btnBack.setOnClickListener(this);
		
		bindView();
		
		View header = LayoutInflater.from(mContext).inflate(R.layout.main_search_bar_top, null);
		mListView.addHeaderView(header);
		
		loadData4WaitingProcess();//第一个加载项
	}	
		
	private void bindView() {
		mPullView = (PullToRefreshListView) this.findViewById(R.id.pulllistview_dbsy);
		mPullView.setPullRefreshEnabled(true);
		mPullView.setPullLoadEnabled(false);
		mPullView.setScrollLoadEnabled(true);
		
		mListView = mPullView.getRefreshableView();
		mListView.setDivider(null);
		mListView.setCacheColorHint(Color.TRANSPARENT);
		mListView.setFadingEdgeLength(0);
		mListView.setSelector(android.R.color.transparent);//或者：mListView.setSelector(this.getResources().getDrawable(android.R.color.transparent));
		
		mPullView.setOnRefreshListener(new OnRefreshListener<ListView>() {
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
				// 下拉加载数据,查询第一页数据，重新加载
				pageIndex = 1;
				acitvity.documentWaitListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_WAIT, pageIndex, false);
			}
			
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
				// 上拉加载下一页的数据
				pageIndex = pageIndex + 1;
				acitvity.documentWaitListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_WAIT, pageIndex, false);
			}
		}); 
		tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
		tvNoDataMsg.setVisibility(View.GONE);
	}		      
			     
	/** 		 
	 * 加载数据：待办 
	 */ 		 
	public void loadData4WaitingProcess() {
		//设置选中项：待办
		OPT_TYPE = Constants.OPT_TYPE_WAIT_DB;
		mBtnDb.setBackgroundResource(R.drawable.waiting_process_normal_btn);//“待办”是选中项
		mBtnDy.setBackgroundResource(R.drawable.waiting_read_press_btn);
				 
		acitvity.documentWaitListHelper = new DocumentWaitListHelper(acitvity, contextView, tvNoDataMsg);
		// 请求加载数据
		pageIndex = 1;
		acitvity.documentWaitListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_WAIT, pageIndex, true);
	}			 
				 
	/** 		 
	 * 加载数据：待阅 
	 */ 		 
	public void loadData4WaitingRead() {
		//设置选中项：待阅
		OPT_TYPE = Constants.OPT_TYPE_WAIT_DY;
		mBtnDy.setBackgroundResource(R.drawable.waiting_read_normal_btn);
		mBtnDb.setBackgroundResource(R.drawable.waiting_process_press_btn);//“待阅”是选中项
				
		acitvity.documentWaitListHelper = new DocumentWaitListHelper(acitvity, contextView, tvNoDataMsg);
		// 请求加载数据
		pageIndex = 1;
		acitvity.documentWaitListHelper.loadData(OPT_TYPE, Constants.WHAT_REQUEST_WAIT, pageIndex, true);
	}			
				
	@Override	
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.btn_system_user:// 右侧菜单
				FrameManager.manager.getmMainActivity().openLeftMenu();
				break;
			case R.id.btn_left_menu:// 左侧菜单
				FrameManager.manager.getmMainActivity().openRightMenu();
				break;
			case R.id.btn_db:// 待办
				loadData4WaitingProcess();
				break;
			case R.id.btn_dy:// 待阅
				loadData4WaitingRead();
				break;
				
		}		
	}			
				
	@Override	
	public void onShow(Intent intent) {
				
	}			
				
	@Override	
	public void onDestroy() {
		//mContext = null;
		mPullView = null;
		mListView = null;
	}			
				
}				
				