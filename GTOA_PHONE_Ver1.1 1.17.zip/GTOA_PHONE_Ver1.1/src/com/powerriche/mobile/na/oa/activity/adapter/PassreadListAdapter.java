package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.bean.PassreadInfo;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br> 
 * 传阅信息列表
 * @author  Fitz
 * @date    2015年5月13日
 * @version v1.0
 */
public class PassreadListAdapter extends BaseAdapter implements OnClickListener{

	private Context mContext = null;
	private LayoutInflater inflater;

	private List<PassreadInfo> dataList;

	public PassreadListAdapter(Context context) {
		this.mContext = context;
		this.inflater = LayoutInflater.from(this.mContext);
		this.dataList = new ArrayList<PassreadInfo>();
	}

	
	@Override
	public void onClick(View v) {
		
	}
	

	@Override
	public int getCount() {
		return dataList.size();
	}

	@Override
	public Object getItem(int position) {
		return dataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		
		ViewHolder holder = null;
        if (view == null) {
        	holder = new ViewHolder();
        	view = inflater.inflate(R.layout.document_detail_passread_item, null);
        	holder.tvName = (TextView) view.findViewById(R.id.tv_user_name);
        	holder.tvDepartment = (TextView) view.findViewById(R.id.tv_department);
        	holder.tvContent = (TextView) view.findViewById(R.id.tv_content);
            holder.tvDatetime = (TextView) view.findViewById(R.id.tv_datetime);
            holder.tvStatus = (TextView) view.findViewById(R.id.tv_status);
            view.setTag(holder);
            
        } else {
        	holder = (ViewHolder) view.getTag();
        }
        
        PassreadInfo bean = dataList.get(position);
        holder.tvDatetime.setText(bean.getDatetime());
        holder.tvContent.setText(BeanUtils.isEmptyStr(bean.getRemark()));
        holder.tvDepartment.setText(bean.getDepartment());
        holder.tvName.setText(bean.getName());
        String status = bean.getStatus();
        if("未阅".equals(status)){
        	holder.tvStatus.setTextColor(mContext.getResources().getColor(R.color.text_color_ba5b5f));
        }else{
        	holder.tvStatus.setTextColor(mContext.getResources().getColor(R.color.text_color_6cb860));//已阅
        }
        holder.tvStatus.setText(status);
		return view;
	}

	
	/**
	 * 添加数据
	 */
	public void addData(List<PassreadInfo> dataList){
		this.dataList.addAll(dataList);
	}
	
	
	public void clearListData(){
		if(dataList!=null){
			dataList.clear();
		}
	}
	
	private class ViewHolder{
		TextView tvName, tvDepartment, tvDatetime, tvContent, tvStatus;
	}

	
}
