package com.powerriche.mobile.na.oa.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.na.oa.activity.view.pull.PullToRefreshBase;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @title  请假查询
 * @author dir_wang
 * @date   2016-6-30下午2:15:07
 */
public class LeaveQueryResultActivity extends BaseActivity {

    private PullToRefreshListView listView;
    private ListView mListView;
    private TopActivity topActivity;
    private Button backBtn;
    public static final int RECEIVE_SEARCH = 0;
    public static final int PURCHASE_SEARCH = 1;

    private List<ResultItem> resultItems = new ArrayList<ResultItem>();

    private String searchTitle;
    private String applyType;
    private String applyBeginTime;
    private String applyEndTime;
    private String applyHandle;
    private String applyPass;

    private TextView tvNoDataMsg;
    private InvokeHelper helper;

    private ResultSimpleAdapter adapter;
    private int index = 1;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        BeanUtils.setPortraitAndLandscape(this);
        setContentView(R.layout.task_search_result_layout);
        Intent intent = getIntent();
        searchTitle = intent.getStringExtra("searchTitle");
        applyType = intent.getStringExtra("applyType");
        if (!applyType.equals("0")) {
        	applyType = String.valueOf(BeanUtils.floatToInt(applyType) - 1);
        } else {
        	applyType = "";
        }
        applyBeginTime = intent.getStringExtra("applyBeginTime");
        applyEndTime = intent.getStringExtra("applyEndTime");
        applyHandle = intent.getStringExtra("applyHandle");
        applyPass = intent.getStringExtra("applyPass");
        initView();
    }

    private void initView() {
        topActivity = (TopActivity) findViewById(R.id.top_activity);
        int titleRes = R.string.leave_query;
        topActivity.setTopTitle(getString(titleRes));// 顶部栏的中间标题
        topActivity.setRightBtnVisibility(View.VISIBLE);// 隐藏右边按钮
        topActivity.setRightBtnVisibility(View.INVISIBLE);//显示右边按钮
        topActivity.setRightBtnStyle(R.drawable.add_button);//“新建”图标
        backBtn = topActivity.getBtnBack();

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        listView = (PullToRefreshListView) findViewById(R.id.my_task_pulllistview);
        mListView = listView.getRefreshableView();
        listView.setPullRefreshEnabled(true);
        listView.setPullLoadEnabled(false);
        listView.setScrollLoadEnabled(true);
        UIHelper.setListViewAttribute(mListView);

        listView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {// 下拉加载数据
                index = 1;
                loadData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {// 上拉加载下一页的数据
                index = index + 1;
                loadData();
            }
        });
        tvNoDataMsg = (TextView) findViewById(R.id.tv_no_data_msg);
        tvNoDataMsg.setVisibility(View.GONE);
        mListView.setDivider(null);
        mListView.setCacheColorHint(Color.TRANSPARENT);
        mListView.setFadingEdgeLength(0);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // 特别注意：由于ListView的第1个列表项是搜索栏，需要进行以下特别处理
                int resultItemIndex = position;
//                if(resultItemIndex == 0 && (R.id.layout_search_bar_top == mListView.getChildAt(0).getId())){
//                    return;//跳过：被单击的是搜索栏
//                }else{
//                    resultItemIndex = resultItemIndex - 1;
//                }

                ResultItem item = resultItems.get(resultItemIndex);
                if(item == null){
                    return;//空
                }
                //这里进入详情界面
                String leaveId = item.getString("LEAVE_BIZ_NO");
                String swfNo = item.getString("SWF_NO");
                String wfNo = item.getString("WF_NO");
                if (null == wfNo || wfNo.length() <= 0) {
                    return;
                }
                //这里进入详情界面
                Bundle data = new Bundle();
                data.putString("documentId", leaveId);
                data.putString("swfNo", swfNo);
                data.putString("wfNo", wfNo);
                UIHelper.forwardTargetActivity(LeaveQueryResultActivity.this, LeaveDetailActivity.class, data, false);
            }
        });
        loadData();
    }

    private IRequestCallBack callBack = new BaseRequestCallBack() {
        @Override
        public void process(HttpResponse response, int what) {
            if (index == 1) {
                resultItems.clear();// 清除
            }
            List<ResultItem> result = response.getResultItem(ResultItem.class).getItems("data");
            if (!BeanUtils.isEmpty(result)) {
                resultItems.addAll(result);
            }
            if (BeanUtils.isEmpty(result)) {
                tvNoDataMsg.setVisibility(View.VISIBLE);
            } else {
                tvNoDataMsg.setVisibility(View.GONE);
            }
            if (null == adapter) {
            	// AndroidUI的组件ID
            	int[] txtids = { R.id.tv_reason, R.id.tv_name, R.id.tv_type, R.id.tv_time, R.id.tv_days, R.id.tv_state };
                String[] keys = { "LEAVE_REASON", "APPLY_REALNAME", "LEAVE_TYPE", "APPLY_TIME", "LEAVE_TOTAL_DAYS", "IS_LEAVE_PASS" };
                adapter = new ResultSimpleAdapter(LeaveQueryResultActivity.this, resultItems,
                        R.layout.list_item_leave, keys, txtids);
                adapter.setHelper(new ResultSimpleAdapter.ISimpleAdapterHelper() {
                    @Override
                    public Object parseValue(Object currentobj, List<?> items,
                                             int position, String key, View view) {
                        try {
                            /**
                             * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
                             */
                        	if ("APPLY_TIME".equals(key) && currentobj != null) {
                        		DateUtils dateUtils = new DateUtils(LeaveQueryResultActivity.this);
                                return dateUtils.diffFromToNow(DateUtils.parseDate(currentobj.toString()));
                            } else if ("LEAVE_TYPE".equals(key) && currentobj != null) {
                        		String type = String.valueOf(currentobj);
                                String result = "";
                                if("0".equals(type) || "1".equals(type) || "2".equals(type) || "3".equals(type) 
                                		|| "4".equals(type) || "5".equals(type) || "6".equals(type)
                                		|| "7".equals(type) || "8".equals(type) || "9".equals(type)) {
                                	result = UIHelper.getLeaveType(LeaveQueryResultActivity.this,type);
                                }
                                return result;
                        	} else if ("LEAVE_TOTAL_DAYS".equals(key) && currentobj != null) {
                        		String days = String.valueOf(currentobj);
                        		if (days.contains(".")) {
                        			days = days.substring(0, days.length() - 1);
                        		}
                        		return days + "天";
                        	} else if ("IS_LEAVE_PASS".equals(key) && currentobj != null) {
                        		String state = String.valueOf(currentobj);
                                String result = "";
                                TextView textView = (TextView) view.findViewById(R.id.tv_state);
                                if ("0".equals(state)) {
                                	result = getString(R.string.applying);
                                	textView.setTextColor(getResources().getColor(R.color.text_color_bdb76b));
                                } else if ("1".equals(state)) {
                                	result = getString(R.string.apply_pass);
                                	textView.setTextColor(getResources().getColor(R.color.text_color_7cfc00));
                                } else {
                                	result = getString(R.string.apply_refuse);
                                	textView.setTextColor(getResources().getColor(R.color.text_color_ff2525));
                                }
                                return result;
                        	}
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return (currentobj == null || "null".equals(currentobj
                                .toString().toLowerCase())) ? "" : currentobj;
                    }

                    @Override
                    public void apply(View convertView, Object obj, int position) {
                        // 如果有搜索关键字，高亮显示
                        if (!BeanUtils.isEmpty(searchTitle)) {
                            TextView textView = (TextView) convertView
                                    .findViewById(R.id.tv_reason);
                            SearchUtils.spannableResultItems(textView,
                                    (String) textView.getText(), searchTitle);
                        }
                    }
                });
                mListView.setAdapter(adapter);
            } else {
                adapter.notifyDataSetChanged();
            }

            /**
             * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
             */
            if (BeanUtils.isEmpty(result) || result.size() < Constants.COMMON_PAGE_SIZE) {
                // 已经全部加载完成，关闭UI组件的下拉加载更多功能
                listView.onPullDownRefreshComplete();
                listView.onPullUpRefreshComplete();
                listView.setHasMoreData(false);

                if(index == 1 && (BeanUtils.isEmpty(result) || result.size()==0)){
//                    listView.setVisibility(View.GONE);
                    tvNoDataMsg.setVisibility(View.VISIBLE);
                    listView.getFooterLoadingLayout().show(false);
                }else{
                    listView.setVisibility(View.VISIBLE);
                    tvNoDataMsg.setVisibility(View.GONE);
                }

            } else {
                // 还有更多数据，继续打开“下拉加载更多”功能
                listView.onPullDownRefreshComplete();
                listView.onPullUpRefreshComplete();
                listView.setHasMoreData(true);
                listView.setVisibility(View.VISIBLE);
                tvNoDataMsg.setVisibility(View.GONE);
            }
        }
    };

    private void loadData() {
        helper = new InvokeHelper(this);
        ApiRequest request = OAServicesHandler.getLeaveGeneralList(applyHandle, applyType, applyPass, applyBeginTime, applyEndTime,index);
        request.setMessage(getString(R.string.system_load_message));
        helper.invokeWidthDialog(request, callBack);
    }

}
