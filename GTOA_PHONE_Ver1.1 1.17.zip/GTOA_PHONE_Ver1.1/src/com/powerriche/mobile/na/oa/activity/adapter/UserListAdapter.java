package com.powerriche.mobile.na.oa.activity.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.UserInfoActivity;
import com.powerriche.mobile.na.oa.activity.document.UserInfoHelper;
import com.powerriche.mobile.na.oa.bean.DepartmentInfo;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.na.oa.view.SystemDialog;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.SearchUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br> 
 * 组织成员列表适配器
 * @author  Fitz
 * @date    2015年4月22日
 * @version v1.0
 */
public class UserListAdapter extends BaseExpandableListAdapter implements OnClickListener, OnLongClickListener{

	private Context mContext = null;
	private LayoutInflater inflater;

	private List<DepartmentInfo> groupList = null;
	private List<List<UserInfo>> userList = null;
	
	private String searchText;
	
	private int currentPosition = -1;

	public UserListAdapter(Context context) {
		this.mContext = context;
		this.inflater = LayoutInflater.from(this.mContext);
		
		this.groupList = new ArrayList<DepartmentInfo>();
		this.userList = new ArrayList<List<UserInfo>>();
	}

	/*
	 * 设置子节点对象，在事件处理时返回的对象，可存放一些数据
	 */
	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return userList.get(groupPosition).get(childPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
		ChildHolder holder = null;
        if (convertView == null) {
        	holder = new ChildHolder();
            convertView = inflater.inflate(R.layout.user_list_item, null);
            holder.tvName = (TextView) convertView.findViewById(R.id.tv_name);
            holder.tvMobile = (TextView) convertView.findViewById(R.id.tv_mobile);
            holder.userItem = (RelativeLayout) convertView.findViewById(R.id.rl_user_item_wrap);
            
            /*holder.tvDial = (TextView) convertView.findViewById(R.id.tv_dial);
            holder.tvMsg = (TextView) convertView.findViewById(R.id.tv_msg);
            holder.llItemMenu = (LinearLayout) convertView.findViewById(R.id.ll_item_menu);
            holder.llItemDial = (LinearLayout) convertView.findViewById(R.id.ll_item_dial);
            holder.llItemMsg = (LinearLayout) convertView.findViewById(R.id.ll_item_msg);*/
            
            convertView.setTag(holder);
        } else {
        	holder = (ChildHolder) convertView.getTag();
        }
        
        UserInfo bean = userList.get(groupPosition).get(childPosition);
        bean.setCurrPosition(childPosition);
    
        holder.tvName.setText(bean.getRealName());
        holder.tvMobile.setText(bean.getMobile());
        holder.userItem.setTag(bean);
        holder.userItem.setOnClickListener(this);
//        holder.userItem.setOnLongClickListener(this);//长按显示隐藏菜单
        // 如果有搜索关键字，高亮显示
 		if (!BeanUtils.isEmpty(searchText)) {
 			SearchUtils.spannableResultItems(holder.tvName,
 					(String) holder.tvName.getText(), searchText);
 		}

 		/*holder.llItemDial.setOnClickListener(this);
 		holder.llItemDial.setTag(bean);
 		holder.tvDial.setOnClickListener(this);
 		holder.tvDial.setTag(bean);
 		
 		holder.llItemMsg.setOnClickListener(this);
 		holder.llItemMsg.setTag(bean);
        holder.tvMsg.setOnClickListener(this);
        holder.tvMsg.setTag(bean);
        
 		if (childPosition == currentPosition) {
 			holder.llItemMenu.setVisibility(View.VISIBLE);
 		}else{
 			holder.llItemMenu.setVisibility(View.GONE);
 		}*/
 		
		return convertView;
	}

	/*
	 * 返回当前分组的字节点个数
	 */
	@Override
	public int getChildrenCount(int groupPosition) {
		return userList.get(groupPosition).size();
	}

	/*
	 * 返回分组对象，用于一些数据传递，在事件处理时可直接取得和分组相关的数据
	 */
	@Override
	public Object getGroup(int groupPosition) {
		return groupList.get(groupPosition);
	}

	/*
	 * 分组的个数
	 */
	@Override
	public int getGroupCount() {
		return groupList.size();
	}
	

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		GroupHolder holder = null;
        if (convertView == null) {
        	holder = new GroupHolder();
            convertView = inflater.inflate(R.layout.user_list_group, null);
            holder.tvGroup = (TextView) convertView.findViewById(R.id.tv_group_name);
            convertView.setTag(holder);
        } else {
        	holder = (GroupHolder) convertView.getTag();
        }
        
        DepartmentInfo group = groupList.get(groupPosition);
        
        String groupName = group.getSiteName();
        holder.tvGroup.setText(groupName);
        holder.tvGroup.setTag(group);
        
        Drawable drawable = null;
        if(isExpanded){
        	drawable = UIHelper.closeDrawable(mContext, R.drawable.ic_arrows_close);
        }else{
        	drawable = UIHelper.openDrawable(mContext, R.drawable.ic_arrows_open);
        }
        holder.tvGroup.setCompoundDrawables(null, null, drawable, null);
		return convertView;
	}

	/*
	 * 判断分组是否为空，本示例中数据是固定的，所以不会为空，我们返回false 如果数据来自数据库，网络时，可以把判断逻辑写到这个方法中，如果为空
	 * 时返回true
	 */
	@Override
	public boolean isEmpty() {
		return false;
	}

	/*
	 * 收缩列表时要处理的东西都放这儿
	 */
	@Override
	public void onGroupCollapsed(int groupPosition) {
		
	}

	/*
	 * 展开列表时要处理的东西都放这儿
	 */
	@Override
	public void onGroupExpanded(int groupPosition) {
	}


	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}
	
	@Override
	public boolean hasStableIds() {
		return false;
	}
	
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		if(id == R.id.rl_user_item_wrap){	//跳转到用户详情界面
			UserInfo user = (UserInfo) v.getTag();
			if(!BeanUtils.isEmpty(user)){
				Bundle bundle = new Bundle();
//				String staffNo = user.getStaffNo();
				String uapStaffNo = user.getUapStaffNo();
				bundle.putString(UserInfoHelper.KEY_USER_STAFFNO, uapStaffNo);
				UIHelper.forwardTargetActivity(mContext, UserInfoActivity.class, bundle, false);
			}
			
		}/*else if(id==R.id.ll_item_dial || id==R.id.tv_dial){	//拨打电话->调用系统
			UserInfo user = (UserInfo) v.getTag();
			
		}else if(id==R.id.ll_item_msg || id==R.id.tv_msg){	//发短信->调用系统
			UserInfo user = (UserInfo) v.getTag();
			
		}*/
	}
	
	/**
	 * 添加数据
	 * @param groupList
	 * @param userList
	 */
	public void addData(List<DepartmentInfo> groupList, List<List<UserInfo>> userList, String searchText){
		this.groupList.addAll(groupList);
		this.userList.addAll(userList);
		this.searchText = searchText;
	}
	
	
	private class GroupHolder {
        TextView tvGroup;
    }
	
	private class ChildHolder{
		TextView tvName, tvMobile;
		RelativeLayout userItem;
		
		/*TextView tvDial, tvMsg;
		LinearLayout llItemMenu, llItemDial, llItemMsg;*/
	}

	public void clearListData() {
		if (groupList != null) {
			groupList.clear();
			userList.clear();
		}
	}

	@Override
	public boolean onLongClick(View v) {
		if(v.getId() == R.id.rl_user_item_wrap){
			UIHelper.vibrate(mContext, 50);
			final UserInfo bean = (UserInfo) v.getTag();
			final String mobile = bean.getMobile();
			if(BeanUtils.isEmpty(mobile)){
				UIHelper.showMessage(mContext, "该用户没有联系电话");
				return false;
			}
			
			/*currentPosition = bean.getCurrPosition();
			this.notifyDataSetChanged();*/
			final SystemDialog dialog = new SystemDialog(mContext);
			dialog.setMessage("请选择");
			dialog.setOnCancelClickListener("呼叫", new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+mobile));
		            mContext.startActivity(intent);//内部类
				}
			});
			dialog.setOnConfirmClickListener("短信", new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+mobile));
					mContext.startActivity(intent);
				}
			});
			dialog.show();
		}
		return false;
	}

}
