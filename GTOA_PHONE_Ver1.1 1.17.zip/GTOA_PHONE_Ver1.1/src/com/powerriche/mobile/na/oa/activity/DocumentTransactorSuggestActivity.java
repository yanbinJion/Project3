package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.SuggestInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * 类描述：<br>
 * 办理信息的时候，选择常用意见
 * 
 * @author Fitz
 * @date 2015年5月7日
 * @version v1.0
 */
public class DocumentTransactorSuggestActivity extends BaseActivity {

	public Context mContext;
	private ListView listView;
	private SuggestAdataper adapter;
	//private View view;
	private List<SuggestInfo> suggestList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		this.mContext = this;
		
		//LayoutInflater inflater = LayoutInflater.from(mContext);
		//view = inflater.inflate(R.layout.dialog_document_transactor_suggest, null);
		//setContentView(R.layout.dialog_document_transactor_suggest);
		doLoadUserNotesList();
	}

	private void bindView() {
		setContentView(R.layout.dialog_document_transactor_suggest);
		//((Activity) mContext).requestWindowFeature(R.style.TipsDialog);
		listView = (ListView)findViewById(R.id.lv_suggest);
		listView.setVerticalScrollBarEnabled(false);// 设置滚动条隐藏(包含活动跟不活动)
		listView.setDivider(null);
		listView.setCacheColorHint(Color.TRANSPARENT);
		listView.setFadingEdgeLength(0);

		TextView tv = new TextView(mContext);
		tv.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT));
		tv.setTextColor(mContext.getResources().getColor(R.color.white));
		tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
		tv.setGravity(Gravity.CENTER);
		tv.setPadding(15, 15, 15, 15);

		
		listView.addFooterView(tv);
		
		adapter = new SuggestAdataper(mContext);
		// 获取交互数据
		adapter.addData(suggestList);
		adapter.notifyDataSetChanged();
		listView.setAdapter(adapter);
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	public SuggestAdataper getSuggestAdapter() {
		return adapter;
	}

	public class SuggestAdataper extends BaseAdapter {

		private Context mContext = null;
		private LayoutInflater inflater;

		private List<SuggestInfo> dataList;

		public SuggestAdataper(Context context) {
			this.mContext = context;
			this.inflater = LayoutInflater.from(this.mContext);
			this.dataList = new ArrayList<SuggestInfo>();
		}

		@Override
		public int getCount() {
			return dataList.size();
		}

		@Override
		public Object getItem(int position) {
			return dataList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View view, ViewGroup parent) {

			ViewHolder holder = null;

			if (view == null) {
				holder = new ViewHolder();
				view = inflater.inflate(
						R.layout.document_transactor_suggest_item, null);
				holder.tvContent = (TextView) view
						.findViewById(R.id.tv_content);
				holder.btnChoose = (Button) view.findViewById(R.id.btn_choose);
				view.setTag(holder);

			} else {
				holder = (ViewHolder) view.getTag();
			}

			final SuggestInfo bean = dataList.get(position);
			holder.tvContent.setText(bean.getContent());
			holder.btnChoose.setTag(bean);
            view.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent();
					if (bean != null) {
						intent.putExtra("SUGGEST_CONTENT", bean.getContent());
					}
					setResult(Activity.RESULT_OK, intent);
					finish();
				}
			});
			return view;
		}

		public void addData(List<SuggestInfo> dataList) {
			this.dataList.addAll(dataList);
		}

		public void clearListData() {
			if (dataList != null) {
				dataList.clear();
			}
		}

		public void removeData(int position) {
			dataList.remove(position);
		}

		private class ViewHolder {
			TextView tvContent;
			Button btnChoose;
		}
	}
	
	/**
	 * 获取常用建议数据
	 */
	public void doLoadUserNotesList(){
        ApiRequest request = OAServicesHandler.getUserNotesList();
        if (request != null){
        	request.setMessage(getString(R.string.system_load_message));
            helper.invokeWidthDialog(request, getCallBack, 2222);
        }
    }
	
	private IRequestCallBack getCallBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			if (what == 2222) { // 常用意见表
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {

					List<ResultItem> items = item.getItems("data");
					if (!BeanUtils.isEmpty(items)) {// 如果数据不为空
						ArrayList<SuggestInfo> list = new ArrayList<SuggestInfo>();
						for (ResultItem it : items) {
							String id = it.getString("NOTE_CONTENT_ID");
							String content = it.getString("CONTENT");
							SuggestInfo bean = new SuggestInfo(id, content);
							list.add(bean);
						}
						if (list == null || list.isEmpty()) {
							UIHelper.showMessage(context, "您还没有设置常用语");
						} else {

							// 封装交互数据
							// Bundle data = new Bundle();
							// data.putSerializable("notesList", (Serializable)
							// suggestList);
							suggestList = list;
							bindView();
							// 弹出常用意见选择对话框
							// UIHelper.forwardTargetActivityForResult(mContext,
							// DocumentTransactorSuggestActivity.class, data,
							// false, 10086);
						}
					} else {
						UIHelper.showMessage(mContext, "您还没有设置常用语");
						((Activity) mContext).finish();
					}
				} else {
					String message = item.getString("message");
					UIHelper.showMessage(mContext, message);
					((Activity) mContext).finish();
				}
			}
		}
	};

}
