package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.DocumentDetailActivity;
import com.powerriche.mobile.na.oa.activity.ExecutiveMeetingDetailActivity;
import com.powerriche.mobile.na.oa.activity.MeetDetailActivity;
import com.powerriche.mobile.na.oa.activity.PassreadListActivity;
import com.powerriche.mobile.na.oa.activity.TaskDetailActivity;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter;
import com.powerriche.mobile.na.oa.activity.adapter.ResultSimpleAdapter.ISimpleAdapterHelper;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.activity.view.PullToRefreshListView;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

/**
 * Filename : DocumentGwcyDaiyueHelper.java
 * @Description : 数据处理：公文传阅->已传
 * @Author : 李运期
 * @Version : 1.0
 * @Date : 2015年6月2日
 */
public class DocumentGwcyYichuanHelper {

	private PullToRefreshListView mPullView;
	private ListView mListView;
	private TextView tvNoDataMsgYichuan;
	
	private List<ResultItem> resultItems = new ArrayList<ResultItem>();
	private int doucmentType = 0;

	private Context mContext = null;
	private InvokeHelper helper = null;
	private IRequestCallBack callBack = null;
	private ResultSimpleAdapter adapter;

	private int pageIndex;
	
	/**
	 * 点击某个待办或者待阅item时，记下这个item索引号，并作出以下处理：
	 * 1、如果当前界面是待阅界面，调用标志已阅接口，将文档的待阅状态转成已阅状态。
	 * 2、传递相应参数，进入公文详情界面
	 * 当从公文详情界面再返回到当前界面时，作出以下处理：
	 * 1、如果当前界面是待阅界面，将其从ListView列表中移除（因为已阅了）。
	 * 2、如果当前界面是待办界面，并且在办理界面那里办理成功(dealwithFlag==1)，也将其从ListView列表中移除（因为已办了）。
	 * 3、如果当前界面是待办界面，并且在办理界面那里退件成功(retroversionFlag==1)，也将其从ListView列表中移除（因为退件了）。
	 * 4、如果当前界面是已办界面，并且在办理界面那里撤回成功(retracementFlag==1)，也将其从ListView列表中移除（因为撤回了）。
	 */
	private int prepareRemoveIndex = -1;

	public DocumentGwcyYichuanHelper(Context context, PullToRefreshListView pullView, ListView listView, TextView tvNoDataMsgYichuan,
			InvokeHelper helperA, IRequestCallBack callback) {
		
		this.mContext = context;
		this.helper = helperA;
		this.callBack = callback;

		this.mPullView = pullView;
		this.mListView = listView;
		this.tvNoDataMsgYichuan = tvNoDataMsgYichuan;

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index, long arg3) {
				try {
					ResultItem item = resultItems.get(index);
					if(item == null){
						return;//空
					}

					String documentId = item.getString("DOCUMENT_ID"); // 文档编号
					String wfNo = item.getString("WF_NO"); // 流程编号
					String passreadId = item.getString("PASSREAD_ID"); // 待阅：传阅编号
					String swfNo = item.getString("SWF_NO"); // 系统流程编号
					String fpuNo = item.getString("FPU_NO"); // 当前环节编号
					String traceNo = item.getString("TRACE_NO"); // 当前跟踪编号
					String tempDocType = BeanUtils.isEmpty4Get(item.getString("DOCUMENT_TYPE")); // 文档类型

					if (BeanUtils.isEmpty(documentId) || BeanUtils.isEmpty(wfNo)) {
						return;
					}

					Bundle data = new Bundle();
					
					prepareRemoveIndex = index;
					// 调用接口：标志已阅，将待阅状态改变为已阅状态
					if (doucmentType == Constants.OPT_TYPE_GWCY_DY && !BeanUtils.isEmpty(passreadId)) {// 公文传阅：待阅
						ApiRequest request = OAServicesHandler.markPassreadState(passreadId);
						if (request != null) {
							new InvokeHelper(mContext).invoke(request, null, 12345);
						}
					}

					// 封装交互数据：需要去掉服务端返回的多余“.0”
					data.putString("documentId", BeanUtils.floatToInt4Str(documentId));//取整
					data.putString("wfNo", BeanUtils.floatToInt4Str(wfNo));//取整
					data.putString("passreadId", BeanUtils.floatToInt4Str(passreadId));//取整
					data.putString("fpuNo", BeanUtils.isEmpty4Get(fpuNo));
					data.putString("swfNo", BeanUtils.isEmpty4Get(swfNo));
					data.putString("traceNo", BeanUtils.floatToInt4Str(traceNo));//取整

					data.putInt("IS_PASS_READ", 1000);	//标识传阅进来的入口
					data.putInt("PASS_READ_TYPE", doucmentType);	//取消”已传件“的回复功能

					// 如果是请假审批的，调转到审批页面
					if ("2014072509353877".equals(swfNo)) {// 业务类型：请假
						//UIHelper.forwardTargetActivity(mContext,
						//	AskleaveApprovalActivity.class, data, false);
						//查询请假详情
						Constants.DOCUMENT_ID = documentId;
						Constants.TRACE_NO = swfNo;
						helper.invokeWidthDialog(OAServicesHandler.getAskLeaveDetail(BeanUtils.floatToInt4Str(documentId)), callBack, Constants.OPT_TYPE_LEAVE_DETAIL);

					} else if("2006122705014455".equals(swfNo)){//主办会议
						data.putInt("doucmentType", Constants.OPT_TYPE_HYGL_ZBHY);
						// 跳转到界面：主办会议详情
						UIHelper.forwardTargetActivity(mContext, MeetDetailActivity.class, data, false);

					} else if(Constants.LW_CODE.equals(swfNo) 
							&& ("HY".equals(tempDocType) || "CWHY".equals(tempDocType))){//会议通知
						// 注意：当是来文时(swfNo=2006083005302033)，并且(DOCUMENT_TYPE=’HY’ or DOCUMENT_TYPE=’CWHY’)，代表接收到的会议通知
						data.putInt("doucmentType", Constants.OPT_TYPE_HYGL_HYTZ);
						// 跳转到界面：会议通知详情
						UIHelper.forwardTargetActivity(mContext, MeetDetailActivity.class, data, false);
						
					} else if("2006112910044951".equals(swfNo)){
                        //调转到常务会议
                        data.putString("meetingId", BeanUtils.floatToInt4Str(documentId));
                        UIHelper.forwardTargetActivity(mContext,
                                ExecutiveMeetingDetailActivity.class, data, false);
                        
                    } else if("2015060606070809".equals(swfNo)||"2015060116171819".equals(swfNo)){
                        //调转到任务
                        data.putString("taskId",BeanUtils.floatToInt4Str(documentId));
                        // 跳转到详情页面
                        UIHelper.forwardTargetActivity(mContext,
                                TaskDetailActivity.class, data, false);
                    } else{
						// 跳转到界面：公文详情
						UIHelper.forwardTargetActivity(mContext, DocumentDetailActivity.class, data, false);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	public void process(HttpResponse response, int what) {
		List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			resultItems.addAll(items);
			if(items.size() > 0){
			    PassreadListActivity.isFirst3 = false;
            }
		}
		romveTemporaryDetails();
		if (adapter == null) {
			int[] txtids = null;
			String[] keys = null;

			if (doucmentType == Constants.OPT_TYPE_GWCY_DY) {// 公文传阅：待阅
				// AndroidUI的组件ID
				txtids = new int[]{R.id.list_item_text_field, R.id.list_item_text_field1, R.id.list_item_text_field2};
				// 公文标题、发送者姓名(传阅人)、发送时间（传阅时间）
				keys = new String[]{"DOCUMENT_TITLE", "PROCESS_STAFF_NAME", "SEND_TIME"};
				adapter = new ResultSimpleAdapter(mContext, resultItems,
						R.layout.list_item_gwcy, keys, txtids);
			} else if (doucmentType == Constants.OPT_TYPE_GWCY_YY) {// 公文传阅：已阅
				// AndroidUI的组件ID
				txtids = new int[]{R.id.list_item_text_field,
						R.id.list_item_text_field1, R.id.list_item_text_field2};
				// 公文标题、发送者姓名(传阅人)、阅读时间
				keys = new String[]{"DOCUMENT_TITLE", "PROCESS_STAFF_NAME",
						"READ_TIME"};
				adapter = new ResultSimpleAdapter(mContext, resultItems,
						R.layout.list_item_gwcy, keys, txtids);
			} else if (doucmentType == Constants.OPT_TYPE_GWCY_YC) {// 公文传阅：已传
				// AndroidUI的组件ID
				txtids = new int[]{R.id.list_item_text_field,
						R.id.list_item_text_field2};
				// 公文标题、发送时间（传阅时间）
				keys = new String[]{"DOCUMENT_TITLE", "SEND_TIME"};
				adapter = new ResultSimpleAdapter(mContext, resultItems,
						R.layout.list_item_gwcy_yy, keys, txtids);
			}

			adapter.setHelper(new ISimpleAdapterHelper() {
				@Override
				public Object parseValue(Object currentobj, List<?> items,
						int position, String key, View view) {
					try {
						ResultItem item = resultItems.get(position);
						String systemtime = item.getString("SYSTEM_TIME");// 系统时间

						/**
						 * 有些字段是不能直接显示的，需要经过调整，才能显示。例如：时间
						 */
						if (doucmentType == Constants.OPT_TYPE_GWCY_DY) {// 公文传阅：待阅
							if ("SEND_TIME".equals(key) && currentobj != null) {
								DateUtils dateUtils = new DateUtils(mContext);
								return dateUtils.diffFromToNow(DateUtils
										.parseDate(currentobj.toString()),
										systemtime);
							}
						} else if (doucmentType == Constants.OPT_TYPE_GWCY_YY) {// 公文传阅：已阅
							if ("READ_TIME".equals(key) && currentobj != null) {
								return DateUtils.diffFromToNow(DateUtils
										.parseDate(currentobj.toString()),
										systemtime);
							}
						} else if (doucmentType == Constants.OPT_TYPE_GWCY_YC) {// 公文传阅：已传
							if ("SEND_TIME".equals(key) && currentobj != null) {
								return DateUtils.diffFromToNow(DateUtils
										.parseDate(currentobj.toString()),
										systemtime);
							}
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
					return (currentobj == null || "null".equals(currentobj
							.toString().toLowerCase())) ? "" : currentobj;
				}

				@Override
				public void apply(View convertView, Object obj, int position) {
					ResultItem item = resultItems.get(position);
					String SWF_NO = item.getString("SWF_NO");// 系统流程编号
					// 不同文档类型对应不同图标
					ImageView view = (ImageView) convertView
							.findViewById(R.id.list_item_icon);
					if (SWF_NO != null && view != null) {
						if ("2006090502280735".equals(SWF_NO.trim())) {
							view.setBackgroundResource(R.drawable.system_icon_dbsy_fw);// 发文：绿色图标
						} else if (Constants.LW_CODE.equals(SWF_NO.trim())) {
							view.setBackgroundResource(R.drawable.system_icon_dbsy_lw);// 来文：红色图标
						} else if ("2006122705014455".equals(SWF_NO.trim())) {
							view.setBackgroundResource(R.drawable.system_icon_dbsy_hy);// 会议：蓝色图标
						} else if ("2014072509353877".equals(SWF_NO.trim())) {
							view.setBackgroundResource(R.drawable.system_icon_dbsy_qj);// 请假：橘黄色图标
						}else{
                            //其他未知的都显示来文
                            view.setBackgroundResource(R.drawable.system_icon_dbsy_lw);// 来文：红色图标
                        }
					}
				}
			});
			mListView.setAdapter(adapter);
		} else {
			adapter.notifyDataSetChanged();
		}

		/**
		 * 判断是否已经全部加载完成：如果完成了就关闭“下拉加载更多”功能，否则，继续打开“下拉加载更多”功能
		 */
		if (BeanUtils.isEmpty(items) || items.size() < Constants.COMMON_PAGE_SIZE) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(false);
			// mPullView.getFooterLoadingLayout().show(false);
			
			if(pageIndex==1 && (BeanUtils.isEmpty(items) || items.size()==0)){
				mPullView.setVisibility(View.GONE);
				tvNoDataMsgYichuan.setVisibility(View.VISIBLE);
			}else{
				mPullView.setVisibility(View.VISIBLE);
				tvNoDataMsgYichuan.setVisibility(View.GONE);
			}
			
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			mPullView.onPullDownRefreshComplete();
			mPullView.onPullUpRefreshComplete();
			mPullView.setHasMoreData(true);
		}

	}

	public void loadData(int documentTye, int what, int pageIndex) {
		this.doucmentType = documentTye;
		this.pageIndex = pageIndex;
		
		if (pageIndex == 1) {
			resultItems.clear();// 清除
		}

		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}

		ApiRequest request = null;
		if (doucmentType == Constants.OPT_TYPE_GWCY_DY) {// 公文传阅：待阅
			request = OAServicesHandler.getPassreadList(pageIndex,
					Constants.PASSREAD_STATE_NOTREAD);
		} else if (doucmentType == Constants.OPT_TYPE_GWCY_YY) {// 公文传阅：已阅
			request = OAServicesHandler.getPassreadList(pageIndex,
					Constants.PASSREAD_STATE_READ);
		} else if (doucmentType == Constants.OPT_TYPE_GWCY_YC) {// 公文传阅：已传
			request = OAServicesHandler.getPassreadList(pageIndex,
					Constants.PASSREAD_STATE_SPREAD);
		}

		if (request != null) {
			if (pageIndex == 1) {
				helper.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				helper.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}
	}

	public int getDoucmentType() {
		return doucmentType;
	}

	/**
	 * 点击某个待阅item时，记住这个item索引号，当从详情返回当前界面时，将其从ListView列表中移除
	 */
	public void doRemoveItemById() {
		if (prepareRemoveIndex >= 0) {
			try {
				//1、如果当前界面是待阅界面，将其从ListView列表中移除（因为已阅了）。
				if (doucmentType == Constants.OPT_TYPE_GWCY_DY) {// 公文传阅：待阅
					if(resultItems != null && prepareRemoveIndex < resultItems.size()){
						resultItems.remove(prepareRemoveIndex);
						if (adapter != null) {
							adapter.notifyDataSetChanged();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			DocumentDetailActivity.dealwithFlag = 0;//恢复
			DocumentDetailActivity.retroversionFlag = 0;//恢复
			DocumentDetailActivity.retracementFlag = 0;//恢复
			MeetDetailActivity.dealwithFlag = 0;//恢复
			MeetDetailActivity.retroversionFlag = 0;//恢复
			MeetDetailActivity.retracementFlag = 0;//恢复
			prepareRemoveIndex = -1;//恢复
		}
	}
	
	/**
     * 移除暂时没有详情的数据  
     * <功能详细描述> 2006112706152949  常务会员议题     2006091804282537 不知名
     * @return void [返回类型说明]
     * @exception throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public void romveTemporaryDetails(){
        //
        if(resultItems != null && resultItems.size() > 0){
            for (int i = 0; i < resultItems.size(); i++)
            {
                ResultItem item = resultItems.get(i);
                String SWF_NO = item.getString("SWF_NO");// 系统流程编号
                if ("2006112706152949".equals(SWF_NO.trim())|| "2006091804282537".equals(SWF_NO.trim())) {
                    resultItems.remove(i);
                }
            }
        }
    }

}
