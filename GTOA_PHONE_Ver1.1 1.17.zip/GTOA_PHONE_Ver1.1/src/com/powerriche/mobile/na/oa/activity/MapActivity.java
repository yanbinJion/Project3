package com.powerriche.mobile.na.oa.activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.map.LocationData;
import com.baidu.mapapi.map.MKMapViewListener;
import com.baidu.mapapi.map.MapController;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationOverlay;
import com.baidu.mapapi.search.MKAddrInfo;
import com.baidu.mapapi.search.MKBusLineResult;
import com.baidu.mapapi.search.MKDrivingRouteResult;
import com.baidu.mapapi.search.MKPoiResult;
import com.baidu.mapapi.search.MKSearch;
import com.baidu.mapapi.search.MKSearchListener;
import com.baidu.mapapi.search.MKShareUrlResult;
import com.baidu.mapapi.search.MKSuggestionResult;
import com.baidu.mapapi.search.MKTransitRouteResult;
import com.baidu.mapapi.search.MKWalkingRouteResult;
import com.baidu.platform.comapi.basestruct.GeoPoint;
import com.powerriche.mobile.MyApplication;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.Constants;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.DateUtils;
import com.powerriche.mobile.oa.tools.UIHelper;

public class MapActivity extends BaseActivity implements OnClickListener {
	protected static final int GET_ATTENDANCE_REQ = 0;
	private MapView mapView;
	private TextView tv_sign_in_time,tv_sign_in_location;
	private MyApplication app;
	private MapController mapController;
	private MKMapViewListener mapViewListener;
	private TopActivity topActivity;
	// 定位相关
	private LocationClient locationClient;
	private MyLocationListener listener = new MyLocationListener();
	private MKSearch mkSearch;
	private LocationData locationData;
	private GeoPoint geoPoint;
	private MyLocationOverlay locationOverlay;
	private String signState;
	private String signType;
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			mkSearch.reverseGeocode(geoPoint);
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		signState = getIntent().getExtras().getString("sign_state");
		signType = getIntent().getExtras().getString("sign_type");
		findViews();
		setApplication();
		initMapView();
		getListener();
		setListener();
		getMapClient();
	}
	
	
	// 考勤签到或签退
	private void signAttendance(String signState, String signType) {
		ApiRequest request = OAServicesHandler.signAttendance(address, signState, signType);
		helper.invokeWidthDialog(request, callBack, GET_ATTENDANCE_REQ);
	}
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItem = response.getResultItem(ResultItem.class);
			if (BeanUtils.isEmpty(resultItem)) {
				return;
			}
			String code = resultItem.getString("code");
			String message = resultItem.getString("message");
			if (!Constants.SUCCESS_CODE.equals(code)) {
				UIHelper.showMessage(MapActivity.this, message);
				return;
			}
			if(what == GET_ATTENDANCE_REQ) {
				UIHelper.showMessage(MapActivity.this, message);
				MapActivity.this.finish();
			}
		}

		@Override
		protected void showErrorMessage(String message) {
			UIHelper.showMessage(MapActivity.this, message);
		}

		@Override
		public void onReturnError(HttpResponse response, ResultItem error,
				int what) {
			showErrorMessage(getString(R.string.system_data_error_message));
		}

		@Override
		public void onNetError(int what) {
			showErrorMessage(getString(R.string.system_net_error_message));
		}
	};

	private void initMapView() {
		mapController = mapView.getController();
		locationClient = new LocationClient(this);
		locationClient.registerLocationListener(listener);
		LocationClientOption option = new LocationClientOption();
		option.setOpenGps(true);// 打开gps
		option.setAddrType("all");// 返回的定位结果包含地址信息
		option.setCoorType("bd09ll");// 返回的定位结果是百度经纬度,默认值gcj02 可以无偏差的显示在百度地图上
		option.setScanSpan(5000);// 设置发起定位请求的间隔时间为5000ms
		option.disableCache(true);// 禁止启用缓存定位
		option.setPoiNumber(5); // 最多返回POI个数
		option.setPoiDistance(1000); // poi查询距离
		option.setPriority(LocationClientOption.GpsFirst);// gps优先
		option.setPoiExtraInfo(true); // 是否需要POI的电话和地址等详细信息
		locationClient.setLocOption(option);
		locationClient.start();
		mapView.getController().setZoom(15);
		mapView.getController().enableClick(true);
		mapView.setBuiltInZoomControls(true);

		GeoPoint centerpt = mapView.getMapCenter();
		int maxLevel = mapView.getMaxZoomLevel();
		float zoomlevel = mapView.getZoomLevel();
		boolean isTraffic = mapView.isTraffic();
		boolean isSatillite = mapView.isSatellite();
		boolean isDoubleClick = mapView.isDoubleClickZooming();
		mapView.setLongClickable(true);

		// 初始化
		mkSearch = new MKSearch();
		mkSearch.init(app.bMapManager, new MyMKSearchListener());
	}

	private String address;
	
	private class MyMKSearchListener implements MKSearchListener {

		

		@Override
		public void onGetAddrResult(MKAddrInfo res, int error) {
			// 获取地理位置信息
			if (error != 0) {
				String str = String.format("错误号：%d", error);
				return;
			}
			
			String posInfo = String.format("纬度：%f 经度：%f 地址：%s\r\n",
					res.geoPt.getLatitudeE6() / 1e6,
					res.geoPt.getLongitudeE6() / 1e6,
					res.addressComponents.city + res.addressComponents.district
							+ res.addressComponents.street);
			// 将地址信息、兴趣点信息显示在TextView上   
			if(DateUtils.getDateStr().length() > 0) {
				tv_sign_in_time.setText(DateUtils.getDateTimeStr().substring(0, 16));
			}
			address = res.strAddr;
            tv_sign_in_location.setText(address);
			Toast.makeText(MapActivity.this, posInfo, Toast.LENGTH_SHORT).show();
		}

		@Override
		public void onGetBusDetailResult(MKBusLineResult arg0, int arg1) {

		}

		@Override
		public void onGetDrivingRouteResult(MKDrivingRouteResult arg0, int arg1) {

		}

		@Override
		public void onGetPoiDetailSearchResult(int arg0, int arg1) {

		}

		@Override
		public void onGetPoiResult(MKPoiResult arg0, int arg1, int arg2) {

		}

		@Override
		public void onGetSuggestionResult(MKSuggestionResult arg0, int arg1) {

		}

		@Override
		public void onGetTransitRouteResult(MKTransitRouteResult arg0, int arg1) {

		}

		@Override
		public void onGetWalkingRouteResult(MKWalkingRouteResult arg0, int arg1) {

		}

		@Override
		public void onGetShareUrlResult(MKShareUrlResult arg0, int arg1,
				int arg2) {
			
		}

	}
	
	private void getMapClient() {
		locationOverlay = new MyLocationOverlay(mapView);
		locationData = new LocationData();
		locationOverlay.setData(locationData);
		mapView.getOverlays().add(locationOverlay);
		locationOverlay.enableCompass();
		mapView.refresh();
	}

	private void findViews() {
		// 设置顶部的标题栏
		topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		topActivity.setTopTitle(getString(R.string.attendance_detail));// 顶部栏的中间标题
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnStyle(getString(R.string.attendance_save));
		topActivity.setRightBtnOnClickListener(this);
		mapView = (MapView) findViewById(R.id.mapView);
		tv_sign_in_time = (TextView) findViewById(R.id.tv_sign_in_time);
		tv_sign_in_location = (TextView) findViewById(R.id.tv_sign_in_location);
	}

	/*
	 * 设置监听
	 */
	private void setListener() {
		mapView.regMapViewListener(MyApplication.getInstance().bMapManager,
				mapViewListener);
	}

	private void getListener() {
		mapViewListener = new MKMapViewListener() {

			@Override
			public void onMapMoveFinish() {

			}

			@Override
			public void onMapAnimationFinish() {

			}

			@Override
			public void onGetCurrentMap(Bitmap bitmap) {

			}

			@Override
			public void onClickMapPoi(MapPoi mapPoiInfo) {
				String title = "";
				if (mapPoiInfo != null) {
					title = mapPoiInfo.strText;
					Toast.makeText(MapActivity.this, title, Toast.LENGTH_SHORT)
							.show();
				}
			}

			@Override
			public void onMapLoadFinish() {
				
			}

		};
	}

	private void setApplication() {
		app = (MyApplication) getApplication();
		if (app.bMapManager == null) {
			app.bMapManager = new BMapManager(this);
			app.bMapManager.init(new MyApplication.MyMKGeneralListener());
		}
	}

	/**
	 * 监听函数，又新位置的时候，格式化成字符串，输出到屏幕中
	 */
	private class MyLocationListener implements BDLocationListener {

		@Override
		public void onReceiveLocation(BDLocation location) {
			if (location == null) {
				return;
			}
			locationData.latitude = location.getLatitude();
			locationData.longitude = location.getLongitude();
			locationData.accuracy = location.getRadius();
			locationData.direction = location.getDerect();
			locationOverlay.setData(locationData);
			mapView.refresh();
			geoPoint = new GeoPoint((int) (locationData.latitude * 1e6), (int) (locationData.longitude * 1e6));
			mapController.animateTo(geoPoint, handler.obtainMessage(1));
//			mapView.getController().animateTo(geoPoint ,handler.obtainMessage(1));
		}

		@Override
		public void onReceivePoi(BDLocation poiLocation) {
			if (poiLocation == null) {
				return;
			}
		}
		

	}

	@Override
	protected void onPause() {
		super.onPause();
		mapView.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		mapView.onResume();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		mapView.destroy();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		mapView.onSaveInstanceState(outState);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		mapView.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			MapActivity.this.finish();
			break;
		case R.id.btn_top_right:
			if (signType.equals("0")) {
				if (signState.equals("1")) {
					signAttendance("1", signType);
				} else if (signState.equals("-1")) {
					signAttendance("-1", signType);
				}
			} else {
				if (signState.equals("1")) {
					signAttendance("1", signType);
				} else if (signState.equals("-1")) {
					signAttendance("-1", signType);
				}
			}
			
			break;
		default:
			break;
		}
	}

}
