package com.powerriche.mobile.na.oa.bean;

import java.io.Serializable;

/**
 * 类描述：<br> 
 * 公文附件
 * @author  Fitz
 * @date    2015年4月29日
 * @version v1.0
 */
public class DocFileInfo implements Serializable{

	public DocFileInfo(){}
	
	public DocFileInfo(String code, String type, String name, int fileCataLog, long fileSize){
		this.fileCode = code;
		this.fileType = type;
		this.fileName = name;
		this.fileCataLog = fileCataLog;
		this.fileSize = fileSize;
		
	}
	
	String fileCode;
	String fileType;
	String fileName;
	String fileTitle;
	int fileCataLog;	//【0:正文】 【1：附件】
	String filePath;
	
	boolean isFileLocal;	//判断本地文件上传后打开状态判断
	String fileLocalPath;	//本地文件路径
	
	long fileSize;
	
	long compeleteSize;	//下载进度的大小
	
	public String getFileCode() {
		return fileCode;
	}
	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public String getFileTitle() {
		return fileTitle;
	}
	public void setFileTitle(String fileTitle) {
		this.fileTitle = fileTitle;
	}
	public int getFileCataLog() {
		return fileCataLog;
	}
	public void setFileCataLog(int fileCataLog) {
		this.fileCataLog = fileCataLog;
	}
	public long getCompeleteSize() {
		return compeleteSize;
	}
	public void setCompeleteSize(long compeleteSize) {
		this.compeleteSize = compeleteSize;
	}
	public boolean isFileLocal() {
		return isFileLocal;
	}
	public void setFileLocal(boolean isFileLocal) {
		this.isFileLocal = isFileLocal;
	}
	public String getFileLocalPath() {
		return fileLocalPath;
	}
	public void setFileLocalPath(String fileLocalPath) {
		this.fileLocalPath = fileLocalPath;
	}
}
