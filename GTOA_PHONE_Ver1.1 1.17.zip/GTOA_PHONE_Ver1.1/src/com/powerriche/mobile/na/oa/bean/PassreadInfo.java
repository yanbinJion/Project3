package com.powerriche.mobile.na.oa.bean;

/**
 * 类描述：<br> 
 * 传阅信息
 * @author  Fitz
 * @date    2015年5月13日
 * @version v1.0
 */
public class PassreadInfo {

	public PassreadInfo(){} 

	public PassreadInfo(String name, String department, String datetime, String remark, String status){
		this.name = name;
		this.department = department;
		this.datetime = datetime;
		this.remark = remark;
		this.status = status;
	} 
	
	String name;
	String department;
	String datetime;
	String remark;
	String status;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
