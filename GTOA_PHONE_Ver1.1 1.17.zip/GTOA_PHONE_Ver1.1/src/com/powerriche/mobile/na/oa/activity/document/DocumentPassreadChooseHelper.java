package com.powerriche.mobile.na.oa.activity.document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.activity.DocumentPassreadChooseActivity;
import com.powerriche.mobile.na.oa.activity.adapter.DocumentPassreadChooseAdapter;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DepartmentInfo;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.BeanUtils;

/**
 * 类描述：<br> 
 * 传阅选人接口
 * @author  Fitz
 * @date    2015年5月13日
 * @version v1.0
 */
public class DocumentPassreadChooseHelper {

	private Context	context;
	private DocumentPassreadChooseActivity	activity;
	private InvokeHelper helper	= null;
	private IRequestCallBack callBack = null;

	private DocumentPassreadChooseAdapter adapter = null;
	private ExpandableListView	exUserList;
	private TextView tvPeople;

	public DocumentPassreadChooseHelper(Context context, IRequestCallBack callBack, ExpandableListView exUserList, TextView tvPeople) {
		this.context = context;
		this.activity = (DocumentPassreadChooseActivity) context;
		this.callBack = callBack;
		this.exUserList = exUserList;
		this.helper = activity.getInvokeHelper();
		this.tvPeople = tvPeople;
	}

	public void loadData() {
		ApiRequest request = OAServicesHandler.getSiteStaffTreeList();
		if (request != null) {
			helper.invokeWidthDialog(request, callBack);
		}
	}

	public void process(HttpResponse response) {
		List<ResultItem> items = response.getResultItem(ResultItem.class).getItems("data");
		if (!BeanUtils.isEmpty(items)) {
			adapter = new DocumentPassreadChooseAdapter(context, tvPeople);
			exUserList.setAdapter(adapter);

			Map<String, List<?>> map = getContactBeanList(items);

			@SuppressWarnings("unchecked")
			List<DepartmentInfo> departmentList = (List<DepartmentInfo>) map.get("groups");
			@SuppressWarnings("unchecked")
			List<List<UserInfo>> userList = (List<List<UserInfo>>) map.get("users");

			adapter.addData(departmentList, userList);
			adapter.notifyDataSetChanged();
		}
	}

	/**
	 * 获取选中的值
	 * @return
	 */
	public List<UserInfo> getValueList() {
		if (adapter != null) {
			return adapter.getValueList();
		}
		return null;
	}


	/**
	 * 解析数据
	 * @param resultItems
	 * @return
	 */
	private Map<String, List<?>> getContactBeanList(List<ResultItem> resultItems) {

		Map<String, List<?>> map = new HashMap<String, List<?>>();

		List<DepartmentInfo> departmentList = new ArrayList<DepartmentInfo>();
		List<List<UserInfo>> userList = new ArrayList<List<UserInfo>>();

		List<UserInfo> dataList = new ArrayList<UserInfo>();
		for (int i = 0; i < resultItems.size(); i++) {
			ResultItem item = resultItems.get(i);

			String siteNo = item.getString("SITE_NO"); //部门编号
			String siteName = item.getString("SITE_NAME"); //部门名称
			int siteStatus = 0;//部门下的员工选中状态：0全部未选中，1全部选中，2部分选中
			int siteStaffSize = 0;
			int siteStaffSizeSelected = 0;

			//部门下的人员数组
			List<ResultItem> childItems = item.getItems("STAFF");
			if (!BeanUtils.isEmpty(childItems)) {
				siteStaffSize = childItems.size();
				for (int j = 0; j < childItems.size(); j++) {
					ResultItem childItem = childItems.get(j);

					String staffNo = childItem.getString("STAFF_NO"); //人员编号
					String realName = childItem.getString("STAFF_NAME"); //人员名称
					String mobile = childItem.getString("MOBILE");	//手机

					UserInfo userInfo = new UserInfo(staffNo, realName, mobile);
					userInfo.setSiteNo(siteNo);
					userInfo.setSiteName(siteName);
					dataList.add(userInfo);
				}
			}

			if (siteStaffSizeSelected > 0) {
				siteStatus = (siteStaffSize == siteStaffSizeSelected) ? 1 : 2;
			}

			DepartmentInfo department = new DepartmentInfo(siteNo, siteName, siteStatus);
			departmentList.add(department);
		}

		//把子项添加到组中，按索引
		for (DepartmentInfo group : departmentList) {
			List<UserInfo> tempList = new ArrayList<UserInfo>();
			for (UserInfo user : dataList) {
				if (group.getSiteNo().equals(user.getSiteNo())) {
					tempList.add(user);
				}
			}
			userList.add(tempList);
		}

		map.put("groups", departmentList);
		map.put("users", userList);

		return map;
	}
	
	
	public void selectAll(boolean isSelectAll){
		List<List<UserInfo>> typeList = adapter.getTypeList();
		StringBuffer sb = new StringBuffer();
		if(isSelectAll){	//全选
			for(int i=0;i<typeList.size();i++){
				List<UserInfo> valueList = typeList.get(i);	//获取到需要设置选中的list
				int length = valueList.size();
				for(int j=0; j<length; j++){
					typeList.get(i).get(j).setStatus(1);
					sb.append(typeList.get(i).get(j).getRealName()).append("、");
				}
				adapter.setValueList(valueList);	//把选中的list添加到全选值中
			}
			
		}else{	//取消全选
			sb = new StringBuffer("");
			for(int i=0;i<typeList.size();i++){
				int length = typeList.get(i).size();
				for(int j=0; j<length; j++){
					typeList.get(i).get(j).setStatus(0);
				}
			}
			adapter.clearValueList();	//清空之前全选的值
		}
		adapter.notifyDataSetChanged();
		adapter.setTextStyle(this.tvPeople, sb.toString());
	}
	
}
