package com.powerriche.mobile.na.oa.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.BaseActivity;
import com.powerriche.mobile.na.oa.activity.base.BaseRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.ChoosePeopleHelper;
import com.powerriche.mobile.na.oa.bean.UserInfo;
import com.powerriche.mobile.na.oa.view.TopActivity;
import com.powerriche.mobile.oa.common.ResultItem;
import com.powerriche.mobile.oa.network.http.HttpResponse;
import com.powerriche.mobile.oa.tools.*;

/**
 * 类描述：<br>
 * 选择代理人
 * 
 * @author Fitz
 * @date 2015年4月22日
 * @version v1.0
 */
public class ChoosePeopleActivity extends BaseActivity
		implements
			OnClickListener,
			ExpandableListView.OnChildClickListener,
			ExpandableListView.OnGroupClickListener {

	private static final String TAG = "ChoosePeopleActivity";

	public static String KEY_CUSTOM_TITLE = "KEY_CUSTOM_TITLE"; // 初始化界面时，自定义的界面标题。传参类型：string
	public static String KEY_IS_MULTIPLE_SELECT = "KEY_IS_MULTIPLE_SELECT"; // 初始化界面时，是否可以人员多选。传参类型：boolean
	public static String KEY_USER_IDS_INIT = "KEY_USER_IDS_INIT"; // 初始化界面时，默认选中的人员ID。传参类型：ArrayList<String>
	// public static String KEY_DEPARTMENT_IDS_INIT =
	// "KEY_DEPARTMENT_IDS_INIT";//初始化界面时，默认选中的部门ID。传参类型：ArrayList<String>
	public static String KEY_USER_NAMES = "KEY_USER_NAMES"; // 退出界面时，返回所有选中的人员姓名。返回类型：ArrayList<String>
	public static String KEY_USER_NAMES_STRING = "KEY_USER_NAMES_STRING"; // 退出界面时，返回所有选中的人员姓名。返回类型：String
	public static String KEY_USER_IDS = "KEY_USER_IDS"; // 退出界面时，返回所有选中的人员ID。返回类型：ArrayList<String>
	public static String KEY_USER_IDS_STRING = "KEY_USER_IDS_STRING"; // 退出界面时，返回所有选中的人员ID。返回类型：String

	public static String KEY_USER_SITENAMES = "KEY_USER_SITENAMES"; // 退出界面时，返回所有选中的人员部门id。返回类型：ArrayList<String>

	public static String KEY_USER_MOBILES = "KEY_USER_MOBILES"; // 退出界面时，返回所有选中的人员手机。返回类型：ArrayList<String>

	private Context mContext;

	private ExpandableListView exListChoose;
	private ChoosePeopleHelper chooseHelper;

	public String customTitle = null; // 初始化界面时，自定义的界面标题
	public boolean isMultipleSelect = false; // 初始化界面时，是否可以人员多选
	public ArrayList<String> userIds4Init = null; // 初始化界面时，默认选中的人员ID

	// public ArrayList<String> departmentIds4Init = null; //初始化界面时，默认选中的部门ID

	public TextView tvSelectedPeople = null;// 初始化界面时，默认选中的人员姓名，以符号、分隔
	public Button btnSelectAll = null;// 当可以多选时，显示“全选”按钮
    private ContactDbhelper contactDbHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//设置横竖屏幕
		BeanUtils.setPortraitAndLandscape(this);
		this.mContext = this;
		UIHelper.hideTitle(this);
		setContentView(R.layout.common_choose_people);

		customTitle = getIntent().getStringExtra(KEY_CUSTOM_TITLE);
		isMultipleSelect = getIntent().getBooleanExtra(KEY_IS_MULTIPLE_SELECT,
				false);
		userIds4Init = getIntent().getStringArrayListExtra(KEY_USER_IDS_INIT);
        contactDbHelper = new ContactDbhelper(this);

		bindView();
		loading();
	}

	private void bindView() {
		TopActivity topActivity = (TopActivity) findViewById(R.id.top_activity);
		topActivity.setBtnBackOnClickListener(this);
		if (BeanUtils.isEmpty(customTitle)) {
			topActivity.setTopTitle(getString(R.string.choose_people_title));// 默认标题
		} else {
			topActivity.setTopTitle(customTitle);// 自定义标题
		}
		topActivity.setRightBtnVisibility(View.VISIBLE);
		topActivity.setRightBtnOnClickListener(this);
		topActivity.setRightBtnStyle("确认");

		exListChoose = (ExpandableListView) findViewById(R.id.exList_choose);
		exListChoose.setGroupIndicator(null);// 去掉圆形三角箭头
		exListChoose.setDivider(null);
		exListChoose.setCacheColorHint(Color.TRANSPARENT);
		exListChoose.setFadingEdgeLength(0);
		exListChoose.setOnChildClickListener(this);
		exListChoose.setOnGroupClickListener(this);

		// 添加“全选”功能
		if (isMultipleSelect) {// 可以多选
			View header = LayoutInflater.from(mContext).inflate(
					R.layout.common_choose_people_header, null);
			tvSelectedPeople = (TextView) header
					.findViewById(R.id.tv_selected_people);
			btnSelectAll = (Button) header.findViewById(R.id.btn_all_select);
			btnSelectAll.setOnClickListener(this);

			header.setVisibility(View.VISIBLE);
			tvSelectedPeople.setVisibility(View.GONE);
			btnSelectAll.setVisibility(View.VISIBLE);

			exListChoose.addHeaderView(header);
		}

		chooseHelper = new ChoosePeopleHelper(mContext, callBack, exListChoose, contactDbHelper);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
			case R.id.system_back : // 系统返回
				finish();
				break;

			case R.id.btn_top_right : // 提交数据
				returnResult();
				break;
			case R.id.btn_all_select : // 全选操作
				if (btnSelectAll != null) {
					if (btnSelectAll.isSelected()) {
						btnSelectAll.setSelected(false);// 取消全选
						chooseHelper.adapter.selectAll(false);
					} else {
						btnSelectAll.setSelected(true);// 全选
						chooseHelper.adapter.selectAll(true);
					}
				}
				break;
		}
	}

	private void loading() {
        List<ResultItem> contacts = contactDbHelper.getContactResult();
        if (!BeanUtils.isEmpty(contacts)) {
            Logger.d(TAG, "loading contact from local");
            chooseHelper.process(contacts, 0, isMultipleSelect);
        } else {
            Logger.d(TAG, "loading contact from sever");
		    chooseHelper.loadData();
        }
	}

	public InvokeHelper getInvokeHelper() {
		return helper;
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (what == 0) {
					chooseHelper.process(response, what, isMultipleSelect);
				}
			}
		}
	};

	private void returnResult() {
		List<UserInfo> selectedList = chooseHelper.getValueListSelected();
		Intent intent = new Intent();

		if (selectedList == null || selectedList.isEmpty()) {// 一个都没有选中
			UIHelper.showMessage(mContext, "请至少选择一个人");
			return;
		} else {
			if (!isMultipleSelect) { // 单选封值
				String userId = "";
				String userName = "";
				for (int i = 0; i < selectedList.size(); i++) {
					if (BeanUtils.isEmpty(selectedList.get(i))) {
						continue;
					}
					UserInfo user = selectedList.get(i);
					if (user == null) {
						continue;
					}
					userId = user.getStaffNo();
					userName = user.getRealName();
					break;
				}

				intent.putExtra("staffNo", (userId == null ? "" : userId));// 获取人员的ID
				intent.putExtra("name", (userName == null ? "" : userName));// 获取人员的姓名
				intent.putExtra(KEY_USER_IDS_STRING, (userId == null
						? ""
						: userId));
				intent.putExtra(KEY_USER_NAMES_STRING, (userName == null
						? ""
						: userName));

			} else { // 多选封值
				ArrayList<String> ids = new ArrayList<String>();
				ArrayList<String> names = new ArrayList<String>();
				ArrayList<String> siteNames = new ArrayList<String>();
				ArrayList<String> userMobiles = new ArrayList<String>();
				StringBuffer sbId = new StringBuffer();
				StringBuffer sbName = new StringBuffer();

				for (int i = 0; i < selectedList.size(); i++) {
					if (BeanUtils.isEmpty(selectedList.get(i))) {
						continue;
					}
					UserInfo user = selectedList.get(i);
					if (user == null) {
						continue;
					}
					String userId = user.getStaffNo();
					String userName = user.getRealName();
					if (userId == null || "".equals(userId.trim())
							|| userName == null || "".equals(userName.trim())) {
						continue;// 跳过：姓名的个数和ID的个数必须是一致的
					}
					ids.add(userId);// 获取人员的ID
					names.add(userName);// 获取人员的姓名
					siteNames.add(user.getSiteName());
					if (BeanUtils.isEmpty(user.getMobile())) { // 此处会有空值出现
						user.setMobile("");
					}
					userMobiles.add(user.getMobile());
					sbId.append(userId.trim()).append(",");
					sbName.append(userName.trim()).append(",");
				}

				intent.putStringArrayListExtra(KEY_USER_IDS, ids);
				intent.putStringArrayListExtra(KEY_USER_NAMES, names);
				intent.putStringArrayListExtra(KEY_USER_SITENAMES, siteNames);
				intent.putStringArrayListExtra(KEY_USER_MOBILES, userMobiles);
				if (!sbId.toString().isEmpty()) {
					intent.putExtra(KEY_USER_IDS_STRING, sbId.toString()
							.substring(0, sbId.length() - 1));
					intent.putExtra(KEY_USER_NAMES_STRING, sbName.toString()
							.substring(0, sbName.length() - 1));
				} else {
					intent.putExtra(KEY_USER_IDS_STRING, "");
					intent.putExtra(KEY_USER_NAMES_STRING, "");
				}

			}
		}

		setResult(Activity.RESULT_OK, intent);
		finish();
	}

	@Override
	public boolean onGroupClick(ExpandableListView parent, View v,
			int groupPosition, long id) {
		if (parent.isGroupExpanded(groupPosition)) {
			parent.collapseGroup(groupPosition);// 折叠：部门
		} else {
			parent.expandGroup(groupPosition);// 展开：部门
		}
		return true;
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v,
			int groupPosition, int childPosition, long id) {
		return true;
	}

}
