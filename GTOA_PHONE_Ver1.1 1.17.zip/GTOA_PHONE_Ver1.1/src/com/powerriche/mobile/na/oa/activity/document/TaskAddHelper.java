package com.powerriche.mobile.na.oa.activity.document;

import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.powerriche.mobile.na.oa.R;
import com.powerriche.mobile.na.oa.activity.base.IRequestCallBack;
import com.powerriche.mobile.na.oa.activity.base.InvokeHelper;
import com.powerriche.mobile.na.oa.activity.document.services.OAServicesHandler;
import com.powerriche.mobile.na.oa.bean.DocFileInfo;
import com.powerriche.mobile.na.oa.bean.TaskDetails;
import com.powerriche.mobile.na.oa.bean.TaskInfo;
import com.powerriche.mobile.na.oa.bean.UploadParams;
import com.powerriche.mobile.oa.api.ApiRequest;
import com.powerriche.mobile.oa.tools.BeanUtils;
import com.powerriche.mobile.oa.tools.HttpMultipartPost;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 新增任务管理帮助类
 * Created by root on 16-5-9.
 */
public class TaskAddHelper {

    private Context mContext;
    private IRequestCallBack callBack = null;
    private InvokeHelper helper = null;

    public TaskAddHelper(Context context, IRequestCallBack callBack, InvokeHelper helper) {
        this.mContext = context;
        this.helper = helper;
        this.callBack = callBack;
    }

    public void onCommit(TaskInfo task, int what) {
        ApiRequest apiRequest = OAServicesHandler.getAddTask(task);
        if (apiRequest != null){
            apiRequest.setMessage(mContext.getString(R.string.system_commit_message));
            helper.invokeWidthDialog(apiRequest, callBack, what);
        }
    }

    /** 附件上传 */
    public void uploadFile(String documentId, String swfNo, LinearLayout llFileWrap, Handler handler, int what, ArrayList<DocFileInfo> fileList){
        if(llFileWrap!=null){
            int fileCount = llFileWrap.getChildCount();
            if(fileCount>0){
                List<File> files = new ArrayList<File>();
                for(int i=0; i<fileCount; i++){
                    View view = llFileWrap.getChildAt(i);
                    TextView tv = (TextView) view.findViewById(R.id.tv_file_name);
                    String path = (String) tv.getTag();

                    File file = new File(path);
                    if(file!=null && file.exists()){
                        if (!BeanUtils.isEmpty(fileList)) {
                            for (DocFileInfo temp : fileList) {
                                if (tv.getText().toString().trim().equals(temp.getFileName())) {
                                    continue;
                                }
                            }
                        }
                        files.add(file);
                    }
                }

                UploadParams params = new UploadParams(mContext.getString(R.string.system_servics_url), "uploadFile", documentId, swfNo, "", what);
                params.setListFile(files);
                HttpMultipartPost post = new HttpMultipartPost(mContext, handler);
                post.execute(params);
            }
        }
    }

}
