package com.powerriche.mobile.na.oa.activity.adapter;

import android.util.SparseArray;
import android.view.View;

/**
 * @title  通用ViewHolder类
 * @author dir_wang
 * @date   2016-7-25上午11:00:11
 */
public class BaseViewHolder {
	@SuppressWarnings("unchecked")
	public static <T extends View> T get(View view, int id) {

        SparseArray<View> viewHolder = (SparseArray<View>) view.getTag();
        if (viewHolder == null) {
            viewHolder = new SparseArray<View>();
            view.setTag(viewHolder);
        }
        View childView = viewHolder.get(id);
        if (childView == null) {
            childView = view.findViewById(id);
            viewHolder.put(id, childView);
        }
        return (T) childView;
	}
}
