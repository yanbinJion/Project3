package com.powerriche.mobile;

import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.MKGeneralListener;
import com.baidu.mapapi.map.MKEvent;
import com.powerriche.mobile.na.oa.R;

import android.app.Application;
import android.content.Context;
import android.widget.Toast;

public class MyApplication extends Application {
	
	private static MyApplication mInstance = null;
	public boolean m_bKeyRight = true;
//	public static final String strKey = "MQ8y9HbzmLR9gAKmE1ZxYUDPEDdYwu4W";
//	public static final String strKey = "0i1zwahufyVs8BiV2tdUnreKFyuY5aSM";
	// 发布版本环境下的key
//	public static final String strKey = "KweklBD3PGfRP3HA3m7WlpplALVFTKEC";
	// eclipse环境下的key
	public static final String strKey = "pCXeNATl5GS7a6WhMrVxXcA8bj9vt7To";
	public BMapManager bMapManager;
	@Override
	public void onCreate() {
		super.onCreate();
		Thread.setDefaultUncaughtExceptionHandler(MyExceptionHandler.getInstance(getApplicationContext()));
		mInstance = this;
		initEngineManager(this);
	}
	
	@Override
	public void onTerminate() {
		super.onTerminate();
		if(bMapManager != null) {
			bMapManager.destroy();
			bMapManager = null;
		}
	}
	
	private void initEngineManager(Context context) {
		if(bMapManager == null) {
			bMapManager = new BMapManager(context);
		}
		if(!bMapManager.init(new MyMKGeneralListener())) {
			Toast.makeText(MyApplication.mInstance.getApplicationContext(), context.getString(R.string.myApplication_toast_1),Toast.LENGTH_LONG).show();
		}
	}
	
	public static MyApplication getInstance() {
		return mInstance;
	}
	
	// 常用事件监听，用来处理通常的网络错误，授权验证错误等
	public static class MyMKGeneralListener implements MKGeneralListener {

		@Override
		public void onGetNetworkState(int iError) {
			if(iError == MKEvent.ERROR_NETWORK_CONNECT) {
				Toast.makeText(MyApplication.mInstance.getApplicationContext(),MyApplication.mInstance.getApplicationContext().getString(R.string.myApplication_toast_2), Toast.LENGTH_LONG).show();
			} else if(iError == MKEvent.ERROR_NETWORK_DATA) {
				Toast.makeText(MyApplication.mInstance.getApplicationContext(), MyApplication.mInstance.getApplicationContext().getString(R.string.myApplication_toast_3), Toast.LENGTH_LONG).show();
			}
		}

		@Override
        public void onGetPermissionState(int iError) {
        	//非零值表示key验证未通过
            if (iError != 0) {
                //授权Key错误：
                Toast.makeText(MyApplication.mInstance.getApplicationContext(), 
                		MyApplication.mInstance.getApplicationContext().getString(R.string.myApplication_toast_4)+iError, Toast.LENGTH_LONG).show();
                MyApplication.mInstance.m_bKeyRight = false;
            }
            else{
            	MyApplication.mInstance.m_bKeyRight = true;
            	Toast.makeText(MyApplication.mInstance.getApplicationContext(), 
            			MyApplication.mInstance.getApplicationContext().getString(R.string.myApplication_toast_5), Toast.LENGTH_LONG).show();
            }
        }
		
	}
}
