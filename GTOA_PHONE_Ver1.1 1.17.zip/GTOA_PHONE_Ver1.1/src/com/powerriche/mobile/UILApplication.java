package com.powerriche.mobile;

import android.app.Application;

/**
 * 类描述：<br>
 * 初始化程序 
 * @author  Fitz
 * @date    2014-08-14
 */
public class UILApplication extends Application {
	
	public static UILApplication mInstance;
	@Override
	public void onCreate() {
		super.onCreate();
		mInstance = this;
		Thread.setDefaultUncaughtExceptionHandler(MyExceptionHandler.getInstance(getApplicationContext()));
		
		//JPushInterface.setDebugMode(true);	// 设置开启日志,发布时请关闭日志
		//JPushInterface.init(this);			// 初始化 JPush
	}
	
	public static UILApplication getIntance() {
		return mInstance;
	}

}