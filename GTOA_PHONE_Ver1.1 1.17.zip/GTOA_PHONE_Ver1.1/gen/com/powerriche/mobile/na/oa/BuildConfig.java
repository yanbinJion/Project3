/** Automatically generated file. DO NOT MODIFY */
package com.powerriche.mobile.na.oa;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}